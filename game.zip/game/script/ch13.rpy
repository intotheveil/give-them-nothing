## Chapter Thirteen — Every Road (finale) + label ending (epilogue, credits)
## Source: docs/manuscript/ch13.txt (Samuel POV). Samuel's sprite is never shown.
## The attack is rendered in narration only, on black / red vignette. No image of the child.

label ch13:
    call chapter_card(13, "The valley floor — that night")

    scene bg valley_station_night with fade_slow
    show vignette
    play music m_ritual3 if_changed fadein 3.0
    play ambient sfx_wind fadein 3.0
    call place("A gas station at the bottom of the valley")

    "The station was nearly empty, the way such places are at that hour."
    "One bored attendant behind the glass of the shop with a phone held close to his face. The forecourt bright and vacant under its cold canopy. No other car for as far as the dark went in either direction."
    "Samuel pulled up at the outermost pump, farthest from the light, out of an old habit he did not examine, and cut the engine."
    show alice neutral at right with dissolve
    "For a moment the two of them sat in the sudden silence, with the tick of the cooling engine between them and the hard white light coming in the windows."
    s tired "I need the fuel. And then it's an hour, and you're there, and this is over."
    stop music fadeout 4.0
    a "Can I use the toilet?"
    "Alice had her hand on the door already, her small bag on her shoulder. A child's voice, ordinary, a little embarrassed the way children are about their bodies."
    a "Before we go the last part. I won't be long."

    menu (screen="read_choice", subject="her"):
        "Her voice.":
            $ read_miss("r13_bag")
            call tell_missed("t13_bag")
        "The bag.":
            $ read_hit("r13_bag")
            "The bag. For a toilet. Everything she owned, and the coin, and whatever else."
            th "A child alone takes all of it with her. Every time."
        "Her hand on the door.":
            $ read_miss("r13_bag")
            call tell_missed("t13_bag")
    "There it was: the ordinary human request that a man cannot refuse a twelve-year-old at a gas station in the dark without becoming, in that instant, a monster himself."
    "He knew everything and could prove nothing. He had spent four hours feeling his certainty drown, and had dragged it, gasping, back up onto dry land in the last cold mile."
    "And he felt the whole impossible shape of his situation close over him like water."

    menu:
        "Let her go.":
            $ chose("m13_door", "letgo")
            "He could not stop her. On what grounds."
            "He could not say {i}I know what you are, so you'll hold it.{/i} He could not cuff a grieving orphan to the door handle of his car, on a suspicion no soul on earth would credit."
        "Search her bag first.":
            $ chose("m13_door", "search", refused_try=True)
            "His eyes went to the canvas holdall on her shoulder. He had not searched her, not once in four hours. Not the bag that held everything the world had left her, nor the small body it hung from."
            "His hand began to move, and stopped."
            "To run his hands over a grieving child like a suspect was a thing he could no more make himself do than strike her. The very wanting-to was its own kind of filth."
        "Tell her to hold it.":
            $ chose("m13_door", "hold", refused_try=True)
            "The words were there. {i}You'll hold it.{/i} Three words."
            "And behind them, the rest of the sentence he would have to say if she asked why. {i}Because I know what you are.{/i}"
            "He could not say it. A grieving orphan, a child in his protective care, on a suspicion no soul on earth would credit."

    "He could not draw the weapon under his coat on a twelve-year-old walking to a toilet, and know himself a man afterward."
    "Every door his training reached for had a child standing in it, and his hand stopped at every one."
    "That was the trap, and it had never been a trap of her building. It was the trap of his own decency, the last unspoiled thing in him."
    "She had read it in him weeks ago across a notebook, and had counted, all the way down the mountain, on its holding."
    s tired "Go on. I'll be right here. Don't be long."
    hide alice with dissolve
    "She got out. He watched her cross the forecourt in the white light, small in her too-big coat, the bag on her shoulder, unhurried."
    "She disappeared around the side of the shop toward the squat row of toilets."
    play sound sfx_heartbeat
    "He sat one moment more with both hands flat on his thighs and his heart going like a fist on a door."
    "Then he made himself move, because a man who sat frozen in a car was no use to anyone, least of all himself."

    # --- The pump ------------------------------------------------------------
    scene bg valley_station_night at slow_zoom with dissolve
    show vignette
    "He got out into the cold. The night was enormous and clean and bitter, the stars very hard overhead."
    "The gorge was a deeper black past the broken run of barrier rail at the lot's edge. The only sound was the hum of the canopy lights and, faint, the wind coming up out of the drop."
    "He unhooked the nozzle and set it in the tank and started the pump, and stood there in the light with the fuel running, his back to the shop and the toilets."
    "And made himself think, fast and cold, the way he had not let himself think in four hours."
    "Because this was the place. He had never seen this station in his life, but he knew the shape of it. The wrongness."
    "The whole day had been running downhill toward exactly this: a lit and lonely nowhere, a cliff, a child gone quiet, and himself alone in the open."
    "He had watched her, on the road, close a file on him."
    th "She didn't ask to use the toilet because she needed the toilet."
    "The animal in him knew it, standing at the pump with the diesel running."

    menu:
        "Reach for the weapon.":
            $ chose("m13_weapon", "reach", refused_try=True)
            "His hand moved toward the weapon under his coat. It got as far as the lapel."
            "And stopped there, because it was a child."
        "Don't.":
            $ chose("m13_weapon", "dont")
            "He kept his hands where they were. And still his hand drifted, without his deciding it, toward the weapon under his coat."
            "And stopped, because it was a child."

    "It hung there, useless, in the six inches between decency and survival where Samuel Harris had lived his whole ruined life."
    "That was where he was standing, and that was where his hand was, when he heard it over the hum of the light and the run of the fuel."
    "The small clean sound of her feet coming back across the concrete behind him. Quicker than a child who needed nothing would walk."

    # --- The return ----------------------------------------------------------
    stop ambient fadeout 2.0
    "He turned."
    show alice cold at center with dissolve_slow
    "And the child was gone."
    "That was the thing he would carry out of that forecourt, if he carried anything out of it at all. Not a monster. Not a face contorted into anything. Nothing so easy to bear."
    "Just an absence. The warmth switched off at the wall. The grief, the softness, the frightened orphan, all of it set down somewhere back in the dark like a coat she no longer needed."
    "What stood in front of him in the cold white light, six feet away and closing, was the thing he had first glimpsed weeks ago across a notebook and had spent every day since refusing to look at."
    "A calm, patient, unhurried attention, very old and entirely without mercy, looking out of a twelve-year-old's gray eyes at a man it had weighed and found wanting."
    "She had a knife. A kitchen knife, plain, the kind that lives in any drawer in any house."
    "She had carried it out of the foster kitchen the way she carried everything: quietly, in advance, in case. Whatever she had decided about him on the road, she had come down the mountain ready to decide it."
    a cold "You knew."
    "Not a question. Her voice had nothing in it. No fear, no heat. Only a kind of mild, terrible interest."
    a cold "For a while now. I watched you know it."
    "Her head tilted: the small precise movement he had seen her make over a dying priest, over a mug of cocoa. Weighing."
    a cold "I hoped I was wrong about you. At the start you were the only strong one. I thought— here, finally, is one who carries it and doesn't break."
    "Something almost like sorrow crossed the calm, and it was the most frightening thing yet, because it was real."
    a cold "But you're soft all the way down, Detective. You had it and you couldn't say it."
    a cold "You knew what I was and you drove me anyway, and you tried to {i}save{/i} me."
    "The word came out with the only contempt she had ever let him see."
    a cold "You were almost worthy. You were the closest I ever found."
    s shocked "Alice—"
    a cold "It's alright."
    "She said it gently, the way you'd gentle a horse. And stepped in."
    hide alice
    scene black with flash_red
    play sound sfx_thud
    with vpunch
    "And put the knife into him."
    call mature_show("samuel_wound")
    play sound sfx_tinnitus
    show vignette red
    "Low in his side, under the ribs. A small hot certainty, no drama to it at all. A child's whole weight behind a domestic blade."
    "The pain came a beat late and enormous, and the world tilted white."
    "He heard himself make a sound he had never made. His knees went."
    "The diesel nozzle tore out of the tank and clattered on the concrete, and lay there hissing a slick of fuel out across the cold forecourt."
    call mature_hide
    "She stepped back from him, out of the reach of a falling man. Patient. Watching him fold. Waiting for the strong one to finish being strong."

    # --- The blind red room --------------------------------------------------
    window hide
    pause 2.0
    window auto
    "But he did not finish."
    "That was the thing she had never seen, in all her careful study of the weak."
    "There is a floor under a man. Below the reason. Below the decency. Below the grief."
    "A blind red room with no thought in it at all."
    "When the knife goes in, it is not the detective who answers. Not the father. Not the good man who could not draw on a child."
    "It is the animal."
    "And the animal does not care that she is twelve. The animal does not care about anything but the next breath."
    "It came up out of the floor of him as his knees hit the concrete and his own blood ran hot over his hand. And it took the wheel."
    "She stepped in to finish it. One more, into the neck, clean, the way you'd end anything."
    play sound sfx_thud
    with vpunch
    "The wounded thing on the ground caught her wrist."
    "It caught her wrist and it did not let go."
    "She pulled, and it held. A big man's ruined hand closed to the bone around a child's thin arm."
    "For the first time in the whole cold history of her, something went wrong in the calm gray eyes. Some small astonishment."
    "The sum was not coming out. The strong one was supposed to be finished, and was not finished, and was rising."
    "Dragging himself up her arm hand over hand like a drowning man up a rope. Enormous, bleeding, beyond stopping."
    "The knife came loose and skittered away into the dark, and neither of them looked at it."
    th "Get up."
    "He got up. Folded around the fire in his side, he got up the way he had gotten up in the road with George, because it was the one thing left in him that was still his."
    "And he got his hands on her."
    play sound sfx_heartbeat
    "He would never be able to lay the seconds out in their order. Only pieces. Only pieces, for the rest of his life."
    "The small body twisting. Ferociously strong for its size."
    "And silent. No scream. No plea. Giving him nothing to the very end, the way the old man had taught her, in a colder house, long ago."
    "His own voice, saying something. A word. A name. He never knew what."
    "There was a gun under his coat and he never reached for it."
    "The animal did not think of steel. Or the man inside the animal would not, even blind, even dying, put a bullet in a child."
    "So it was his hands. Only ever his hands."
    "The hands that had held a report and a cigarette and a dead man's ruined face. And once, a thing no heavier than a loaf of bread, that had been warm and then was not."
    "Those hands found the child's throat in the dark, and closed."
    "Not the detective deciding it. Not the father. Only the animal in the blind red room, and the body taking her breath to keep its own."
    window hide
    pause 2.5
    window auto
    "It did not take long. She was very small."
    "That was the thing he would not be able to stop knowing. That at the last she did not fight it the way she had fought the wrist."
    "Somewhere in it the ferocity went out of her, and she let it come."
    "He could never decide, in all the years he had to decide it, whether that had been the body giving up, or the judge, at the very end, closing one last file."
    "Weighing the strong one's hands around her throat, and finding, at last, exactly the verdict she had come down the mountain to prove."
    th "You were almost worthy. You were the closest I ever found."
    "She had come all this way, worked four hours down a mountain, to take the one strong man she had ever met and make him weak. Make him break."
    "Make him kill with his bare hands, in a red rage, the child he had sworn to protect."
    "And she had done it. In the only country that had ever mattered to her, the cold country of her judgment, Alice Bennett had won, and knew it as she went."
    "Samuel knelt in the spreading fuel with her gone still under his hands, and knew it too."
    "The winning was hers. The losing was only his. And it would be his forever."
    window hide
    pause 2.0
    window auto
    "Then his hands opened."
    "And there was nothing under them but a child."
    hide vignette
    window hide
    pause 3.0
    window auto

    # --- The forecourt -------------------------------------------------------
    scene bg valley_station_night with dissolve_slow
    show vignette
    play music m_aftermath2 fadein 6.0
    "He knelt over her for a long time in the spreading fuel and the cold, and did not weep."
    "The weeping place was already full. It had been full for thirteen years, and there was no room in it for this."
    "He knelt the way he had knelt over George. The way he had once stood over a coffin no heavier than a loaf of bread. Dry-eyed, upright, watching from a little way outside himself while his life fell into itself."
    "Somewhere behind the glass the attendant had finally looked up from his phone, and seen, and was shouting into it now."
    "The sound came to Samuel thin and far away, from another country. The country of people to whom things had not happened yet."
    "He should have been dead. The blade had gone in low and wide and found nothing in him that would kill a man."
    "Not because he had been quick. He had been slow, a half-second too slow, slowed to the last by the decency in him that could not, even with a knife coming, believe a child would."
    "But because she was twelve, and strong for it, and very good, and had not yet lived the years it takes to know exactly where in a body a life is kept."
    "It was the one mercy in the whole of it, and it was an accident, and it was the cruelest of them all. Because it meant he lived."
    "He got the coat off, one-handed, and wadded it against his side, and lay down on the cold concrete beside her, out of the reach of the fuel."
    scene cg forecourt with dissolve_slow
    window hide
    pause 2.0
    window auto
    "He looked up at the hard stars, and waited for the far country to arrive with its lights and its hands."
    "And while he waited he did the last of the arithmetic, because he was, to the marrow, past all saving, a detective."
    "They would believe him now."
    "That was the terrible sum, coming out at last, clean and balanced and unbearable."
    "A twelve-year-old who walks calm out of a toilet with a kitchen knife from a foster kitchen and puts it into a detective in the dark is not a grieving orphan."
    "And a detective bleeding out beside her, with the receipt in his hotel room that put George Bennett twenty-five miles from a dying girl, is not a broken man seeing monsters anymore."
    "He had come down the mountain with a truth no soul on earth would credit, and she had, in the last thing she ever did, made them credit it."
    "George Bennett would come up out of the mud. The name would be cleared, the record set right. The one thing Samuel had sworn over his body to return to him."
    "It had cost him a child's throat in his two hands."
    "Every good thing this case had ever given him, it had charged for in the one currency he had left. And now the account was empty, and George was clean, and the truth was safe."
    "He lay on his back at a gas station at the bottom of the world with the blood of a little girl going cold on his shirt, and understood that he had solved it."
    "Every piece of it. Start to finish, the whole cold machine laid bare and proven. The best work of thirty years."
    "And that it had solved him too, the way she had promised him on the road it would."
    th "You're just as sad and soft as everybody. You only hid it better and longer."
    "She had been right. Thirteen years he had believed the caring was the weakness, and thirteen years Martha had sworn it was the only thing that ever made him good."
    "Here at the bottom of the world he finally had the answer, and it was worthless, because they had both been right."
    "The caring was the best of him and the ruin of him. The same thing. Indivisible."
    "He had spent his whole life keeping the one door shut, and at the very end he had opened it, and reached in, and it had cost him a child."
    "The far country came at last, red and blue against the hard dark, sirens climbing the empty road."
    "Hands lifted him. A voice asked his name, and he gave it."
    "They worked over the child a while, because they did not yet know. And then they stopped, and drew the sheet."
    "The small covered shape under the canopy light was the last thing he saw before they closed the ambulance doors."

    # --- The hospital --------------------------------------------------------
    scene bg hospital_room with fade_long
    call place("City hospital, surgical ward — the second day")
    play sound sfx_beep
    "Martha came the second day, when they had him stitched and drained and propped up in a bed with a machine counting his heart for him."
    "He heard her before he saw her: the particular quick step of her down the corridor, faster at the end."
    show martha concerned at center with dissolve
    "Then she was in the door, and stopped, and looked at him. He watched her take in the whole of it in one sweep: the taped side, the gray face, the thing behind his eyes the surgeons had not been able to reach."
    "She did not fuss. She had never once fussed."
    "She came and sat in the hard chair by the bed and took his nearer hand in both of hers and held it, and for a long time neither of them said anything."
    play sound sfx_beep
    "The machine counted. Outside the window the flat gray city went about its business."
    ma cry "I heard what she was. Raymond told me. What she'd done. What she made you do."
    "Her thumb moved over his knuckles."
    ma concerned "You listen to me, Sam. That was not you."
    ma concerned "A thing came at you with a knife in the dark and your body did what a body does. That was not the man doing it. That was the meat keeping itself alive."
    s hurt "I know."
    "And he did know it, and it did not help at all. He could see in her face that she knew that too."
    "Of all the things she had ever said to him across all the years, this was the one that would not go in. Because it was true, and it did not matter that it was true."
    "She had told him the caring was the only good thing in him. She had been right. And he had reached in for a child, and it had turned to a knife in his hands."
    "There was no sentence in the language, hers or anyone's, that could make that a thing a man carried lightly."
    "She stayed the day. She did not try again."
    "She only held his hand, which was, in the end, the only argument she had ever really been making."
    hide martha with dissolve
    stop music fadeout 3.0

    jump ending


label ending:
    # --- The inquiry ---------------------------------------------------------
    scene bg inquiry_room with fade_long
    # ART-REQUEST (fulfilled): a plain inquiry/hearing room — long table, water jugs, gray daylight; no figures.
    play music m_aftermath2 if_changed fadein 3.0
    "There was an inquiry after, because there is always an inquiry when a policeman's hands stop a life. It did not last long."
    "There was the knife with her prints on it, and the wound low in his side, and the blood he had left across half a forecourt."
    $ note("Knife: her prints.")
    "It took no great wisdom to call the thing what it plainly was: a man attacked in the dark by a child he had been trying to help. And to let him go."
    "No one at the inquiry said serial killer about a twelve-year-old, and no one afterward quite could."
    "But the receipt came up out of his hotel room and did its quiet work. The file on George Bennett was opened again and closed again, differently, and the dead man was given back his name."
    if "m11_call" in refused:
        th "Once, at dawn, I had his number under my thumb. I put the phone face down."
    $ note("George Bennett: name cleared.")
    note_voice "George Bennett: name cleared."
    "It was the last case Samuel Harris ever cleared, and the only one he ever wished he had not."

    # --- The town's story ----------------------------------------------------
    scene bg greyvale_square at night with fade_slow
    show snow light
    show vignette
    play ambient sfx_wind fadein 2.0
    call cinematic("greyvale_snow", grade="night")
    call place("Greyvale — winters after")
    "They tell it, in the town, still."
    "How the strange man from Driftwood killed all those people and got what was coming to him on the road."
    "And how it turned out, in the end, in some way nobody quite has the shape of, that they'd had it wrong. That the old man hadn't done it after all."
    woman "That it was— the little girl. His granddaughter. All along."
    "Here the tellers always lower their voices, because it is not a thing the mouth wants to say."
    "They tell it by the fire on winter nights, and they shiver, and they do not, in their hearts, believe it. Not really. Because it cannot be believed. Because the world is not built to allow it."
    "And they never mention the detective at all, the tall gray one who was there for the worst of it and left when it was done."
    "There is nothing to tell about him."
    "He solved it. He went home."
    stop ambient fadeout 2.0

    # --- Home ----------------------------------------------------------------
    scene bg apartment_samuel with fade_slow
    "He went home to an apartment where a woman had left food that would not keep and sat, sometimes, in a chair that nobody else sat in."
    "He healed, in the body, the way bodies do."
    "On the far side of it he was, to anyone who did not know him, exactly the man he had always been. Quiet, courteous, worn, a little grayer."
    "Back at his desk with his cigarettes and his paperwork, keeping the chaos at bay with ink and routine."
    "Only Martha, who loved him, saw that the last light in him had gone out on a mountain road at a gas station in the dark."
    "That the thing that came back down and sat at the desk and answered to his name was a man who had found the one thing he had spent his whole life certain was safest to keep locked away."
    "And had opened the door on it, and reached for it, and had it turn, in his hands, in the cold white light, into a knife."
    stop music fadeout 3.0

    # --- The property room ---------------------------------------------------
    scene bg property_room with fade_long
    play music m_title2 fadein 4.0
    call place("County property room — weeks after")
    "He kept the coin."
    "It was in the county property room, weeks after, that he took it."
    "They had let him sit with the girl's effects one last time before the file closed for good. A courtesy to the detective who had cleared it: an hour alone at a steel table with the canvas holdall."
    "He went through it slowly, the way he went through everything. The folded child's clothes. The worn copy of {i}Tom Sawyer{/i}. The toothbrush. The small dead ordinary weight of a life."
    "And at the bottom, in a fold of the lining, his fingers found the coin."
    "He knew it by touch before he saw it."
    scene cg coin with dissolve_slow
    window hide
    pause 2.5
    window auto
    "Smooth as a river stone, warm from nothing, no bigger than the pad of his thumb. The face worn clean off it by more hands than either of them would ever count."
    "He turned it over once in the fluorescent light of that cold room. This blind bronze blank a dead girl had given, out of a toffee tin, to the friend who would kneel in the snow and kill her."
    "The best one, she'd said. The one you only give to someone you love."
    "Then, without any decision he could afterward point to, he closed his hand around it and put it in his coat pocket."
    "He signed the inventory sheet that did not, now, list it, and stood up, and walked out with it."
    "It was the one crime he ever committed, and the only thing he ever stole."

    # --- Samuel alone --------------------------------------------------------
    scene cg samuel_alone with fade_long
    window hide
    pause 2.5
    window auto
    "He carried it in his coat pocket for the rest of his life, and turned it over in his fingers on the bad nights. The smooth blind face of it."
    "The trace of a girl who had loved a friend and killed her."
    "The trace of the past that does not stay in the past. That rides down out of the mountains in the seat beside you, small and patient and quiet."
    "And waits, in the cold, at the bottom of every road, for you to pull in."
    window hide
    pause 2.0
    window auto

    # --- The last page (insight payoff) --------------------------------------
    # Three pages keyed to how often the player looked (docs/design/interactivity.md §4).
    # Tiers II and III are assembled from the tells the player actually noticed. A run
    # started from chapter select shows the last full run's page and doesn't overwrite it.
    python:
        page_tier = ending_tier() if full_run else (persistent.last_full_tier or 1)
        page_tells = [t for t in TELLS if t in tells]
        if full_run:
            persistent.last_full_tier = page_tier
        persistent.pages_seen.add(page_tier)
    if page_tier == 3:
        "One night, late, he opened the notebook to a clean page and wrote, for once, about himself."
        python:
            if page_tells:
                # the first noticed, up to three between, and the last noticed
                page_lines = [page_tells[0]] + page_tells[1:-1][:3] + (page_tells[-1:] if len(page_tells) > 1 else [])
            else:   # an old save with a count but no ids: the shipped page
                page_lines = ["t02_bikeracks", "t04_scream", "t04_funeral", "t12_stain"]
            for page_id in page_lines:
                renpy.say(note_voice, TELLS[page_id][2])
        note_voice "Every time, there was a choice, and every time I chose not to look. That's not a failure of the eye. I had the eye. That's a decision."
        note_voice "The old man gave them nothing, to keep her. She gave them nothing, to the end. And I had it in front of me from the first week, and I put it where I put Thomas."
        if picked("m13_door", "search"):
            note_voice "I didn't search the bag."
        elif picked("m13_door", "hold"):
            note_voice "I didn't tell her to hold it."
        if len(refused) >= 4:
            note_voice "Every door I reached for, I stopped at the handle."
        note_voice "Give them nothing. I gave myself nothing."
        $ note("Give them nothing. I gave myself nothing.")
    elif page_tier == 2:
        "One night, late, he opened the notebook to a clean page, and sat a long time before he wrote."
        python:
            if page_tells:
                page_text = "Did I see it? " + " ".join(TELLS[t][1] for t in page_tells[:3])
            else:
                page_text = "Did I see it? The bike racks. The head tilt. The way she looked at the road."
            renpy.say(note_voice, page_text)
        note_voice "Some nights I'm sure I did. Some nights I think I put it there after, the way you do, to make it bearable that I didn't."
        if picked("m13_door", "search"):
            note_voice "I didn't search the bag."
        elif picked("m13_door", "hold"):
            note_voice "I didn't tell her to hold it."
        if len(refused) >= 4:
            note_voice "Every door I reached for, I stopped at the handle."
        note_voice "Either way, I wrote down everything but her."
        $ note("I wrote down everything but her.")
    else:
        "One night, late, he opened the notebook to a clean page, and wrote one line, and closed it."
        note_voice "I solved it. I went home."
        $ note("I solved it. I went home.")

    window hide
    pause 2.0
    stop music fadeout 4.0

    # --- Credits -------------------------------------------------------------
    scene black with fade_long
    play music m_title fadein 4.0
    show text "{size=60}{font=fonts/Cinzel.ttf}GIVE THEM NOTHING{/font}{/size}" at truecenter with dissolve_slow
    pause 4.0
    hide text with dissolve_slow
    centered "Adapted from the novel by A. Damon"
    centered "Art generated for this adaptation"
    centered "Music: {i}Last Seen{/i} soundtrack"
    window hide
    pause 1.5
    centered "{i}Give them nothing.{/i}"
    stop music fadeout 6.0
    scene black with fade_long
    if full_run:
        # Second Read (chapter select) unlocks, on by default the first time.
        if not persistent.finished:
            $ persistent.second_read = True
        $ persistent.finished = True
    return
