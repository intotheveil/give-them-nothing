# Chapter 7 — "Sacrifice is the highest purity"
# Source: tail of docs/manuscript/ch06.txt (from "Alice caught her before she fell.")
#         + all of docs/manuscript/ch07.txt.
# POV: Alice (cemetery, night) -> Samuel (the morning after, the arrest).

# --- Internal subroutines for the scene-examination choice (entered only via call) ---

label ch07_scene_note:
    "The note next. It lay on the folded hands, set square, meant to be found."
    "A scrap of paper torn, not cut, its edges ragged, the stock thick and pulpy. The same as the slip in Hensley's till. The same as the scrap trodden into the churchyard grass the morning the priest fell."
    "Samuel crouched and read it without lifting it, his breath clouding over the words."
    note_voice "Sacrifice is the highest purity."
    "He held very still for a moment."
    "Then he lifted it with the tweezers, bagged it, labeled it, logged the exact position. Centered. Folded hands."
    "He did not let his hand shake. A man's hands did not shake at a scene. They shook afterward, in a car, in the dark, where no one filed a report on them."
    $ note("Emily Carter, 14. Cyanosis. Arranged. Note: 'Sacrifice is the highest purity.'")
    return

label ch07_scene_button:
    "It was set into the snow three plots along, at the head of the raw grave. The new one. Clara's, still without a stone of her own."
    "A button. Deep green, small, a little worn anchor stamped in its face, pressed deliberately into the white."
    "And beside it, folded once, gone soft and translucent with damp, a scrap of paper that was not the killer's stock."
    "He crouched over it without touching. A drawing. A child's drawing, in pencil, of a girl's face."
    "Clumsy, unfinished, the nose gone over and over and never right. Done by someone who had not looked long enough at the living face to get it, and was trying, too late, to remember."
    "Samuel looked at the button, and the drawing, and the two graves three plots apart, and something in him that was not the detective ached and could not say why."
    th "It makes no sense in the frame. A cult doesn't leave a child's drawing. A ritual doesn't bring a present to a grave."
    $ note("Button + drawing, Ward grave — unexplained.")
    note_voice "Button + drawing, Ward grave — unexplained."
    "He underlined it once, and did not understand it, and moved on. A scene did not let you stop at the thing that hurt."
    return


label ch07:
    call chapter_card(7, "Greyvale — the night, and the morning after")

    # ------------------------------------------------------------------
    # ALICE POV — the cemetery. Never an image of the dying child.
    # ------------------------------------------------------------------
    scene black with fade_long
    stop music fadeout 3.0
    play ambient sfx_wind fadein 3.0
    window show

    "Alice caught her before she fell."
    "She took the whole small weight down into the snow the way you lower a thing you don't want to break, and she held her."
    "She had prepared for a great many parts of this. Not, it turned out, for the warmth."

    scene bg cemetery_night at night with dissolve_slow
    show snow light
    show vignette

    "She had thought it would be cold. That was the shape the ending had always taken in her mind, across the eleven days she had carried it. A clean cold. A stillness. A candle pinched out."
    "Everything she had done had been in service of that cold. The extract steeped behind the flour. The seeds crushed in a folded rag. The gloves, the scrubbed and aching hands."
    "The after, rehearsed motion by motion, so that nothing would have to be felt in the during. She had built the whole night to be cold."

    scene black with dissolve_slow
    play sound sfx_heartbeat

    "It was not cold. That was the thing no book had told her."
    "Emily fought. The body always fought; it did not believe in causes."
    "Alice held her through it. The small drumming heels, the arching back, the fingers that clutched at her sleeve with a strength that would leave marks."
    "All of it was warm. Terribly warm. The warmth of a body still full of the animal work of living."
    "Alice knelt in the snow and was the only witness, and did not look away, because looking away would have been for herself."
    a "You're not alone."
    "Low. Even. The one true thing she had left to give."
    a "You're not alone. I'm here."
    "The fighting slowed. The grip on her sleeve loosened, finger by finger, and the hand slid down and lay open in the snow, palm up."
    "The breath, which had been ragged, went shallow. And then long. And then—Alice counted, because she had made herself learn to count—"
    window hide
    pause 2.5
    window auto
    "—stopped."
    "And still the warmth stayed."

    scene bg cemetery_night at night with fade_slow
    show snow light
    show vignette

    "That was the thing that opened something in her she had believed sealed."
    "Emily was gone. She had felt her go, felt the exact moment the thing that was Emily left the body it had lived in."
    "And yet the body stayed warm in her arms. Soft, heavy, warm as sleep. Warm as a friend fallen asleep against your shoulder on a long drive."
    "It went on being warm, obscenely, patiently, in no hurry at all to become the cold thing Alice had prepared for."
    "She held her friend and felt the warmth not leave. It only, over the long minutes, very slowly, began to."

    play music m_ritual fadein 6.0

    "She stayed there longer than the plan allowed."
    "The tears came, and she let them come. She had earned them."
    "She did not sob. Sobbing was the sound grief made when it wanted a witness, and there was no witness here, and she wanted none."
    "She had loved Emily. She made herself hold the whole size of it, there in the snow, the warm weight cooling by degrees against her."
    "She had loved this one truly, more than anyone since the coast. And she had weighed that love against the cause, and chosen."
    "Not because the love was small. Because she would not be a judge with a door in her. A room she would not enter. A person who could be ruled through the thing she loved."
    "She had watched a door like that make a coward of George."
    "She had closed hers herself, tonight, with her own hands. And now she knew the price of it, which was this: the warmth, and how long it took to go."
    ath "The priestess does not bend to love."
    "She had not bent. She had chosen."
    "It felt like dying. She understood, kneeling there, that this was the last of her own childhood leaving—quietly, the way Emily's breath had left, without any fuss at all."
    window hide
    pause 2.0
    window auto
    "Then she wiped her face on the back of her wrist, and stood, and went to work."

    # --- the cold work ---
    "The cold helped, the way it always did. She was steady again."
    "She moved in order, no motion wasted, the way George moved."
    "The thermos and the mug into the bag. Nothing warm, nothing shared, no sign that two girls had ever crouched here over cocoa."
    "Fresh snow scuffed across the dark spill until it was only snow. The gloves stayed on."
    "And the phone. The cheap one from Emily's coat pocket, the one that held every message between them."
    "The single thread in all of this that led anywhere but where she needed it to lead."
    "That went into her own bag too, to be broken small and scattered off the gorge bridge on the way down."
    "The drawing she let be. A child's drawing of a dead girl led nowhere, and it belonged where Emily had meant it to go."
    "Then the staging. It had to shout one thing to a starved and frightened town so loudly that no one would ever think to listen underneath it."
    "She laid Emily on her back and folded the warm hands on the still chest. Composed. Deliberate. Placed, the way the others had been placed."
    "Whoever found her would feel the wrongness before they understood it."
    "From her pocket she took the scrap she had torn that morning from the thick pulpy stock, the same as all the others, and set it on the folded hands."

    scene black with dissolve
    show text "{size=+12}{i}SACRIFICE IS THE HIGHEST PURITY{/i}{/size}" at truecenter with dissolve_slow
    window hide
    pause 2.5
    hide text with dissolve
    window auto

    scene bg cemetery_night at night with dissolve
    show snow light
    show vignette

    "True on both readings, like all of them."
    "Let the town read a cult. A ritual. An old handyman's inherited madness, pointing back to a village that didn't talk."
    "She read the other thing. That she had made a sacrifice tonight, the highest she would ever be asked for, and had not flinched."
    "And that its purity was the purity of a blade with nothing left on it."
    "The markings last. Chalked quick and sure on the flat face of the nearest stone—the shapes she had carried out of Driftwood in her head, where no search of any house could ever find them."
    ath "Cult-tongued. Inherited. He carries it everywhere, and so must I."
    "The words she had handed the detective a few hours ago, in a warm room. Doing their slow clouding work in him even now."
    "So that when he stood over this in the grey morning, some part of him would already have been taught what to see."
    "She did not take the button back."
    "She left it where Emily had pressed it, at the head of Clara's raw grave, and set the little folded drawing beside it, in the snow, where the goodbye had been meant to go."
    "It changed nothing in the frame. It was the one thing she did that night that was not for the cause."
    "She let herself have it, once, exactly, the way she had let herself have the tears."
    "Then she turned her back on both graves and did not look at either again."

    # --- the walk down ---
    stop music fadeout 4.0
    scene bg greyvale_street at night with fade_slow
    show snow light
    show vignette

    "The walk down was long, and downhill, and easier than the climb."
    show alice cold at center with dissolve
    "Piece by piece, as she went, she rebuilt the girl the town believed in."
    "Straightened the back. Smoothed the face."
    show alice sad at center with dissolve_slow
    "Set into it the hollow, frightened look of a child who had been somewhere warm and safe while a terrible thing happened out in the dark to the one friend she had."
    hide alice with dissolve

    scene bg alice_room_night with fade
    show vignette
    stop ambient fadeout 2.0

    "The house was still dark. The truck still gone."
    "She let herself in the side, and hung her wet coat, and washed the thermos and the mug and set them exactly where they lived."
    "She pushed one more rag deep into the dead ash of the hearth."
    "Then she went up and lay down on top of the covers in her clothes, and folded her hands on her chest the way she had folded Emily's, and stared at the ceiling, and waited."
    window hide
    pause 2.0
    window auto
    play sound sfx_engine fadein 1.0
    "The engine came a little after two."
    "The tires on the snow. The door."
    play sound sfx_thud
    "The heavy tread on the stair that paused, out of habit, outside her room. And moved on."
    window hide
    pause 1.5
    window auto
    ath "I heard my grandfather leave."
    "She would say it, when they came."
    ath "And later, I heard him come home."
    "Both true."
    "She closed her eyes. Outside, the snow had started again, and was already, patiently, beginning to cover everything she had left on the hill."

    scene black with fade_long
    pause 1.5

    # ------------------------------------------------------------------
    # SAMUEL POV — 6:52 a.m.
    # ------------------------------------------------------------------
    scene bg hotel_room at night with fade
    call place("The Greyvale Hotel — 6:52 a.m.")

    play sound sfx_phone
    "The phone woke him at 6:52, and he knew before he answered."
    "There is a particular way a phone rings before dawn in a town where people have started to die. Samuel had learned it that week, the way a soldier learns the difference between weather and gunfire."
    "The cold of the room on his bare arm. The radiator ticking in the dark. MERCER on the screen."
    "He sat up and put his feet on the floor and was a detective again before he had said a word."

    show screen phone_call("Daniel Mercer")
    s "Harris."
    m shaken "Detective."
    "Mercer's voice had no colour in it at all. That was how Samuel knew it was bad in a new way. Worse than a shopkeeper. Worse than a priest."
    "Mercer had found a voice for those. He hadn't found one for this."
    m shaken "You need to come up to the cemetery. Same one. Up by the Ward plot."
    s "Talk to me."
    m shaken "It's a child."
    "A breath came down the line, unsteady."
    m shaken "A girl. Kaftanis found her when he came up to clear the paths, maybe an hour ago. She's—"
    "The word didn't come. Mercer tried again."
    m shaken "She's laid out, Detective. Like the others. There's a note."
    s "Don't touch anything. Don't let anyone touch anything. Keep Kaftanis there and keep everybody else at the gate."
    "He had the phone jammed against his shoulder, buttoning his shirt with cold fingers. Some part of him had already gone up the hill ahead of his body."
    s "Have you got a name?"
    "The silence on the line lasted a beat too long."
    s "Mercer. The girl. Do we have a name."
    m shaken "We think so. There's a school bag near the wall."
    m shaken "Carter. Emily Carter."
    play sound sfx_tinnitus
    "Samuel stopped with one button undone."
    "For a moment the room was very loud—the radiator, the wind at the glass, the blood in his own ears—and then it was very quiet."
    "And into the quiet came a small warm voice from the passenger seat of his own car, hours ago, close enough that he could have reached out and touched the girl who had said it."
    "{i}She's my best friend. I don't want to lose her.{/i}"
    m shaken "Detective? You there?"
    s "I'm here."
    "His own voice sounded far away. Flat. Professional. The voice that had walked into a hundred rooms after the worst thing had already happened."
    s "I'm coming. Fifteen minutes. Mercer—"
    "He made himself say it."
    s "Has anyone told the parents?"
    m "Not yet."
    s "Then nobody does until I'm there. Not one word."
    hide screen phone_call
    "He stood a moment in the dark with the phone in his hand. Then he finished the button, and put on his coat, and went."

    # --- the drive ---
    scene bg car_day_snow with fade_slow
    play ambient2 sfx_engine fadein 2.0
    call place("The cemetery road — dawn")

    "The sky was going from black to the colour of ash as he drove up out of the town. The mountains stood out of it hard and white and indifferent."
    "He smoked one cigarette down to the filter and lit another off it and did not taste either."
    "He knew this road now. He had driven it once already, days ago, following a coffin."
    "He had stood in that cemetery and felt the old wound tear its stitches, and a priest had died at his feet, and he had thought the place had shown him the worst it had."
    th "The place had been saving something."
    "He made himself go cold. It was a door he knew how to pull, and he pulled it now the way he had pulled it for thirteen years."
    "Not because he did not feel it. Because feeling it was a luxury the dead could not afford."
    th "Work first. The child needs a detective, not a mourner. Feel it later, on your own time, the way you feel everything."
    "By the time the cemetery gate rose out of the pale morning he was, on the outside, exactly the man the scene required."

    # --- the scene ---
    stop ambient2 fadeout 1.5
    scene bg cemetery_dawn with fade_slow
    show snow light
    play ambient sfx_wind fadein 2.0
    play music m_church2 fadein 3.0

    "Two patrol cars stood at odd angles below the gate, their lights turning slow and useless in the growing light."
    "A knot of people had already gathered on the road, despite the hour, despite the cold. A town could smell this now. A single uniform held them back with his arms spread and his face grey."
    "Above, past the black iron, the graves climbed the slope in their white rows. Among them, small figures moved. And one figure did not."

    show mercer shaken at right with dissolve
    "Mercer came down through the stones to meet him. He looked ten years older than he had the night before. His eyes were red-rimmed, and not from sleep this time."
    m shaken "Detective. She's up by the Ward plot."
    m shaken "Kaftanis is over by the shed. I sat him down, gave him a cigarette, he's not good. He covered her with his coat before he understood. Didn't know what else to do. I've bagged the coat."
    s "Good man."
    "Samuel put a hand on his shoulder once, brief, hard. The only comfort he had time for."
    s "Walk me up. Tell me what you've touched."
    m shaken "Nothing. Nobody. I made them stand where they are."
    m shaken "It snowed on her, Detective. After. She's got snow on her. She's been up here—"
    "He stopped."
    m shaken "She's been up here since the night."
    hide mercer with dissolve

    "The valley opened below them as they climbed, the whole town laid out small and blue, lights just going on in kitchen windows. Ordinary people waking to an ordinary day they did not yet know was over."
    "They came over the shoulder of the slope, among the older headstones a few plots above the raw unstoned mound that was all Clara Ward yet had."
    "Samuel saw her, and stopped."

    scene bg cemetery_dawn at slow_zoom with dissolve_slow
    show snow light
    show vignette

    "She lay on her back in the snow with her hands folded on her chest."
    "That was the first thing. The wrong thing. She was not fallen but arranged. Composed. Laid out with a care that no accident and no despair had ever managed."
    "Her hands folded one over the other exactly at the centre of her. Her hair drawn back from her face. Her coat straightened."
    th "Someone made her neat. Someone knelt in this snow and made a murdered child neat."
    "The wrongness of it went into Samuel like cold water into a cracked tooth."
    "Snow had fallen on her through the night, a fine white veil that softened her and made her, for one merciful second, look only asleep."
    "Then he was standing over her, and it was Emily. Of course it was Emily."
    "The girl from the counsellor's office who had asked him not to think badly of Clara. The girl at the funeral who had turned her face into her friend's shoulder so she wouldn't have to see."
    "The girl whose name he had spoken in his own warm car not twelve hours ago, fishing, working an angle, while she was alive somewhere in this town with hours left."
    th "She's a good one, from the look of her."
    "She had been. She was fourteen and she had been a good one, and now she was laid out in the snow with a stranger's care."
    "Behind the cold visor of his face, Samuel felt the old welded door shudder in its frame."
    "He did not open it. He could not, not here. But he felt it, and he knew he would pay for feeling it later, the way he paid for everything."
    m "Detective?"
    s "Give me a minute."
    "He took out his notebook, and clicked his pen, and made himself begin."

    scene bg cemetery_dawn with dissolve
    show snow light
    call place("Greyvale Cemetery — 7:40 a.m.")

    "He worked the way he always worked, from the outside in, and let the cold visor do the seeing so the man behind it could stay standing."
    "The coroner and a scene unit from the city were two hours out on the mountain road, if the passes were clear. Until they climbed it, the hill and the girl were his alone."
    "The body first, without touching. The pallor he had learned to read that week. At the lips, a faint blue-purple bloom; the same shadow under the nails of the folded hands."
    "Cyanosis. The quiet signature of a heart that had been made to stop. No wound. No blood. Only the terrible neatness and the colour of the mouth."
    th "Yew. Same as Hensley. Same as Karalis. I won't say it until the lab does."
    "A girl of fourteen did not sit in a cemetery at midnight in a coat and drink a poison by choice. She had been brought here. She had been given it. She had been arranged."

    $ ch07_button_first = False
    menu:
        "Read the note on her hands.":
            call ch07_scene_note
        "Something at Clara's grave. Look there first.":
            $ ch07_button_first = True
            "Three plots along, at the head of the raw grave, something small and dark broke the white. He went to it before he let himself look at her hands again."
            call ch07_scene_button
            "Then he came back to the girl."
            call ch07_scene_note

    "The stone beside her carried the rest."
    "On the flat face of the nearest headstone, chalked quick and sure, were the marks. Angular, deliberate. A language that was not a language."
    "The same cult-tongue that had trailed this killer through four deaths and pointed, every time, back toward a strange old man from a village that answered its phone in silence."
    "Samuel photographed them. He had Mercer photograph them again. He wrote them into his notebook stroke by stroke, though he could not read them, because someone, somewhere, might."
    "Then the things that were missing, which were always the things that mattered most."
    "No cup. No bottle, no flask, no vessel of any kind. The poison had gone into her through something. Whoever had done this had taken it away."
    "No phone. The bag by the wall held schoolbooks, a pencil case, a half-eaten roll of sweets. He had never in his life met a fourteen-year-old without a phone within arm's reach."
    "He circled the grave twice, slow, reading the churned and re-frozen snow. The night's snowfall had smoothed the world to a blank sheet. Whatever tracks had been here were filled and sealed."
    $ note("No cup. No phone. Tracks gone under snow.")
    note_voice "No cup. No phone. Tracks gone under snow."

    if not ch07_button_first:
        "He was straightening from the stone when he saw the button."
        call ch07_scene_button
    else:
        "He looked once more toward Clara's grave, at the small green thing in the snow. It still made no sense. He let it not make sense."

    # --- the car memory ---
    "It was while he was logging the bag by the wall, kneeling in the snow with the girl's schoolbooks in his gloved hands, that the car came back to him."

    scene bg car_night_storm at memory with flash_ice
    play ambient2 sfx_engine fadein 1.0

    "Not as a memory. As a room he suddenly found himself standing in, whole, lit, the heater roaring, the wipers counting, the snow coming out of the black."
    "And the small voice beside him, calm, sad, feeding him a sentence at a time."
    "{i}He doesn't like me having her. He says she makes me weak. He says we won't be able to keep people, where we're going. I don't want to lose her.{/i}"
    "{i}This work of your grandfather's. He tell you where?{/i} — {i}No. He never says where.{/i}"
    "{i}And tonight? He out on one now?{/i} — {i}He said he'd be late. He said he had preparations.{/i}"

    stop ambient2 fadeout 1.0
    scene bg cemetery_dawn with dissolve
    show snow light

    "Samuel knelt very still in the snow."
    "He had sat in that warm car and filed every word of it against George Bennett, brick by brick. Then he had driven the child home and watched her light come on and driven away pleased with himself."
    "And while he did it, the man he was building it against had been—"
    th "No. Stop. That's the grief talking, not the work. The leap that feels like insight and is only guilt looking for somewhere to stand."
    "He did not know George Bennett had done this."
    "He knew a girl had told him, hours before her death, that her grandfather resented her one friendship. That he spoke of leaving. That he was out that very night on unnamed preparations."
    "And now the friend was dead, laid out in the killer's own hand, days before whatever leaving George had planned."
    "He knew what a jury would call that. He knew what he would have called it, in any other town, about any other man."
    "He had been told. That was the thing that would not let him breathe."
    "A frightened child had all but drawn him the map in his own car, and he had folded it up and put it in his pocket, and driven her home to an empty house and a grandfather due back after two, and gone to bed."
    "And Emily Carter had climbed a hill in the dark and drunk something warm and sweet and been laid out in the snow while Samuel Harris slept off a good day's work."
    "The welded door shuddered again. Behind it, very far down, a smaller coffin than this one waited in a smaller grave, and a woman screamed, and Samuel had stood dry-eyed and useless then too."
    s "Later."
    "Under his breath, to no one."
    s "Later."
    "He finished logging the bag. His hands did not shake. That would come later, with the rest of it, on his own time, in the dark, where it always came."

    # ------------------------------------------------------------------
    # The Carters
    # ------------------------------------------------------------------
    stop music fadeout 2.0
    stop ambient fadeout 2.0
    scene bg carter_hallway with fade_slow
    show snow light
    # ART-REQUEST (fulfilled): Carter house — narrow stair and front hallway of a modest Greyvale family home, morning, coats on hooks, boots by the door.
    play music m_aftermath fadein 3.0
    call place("The Carter house — morning")

    "The Carters already knew, in the way that people know, before he ever reached their door."
    "They had woken to an empty bed. Found her boots gone and the front door unbolted. They had been calling her name through the house and then through the streets since first light."

    show lara neutral at right with dissolve
    "Samuel came up their stair with Lara Whitfield a step behind him and his hat in his hand."

    menu:
        "Tell them plainly. Now.":
            "He did not let the stair finish. He looked up at the mother, and she read the whole of it off his face before he had climbed the last step."
        "Let Lara speak first.":
            l "Mrs. Carter—"
            "Lara's voice was gentle and it was not enough. Nothing would have been. Emily's mother looked past her, at Samuel, and read the whole of it off his face."
            "He would not leave it to anyone else. He stepped up beside Lara."

    mrsc "No— no, no—"
    "The sound she made after that was not a word."
    "Samuel had done this more times than he could count. He had a way of standing, a way of speaking, low and level and without flinching, that gave grief something solid to break against."
    "He told them the truth, plainly, because people deserved the truth, and because the lies they told themselves in its place were always worse."
    "He did not say ritual. He did not say poison."
    s "Your daughter is gone. I'm so sorry."
    show lara stern at right
    "The mother had already gone down. Lara had her, on the stair, folding around the sound she was making."
    "It was the father Samuel watched, because the father was the one who had not moved."
    "A big soft-handed man in a vest and unlaced boots, who mended roofs for a living. He heard the words and did not fall and did not weep."
    "He only looked at Samuel with a slow, terrible reasonableness."
    carter "No. She's with Alice. She goes off with Alice sometimes."
    "As though it were a scheduling error. As though, if he were patient and clear, the detective would check his notes and find he had come to the wrong house."
    s "Mr. Carter."
    "Samuel held his eyes and did not let him have the door out of it."
    s "She's not with Alice. I'm sorry. I saw her myself, an hour ago. It's her."
    "He watched the reasonableness go. The exact moment it left the man, the way a lamp goes out, and the thing underneath came up into the face all at once, unhoused."
    "Carter's big useless hands rose a few inches from his sides and hung there, holding nothing. A sound came up out of him that had no shape to it."
    "He took one step toward Samuel, as if the detective were the thing that had done it or the thing that could undo it, and Samuel did not step back."
    "He took the man's weight when it came, the whole grieving bulk of him folding forward, and held him up in the doorway of his own house, because there was no one else to do it."
    s "She didn't suffer long. I'm going to find who did this."
    "Not because Carter could hear it now. Because someday, surfacing, he would need to have been told."
    hide lara with dissolve

    "He learned what there was to learn, gently, in the wreckage."
    "Emily had gone to bed at her usual hour. No, they had heard nothing. No, she had not said she was meeting anyone."
    mrsc "Her phone— it's here. It was on her nightstand. Charging. Where she always leaves it."
    "Her mother pressed it into his hands. The screen was a smiling photograph of the two girls, Emily and Alice, cheek to cheek."
    "She had gone out into the night without it. To a place a mile away, in a storm, at fourteen."
    th "Only one thing takes a careful, frightened, sensible girl out into the dark without so much as her phone. Love."
    th "Someone she trusted asked her to come. Someone she wouldn't refuse."
    $ note("Someone she trusted asked her to come.")
    note_voice "Someone she trusted asked her to come."
    "He held that thought very carefully, the way you hold something with an edge."
    "He left them to Lara and the family that had begun to gather. The aunts, the neighbours, the terrible machinery of a town's mourning cranking into motion."

    # --- the car, Doyle ---
    stop music fadeout 2.0
    scene bg car_day_snow with fade
    play ambient2 sfx_engine fadein 2.0

    "He sat in the car a moment with the smiling phone in an evidence bag on the seat beside him. Two girls, cheek to cheek. Then he started the engine."

    play sound sfx_phone
    show screen phone_call("Raymond Doyle")
    "Doyle called before he reached the square."
    d angry "Tell me it isn't what they're saying."
    "No greeting. The captain's voice had gone past fury into something flatter and more frightened."
    d angry "Tell me I don't have a fourth— Sam, tell me it is not a child."
    s "It's a child. Fourteen. Same method as the priest, same signatures, laid out ritual up at the cemetery, a few plots off the Ward girl's grave. Her name was Emily Carter."
    s "She was the Bennett girl's best friend."
    "The line was silent for a long moment."
    d neutral "The grandfather. The one you've been circling."
    s "His granddaughter told me, last night, that he resented the friendship. That he was leaving town soon and was out that night on— her word— preparations."
    "Samuel heard how it sounded, said aloud, and did not soften it."
    s "I filed it as a controlling old man isolating a kid. Ray, it reads different this morning."
    d angry "It reads like probable cause is what it reads like."
    d angry "A man with cult ties from a village full of missing girls, no alibi, near half these scenes on his handyman rounds, whose own blood sat in your car and told you he was dangerous and about to run—"
    d angry "—and now the one person she said he wanted gone is dead in ground he could've dug. What are you waiting for? Christmas?"

    menu:
        "\"Not yet.\"":
            s "Not yet. I'm waiting to not be wrong."
            "Samuel pulled the car to the curb and stopped, and sat, the engine idling."
            s "Because if I take George Bennett and I'm wrong, the real one walks, and there's a fifth."
        "\"Bring him in.\"":
            s "You're right. It reads like cause."
            "Samuel pulled the car to the curb and stopped, and sat, the engine idling, and heard himself go on anyway."
            s "But if I take George Bennett and I'm wrong, Ray, the real one walks. And there's a fifth."

    d angry "You think I don't know that?"
    "Something broke loose under the fury then, the frightened thing beneath it."
    d angry "The mayor's called me four times before nine, and I can live with the mayor. What I can't live with is the stringer from the city paper who already has the word cult and is maybe three hours from filing."
    d angry "You know what happens the day that runs? It stops being a town, Sam. It becomes a story. A satanic child-killer loose in the mountains while the police sit in the hotel."
    d angry "That is the kind of story that ends careers. Mine first and then yours, and neither of us young enough to outrun it."
    "Samuel said nothing. Through the windshield, the square was filling."
    d neutral "So here's where we are."
    "Doyle's voice dropped, and the drop was worse than the shouting."
    d neutral "You give me a name today, or the day after tomorrow this stops being yours. They send people. A task force. Feds, if the cult angle holds. Strangers tearing that town apart."
    d neutral "And you and me in a room explaining why we sat on a suspect the whole valley could name."
    d angry "You've got probable cause a first-year could stand up in front of a judge. You've got a man the town already convicted. Take him. Hold him. Build it right from inside a cell."
    d neutral "You don't have to charge him today. But you get him off that street."
    s "And if I don't."
    d neutral "If you don't, that street takes him off it for you."
    "Flat now. Certain. A man who had watched it happen before."
    d neutral "They are already saying his name in the square, Sam. I can hear it in the calls, that particular note. A child is dead. They are terrified and they are furious and at last they have a face."
    d neutral "The only thing standing between George Bennett and a rope is you putting him somewhere they can't reach."
    d angry "I would rather he sat in your cell cursing your name for a year than swung off their lamppost tonight. Bring him in, Sam."
    "Samuel looked out through the fogging windshield at the shuttered shops, the church on the far side, the little knots of people gathering in doorways, heads bent together."
    "The low current of a town's fear, finding at last a name to run toward."
    s "I'll talk to the girl first. Then I'll bring him in."
    hide screen phone_call

    # ------------------------------------------------------------------
    # The square — 10 a.m.
    # ------------------------------------------------------------------
    scene bg square_day with fade
    show snow light
    # ART-REQUEST (fulfilled): greyvale_square in grey mid-morning daylight (current asset is dusk) — crowd of 40–50 in coats, church doors open behind.
    play music m_ritual3 fadein 3.0
    play ambient2 sfx_crowd fadein 2.0
    call place("Greyvale Square — 10:04 a.m.")

    "He should have gone the back way. But the square lay between him and the road out to Markou's, and the square was where the town had come."
    "Forty of them, fifty, more coming down the side lanes with their breath rising white. The church doors standing open behind them, and the word {i}child{/i} passing mouth to mouth like a coal too hot to hold."
    "Samuel brought the car to a crawl through them. They turned to look at it, and the thing he had felt building under this town all week finally came up into their faces and showed itself."
    "At the funeral it had been a whisper. {i}Outsider. Why is he here.{/i} It was not a whisper now."
    play sound sfx_thud
    "A palm came down flat on the hood. Not hard, but deliberate, the way you lay a hand on a man's chest to stop him."
    "Samuel braked, because to drive on was to drag someone. And rolled the window down, because a coward rolled it up."

    show leary angry at center with dissolve
    "Kurt Leary, naturally. His face blotched red with cold and with something hotter, and drink on him already at ten in the morning. Men gathered at his shoulder as he bent to the window."
    kl angry "Four. Four now. And a little girl this time, a baby."
    "His voice shook."
    kl angry "A week and more you've been here, mister big-city detective, walking round with your notebook and your cigarettes, and there's four of ours in the ground and not one hand laid on him."
    kl angry "So which is it? You can't catch him? Or you're too busy sleeping in that hotel to try?"
    "A sound went through the crowd behind him. Low. Agreeing. Ugly."
    "Samuel held the man's eyes. A crowd like this fed on flinch; the only thing to feed it instead was stillness."
    s "I'm going to catch who did this. Today, if the day gives me room."
    s "And it'll be because it was done right and it holds. Not because I handed you a face so you could sleep tonight."
    s "You want the wrong man in the ground beside that child? Fast and wrong is how you get a second grave and the real one still out here."
    woman "We know who it is. Everyone knows. That devil up in the trees and his cold little girl, come here from nowhere—"
    crowd "—and the dying started—"
    crowd "—while you drink coffee and he picks us off one at a time—"
    show leary angry at center, shake
    "The voices climbed over one another. The ring of bodies pressed a half-step in."
    "Samuel felt the thing in the crowd change temperature. Felt it stop being fear and start wanting somewhere to go. A door to put its shoulder to."
    "He had stood in the middle of this before. He knew exactly how thin the wall was, and how fast it went."
    s "Go home."
    "He put the edge in it now, the flat cold authority that had turned rooms before."
    s "All of you. It is ten in the morning and there is a family two streets from here that lost their daughter in the night, and you are out here making theatre of your fear where they can hear every word."
    s "Go home. Let me work. You'll have your answer before dark."
    "It was the family that did it. The shame of it. The reminder that the grief was real and near and belonged to someone, while they performed their own out in the cold."
    show leary angry at center
    "Leary straightened. The ring gave."
    hide leary with dissolve
    stop ambient2 fadeout 3.0
    "They did not scatter so much as loosen, sullen, still muttering. Their faces slid by the glass one after another, and the Bennett name was in every one of them, whether the mouth said it or not."
    th "Before dark. I promised a frightened town an answer before dark, the way you promise a screaming child anything to make the screaming stop."
    "And there was exactly one name in the whole white valley to give them."
    "Doyle had been right, and that was the worst of it. This town would have George Bennett before the day was out, one way or the other."
    "The only choice still left to Samuel was whether it happened behind a locked door or at the end of a rope."

    # ------------------------------------------------------------------
    # Markou's office
    # ------------------------------------------------------------------
    stop music fadeout 2.0
    scene bg markou_office with fade_slow
    play music m_office fadein 3.0
    call place("Dr. Markou's office — late morning")

    "Helena Markou was waiting for him at her door, and she had Alice."
    "She had gone and got her herself, Samuel understood. Had heard, the way the town heard, and driven out to the house at the edge of the trees and taken the child before anyone else could."
    "It was what she had refused to do for him with a file, and did without hesitation for a girl: put herself between the child and the world."
    show helena concerned at right with dissolve
    "She met his eyes with a look that was half warning and half plea."
    th "Gently. She is twelve, and her friend is dead. Gently, or not at all."

    show alice cry at left with dissolve
    "Alice sat in the same armchair by the same fire, wrapped in the same blanket. And she was not composed."
    "That was the thing that stopped Samuel in the doorway. Every time he had seen this child she had been still, contained, older than her years. A calm that never broke."
    "It had broken now. She sat small and folded in on herself, knees drawn up, her face blotched and swollen."
    "When she saw him her mouth worked and no sound came, and then the sound came. A raw high hitching thing. The sound of a child who has lost the one warm thing she had."
    "Tears ran down her face and she did not wipe them. Her hands shook. She looked, for the first time since he had met her, exactly like what she was."
    "A little girl whose best friend was dead."
    "Something in Samuel's chest, already cracked, gave a little further."
    s "Alice."
    "He crossed to her, and crouched to her level the way he had learned to, his voice gone low and careful."
    s "I'm so sorry. I am so sorry."
    a cry "They said— Mrs. Markou said someone— that Emily—"
    "Her face crumpled."
    a cry "It's not true. Tell me it's not true."
    "He did not lie to children."
    s "It's true. I'm sorry, Alice. She's gone."
    show alice cry at left, tremble
    "The sound she made then, he would hear for a long time."
    "Helena moved to her and gathered her in. The girl turned her face into the woman's shoulder—exactly the way, Samuel remembered with a lurch, Emily had turned her face into Alice's at the funeral."
    "She cried until the crying wore itself down to shudders. Samuel knelt there and waited, and hated the job, and did it anyway, because there was a killer and there was a clock."
    show alice cry at left
    s "Alice."
    "He waited until her eyes came back to him, red and streaming."
    s "I have to ask you some things. Hard things. And then I'll leave you be, I promise. Can you do that? For Emily?"
    "The name steadied her the way nothing else could have. She nodded, a small fierce nod, and pressed her lips together."
    "Samuel saw her gather herself by force, and mistook it for courage."
    s "Your grandfather. Last night. When I brought you home, his truck was gone— you remember? He was already out."
    a sad "He went after dinner. Before I walked to Mrs. Markou's. He said he had work. He said he'd be late."
    "A breath."
    a sad "I heard him leave. The truck, on the gravel. I always hear the truck."
    "Samuel kept his own voice level, kept the pen still."
    s "And did you hear him come back?"
    "She was quiet a moment. Her eyes moved to the fire, and the flames turned in them."

    menu:
        "Comfort her. Let her take her time.":
            "He laid a hand, lightly, on the arm of the chair. Not on her. Just near. Something solid."
            s "Take your time. There's no wrong answer."
            a sad "Late. Really late. After two— I looked at the clock, because I couldn't sleep."
        "Watch her eyes on the fire.":
            $ notice()
            "He watched her eyes, the firelight moving in them. The tears were real; he had seen enough false ones to know. They ran and she let them."
            a sad "Late. Really late. After two— I looked at the clock, because I couldn't sleep."
            "And when she said {i}after two{/i}, her eyes did not waver. Not a flicker. Not the small search upward that people made for a number they half remembered."
            th "She looked at the clock. She's sure. Grief makes some things very sharp."
            "He heard it as certainty, and let it go."

    "She lifted her wet eyes back to Samuel's, and they did not waver."
    a cry "Why? Why are you asking me about George?"
    "And there it was."
    stop music fadeout 3.0
    "Samuel felt it settle over him, cold and total."
    "A man gone from his house the whole of the murder night—he had seen the empty drive with his own eyes. Home after two. Days from a leaving he had told no one about."
    "Whose own granddaughter had wept in Samuel's passenger seat that he wanted her one friend gone."
    $ note("George out all night. Home after two (per Alice).")
    note_voice "George out all night. Home after two (per Alice)."
    "He would want it corroborated. He would put men on the truck, on the roads out, on the resin a poisoner carried under his nails, and build it the right way, brick by proven brick."
    "But he already knew where every road of it ran, and they all ran to the same door."
    "Somewhere under the certainty a smaller thing tried to be heard."
    th "A careful girl doesn't climb out into a storm at midnight for a grandfather she's afraid of. She goes for someone she loves. Someone she'd open a window for—"
    "Samuel felt it move in him, and reached for it, and it was gone before it had a name. Sunk without trace, the way the wrong-turning instinct in the dark car had sunk."
    "He looked at the shaking, streaming, broken child in front of him, and let it go. Grief was loud in the room, and the work was quiet, and the work said George."
    s "You did the right thing telling me. You've been so brave."
    s "This isn't your fault, Alice. None of it is your fault. Do you understand me?"
    a cry "I want George to come home."
    "A whisper. She put her face back in Helena's shoulder."
    a cry "I just want to go home."
    hide alice with dissolve
    "Over the child's bowed head, Helena Markou looked at Samuel. There was a question in her face, and a dread, because she had seen where his own face had gone."
    h concerned "Detective. What are you going to do?"
    "Samuel stood. His knees ached. Outside the tall windows the light had come up full and grey over the snow, and the town waited under it, afraid."
    "Somewhere in it an old man was cutting wood or fixing a gutter, with no idea that a detective and a frightened town had, in the last hour, quietly agreed on his name."
    s "My job."
    hide helena with dissolve
    play sound sfx_static
    "He let himself out into the cold, and got into his car, and picked up the radio, and called it in."

    # ------------------------------------------------------------------
    # The arrest — a little before noon
    # ------------------------------------------------------------------
    scene black with fade
    pause 1.0
    scene bg bennett_house with fade_slow
    show snow light
    play music m_ritual3 fadein 3.0
    play ambient2 sfx_crowd fadein 3.0
    call place("The Bennett house — 11:48 a.m.")

    "They took George Bennett a little before noon, and the town came up the mountain to watch."
    "Samuel went himself, with Mercer and Lara and two more uniforms behind him in a second car, up the winding road to the tree line where the house sat behind its squared fence."
    "Word of a police convoy climbing the hill had done what four bodies could not quite do. It had given the fear a place to go."
    "They came labouring up the road in trucks and on foot. Thirty already strung along the fence when Samuel stepped out, more arriving every minute."
    "The low sound coming off them was not yet words. But it was well on its way to being words."

    show helena concerned at far_left with dissolve
    "Helena Markou's car stood in the drive. She had brought the girl home an hour past, because the child had asked and asked."
    "And because whatever Samuel's face had told her in that office was a look and not a warrant, and Helena Markou did not tear a grieving child from the last of her family on the strength of a detective's look."
    "She came out onto the step now with her coat half on and her face white, understanding all at once, too late, what that principle had delivered the child home into."

    show george grim at center with dissolve
    "George Bennett opened his door before Samuel reached it, the way he had the last time, as though he had been standing behind it all along."
    "He filled the frame, tall and grey and still, his face set in the hard lines this town had long since decided were a killer's lines."
    "He looked past Samuel at the officers, and past them at the crowd bleeding up his road. The thing that moved behind his eyes was not surprise."
    "It was nearer to recognition. As if something he had been braced against for a very long time had finally, almost restfully, arrived."
    s "Mr. Bennett. I need you to come with me."
    g grim "On what."
    s "We'll talk about it at the station."
    "George's gaze went over Samuel's shoulder to the crowd. The raised phones, the red faces. The men at the front who had already, without deciding to, bent and taken up what the frozen ground offered a hand."
    "Samuel watched a grim arithmetic finish itself behind the old man's face. The arithmetic of a man who had spent a lifetime expecting the worst, and been schooled by it."
    g neutral "You'll want to be quick about it, then. For your sake more than mine."

    scene cg george_wrists with dissolve_slow
    window hide
    pause 2.0
    window auto
    "And he brought his own hands up and held them out before him, wrists together, waiting for the cuffs, before Samuel had said the word."
    "At the fence a phone was already up and filming. The town would have that image by nightfall—the old man offering his hands to the law like he knew the shape of the thing."
    "It would be all the proof they ever wanted."

    scene bg bennett_house with dissolve
    show snow light
    show george grim at right with dissolve
    stop music fadeout 2.0
    show alice sad at left with dissolve
    a sad "Grandpa?"
    "The voice came small from the dim of the hall behind him. Alice stood at the foot of the stairs."
    "Samuel's stomach turned over at the sight of her. A child about to watch this thing happen to the last of her family."
    "George went still. He turned his head, and for one long moment the old man looked at the girl."
    "And Samuel—reading faces was his life, his one true skill—could not read what was in it."
    "Not the fury of the framed. Not the plea of the innocent. Something heavier and more private than either."
    "Something that looked, impossibly, like a question he had carried a long way and was afraid to reach the end of."
    "Then he shut it, the way he shut everything, behind the grey door of his face."
    g grim "Go inside."
    "Rough. Not unkind."
    g grim "Go to Mrs. Markou. Don't watch this."
    hide george with dissolve
    "He turned his back on the child and stepped out into the cold and the rising noise, and did not look at her again."
    hide alice with dissolve

    play music m_ritual3 fadein 1.0
    play ambient2 sfx_crowd fadein 1.0
    "They walked him to the car through a gauntlet of it. The crowd surged and the uniforms held, barely."
    m shaken "Back! Get back— all of you, get back!"
    l stern "Off the road! Off the road, now!"
    "Mercer with his arms spread and his voice gone hoarse. Lara shouting them back a foot at a time."
    play sound sfx_thud
    show vignette red
    "A stone came out of the pack from somewhere and starred the rear window white."
    with hpunch
    woman "Emily! Clara! God sees you— God sees what you are—"
    "George Bennett walked through all of it with his cuffed hands before him and his eyes on nothing. Upright. Silent."
    "Giving them the stillness Samuel himself had given the square. And looking for all the world exactly like the monster they had made of him."
    hide vignette
    "Lara got the car turned and moving, nosing down through the parting, jeering, howling town."
    stop music fadeout 4.0
    stop ambient2 fadeout 5.0

    # --- the curtain ---
    scene bg bennett_house at slow_zoom with dissolve_slow
    show snow light
    play ambient sfx_wind fadein 3.0
    "Samuel stood a moment alone in the churned snow of George Bennett's tidy garden."
    "The trimmed hedges. The cleared path. The order the old man had kept against a world he'd always known was coming for him."
    "He felt no triumph in it at all."
    "Only a certainty, cold and total and correct, that he had done everything exactly right."
    "And under it, quiet and immovable, the sense that something in it was wrong in a way he could not yet find."
    window hide
    pause 2.0
    window auto
    play music m_ritual fadein 4.0
    "Behind an upstairs window, a curtain moved."
    "And was still."
    window hide
    pause 2.5
    stop music fadeout 3.0
    scene black with fade_long
    jump ch08
