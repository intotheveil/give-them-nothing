## Chapter 6 — "So it's you."
## Source: docs/manuscript/ch06.txt, from "Dr. Markou was the one who ended it"
## through Emily's last words at the cemetery. (Alice's aftermath, from
## "Alice caught her before she fell.", opens ch07.)

label ch06:
    call chapter_card(6, "Greyvale — January, 2025")

    # --- Markou's office: the end of the confession (Samuel POV) -------------
    scene bg markou_office with fade_slow
    play music m_ritual2 fadein 2.0
    call place("Dr. Markou's office — evening")
    show vignette

    show helena concerned at midright with dissolve
    show alice neutral at midleft with dissolve

    "Dr. Markou was the one who ended it, in the end."
    "She let the girl finish. Let the last of it settle into the warm room: the fire, the snow at the glass, the two adults leaning toward the small figure in the armchair."
    "Then she closed the folder on her knee with the quiet finality of a woman drawing a blanket over someone asleep."
    h "That's enough for tonight."
    h "You've been very brave, Alice. Braver than you should have had to be."
    "Samuel didn't move for a moment. His pen had stopped somewhere in the last minute and he hadn't noticed."
    "He looked at the child: the composed face, the folded hands, the tea gone cold and untouched at her elbow."
    "Then at Helena. Something passed between the two adults that had no words in it, only the shared weight of what they had heard and could not yet use."
    "He closed his notebook."
    s "You did the right thing. Telling us."
    "Alice nodded, small, her eyes on the fire."
    "Outside, the storm had not eased. It threw itself against the tall windows in long gray sheets."
    "When Samuel stood and looked toward the door, his face changed: the calculation of a man measuring a road."
    h firm "You're not walking her home in this."
    "It wasn't a question."
    s "No."
    "He was already reaching for his coat."
    s "I'll take her. It's on my way back to the hotel. More or less."
    s "That alright with you, Alice? I'll have you at your door in fifteen minutes. Warmer than the last time you made that walk."
    "For a moment the girl didn't answer."
    show alice smile
    "Then she lifted her face to him and gave him a small, tired smile."
    a "Thank you, Detective. I'd like that."
    "Helena walked them to the door. At the threshold she crouched and tucked a stray strand of damp hair behind the child's ear."
    "She murmured something too low for Samuel to catch."
    h sad "{size=-6}You can come to me. Any hour. You understand?{/size}"
    a neutral "I understand."
    "She said it as if she meant it. Or seemed to."
    hide helena with dissolve
    "Then the cold took them, and the warm door closed behind."

    # --- The car ride home (Samuel POV) -------------------------------------
    scene bg car_night_storm with fade
    show snow heavy
    show vignette
    play music m_outside2 fadein 2.5
    play ambient2 sfx_engine fadein 2.0
    show alice neutral at midright, dimmed with dissolve

    "The road out of town belonged to the storm."
    "The wipers kept their steady two-count. The heater roared dry heat into the small lit box of the cabin."
    "Beyond the glass the world had gone to two colors: the black of the pines, and the white coming at them out of it, endless, hypnotic, swallowed under the headlights."
    "Samuel drove with his hands at ten and two and his mind three hours behind him, in a warm office, turning over the four words that mattered."
    th "Finish his work here."
    "Beside him the girl sat with her hands folded in her lap and watched the snow."
    "She hadn't reached for the radio. Hadn't fidgeted, hadn't asked how long, hadn't done any of the small restless things a child does to fill a moving car."
    "She filled it instead with a stillness he found himself aware of, the way you become aware of a held breath in a room."
    th "Twelve years old. I know grown men who came apart in the back of a patrol car. This one sits like she's waiting for a bus."
    th "Don't."
    "That was the part of him that had listened to Helena Markou."
    th "She's a child. You treat a child as a source, you break something you can't fix, and a lawyer buries whatever you get."
    "He knew it. He also had three bodies in a town of not three thousand souls."
    "A grandfather with no past on paper, a village behind him that answered the phone in shrugs."
    "And a girl in his passenger seat who had just used the phrase {i}finish his work{/i} about a man Samuel was quietly, carefully, beginning to build into a shape."
    th "Walk the line. You've walked worse."
    s "You did well back there."
    "Easy. Eyes on the road."
    s "That's a hard thing, saying all that out loud. To me and Dr. Markou both."
    a "She's kind. I trust her."
    s "Good. You should have someone."
    "He let a bend come and go."
    s "This work of your grandfather's. The traveling. He tell you where, this time?"
    a "No."
    a "He never says where. He says it's safer if I don't carry it."
    th "Safer if I don't carry it."
    "Samuel let that one sit, kept his face flat, filed it."
    "It was the kind of sentence a frightened kid parroted from a controlling man."
    "It was also the kind of sentence that meant a man moved when he needed to move, and left no one able to say which road he'd taken."
    s "When does he go? These trips."
    a "At night, mostly. When it's quiet."
    "She was still watching the snow."
    a "He leaves after I'm asleep. Sometimes I hear the truck. In the morning he's back and we don't talk about it."
    $ note("'Safer if I don't carry it.' He leaves at night.")
    note_voice "'Safer if I don't carry it.' He leaves at night."
    s "And tonight? He out on one now?"
    a "He said he'd be late."
    "Her voice didn't change."
    a "He said he had preparations."
    "The word landed the same way it had in the office, heavy and shapeless at once."
    "Samuel felt the old pull of it, the detective's greed for a thing that almost means something."
    th "Preparations. A twelve-year-old wouldn't know what that word could carry."
    "He did. He'd sat across steel tables from men who used it."

    menu:
        "Ask her about Emily.":
            s "You've got people here, though. Friends."
            "He said it before he'd decided to, and kept his eyes on the road."
            "Beside him she stayed exactly as still as before. He didn't look."
            th "Leave her be a second. She's had enough eyes on her tonight."
            jump ch06_car_emily
        "Watch her face in the dash light.":
            $ notice()
            "He glanced at her. Just a flick, road to profile and back."
            show alice neutral at midright with dissolve_fast
            "The dashboard light caught the side of her face. Calm. Composed. The lashes lowered."
            "For a half-second something in him ticked over wrong, some old instinct turning in its sleep."
            "A sense he had no words for, except that a face that still had no fear in it, after the week this child had lived, was a face that—"
            "Then the thing turned back over and slept."
            th "She's a kid. Kids go blank when the world gets too big."
            "He'd seen it in the Mallory children, in the girls in the counselor's office. The ones who couldn't cry because the crying place was already full."
            th "She isn't cold. She's emptied."
            "God knew he understood emptied."
            show alice neutral at midright, dimmed with dissolve_fast
            "The car warmed. The snow came on."
            s "You've got people here, though."
            "Gentler now. He wasn't sure anymore if he was working her or just talking. The two had gone blurred, the way they did when he was tired."
            s "Friends."

label ch06_car_emily:
    s "That girl at the funeral, holding onto you. Emily."
    "For the first time the folded hands moved. A small thing: one thumb passing over the other knuckles, there and gone."
    a sad "Emily."
    "She said it like the name cost something."
    a "She's my best friend."
    s "She's a good one, from the look of her."
    "He kept it light."
    s "George alright with that? Her coming round?"
    "A silence, longer than the others. The wipers counted through it."
    a "He says she makes me weak."
    "She said it finally, quietly, to the glass."
    a "He doesn't like me having her. He says we won't be able to keep people, where we're going."
    a "I don't want to lose her."
    th "And there it is."
    "The whole shape of the man in one child's sentence. A grandfather who broke a girl's ties before he dragged her off into the dark, one town after another."
    "It made him want to put George Bennett in a small room and leave the light on."
    $ note("George resents the friendship (per Alice).")
    note_voice "George resents the friendship (per Alice)."
    "He filed it with the rest, another brick in the wall he was quietly building around the old man."
    "The girl beside him was small and sad and frightened of losing the one warm thing she had."
    "That was what he saw, because that was what he was able to see, with a child in the seat beside him and the other thing in him kept behind its welded door."

    # --- The Bennett house --------------------------------------------------
    stop ambient2 fadeout 2.0
    scene bg bennett_house at night with dissolve_slow
    show snow heavy
    show vignette
    show alice neutral at center with dissolve

    "The house rose behind its fence. He slowed, pulled into the drive, let the engine idle."
    "The garden lay squared and trimmed under the snow, every hedge neat, the path already cleared once and going white again. Order announcing itself before you reached the gate."
    "No truck. The windows dark."
    s "He's not back."
    s "You going to be alright? Alone, till he is?"
    a "I'm used to it."
    "Her hand was already on the door."
    a "I'll go straight to bed."
    s "Alice."
    "She stopped."
    "He held out one of his cards. The second one he'd given someone in this town who was too young for it."
    s "Anything at all. Any hour. You hear the truck, you get scared, you remember something, you call me."
    s stern "Not Markou. Me. Understand?"
    "She took it, and looked at it a moment in the dashboard light, and something crossed her face he couldn't read."
    a "Thank you, Detective."
    hide alice with dissolve
    "She got out. He watched her cross the cleared path, small and straight-backed against the pale garden, and let herself in."
    "He waited, engine idling, until a light came on in a downstairs window. Proof of life. An old habit."
    "Then a moment longer, for no reason he could name, watching the lit square of the house with the snow coming down between them."
    $ note("No truck at the house. Gave her my card.")
    note_voice "No truck at the house. Gave her my card."
    "Then he put the car in gear and drove back toward town, and the wrongness rode with him the whole way, formless, insistent."
    "He spent the drive pinning it on George Bennett, because George Bennett was where all the arrows pointed."
    "And because the other place it might have pointed was a door in Samuel he had welded shut a long time ago, and did not know how to open."
    stop music fadeout 3.0

    # --- The house, later; Alice goes uphill (narration only) --------------
    scene bg bennett_house at night with fade_long
    show snow light
    show vignette
    play ambient sfx_wind fadein 3.0

    window hide
    pause 1.5
    window auto
    "The light went off again twenty minutes later."
    "The house held its heat for a while, and then began, room by room, to give it back to the night."
    "George's coat was not on its peg. The truck was not in the drive."
    "The snow came down over the fence and the trimmed hedges and the cleared path, and began, patiently, to un-clear it."
    play music m_ritual fadein 4.0
    "A little before eleven the side door opened and Alice stepped out into the cold, buttoned to the throat, and pulled the door shut behind her with both hands."
    "She carried a small bag over one shoulder."
    "She stood a moment on the step, her breath clouding, listening to the particular silence of a town gone under snow."
    "Then she went down the path and through the gate, and turned uphill. Away from the road that led to the houses. Toward the darker road that climbed."

    scene bg cemetery_night at slow_zoom with fade_slow
    show snow light
    show vignette
    "She walked without hurry. The cold did not seem to touch her."
    "Where the streetlamps gave out she took a small torch from her pocket and did not use it. Only held it, and let her eyes find the road on their own."
    "It was not far now. A few minutes, no more, to the place she was going."
    "She kept climbing, and the town fell away below her, small and bright and asleep."
    "And ahead the dark shape of the hill waited, with its low wall and its open gate."
    window hide
    pause 2.0
    stop music fadeout 3.0
    stop ambient fadeout 3.0
    scene black with fade_long
    pause 1.0
    window auto

    # --- Emily's morning (Emily POV) ----------------------------------------
    # ART-REQUEST (fulfilled): emily_bedroom_morning — a 14-year-old's small bedroom, sun laying yellow squares on the wall, drawings pinned up, a flat toffee tin on the desk.
    scene bg emily_bedroom with fade_slow
    play music m_title2 fadein 3.0
    call place("The Carter house — that same morning")

    "That same morning, Emily Carter had woken up happy."
    "She didn't always. Since Clara, the nights had been bad."
    "Full of a locker room she'd never actually seen properly, and a face she kept trying to draw and couldn't. Most mornings she woke with her jaw aching from clenching."
    "But that morning the sun was out for the first time in a week. Real sun, laying yellow squares across her bedroom wall."
    "She lay in it for a while like a cat before she remembered to be sad. By then the day had already started being good, and it seemed rude to stop it."

    # ART-REQUEST (fulfilled): carter_kitchen_morning — a warm, bright family kitchen, pancakes, sun through the window.
    scene bg carter_kitchen with dissolve
    "Her mother made pancakes because the sun was out. Her father did his terrible impression of the weatherman."
    "Emily drew a bird in the syrup with the tip of her fork, a fat crooked bird. Her little brother demanded one too, and she gave him a dog."
    "For ten minutes the kitchen was loud and warm and the way it used to be, before the whole town had gone quiet and watchful and afraid."
    show emily smile at center with dissolve
    "At the door her mother held her face for a second, the way she'd taken to doing lately."
    mrsc "You seem brighter. Sleep alright?"
    e "Mostly."
    "Emily leaned into the hand because it was nice."
    e "It's just the sun."
    mrsc "Dr. Elena on Thursday. You'll go?"
    e "I'll go, Mum."
    "She'd said it lightly. She did mean to go."
    "She just didn't think a lady with a soft voice and a box of tissues was going to fix the thing that was actually wrong."
    "It wasn't a thing she had a name for. Only a shape: a cold shape at the edge of everything, that had started the week Clara died and had not gone away."
    eth "Not now. Not on a sun day."
    "She put it out of her mind. She was good at that."
    "It was, her mother sometimes said, her best and her worst quality."
    "That Emily could look straight at a hard thing and decide, out of sheer stubborn hope, to see the softer thing beside it instead."

    # --- School: finding Alice ----------------------------------------------
    scene bg school_corridor with fade
    play ambient sfx_wind fadein 2.0
    "She looked for Alice before first bell, the way she always did."
    "That was the shape of Emily's days and had been for two years: finding Alice."
    "In the yard, in the library, at the end of the corridor by the tall windows where Alice liked to stand, because the light was good and nobody bothered her there."
    "Emily had appointed herself to Alice on the second day of school, when Alice was a stranger, and being a stranger in Greyvale was a kind of crime."
    "She had never once regretted it. Not really."
    "People didn't understand Alice. That was the thing Emily carried like a small hot coal of loyalty."
    "They said she was cold, that she was strange, that she made your skin crawl. Emily had heard all of it and defended her every time."
    eth "They don't know her."
    "They hadn't seen Alice save a cornered girl from bullies with three quiet sentences."
    "They didn't know that Alice never wasted a kind word, so that when she gave you one it was worth ten of anyone else's."
    "They didn't know that Alice had held her at the funeral, and turned her face away from the terrible thing so she wouldn't have to see it."
    "They didn't know, and Emily did, and that was that."

    # --- The coin (memory) --------------------------------------------------
    # ART-REQUEST (fulfilled): the low wall behind Greyvale High in autumn, leaves coming down, no police cars (school_exterior shows the January crime scene).
    scene bg school_wall_autumn at memory with dissolve_slow
    "She thought sometimes of the day she'd given Alice the coin."
    "It had been autumn, the two of them on the low wall behind the school with the leaves coming down."
    "Emily had been going through her tin. She carried it everywhere: the flat toffee tin with the buttons and the pressed leaves and the three foreign coins and the one good marble."
    "And she had come to the old coin, the best one. Bronze, worn so smooth by so many hands over so many years that there was no face left on it at all."
    "Only a blind gold-brown blank."
    show emily smile at midleft with dissolve
    show alice neutral at midright with dissolve
    "She had held it up to the light, and then, without really deciding to, held it out to Alice."
    e "You should have this one."
    "Alice had looked at it a long moment, not taking it, the way she looked at anything offered to her. As though a gift were a small test she had to be sure of."
    a "It's your best one."
    e "That's why."
    "Emily pressed it into her hand and folded her fingers over it."
    "She could not have said, then or after, why it had felt so important that Alice, of all the people in the world, be the one to carry the coin with no face. Only that it had."
    "Alice had turned it over once in her fingers and put it in her pocket."
    a "I'll keep it."
    "Flat and quiet. From her, it meant more than anyone else's tears. And she had, as far as Emily knew, kept it."
    "That was who Alice was, to Emily. The one who kept things."
    "The one who, when you gave her the best thing you had, understood exactly what it had cost you and did not waste it."

    # --- The school day -----------------------------------------------------
    scene bg school_corridor with dissolve_slow
    show alice neutral at midright with dissolve
    "She found her by the windows."
    show emily smile at midleft with dissolve
    e "There you are."
    "It came out on a breath of relief, the way it always did."
    show alice smile
    "Alice turned, and the faint curve came to her mouth that Emily had learned to read as gladness."
    "They walked to class together, and the day folded itself around her the way the days did now: Alice at her side, and the town's fear humming under everything."

    scene bg cafeteria with dissolve
    show emily worried at midleft with dissolve
    show alice neutral at midright with dissolve
    "At lunch she told Alice the true things, because Alice was the one person she could tell them to."
    "The nightmares. Dr. Elena on Thursday. How she still couldn't get Clara's face right on paper, no matter how many times she tried."
    "Alice took her hand across the table, her gray-brown eyes steady."
    "The good memories would hold, she said, if Emily kept them close. And if there were not enough of them, she should go and make more."
    show emily smile

    scene bg school_corridor with dissolve
    show emily worried at midleft with dissolve
    show alice neutral at midright with dissolve
    "Later, in the corridor, Emily said the smaller, uglier thing. The thing she'd overheard at home."
    "That her parents believed George was mixed up in all of it. That it frightened her."
    "Alice had gone quiet at that."
    "She said only that she hardly saw George anymore. That she kept to her room, and he kept to the cold."
    "Emily let it drop. Pressing made her friend go somewhere Emily couldn't follow, and helped no one."
    hide alice with dissolve

    # --- The cold shape -----------------------------------------------------
    stop music fadeout 2.0
    scene bg cafeteria at memory with dissolve_slow
    "The cold shape had only truly moved once, and it had not been that day."
    "Days before, they had been talking about the killings, the way everyone did that winter. Emily had said how frightening it was. That it could be anyone."
    show alice neutral at center with dissolve
    "Alice had answered mild, not looking up from the apple she was turning in her hands."
    a "Not anyone. Only the ones who deserved a closer look."
    "Emily had laughed, because it was the kind of dry, strange thing Alice said."
    "And then the laugh had not quite finished."
    play sound sfx_heartbeat
    "For half a second she had heard the sentence another way, and felt her stomach drop for no reason she could have defended."
    hide alice with dissolve_fast
    "She had pushed it down hard, the way you push a jack-in-the-box back into its case."
    eth "What kind of person thinks a thing like that about their best friend?"
    eth "A disloyal one. A person as ugly as the ones who called Clara names."
    "She had bought Alice a chocolate milk the next morning, to make up for a thought Alice never knew she'd had."
    "She told no one, ever. And refused, flatly and completely, to be the kind of girl that thought would make her."
    stop ambient fadeout 2.0

    # --- The message (Emily's bedroom, night) -------------------------------
    scene bg emily_bedroom at night with fade_slow
    show snow light
    show vignette
    call place("The Carter house — that evening")
    "The message came that evening, after dark, on the cheap phone Emily wasn't supposed to have either."
    play sound sfx_beep
    a "{size=-4}i'm scared, em. george says we're leaving. soon. maybe any day. i can't sleep.{/size}"
    show emily worried at center with dissolve
    "Emily was sitting up in bed before she'd finished reading it. Then more."
    play sound sfx_beep
    a "{size=-4}i keep thinking about clara. nobody got to say goodbye properly. the funeral got ruined, everyone ran, it wasn't finished. it's not right is it.{/size}"
    play sound sfx_beep
    a "{size=-4}i want to go to her. tonight, while george is out. before i'm gone and can't. just us. i don't want to do it alone. will you come.{/size}"
    "Emily read it three times."
    "Outside her window the sun's good morning had gone. The sky had closed over again, and the snow had come back."
    "Somewhere across the dark town Alice was frightened and about to be taken away, and wanted, of all the things in the world, to go and finish a goodbye for a girl nobody else had bothered to mourn."
    "And it was a cemetery. At night. And Emily was the kind of person who checked under the bed at fourteen."
    play sound sfx_heartbeat
    show emily scared
    "For one moment — one — the cold shape was there in the room with her."
    "It had almost a voice. And the voice almost said:"
    eth "{i}Don't.{/i}"

    menu:
        "Go to her.":
            "She didn't listen to it. She was ashamed it had spoken at all."
        "Stay home.":
            "Her thumb hovered over the screen. She could say no. She could say {i}tomorrow{/i}. She could say her parents would hear the stairs."
            "She sat there in the dark with the phone lighting her face, and the cold shape waited with her, patient, almost kind."
            "And then the shame came, hot and total, flooding up over it."
            eth "She's scared. She asked me. Me. And I'm sitting here thinking — what? About Alice?"
            eth "That's not a feeling. That's me being a coward in a costume."
            "She pushed it down, harder than she had ever pushed it, and was ashamed it had spoken at all."

    "You did not leave a person alone with fear like that. Not a person you loved. Not for anything."
    "Not even for a feeling you couldn't explain, and were half sure was just your own cowardice wearing a costume."
    "Alice had come for her at the funeral. Alice had turned her face away from the horror."
    "You didn't get to be loved like that and then not show up."
    e worried "{size=-4}of course. dont be scared. ill be there. i wont let you do it alone.{/size}"
    "Her thumbs were quick and certain, even though her heart was going."
    "She dressed in the dark. She waited for her parents' window to go black."
    "She counted the stairs on the way down and landed on twelve, which was even, so everything would be fine."
    "She brought things, because you didn't come empty-handed to a goodbye."
    "The little drawing she'd done of Clara from memory. Not a good one. She'd never looked at Clara long enough to draw her properly, and that was one of the sad things she kept turning over."
    "And a button from her collection, her second-best: deep green, with a tiny anchor stamped in it, to leave on the grave."
    "A stone was what you left, Alice had told her once. But Emily didn't have a nice enough stone, and a button was more like a present."
    "And Clara had probably not had many of those."
    hide emily with dissolve

    # --- The walk up the hill -----------------------------------------------
    scene bg greyvale_street at night with fade_slow
    show snow light
    show vignette
    play ambient sfx_wind fadein 2.0
    "The town was blue and silent and enormous. Her boots were the only sound in it."
    "She climbed the hill talking herself up it under her breath."
    eth "It's fine. It's just Alice. Ghosts aren't real, and Clara was nice anyway."
    "The houses fell away, and the black gate stood open against the pale slope."
    "Her stomach rolled over slow, and she went through it anyway. Because on the other side of the fear was Alice."

    # --- The cemetery -------------------------------------------------------
    scene bg cemetery_night with fade_slow
    show vignette
    play music m_church fadein 3.0
    "And there she was. A small dark shape among the stones, so still that for one lurching second every ghost story Emily had ever heard came true at once."
    show alice neutral at midright with dissolve_slow
    "Then the shape turned, and it was only Alice, of course it was, her breath a little cloud."
    "Emily's chest went loose all at once. She half-ran the last stretch, weaving between the headstones, and threw her arms around her."
    show emily smile at midleft with dissolve_fast
    a "You came."
    "Alice said it into her hair."
    e "Of course I came."
    "Emily pulled back to hold her by both arms, checking her over the way her mother checked her."
    e "You're freezing, how long have you been out here, you icicle."
    "She was talking too much. She could hear it, the words tumbling the way they did when she was scared and trying not to be."
    e "Okay. I'm here now. Look — I brought a drawing, it's bad, I couldn't get her nose."
    e "And this button, isn't it a good one, the little anchor? I thought we could leave it for her. Is that stupid?"
    a "I think it's exactly right."
    "Emily beamed. She couldn't help it. Alice never said things like that unless she meant them."
    show emily sad
    "They stood a while over the raw new grave three plots along, where the earth was unmarked and no one had yet paid for a stone."
    "Emily pressed the green button down into the snow at the head of it, and said a small goodbye in her head."
    "She found, to her surprise, that the cemetery wasn't frightening anymore. It was sad, and quiet, and almost beautiful."
    "The valley dropped away below the low wall, all the town's little lights far down and small. The clouds had torn open, and there were actual stars."
    e "It's not scary. I thought it'd be scary."
    a warm "Not with you here."
    "Emily bumped her shoulder against Alice's, and Alice let her, which was its own small victory."
    show emily worried
    e "Whatever happens..."
    "Her voice wobbled without permission."
    e "If he takes you — I'll write. Every week. I'll be so annoying you'll beg to come back."
    "Her eyes were stinging, stupidly."
    e "I don't want you to go."
    "Alice looked at her for a long moment."
    "Something moved behind her face, quick and deep, there and gone, like a fish turning under ice."
    a warm "Drink something warm first."

    # --- The cocoa ----------------------------------------------------------
    scene cg cocoa with dissolve_slow
    window hide
    pause 2.0
    window auto
    "She crouched to a flat stone and poured from a thermos, the steam rising up between them into the cold."
    "She pressed the mug into Emily's hands, folding Emily's stiff red fingers around it with both of her own."
    a "You walked all this way. You're frozen."
    "The mug was hot, gloriously hot, and thick and sweet with chocolate the way Emily liked it, and no one else ever bothered to make it."
    "Emily curled around it and breathed it in, and felt the warmth go straight up her arms into the cold frightened place in her chest."
    "She looked at Alice crouched in the snow, having remembered, of everything, the cocoa."
    eth "I have the best friend in the whole world. And I'm never, ever going to let her be alone."
    e "Thank you."
    "And she drank."
    "They talked a while. Emily did most of it. The stars, the letters she'd write, a plan for a code so George couldn't read them."
    "Alice mostly listened, and watched her, and let her talk."
    "The warmth spread through her, lovely at first, an ease sinking into her cold hands and her chest."
    "It was a while before it changed."

    # --- The turn -----------------------------------------------------------
    stop music
    stop ambient fadeout 1.0
    play sound sfx_heartbeat
    "Somewhere in the middle of a sentence about the code, it stopped being the warmth of the cocoa and became too much of itself."
    "A heat that climbed her throat, and turned."
    scene bg cemetery_night at bloodtint with dissolve_slow
    show vignette red
    "The stars smeared. Her mouth had gone strange, thick and far away."
    "She put a hand to the flat stone to steady the tilting world."
    play sound sfx_thud
    "The mug went from her other hand and rang once on the rock, and she barely heard it."
    e scared "{size=-6}Alice... I feel — something's —{/size}"
    show alice cold at center, breathe with dissolve_slow
    "Alice was very close, and very calm."
    "Her hands came up to hold Emily's face, and her eyes did not have any fear in them at all."
    "None."
    play sound sfx_tinnitus
    "And the cold shape that Emily had pushed down all day, all week, for two whole years — the shape she had refused and refused, because loving Alice meant refusing it —"
    "rose up all at once, now that there was no strength left to hold it under."
    "And it finished forming. Finally. Completely. In the last clear second she had."
    "She looked at her friend. Her friend looked back, steady, waiting."
    e "{size=-6}So it's you.{/size}"
    "The world was going."
    a cold "...Of course."
    scene black with fade_long
    window hide
    pause 3.0
    window auto

    jump ch07
