## Chapter Nine — Route Nine.
## POV: Samuel (the road, the aftermath) / George (the dying).
## Violence lives in narration only: bg route_nine, vignette red, black frames.

label ch09:
    call chapter_card(9, "Route Nine — first light")

    scene bg route_nine with fade
    show snow light
    show vignette
    play ambient sfx_wind fadein 1.0
    play ambient2 sfx_engine fadein 0.5
    play music m_ritual fadein 2.0

    "They had stopped the van with a log truck."
    "Samuel saw it as he came down the last bend too fast, the tail of his car drifting on the packed snow before he caught it."
    "A flatbed hauler slewed broadside across Route Nine at the narrowest point, where the road pinched between the cliff wall and the gorge rail."
    "The little white county van nosed up against it, boxed, going nowhere."
    "Behind and around the van the town had come to a stop and become, in the space of a mile, the thing Samuel had watched it deciding to be all night."
    stop ambient2 fadeout 0.5
    "Fifty of them already out of their trucks in the road, and more spilling down the bends on foot."
    "The sound they made when he cut his engine and stepped out was not the sound of a crowd. A crowd argues. This had gone past argument."
    "This was the low, unanimous, working sound of a thing that has made up its mind and only wants room."

    # The frozen tableau — held, then shattered.
    stop music fadeout 1.0
    window hide
    scene cg route_nine with dissolve_slow
    call cinematic("route_nine_breath")
    window auto
    "For one held second before he moved — the second the mind steals out of any catastrophe to photograph it — the whole of it stood still in front of him like a painting hung in a cold gallery."
    "The log truck broadside and black against the snow. The little white van nosed against it, meek as a lamb run up against a wall."
    "The gorge falling away on the right into blue nothing and the cliff rising sheer on the left, and strung between them, filling the pinch wall to wall, the town."
    "Fifty dark shapes on a white road under a white sky, their breath going up off them all together in a single low cloud, like something the crowd itself was exhaling."
    "Trucks slewed at angles down the bends behind them with their doors flung open. A dropped scarf, red, very bright, trodden into the snow near the van's front wheel."
    "And over it all the enormous mountain morning, indifferent, beautiful, the light coming up clean and gray on a thing about to happen that the light did not care about at all."
    "Samuel would carry the frame of it the rest of his life, composed and terrible and still — the last still second before the road came alive."
    window hide
    pause 1.5
    play ambient2 sfx_crowd
    play music m_ritual3
    scene bg route_nine with hpunch
    show snow light
    show vignette
    window auto

    "He read it in the first three seconds, the way he read everything, and everything he read was bad."
    "Poole and the other county man were still on their feet, but only just — backed against the van's cab, hands up, shouting the words that had turned crowds in easier towns and turned nothing here."
    "The log truck was no accident. Someone had thought of it, moved it, slewed it across the pinch in the dark and waited."
    th "This didn't boil over on the road. It was built in the night. In the same black hours I spent on the phone begging for men, for the dark, for the mine track. No, and no, and no."
    th "I said it out loud. Half this town has a truck."
    "He had seen the shape of this before it had a shape. He had simply not been allowed to stop it."
    "The cage in the back of the van still held — that was the whole of the good news, and it would not hold long."
    "Four men were already at the rear doors with a tire iron and the honest patience of people who have all the time in the world and God on their side."
    "And they were not strangers. That was the thing that went through him coldest as he shoved off the car and into it: he knew these faces."
    "The baker who'd sold him thin coffee his first morning in town. The hardware man who had told him, unasked, that he wouldn't want George Bennett for a neighbor."
    "The young mother who'd chased two children round the hotel dining room while Samuel ate his chicken pie, who stood now at the edge of the pack with her mittened fists at her sides and her face wide open, her grief finally given somewhere to go."
    "Ordinary people. Good people, most of them, on any other morning of their lives."
    th "There's no monster on this road to fight. There's only a town."
    "Samuel did the arithmetic and did not like the sum, and went in anyway, because the sum did not change what he was."
    s angry "POLICE."
    "He put the whole of his chest into it, the voice that had emptied the square, and it opened a seam in the crowd three bodies deep and no more. He drove into the seam."
    s "This is a police prisoner in a police vehicle and every hand that touches it hangs. You hear me? Every hand."
    s "I have your faces. I have the phones you've been so proud of. Step back."
    "For a heartbeat it almost worked. Hands hesitated; faces turned to him uncertain, their bodies remembering a whole lifetime of doing what the law told them."
    "He got four steps closer to the van on that heartbeat. Close enough to see George Bennett's face through the mesh of the cage window, gray and still and turned toward the noise."
    "Close enough to see that the old man was not afraid."
    show leary angry at right with dissolve_fast
    kl angry "He's protecting him! The outsider's protecting the other one!"
    hide leary with dissolve_fast
    "And the heartbeat broke."
    "It did not break like a wave. It broke like ice, all at once and everywhere, and the seam Samuel had opened closed around him."
    "The working sound became a roar, and the roar had his name in it now too: the big-city detective who drank coffee while their children died and now stood between honest people and the devil they had cornered."
    show vignette red
    play sound sfx_thud
    with vpunch
    "A shoulder caught him. Then a fist, high on the cheekbone — not aimed, just the overflow of a body with nowhere to put itself."
    "The cold road tilted and he got a hand on the van's wing mirror and held himself up by it and kept shouting, because shouting was the last tool he had left."
    play sound sfx_thud
    scene bg route_nine at bloodtint with flash_red
    show vignette red
    "A boot caught him low in the ribs, and something there went from bone to glass — a bright wire of pain up his side with every breath after."
    "He breathed around it and did not stop."
    "He saw Poole go down, dragged sideways off his feet into the mass, gone."
    play sound sfx_thud
    "He saw the tire iron come back and swing, and heard the county van's rear lock give with a sound like a bone."

    menu:
        "Go for the man with the tire iron.":
            $ chose("m09_fight", "iron")
            "He got one hand on the man's collar and hauled him back with the whole strength of an arm that had once been stronger, and for a second the man came, stumbling—"
            "—and then two more had Samuel by the coat and the arm and the back of the neck."
        "Go for the van doors.":
            $ chose("m09_fight", "doors")
            "He threw himself at the rear of the van, shoulder first, to put his own body across the doors. He got a hand flat on the cold white panel—"
            "—and then two more had him by the coat and the arm and the back of the neck, and peeled him off it like tape."

    play sound sfx_thud
    with vpunch
    "The road came up, and he was on his knees in the churned red-brown snow with boots all around him."
    "The world reduced to shins and the smell of diesel and sweat and the sweet copper thing underneath it that he already knew, on his knees, was coming."
    "He got up."
    "A man half his age would have stayed down and been forgiven for it. Samuel Harris, forty-seven and smoke-lunged and grieving and now cracked along one side, got his boots under him and stood back up."
    th "He's in that cage because I put him there. I will not kneel in the snow and let them finish it."
    "He was three men from the rear doors when they got them open."
    "They took George Bennett out of the cage the way the sea takes a thing off a deck — not one pair of hands but twenty, a single hunger with too many arms."
    "The old man came out into the gray morning and the cold and the noise and did not fight it, and did not beg, and did not make a sound."
    "Samuel saw it in pieces, over shoulders, between heads, the way you see the worst things."
    "George on his feet a moment, upright even now, even here, his cuffed hands still before him, his gray head above the crowd for one second like a man standing in a river."
    play sound sfx_thud
    scene black with flash_red
    "He saw the first blow take him from the side. He saw the head snap and the old man go down out of sight into the mass."
    "And the mass folded inward over the place where he had been — boots and arms and the long animal note of a hundred people doing at last the thing they had come up the mountain to do."
    scene bg route_nine at bloodtint with dissolve_fast
    show vignette red
    "Samuel, fighting toward it, screaming words that had lost their shape, understood the thing under the horror."
    "They believed they were doing justice. Not a riot. A court. They had weighed the outsider and found him wanting, and were passing the sentence with the clean conscience of the certain."
    th "I've seen that certainty somewhere close. This week. Where—"
    "He could not place it, and the not-placing sat in him like a splinter driven deep."
    "Then he stopped thinking anything at all, and only fought."
    "He shoved and hauled and clawed his way into the mass toward the place the old man had gone down, and got one hand on a gray sleeve — one hand, for half a second—"
    play sound sfx_thud
    with vpunch
    "—before it closed, and three of them took him by the arms and the coat and the broken side of him and flung him back out of it the way a body spits a splinter."
    "He went down hard on the road on the cracked rib, and the white sky wheeled over him."
    stop music fadeout 4.0
    stop ambient2 fadeout 4.0
    scene black with fade_slow

    # ------------------------------------------------------------------
    # George (POV) — the dying. Very slow. Silence at the end.
    # ------------------------------------------------------------------
    pause 1.5
    "They had him on the ground now."
    "George Bennett, who had spent forty years teaching himself and everyone he loved that the world was a machine for grinding the weak to nothing, discovered at the very end that he had been right all along."
    "And that being right was no comfort at all."
    play sound sfx_heartbeat
    "The first boots came in, and his body did the thing he had trained it across a whole hard life to do."
    "It made no sound."
    "That was the deepest lesson the cold house had ever put in him, older than the doctrine, under the words and holding them up."
    gth "You do not give them your pain. Pain shown is pain doubled. A man who cries out has handed the world the one thing it ever wanted from him."
    "He had knelt on bare boards and learned it from a father who had learned it from his. He had put it into his own son with a cold and patient hand he had genuinely believed was love."
    "Now the town of Greyvale, which knew nothing of Driftwood or the sea or the catechism, stood over him in a mountain road and tried to beat that same thing out of him one blow at a time."
    "And found, exactly as the boy on the boards had found, that there was nothing under the hardness left to break."
    "He curled, and covered, and took it, and gave them nothing. Some far cold part of him, even now, with his own blood in his mouth, was almost proud."
    gth "The machine came for me. I always knew it would. A man who feeds a machine does not get to walk out of it clean."
    "He had fed it his whole life. He had fed it the boy."
    "He had stood at a rain-streaked window and watched it begin to take a five-year-old, and had reached in, once, the single time in all his years, and dragged something back into the light."
    "And even that, the one mercy he had ever managed, he had done too late and too small, and the machine had only smiled and gone on turning, and taken her the long way round instead."
    play sound sfx_thud
    "So it was fair, said some old accountant deep in him, unbothered, as a heel came down on his hand and broke it against the road."
    gth "Only the sum coming right. Only the past, catching up the way the past always does, on its own patient legs."
    "A boot found his ribs and something deep inside gave way, and the pain of it was very large and very far off at the same time — a catastrophe in a house he had already moved out of."
    stop sound fadeout 2.0
    "And then there came a moment, near the end, when he stopped feeling the blows entirely."
    "It was not peace. He had never believed in peace; it was one of the soft lies the weak told themselves to get through the night."
    "It was only distance — the body carrying on somewhere down below while the part of him that had done all the watching floated up and off and looked down at it, unhurried."
    gth "The town is weather. You don't hate weather. You only, sometimes, fail to live through it."

    play music m_ritual2 fadein 4.0
    scene bg driftwood_front_room at memory with dissolve_slow
    "He thought instead, with the strange wide calm of the almost-gone, of the boy on the bare boards, the thin careful voice going through the catechism while the tears ran and the mouth kept on."
    scene bg driftwood_yard_rain at memory with dissolve_slow
    show rain
    "He thought of the girl in the yard in the rain, and his own shirt drying her hair, and the forbidden whispered thing that he had believed, that one night, would be enough to save her."
    g neutral "{i}You do not have to be what they make you.{/i}"
    scene bg truck_night at memory with dissolve_slow
    "He thought of a truck on a coast road in the dark and a small silent shape beside him with rain-wet hair, watching the black go by."
    "He had told himself the whole way that he was carrying her out of danger. He had only, in truth, been carrying her — and the thing that was already in her — further down the same road that had made them both."
    scene black with fade_long
    stop music fadeout 4.0
    "And then he thought, because there was no longer any reason under heaven not to, the thought he had refused for two years to think all the way to its end."
    "He let it arrive whole, because a dying man owes the truth nothing and can afford it at last."
    window hide
    pause 2.0
    window auto
    gth "It was her."
    gth "The teacher. The shopkeeper. The priest. The little friend laid out in the snow. My girl."
    "The soft thing he had smuggled out of the rain had grown up wearing his own doctrine like a second skin."
    "He had felt it since the first grave and refused to feel it. He had built the whole vast architecture of his denial across two years for this single reason:"
    "To finish the thought was to know that he had won. That the cold house had won. That everything he fled had ridden out of Driftwood in the seat beside him, small and patient and quiet and his."
    "And having thought it, whole, at the very last, he did the one thing he had left in the world to do with it."
    "He kept it."
    window hide
    pause 1.5
    window auto
    gth "Give them nothing."
    "His own words, forty years old, the only inheritance he had ever succeeded in passing down — and the only one that had ever, at the very end, come out of him as something like a mercy."
    "He would not say her name. Not to the detective who had all but gone on his knees for it, not to the county, not to the God the priest had died still believing in, not to the fists."
    "He would carry the whole of it down into the dark: the name, the knowing, the two years, the entire ruined truth of what he had made and what he had failed to unmake."
    "And she would go on being an ordinary girl who had lost her grandfather. The only thing he had ever given her that the cold house had not first gotten to and spoiled: his silence, entire, unbroken, forever."
    "He told them, all of them at once — the boy on the boards, the girl in the rain, the two sisters on the far coast, the whole ruined line of them running back and back into the salt dark—"
    gth "I'm sorry."
    gth "I'm sorry. I gave you nothing."
    gth "I never did have anything else to give."
    "Then the distance became the dark."
    "And George Bennett, who had judged and been judged, who had built a machine with his own hands and been ground to nothing inside it, went down into that dark having said, aloud, to the very end, not one single word."
    window hide
    pause 4.0

    # ------------------------------------------------------------------
    # Aftermath (Samuel POV)
    # ------------------------------------------------------------------
    scene bg route_nine with fade_long
    show snow light
    show vignette
    play ambient sfx_wind fadein 3.0
    window auto
    "They were already breaking apart when Samuel reached him."
    "He had read enough of these to know: the thing that comes over a crowd the instant the deed is done, the tide going out as fast as it came in."
    "It left them blinking and separate and human again on the cold road. No longer a court. Only forty or fifty men and women standing too close to a thing they had made together and could not now believe."
    "The working roar had emptied out into a silence broken only by someone, somewhere back in the pack, beginning to weep."
    "Samuel went through them, and this time they let him, parting, stepping back, their faces already rearranging themselves toward the story they would tell tonight and for the rest of their lives."
    "He went down on his knees in the red snow beside what they had left."
    call mature_show("george_road")
    "There was no help to give. He had known there would be none since the bend, but his hands did the things anyway — the checking, two fingers at the ruined throat."
    "To not do them was to accept it one second sooner than the body forced him to."
    "George Bennett was gone. He had gone, Samuel thought, some while before his heart had. There was a stillness in the wrecked face that had arrived ahead of death — the look of a man who had finished a thing."
    "Samuel knelt there with his own blood running warm down his cheek and the old man's blood going cold under his knees, and for a while he did not do anything at all."
    window hide
    pause 2.5
    window auto

    call mature_hide
    play music m_aftermath fadein 4.0
    "Then he stood up, because he was the only law on that road, and the law does not get to grieve until the scene is closed."
    "He found Poole alive against the gorge rail, sitting in the snow with his nose broken sideways and one hand pressed to his ribs, the other county man beside him worse but breathing."
    play sound sfx_static
    "He got on his radio with a hand that had started, now, at last, to shake, and he called it in."
    s hurt "Officers down. Death in custody, Route Nine. The transport is lost."
    "The flat clipped grammar of the job, because the grammar of the job was the only thing holding him upright, and he knew it, and he clung to it."
    "Sirens somewhere below, climbing. Mercer's voice breaking on the radio. The mountain going about its enormous indifferent morning while a town crept back to its trucks and would not meet his eyes."
    "He did the work. He held the scene. He would not let them move the body, though a dozen hands offered, suddenly gentle, suddenly ashamed."
    "He photographed what had to be photographed with his own phone, the county's camera lost somewhere under the log truck. Where his hands shook he braced them against his knees and did it anyway."
    $ note("George Bennett — dead in custody, Route Nine. 50+ present.")
    note_voice "George Bennett — dead in custody, Route Nine. 50+ present."
    "Then he took the names."
    "He walked the line of them where they stood scattered along the road, and he looked into each face until it looked away and gave up its name."
    "The baker gave his, and could not stop the apology that came with it."
    vo "I only came to watch, Detective. I swear before God I never laid a hand—"
    "Maybe it was even true. It did not matter. Samuel wrote him down."
    "The hardware man gave his name to the snow at his own boots and would not lift his eyes."
    "And the young mother from the hotel dining room, when Samuel reached her, was weeping too hard to stand straight."

    menu:
        "Look her in the eye.":
            $ chose("m09_mother", "eye")
            "He made himself hold her face. It was the face from the dining room, the one that had shushed two children over breakfast, and it would be in his notebook now beside the others."
            "She turned it up to him, ruined and open."
        "Look at the notebook.":
            $ chose("m09_mother", "notebook")
            "He kept his eyes on the page. He did not trust what his face would do."
            "She turned her ruined open face up to him anyway, and he heard it in her voice."

    woman "I don't— I don't know what happened."
    woman "I don't know what happened to us."
    "Samuel, who an hour ago had wanted to hate every soul on this road and found that now he mostly could not, said only, quietly—"
    s hurt "Your name."
    "And she gave it, and he wrote it down."
    show leary ashamed at right with dissolve
    "Even Leary gave his — small now, the drink gone out of him, a middle-aged man on a cold road who had helped to kill a person and was just beginning to understand it."
    hide leary with dissolve
    "Samuel wrote them all down, every one, in his cramped hand."
    "It was mostly theater and he knew it. No county in the world hangs a whole town, and the story by nightfall would be a tragic loss of control, a community pushed past its bearing."
    "But he wrote them down anyway, because it was the last thing left he could do for George Bennett — and because the alternative was to kneel back down in the snow and not get up."
    $ note("Names: the baker (sorry, sorry). Hardware man. The young mother. Leary. Forty-odd more.")
    note_voice "Names: the baker (sorry, sorry). Hardware man. The young mother. Leary. Forty-odd more."

    play sound sfx_phone
    "Doyle reached him on the phone as the ambulance crested the bend."
    show screen phone_call("Raymond Doyle")
    d worried "Sam."
    "Just his name, at first. Doyle had heard. Doyle had heard everything."
    d "Sam, are you—"
    s shocked "He's dead, Ray."
    "His own voice sounded very far away and very calm."
    s "They took him off the van on Route Nine and beat him to death in the road, and I was ten feet from him, and there were fifty of them, and I could not stop it."
    "A long silence on the line. When Doyle spoke again his voice had gone thick."
    d "Poole's already on to the county saying you went in alone against the whole road. Sam — nobody is going to lay this on you—"
    s "I don't care what they lay on me."
    "And he found, saying it, that it was true. Under the grief and the guilt and the blood drying on his face there was a third thing rising, cold and clear and level, that he did not yet have a name for."
    s hurt "Ray. Listen to me. Something's wrong."
    d "Sam—"
    s "I mean it."
    "He was looking down at George Bennett as he said it, at the ruined, finished face, at the cuffed hands that even now had never come apart."
    s hurt "He never said a word. All night. I gave him every door, Ray. I gave him the girl, I gave him his own life, and he sat there and took the rope over one sentence that would've saved him."
    s "And I have been telling myself all night that's a guilty man protecting himself."
    "He wiped the blood out of his eye with the back of his wrist."
    s hurt "Guilty men don't do that. I've been doing this thirty years. Guilty men talk. Guilty men deal. Guilty men give you the other fella."
    s "This man had a way out and looked at it and chose to die instead, and there is only one kind of man I've ever known do that."
    d "...And what kind is that."
    "Samuel was quiet a moment, on his knees again now, though he did not remember kneeling, beside the body in the reddened snow. The certainty settled into him the way cold settles, from the outside in."
    stop music fadeout 3.0
    window hide
    pause 1.5
    window auto
    s hurt "A man protecting somebody."
    if picked("m07_doyle", "notyet"):
        th "I told Ray 'not yet' in that car. He heard 'soon'. So did I."
    elif picked("m07_doyle", "bringin"):
        th "'You're right,' I told him in that car. The truest wrong thing I said all winter."
    hide screen phone_call
    $ note("He never said a word. Guilty men talk.")
    note_voice "He never said a word. Guilty men talk."
    $ note("A man protecting somebody.")
    note_voice "A man protecting somebody."
    call pin_prompt("c09_protecting")

    scene bg route_nine at slow_zoom with dissolve_slow
    show snow light
    show vignette
    play music m_aftermath2 fadein 4.0
    "Far below them the town was going home. Above them the pines held their snow."
    "And somewhere down in the white valley a twelve-year-old girl was being minded by a kind woman who believed she was comforting an orphan."
    "While up on the road Samuel Harris knelt bleeding beside the innocent man he had helped to kill, and felt the first thin crack open in the floor he had stood on all week."
    "And through it, where his certainty had been, nothing but cold air, and a long way down."
    stop music fadeout 4.0
    stop ambient fadeout 4.0
    scene black with fade_long
    pause 1.5

    jump ch10
