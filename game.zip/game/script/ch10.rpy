## Chapter Ten — Samuel POV. The silence; Martha; the Bennett house; the receipt;
## Vale Cross; Thomas; "Someone has to."

label ch10:
    call chapter_card(10, "Greyvale — January, 2025")

    # --- The killings stop -------------------------------------------------
    scene bg greyvale_street with fade_slow
    show snow light
    play music m_aftermath fadein 3.0
    play ambient sfx_wind fadein 2.0

    "The killings stopped, and that was the thing that damned George Bennett more thoroughly in death than any evidence had in life."
    "For three days after the road, Greyvale held its breath and nothing happened."
    "No teacher went off a roof. No shopkeeper folded over his counter. No scrap of torn paper turned up on any threshold."
    "The snow came and stopped and came again, and the town crept out from behind its doors and found the world unchanged and safe."
    "And it drew from that safety the only conclusion a frightened people ever draws: that the thing which had hunted them was in the ground, and they had put it there, and it had been right to do."
    "By the second day the fires in the square were gone, and the shame had begun its quiet work of turning into a story they could live inside."
    "A hard winter. A terrible strain. A community pushed past bearing."
    "By the third day a man could buy his bread in the bakery and not lower his voice. It was over. Everyone said so."
    "The proof was the silence, and the silence went on and on."

    call place("Greyvale — the third morning")
    "On the third morning he walked the square, because he could not sit in the hotel room any longer, and what he saw there was worse than the fires had been."
    "The oil drums were gone. The snow had been swept off the church steps."
    "A man was up a ladder rehanging a shutter the crowd had torn loose the day of the road, whistling, unhurried."
    "In the bakery, when Samuel went in for coffee because a man has to be somewhere, the baker served him."
    "The same baker whose name Samuel had written down in the red snow three days ago. Whose {i}I never laid a hand, I swear before God{/i} was still logged in Samuel's notebook."
    "The baker" "There you are, Detective. Coffee, and a roll while they're warm."
    "The baker" "Heading home soon, I expect? Now the bad business is finished."
    "Not a flicker in him. Not a shadow."
    "The man had helped kill someone in a road and had folded it away already into {i}the bad business{/i}: a thing that had happened to the town, rather than a thing the town had done."
    "And he had gone back to his ovens with clean hands and a clear morning ahead."
    s tired "I expect I'll be off shortly."
    "Samuel paid, and stood in the doorway with the warm cup going cold in his hand, and watched the square be a square."
    "Children. A dog. A woman shaking a rug."
    "And he felt, without yet being able to say why, that this, exactly this, the whole ordinary machinery of a town forgetting, was the thing someone had been counting on all along."
    th "Someone was counting on this."

    # --- The report he can't sign -----------------------------------------
    scene bg hotel_room with fade
    show vignette
    stop ambient fadeout 2.0
    play music m_office fadein 2.0
    call place("The Greyvale Hotel — the third night")

    "Samuel did not believe it, and he could not have told anyone, in those three days, exactly why."
    "He should have been gone. Doyle had all but ordered him home."
    "{i}You did what could be done and more, Sam. Come back, write it up, let the county close it out.{/i}"
    "And the county wanted nothing so much as a tidy file. Suspect identified, suspect deceased, matter concluded. The awkward business of the road to be handled by a different office and a softer word."
    "There was a shape the whole world wanted this to take, and the shape was closed."
    "All Samuel had to do to be free of Greyvale forever was sign his name under the story everyone had already agreed to tell."
    "He sat in his hotel room with the report half-typed on his phone, his cracked rib taped tight under his shirt, a cigarette burning down unregarded in the ashtray."
    "He could not make his thumb move to the last line."
    $ note("Report unsigned.")
    note_voice "Report unsigned."

    "Because a dead man had thrown a rope back into a flood. That was what would not leave him."
    "He had turned it over a hundred times in three days and it would not wear smooth."
    "He had given George Bennett every door a man could be given. His freedom, his granddaughter, his life."
    "And George had sat in a warm room and looked at each door and chosen the rope."
    "Samuel had thirty years of watching guilty men to tell him that guilty men do not do that."
    th "Guilty men talk. Guilty men trade. Guilty men, cornered, give you somebody else."
    "Only one kind of man takes the rope over one sentence that would save him. Samuel had said the words aloud on the mountain, with the old man's blood going cold under his knees."
    th "A man protecting somebody."
    "The killings had stopped. Fine. He made himself think it through the way he would have made a junior think it through: cold, from the outside."
    th "What does a stopped killing prove? It proves a killer stopped. It doesn't prove which killer."
    "A thing can stop because you have buried it. Or because it has finished what it came to do."
    "Or because it has learned, from watching a town tear a man apart in a road, exactly how safe it now is."
    "The silence the town was calling proof was the one piece of evidence in the whole affair that pointed nowhere at all."
    "He picked up the cigarette, found it dead, lit another."
    "He was not going home. He had known it, he realized, since the road: known it under the grief, under the guilt, in the cold clear third place that had opened in him kneeling by the body."
    "He was going to reopen a closed grave and look, properly this time, at a man he had helped to kill."
    "He was going to find out what George Bennett had died rather than say."
    th "I owe him that. It's the only thing left I can pay."

    # --- Martha ------------------------------------------------------------
    scene bg hotel_room_day with fade
    play music m_title2 fadein 2.0
    call place("The next morning")

    "Martha called him the next morning, because Martha always knew, the way she had always known, when the shell was cracking."
    play sound sfx_phone
    show screen phone_call("Martha Johnson")
    ma concerned "You're not back."
    "No hello."
    ma concerned "Raymond says you were supposed to be back two days ago. Raymond says there's nothing left up there but paperwork and a town that ought to be ashamed of itself."

    menu:
        "Tell her the truth. There's more.":
            s tired "There's a little more than paperwork."
            ma smile "There's always a little more than paperwork with you."
        "\"Just paperwork, Martha.\"":
            s tired "It's just paperwork, Martha. A few signatures."
            "The lie came out practiced and smooth, and fell flat on the line like a dropped plate."
            ma concerned "Sam. There's always a little more than paperwork with you. Don't you try that voice on me."

    "A pause. He heard her sit down, heard the kitchen chair take her weight, and something in him eased at the sound the way it always did."
    "The small proof that somewhere a room existed with her in it."
    ma concerned "I heard what happened, Sam. On the road. I heard you went in."
    s hurt "I didn't stop it."
    ma concerned "That is not what I said."
    "Her voice had gone quiet and hard, the voice she used when she meant to be heard."
    ma concerned "I said you went in. Fifty of them and you the only soul on that mountain who tried."
    ma concerned "You listen to me, Samuel Harris, because I know how your head works, and I know you're sitting in some cold little room right now stacking this on the pile with all the rest and calling it your fault."
    "A breath."
    ma concerned "A man died who maybe shouldn't have. That's a weight. Carry it honest."
    ma concerned "But don't you dare use it to prove the old thing to yourself. Don't you dare."
    "He didn't answer. Outside the window the square lay white and ordinary, a woman crossing it with bread under her arm, a town that had gone back to being a town."
    ma concerned "You still there?"
    s soft "I'm here."
    ma concerned "The old thing. That you couldn't save the one that mattered. That caring's a thing that gets taken from you, so you'd best not do it."
    ma concerned "Thirteen years you've believed it, and it's a lie, Sam. It was always a lie. And one of these days it's going to be the thing that gets you killed."
    "He heard her swallow."
    ma smile "Come home when you can. There's food that won't keep and a chair nobody's sitting in."
    ma concerned "And Sam — the thing you're chasing up there. If it's a true thing, chase it. You were always better than all of them at the true things."
    ma concerned "Just don't chase it to punish yourself. Chase it because it's true."
    hide screen phone_call

    "When she'd rung off he sat a while with the phone warm in his hand, the shell cracked another quiet inch by the plain unwanted fact of her."
    th "You were always better than all of them at the true things."
    "He had spent thirteen years certain the caring was the weakness. She had spent them just as certain it was the only thing that had ever made him worth a damn at the work."
    "He had never had to choose between them, because the not-choosing was safe, and safety was the whole of what he had built."
    "He understood, sitting there, that the case out in the snow was going to choose for him now, one way or the other, and that he was not going to like the cost of the answer."
    "Then he put out the cigarette, and took the tape tighter around his ribs, and went to find out what a dead man had been hiding."

    # --- The Bennett house ---------------------------------------------------
    scene bg bennett_house_day with fade_slow
    show snow light
    play music m_ritual2 fadein 3.0
    play ambient sfx_wind fadein 2.0
    call place("The Bennett house — afternoon")

    "The Bennett house had been searched once already, on the day of the arrest, in the fast and certain way of men who already know what they will find and only want it confirmed."
    "Samuel had read that search in the file and known it for what it was. A formality. Boots through rooms, looking for the shape of a killer, and finding — because they were looking for it — the shape of a killer."
    "Nobody had searched it the other way. Nobody had walked those rooms asking what an innocent man would leave behind."
    "That was what Samuel had come to do. He had the sealed-scene key from a county clerk who had handed it over gladly, glad to have the awkwardness of the Bennett house be somebody else's for an afternoon."

    scene bg bennett_front_room with dissolve
    # ART-REQUEST (fulfilled): Bennett front room, abandoned — cold dead hearth, no food on the table, shutters closed, every book squared; gray afternoon. (bennett_dining shows a live fire and porridge, which contradicts "the fire was long dead", so we hold on the exterior.)
    stop ambient fadeout 2.0
    "The house met him with the particular silence of a place whose people are not coming back. The fire was long dead. The cold had got into everything."
    "It was, even now, even empty, the most orderly house he had ever stood in."
    "Every tool on its hook, every book squared to the shelf edge, the woodpile stacked to a plumb line under its tarp. A whole life kept in rigid trim against a world the old man had never for one day trusted."
    "Samuel stood in the front room and let it talk to him the way scenes talked to him when he was patient."
    "And what it said, under the story of the killer, was a different and quieter thing."
    th "A man who was always ready to leave."

    # ART-REQUEST (fulfilled): Alice's bedroom in the Bennett house — narrow bed made tight, shelf of schoolbooks, worn Tom Sawyer, a child's drawings (bird, long-eared dog) pinned up; cold winter afternoon light.
    scene bg alice_bedroom with dissolve
    show vignette
    "He found the girl's room first, and stood in the doorway of it a moment, and did not go in."
    "It was an ordinary child's room. A narrow bed, made tight. A shelf of schoolbooks and, tucked at the end, softer-spined, a worn copy of {i}The Adventures of Tom Sawyer{/i}."
    "Drawings, a few, pinned up. A bird. A long-eared dog. Done by some other child's hand, and kept."
    "Nothing out of place. Nothing hidden. Nothing that was not exactly what it appeared to be."
    "The room of a twelve-year-old girl who had lost, in the space of a week, her only friend and the last of her family, and who was tonight asleep in a stranger's spare bed with none of it left."
    "Samuel felt the old pull come up in him, hard. The thing he had spent thirteen years walling off: the pull toward a child who needed a wall between her and the world."
    "And he let it come, this once, because Martha had told him to and because he was too tired to fight it."
    th "Whatever else I find in this house, that girl is going to need somebody to stand between her and what happens next."
    th "George knew it. That's why he wouldn't talk. He was standing between her and something, right to the end."
    "He shut the door softly, the way you shut a door on someone sleeping, and went to work on the rest."

    # --- The workshop: interactive search ------------------------------------
    scene bg bennett_workshop with fade
    play music m_office fadein 2.0
    call place("The workshop, behind the trees")

    "He found it in the workshop, behind the trees, where the arrest-day search had logged {i}tools, sundry{/i} and moved on."
    "George Bennett had been good at this, the way he had been good at everything that kept him and the girl alive."
    "But Samuel had been finding hidden things for thirty years, and the cold clear place in him was patient now. Methodical. Almost calm."

    $ ch10_searched = set()

label ch10_workshop_search:
    menu:
        "Where would a careful man hide the thing that mattered?"

        "Search the shelves." if "shelves" not in ch10_searched:
            $ ch10_searched.add("shelves")
            "Tins of screws sorted by gauge. Chisels in a rack, edges oiled. He lifted every tin and ran his hand along every board. Nothing behind them but plank and frost."
            jump ch10_workshop_search

        "Search the woodpile." if "woodpile" not in ch10_searched:
            $ ch10_searched.add("woodpile")
            "He unstacked the top courses, one split log at a time, and stacked them back to the old man's plumb line. Wood, and cold, and the smell of resin. A woodpile was the first place anyone would look. George would know that."
            jump ch10_workshop_search

        "Look under the workbench." if "bench" not in ch10_searched:
            $ ch10_searched.add("bench")
            "He got down on his knees, careful of the rib. The floor beneath the bench was swept clean."
            "But the back of the bench sat a little too far forward from the wall. Two inches. A careless man would never notice the depth."
            th "Two inches is a lot of room, if you build it right."
            jump ch10_workshop_search

        "Knock on the back panel.":
            if "bench" in ch10_searched:
                "He reached in under the bench and knocked along the back panel, hand's width by hand's width."
            else:
                "He went along the walls knocking, hand's width by hand's width, listening, and found nothing until he got down under the workbench and knocked along its back."
            play sound sfx_thud
            "The knock came back hollow."
            jump ch10_workshop_found

label ch10_workshop_found:
    "It took him an hour, all told. Behind a false back he found by knocking: a fitted compartment a careless man would never have built and a hunted one always would."
    "Inside it, a canvas duffel, packed."
    "He drew it out and opened it on the bench and stood over it a long time."
    "Clothes for two. A man's and a child's, folded with the same rigid care as everything else, sized for winter."
    "An envelope, thick, of cash. Used notes, non-sequential, the patient savings of a cash-only life. More than a handyman banks, and none of it in any bank."
    "A second envelope of documents he'd need a warrant and a week to make sense of. He did not need either to read the shape of them."
    "The papers a man carries when the name he is using has to be left behind with the house."
    "A folded road atlas. When he opened it the route was there, penciled faint, running south and west and off the edge of anywhere Samuel knew."
    "It did not go back toward Driftwood. It went away from everything."
    $ note("Packed bag for two. Cash. Papers. Route away from everything.")
    note_voice "Packed bag for two. Cash. Papers. Route away from everything."

    scene bg county_lot with fade
    # ART-REQUEST (fulfilled): George's pickup impounded in the county lot, grey winter afternoon; full fuel cans lashed under a tarp in the bed.
    call place("The county lot")
    "And in the truck, when he checked it after — the impounded truck in the county lot, that no one had thought to look at as anything but a killer's vehicle — the tank was full."
    "There were two more full cans lashed in the bed under a tarp."
    "The whole thing sat there fueled and ready like a horse saddled in a stall, waiting for a rider who was three days late and now was never coming."
    $ note("Truck fueled + two cans.")
    note_voice "Truck fueled + two cans."
    "Samuel stood in the cold with the packed bag in his mind and felt the first plank of the closed case give under his weight."
    th "A killer doesn't run."
    "That was the thing, simple and enormous. Whoever had done these things had done them like a mission. Patient, ritual, righteous."
    "A man on a mission does not pack a bag for two and fuel a truck and pencil a road off the edge of the map. A man on a mission stays. He finishes."
    "Fanatics do not flee mid-sermon. Hunted men flee. Frightened men flee. Men running from something flee."
    "George Bennett, in the last week of his life, had not been a man settling in to kill. He had been a man about to run for his life, and the girl's, and had been three days too slow."
    th "Running from what?"
    "And under the thought, cold, the splinter he could not place turned over once and would not let itself be seen."

    # --- The receipt: interactive cab search ---------------------------------
    "The bag told him George Bennett was a hunted man. It was the truck that told him George Bennett was innocent."
    "It did so in the ordinary handwriting of a fuel pump, because the past leaves its traces whether a man wants it to or not, and the deepest secret in the world cannot stop a machine from printing the time."
    "Having looked at the fuel, he did the thing thirty years had made a reflex and nobody else had bothered with: he searched the cab the way you search the cab of a man whose movements you actually want to know."

    $ ch10_cab = set()

label ch10_cab_search:
    menu:
        "Where does a cash man keep his life?"

        "The door pockets." if "doors" not in ch10_cab:
            $ ch10_cab.add("doors")
            "A pencil stub. A folded rag. A tire gauge. In the passenger door, a child's hair tie, dark blue, worn thin. He held it a moment and put it back."
            jump ch10_cab_search

        "Under the seat." if "seat" not in ch10_cab:
            $ ch10_cab.add("seat")
            "Under the seats, under the mats, in the gap where the seat met the console where small paper things go to die. Grit. A bent nail. Nothing printed, nothing kept."
            jump ch10_cab_search

        "The glovebox.":
            jump ch10_receipt

label ch10_receipt:
    "George Bennett kept his receipts. Of course he did. A man who trusts nothing keeps a record of everything."
    "And a cash man especially, a man with no card statement to reconstruct his life from, keeps the little printed proofs of where his money went."
    "There was a rubber-banded roll of them in the glovebox. Months of them. Fuel and hardware and feed."
    "Samuel sat in the cold cab with his taped rib aching and went through them one by one in the gray afternoon light."
    stop music fadeout 3.0
    "Near the middle of the roll, he stopped."
    window hide
    pause 1.5
    window auto
    "A diesel receipt. Thirty-one liters."
    "A station called Vale Cross Services. A lonely pump-and-shop on the far side of the gorge where the mountain road met the county highway."
    "Better than an hour from Greyvale by the only road that joined them. Twenty-five miles as the crow flew, and the crow could not drive."
    "And the date on it was the date Emily Carter died."
    play sound sfx_heartbeat
    "And the time stamped under the date, in the small honest type of a machine that has never in its life told a lie or protected anyone, was 11:52 p.m."
    $ note("Vale Cross Services — 31 L — 11:52 p.m. — night of E.C.")
    note_voice "Vale Cross Services — 31 L — 11:52 p.m. — night of E.C."
    "Samuel sat very still. He knew the window. He had built the window himself."
    "Out of the medical examiner's estimate, and the snow on the body, and the cooling, and the girl's own testimony. {i}I heard him leave. I heard him come home after two.{/i}"
    "Emily Carter had been walked to a cemetery and given a poisoned cup and laid out in the snow between eleven and half past midnight. Tightest, the examiner had said, around midnight."
    "At 11:52 that night, George Bennett's truck had been twenty-five miles away on the wrong side of the gorge, taking on diesel at a lonely pump."
    "He could not have been in both places. No one could. The road did not allow it. The clock did not allow it."
    th "George Bennett did not kill Emily Carter. He was buying fuel to run."
    "Samuel did not put the receipt back in the roll. He took an evidence sleeve from his coat and slid it in and sealed it."
    "He wrote the date and the place and his own initials across the seal in a hand that had gone very steady, the way it always went steady when the rest of him had begun, somewhere underneath, to shake."
    "This did not go back in a glovebox in a county lot, where a tidy office that wanted the case closed could lose it by accident."
    "It went in his breast pocket, over the taped rib, and it stayed there."

    # --- Vale Cross --------------------------------------------------------
    scene bg mountain_road_dusk with fade_slow
    play ambient2 sfx_engine fadein 2.0
    play music m_outside2 fadein 3.0
    "Samuel drove out to Vale Cross that same afternoon, because a receipt is a piece of paper, and a man who has just watched a town kill an innocent over pieces of paper wants more than paper."
    "The road took him an hour and ten, the gorge dropping away black beside him the whole way."

    scene bg vale_cross with fade
    stop ambient2 fadeout 2.0
    play ambient sfx_wind fadein 2.0
    show vignette
    call place("Vale Cross Services — far side of the gorge")
    "The station was exactly what the receipt had promised. A single island of light in a great deal of dark. One pump island, one sleepy attendant, one camera bolted under the eave."
    "The attendant was a boy of maybe nineteen, and he remembered."
    "You did not forget much out there on the graveyard shift. A face was an event, and a face on a night like that one, with the whole mountain snowed in, was an event you kept."
    att "Old fella. Sure."
    att "Big, gray, didn't talk. Paid cash — counted it out exact, which you don't see."
    att "Filled his tank and two cans in the bed, and stood there while it ran. Out by the pump, not in the warm. Just... standing. Watching the road he'd come off of, back toward the pass."
    "He frowned, remembering."
    att "Thought at the time he looked like a man waiting for something to catch up to him."
    s "You'd have footage."
    att "I mean... I'm not really supposed to — the owner, he..."

    menu:
        "Ask him. Plainly.":
            s tired "I know. I'm asking anyway. A man died because nobody looked. I'd like to look."
            "The boy studied him, the taped way he held himself, the tired face. Then he nodded, slowly."
            att "...Yeah. Okay. Back here."
        "Lean on him. Quiet certainty.":
            s "It's in the back office, I'd guess. Let's go and have a look."
            "Samuel did not raise his voice. He had learned thirty years ago how to be given the thing he had no paper to demand: a quiet certainty, a way of making the giving feel like the natural course of the world."
            "He was already walking. The boy found himself following."
            att "...It's — yeah. Back here."

    "They stood together in the cramped back office, and the boy scrubbed the file back through its cold hours until a shape came up out of the gray."
    "George Bennett. Nineteen seconds of him."
    "Standing at the pump on the wrong side of the mountain at 11:51 at night, the timestamp ticking in the corner. Alive and alone and unhurried."
    "The diesel running into his tank, while an hour's hard road away, in a cemetery he could not possibly reach, a girl he was going to be hanged for was being laid out in the snow by somebody else's hands."
    $ note("Footage: G.B. at the pump, 11:51. 25 miles from the cemetery.")
    note_voice "Footage: G.B. at the pump, 11:51. 25 miles from the cemetery."
    "Samuel watched the nineteen seconds four times."
    "The boy watched him watch it, and something in the detective's face made him go quiet and stop offering to help."
    s "Copy it. The whole hour, not just the nineteen seconds. Timestamp and all."
    "He put a drive from his own pocket on the desk, and watched the boy do it, and took the drive."
    "He wrote the boy's name and the station and the date in his notebook, against the day someone would tell him none of this had ever existed."
    "He was not going to leave the one proof of an innocent man's innocence on a hard disk in a shed on the far side of a gorge, to be wiped in ninety days when the loop came round."
    s soft "Thank you."
    "Then he got back in his car, and sat in the island of light with the engine off and the cold coming in through the glass, and did not drive anywhere at all for a long while."

    # --- An innocent man was dead ------------------------------------------
    scene bg vale_cross with dissolve_slow
    show vignette
    stop music fadeout 3.0
    pause 1.0
    s hurt "An innocent man is dead."
    "He made himself say it plainly, sitting there in the dark, because the mind will do anything to avoid a sentence like that, and his had already begun to reach for the softenings."
    th "You couldn't have known. The evidence was overwhelming. You tried to stop the road."
    "He took each softening as it came and set it aside, because he had never in his life allowed a witness to hide behind a softening, and he would not allow himself."
    "An innocent man was dead. He had put him in the cell that made him a target."
    "His arrest, his case, his certainty, had handed a frightened town the face it needed, and the town had done the rest."
    "George Bennett had gone into the ground guilty of nothing but the crime of being unlucky enough to be strange in a place that was afraid."
    "That was on Samuel. Not only on him — on Doyle, on the county, on the paper, on fifty pairs of hands in a road — but on him, first and most."
    "Because he was the one who was supposed to be better than all of them at the true things. And this time, in the one place it mattered, he had not been."
    $ note("George Bennett did not kill Emily Carter.")
    note_voice "George Bennett did not kill Emily Carter."

    "The old grief came up to meet the new one, the way it always did, the way water finds water."

    # --- Thomas ------------------------------------------------------------
    scene black with fade_slow
    play music m_aftermath2 fadein 3.0
    "He was thirty-four again, and it was a different winter, and the coffin was so small the man from the funeral home had carried it under one arm."
    "The way you carry a parcel. The way you carry nothing at all."
    "Thomas. Eleven weeks old."
    "He had gone down for his morning sleep in a warm room that smelled of milk and had simply, in the ordinary quiet of it, not woken up."
    "There was a word for that. An acronym, four clean letters the doctors said in the gentle careful voice they kept for the thing they could not explain."
    "As if a word that fit on a form could hold what had happened."
    "Samuel had stood in the hospital corridor and listened to the four letters and understood, with a detective's terrible clarity, that no one had done this."
    "That there was no one to find, no door to kick, no hand to put the cuffs on."
    "That the world had simply reached into the one warm room he had and taken the one thing in it, for no reason, and would not be answering questions."

    scene bg cemetery_day at memory with dissolve_slow
    show rain
    "And at the grave, three days later, in the cold, Claire had gone down onto her knees in the wet dirt and howled."
    "A sound he still heard. A sound with no bottom to it. Her hands in the earth, as though she could dig the box back up."
    "Every other soul at that graveside had wept. Her mother. His own mother. The priest whose voice broke on the words. All of them undone, holding one another, letting it out into the rain."
    "And Samuel had stood a little apart from all of it, dry-eyed, upright, his hands at his sides, and watched the small box go down into the ground, and had not wept."
    "Could not. Had felt the grief come to the door of him, enormous, and had felt something in him meet it there and hold the door shut."
    "He had understood, standing in the rain while his wife screamed his son's name into the mud, that he had made a decision he would never be able to unmake."
    "That a man who let that door open would die of what came through it. And that he intended to live."
    "Claire had looked up at him once, from her knees, her face ruined, and seen him standing there with his dry eyes and his straight back."
    "Something had gone out of her face when she looked at him that never came back into it."
    "The marriage was over from that moment, though it took two more years to admit it, because a woman cannot stay married to a wall, however good the wall's reasons."
    "That was the day Samuel Harris learned the lesson he had spent thirteen years refusing to unlearn: that to love a thing was to be handed, someday, the unbearable bill for it."
    "And that the only safe man was the man who never signed."

    scene bg vale_cross with dissolve_slow
    show vignette
    "He had run his whole life on that arithmetic since. And here was where it had brought him."
    "To an island of light on a mountain road, having failed, again, catastrophically, to protect the very thing he had told himself he was too careful to lose."
    th "Caring is the weakness."
    "So said thirteen years of him."
    "{i}Caring was the only thing that ever made you good,{/i} said Martha. And said, from further back, a woman kneeling in the dirt he had not been able to kneel in beside."
    "He did not know which of them was right. But he knew the case had stopped being about George Bennett."

    # --- Steered -------------------------------------------------------------
    play music m_ritual fadein 3.0
    "Because if George had not done it — and George had not done it, the clock did not lie — then someone had."
    "Someone was still out there in that white valley. Someone who had walked a teacher onto a roof and folded a shopkeeper over his counter and dropped a priest in front of his church and laid a girl of fourteen in the snow."
    "And who had done one more thing besides, the cleverest and coldest thing of all."
    "Had reached into all of it and arranged every piece so that it pointed, patiently, unmistakably, at George Bennett."
    "The notes in the cult tongue George's people spoke. The killings at the sites George's handyman rounds had touched. The preparations, the leaving, the whole shape of a strange secretive man."
    "Handed to Samuel not as evidence he had dug up, but as evidence he had been given. A trail laid down for a detective to follow."
    "And he had followed it like a good dog, all the way to a rope."
    play sound sfx_tinnitus
    th "I was steered."
    $ note("I was steered.")
    note_voice "I was steered."
    "The knowing of it went through him cold and total."
    "Every arrow that had ever pointed at George had been placed by a hand that knew exactly what a detective's eye would leap to."
    "And that hand had known the movements of these victims, and the language of that dead cult, and the private history of the Bennett house."
    "It had been close enough to all of it, unseen, to reach into the case itself and lay the trail down clean and patient and pointing one single way —"
    "The thought reached its edge, and there, at the edge, it stopped."
    "It stopped the way a man's foot stops at a drop in the dark, some older sense throwing out a hand before the mind has seen the ground fall away."
    "There was a shape at the center of it. He could feel the whole apparatus of the frame turning around a single point, the way a wheel turns around a hub."
    "And every time his mind moved toward the hub it slid off, baffled, and landed somewhere safe and wrong."

    menu:
        "Look at the center of the wheel.":
            $ notice()
            "He made himself turn toward it. For one second the hub almost had a shape: small, and quiet, and sitting very straight in his passenger seat, gray eyes on the dark road —"
            "And then the shape was gone, slid out from under his looking like a coin under ice."
        "Look away.":
            "He let it go. He was too tired to chase a shape he couldn't see."

    "He was tired. He was hurt. He had watched a man beaten to death and not slept since. He told himself these things."
    "And under them the truth was simpler and worse: that the hub of the wheel was small, and quiet, and twelve years old, and had wept in his passenger seat."
    "And that Samuel Harris had a place in him worn exactly to the shape of a child, that no evidence on earth could make him look straight at."
    "So he did not look at it. He looked, instead, where thirteen years had taught him to look, and what he found there was not suspicion but its terrible opposite."
    "Duty."
    th "George died protecting her."
    "That was the thing his mind put in the empty place instead of the truth."
    "George Bennett had taken the rope over one sentence, and the only thing on this earth a man like that would die to shield was the girl."
    "George had known something was coming for her — the cult, the past, the thing he'd run from — and had died keeping it off her."
    "And now George was gone, and the girl was alone in a stranger's house, and there was no one left in the whole valley standing between that child and whatever her grandfather had been so afraid of."
    th "Someone has to."
    "He felt the decision close in him like a hand, warm and certain and thirteen years overdue: the worst decision of his life, wearing the face of the first good one."
    th "I couldn't do it. Not for him. But someone has to."

    # --- Down into the valley --------------------------------------------------
    scene bg mountain_road_dusk at night with fade_slow
    show vignette
    play ambient2 sfx_engine fadein 2.0
    play music m_title2 fadein 3.0
    "He started the car."
    "Far off down the mountain the lights of Greyvale lay scattered and small in the dark, an ordinary town gone back to sleep, believing its nightmare buried."
    "And somewhere among the lights a kind woman was sitting up late over a sleeping child she thought she was protecting."
    "Samuel Harris turned the car toward them both, hollow and resolved, and drove down into the valley to look after the one thing in it he should have been most afraid of."
    stop ambient2 fadeout 3.0
    stop music fadeout 3.0
    scene black with fade_long
    pause 1.0

    jump ch11
