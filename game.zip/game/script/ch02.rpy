## Chapter Two — Samuel's POV. Greyford, New Year's Eve 2024 -> Greyvale, January 3rd 2025.
## Source: docs/manuscript/ch02.txt
## Samuel is the camera: never show the samuel sprite in this chapter.

label ch02:
    call chapter_card(2, "Greyford — New Year's Eve, 2024")

    # --- The precinct --------------------------------------------------------------
    scene bg precinct_records with fade_slow
    play music m_office fadein 2.0
    call place("States Police Department, Greyford Division — morning")

    "The Greyford Division spent the morning of New Year's Eve being scrubbed for luck. Cleaners worked the bullpen with mops and a lemon-and-lavender solution."
    "Officers traded plans for the night over the smell of it — family dinners, quiet drinks, bar crawls that ended in regret."
    "A small Christmas tree stood forgotten in the corner, its lights washed thin in the daylight, an ornament or two hanging crooked."
    "None of it reached the records office at the end of the corridor. That room had belonged to Detective Samuel Harris for thirteen years, and it smelled of it."
    "Old smoke, standing in a haze the cracked window did nothing to move."
    "He sat with the year's final report in one hand and a cigarette going in the other. He was not, whatever the room suggested, a man his work had beaten down."
    "He was the best reader of people the division had — the one they brought in when a suspect wouldn't break or a story wouldn't hold."
    "And everyone who mattered knew, too, that he had asked for this desk. Records. The one corner of the job where the only things a man had to read were numbers."
    "He had walked into strangers' worst days for a living until, at some point he never named to anyone, he decided he had done enough of it."
    "Since then he had been, by every measure the department kept, exceptional and quiet and no trouble to anyone."

    "A knock. He didn't look up. It came again, and then a throat cleared, and he let the silence run one more beat — an old habit, making the room wait."
    "Officer James Crown stood in the doorway, neat-haired and pressed, with the careful straightness of a young man determined to be taken seriously."
    "Samuel had him read before he'd finished stepping in: the boy wanted his paperwork done today, and was too polite to say so and too anxious to hide it."
    s "It's here, James."
    "He lifted the folder from the corner of the desk where it had sat waiting."
    s "I'll have it filed before I leave. You didn't need to come all this way."
    "Relief crossed the young man's face, and he worked to keep it off."
    jc "Thank you, sir."
    s "Plans tonight?"
    jc "My parents. And my fiancée."
    s "Good. That's where you should be. Go on."
    "He meant it, and let the boy see that he did."
    "James went. Samuel crushed out the cigarette, sat a moment with his hand flat on the last page of the year, then got up for more coffee, because the alternative was to keep sitting there."

    "Two women from another floor broke off their talk in the kitchen to wish him a happy new year. He gave it back with a nod."
    "He read them both without meaning to — one of them newly unhappy about something at home, the whole of it plain in the way she held her cup."
    "He disliked, the way he always did now, how little the reading cost him and how seldom it did anyone any good."
    "Back in the office he lit another. He had never cared for the new year: too much manufactured warmth, too much empty time."
    "Administration had spent a month pushing him to take the leave he'd let stack up, as though rest were a thing a man could be ordered into."
    "So he worked instead. It was what the room was for. It was, if he was honest, most of what he was for now."
    "A man holding a great deal of chaos in order with nothing but ink and routine, and asking for no more than that."

    # --- Doyle --------------------------------------------------------------------
    scene bg precinct_records at night with fade
    show vignette
    "By evening the building had thinned to silence. The clock ticked past eight when another knock rattled his door."
    s tired "Come in."
    show doyle neutral at center with dissolve
    "Captain Raymond Doyle stepped in, broad-shouldered, his fifties showing in the heavy lines of his face. He fanned the air in front of him."
    d "God, Sam. It's like breathing a chimney in here. One of these years it's going to be you I'm writing the report on."
    "Samuel gave a low laugh."
    s "Ray. What brings you down here?"
    d "Just to wish you a happy new year. And to tell you it's late. You should go."
    s "Happy new year, Ray. I'll be on my way soon enough."
    d "Good man."
    hide doyle with dissolve
    "Doyle clapped the doorframe lightly and left. Samuel rubbed a hand through his graying hair, the gesture more nervous than weary."
    "He shuffled the files and cups into some semblance of order, slipped on his coat, and pocketed the nearly empty pack of Marlboros."
    "Without a glance back, he left the department behind."

    # --- The apartment ------------------------------------------------------------
    scene bg apartment_samuel with fade_slow
    show vignette
    call place("Apartment 44 — 8:40 p.m.")
    "His building met him with the strange silence of overcleaned spaces. Marble polished to a mirror, the mirror wall a little too bright, a little too honest."
    "Lemon and lavender, the same as the precinct. The annual ritual — less tradition, he thought, than a way of pretending order could be renewed with a mop and bucket."
    "From the higher floors, music and laughter bled through the ceilings. The sounds of company, family. A distant joy that seemed meant for other people."
    "At the door of 44 the smell hit him — roasted meat, garlic, onions, something home-cooked. His shoulders eased before he realized it."
    s "Martha?"
    ma "Who else would it be, you dumb fool? A burglar with a New Year's Eve mood who decided to make you dinner?"
    show martha smile at center with dissolve
    "Samuel smiled — one of the rare, real ones."
    "Martha Johnson came out of the kitchen wiping her hands on a dish towel. Heavyset but sturdy, warmth and authority both, dark fuzzy hair framing her round face like a halo she'd never bothered to tame."
    ma "You're late. Food's almost gone cold."
    s "I was working. Raymond passed by, wished me a happy new year. Told me to get the hell out of there."
    ma "Good man. He probably saved you from drowning in your own smoke."
    ma "You're the smartest fool I know, Sam. Too smart for this smoke, too foolish to stop it."
    "She gave the stew a final stir. The table was already set, a plate waiting, cutlery laid straight. She set the pot within reach, steam rising thick and fragrant."
    ma "That's dinner. Enough to last you through the night."
    s soft "Thank you, Martha."
    "She untied her apron and headed for the door. Just before she reached it, she stopped, one hand resting on the frame."
    show martha concerned
    "Her voice changed — no longer playful, but steady, serious, almost maternal."
    ma "Dear, try to do something different tomorrow. Go on a trip. See something new for once."
    ma "I'm sick and tired of watching you live on coffee, smoke, and whatever garbage you drag in from across the street. You need a change."
    "Samuel didn't answer. He sat still, eyes on the floor. The words stung, not because they were wrong, but because they were true."
    "A man his age, hardened, disciplined, sitting like a boy being scolded. The silence stretched until he lifted his head and broke into a small smile."
    s "Happy New Year, Martha. To you and your family."
    "Her expression softened, though sadness lingered in her eyes."
    ma "Happy New Year, Sam."
    hide martha with dissolve
    "The door closed behind her, and the apartment fell quiet once more."
    "The kitchen was still warm, rich with the stew. But he didn't sit. He never did. Martha knew it, though she pretended not to. Her meals were left like offerings, mostly untouched."
    "He poured another coffee from the pot she'd set ready, sat heavily on the sofa, and switched on the television — background more than anything."
    "He lit another cigarette and let the smoke seep slowly from his lungs."

    # --- Claire -------------------------------------------------------------------
    play sound sfx_phone
    "That was when the phone rang. He exhaled, close to a sigh, and leaned across the table for it."
    "One glance at the screen told him all he needed to know. Claire. Of course it would be her."
    show screen phone_call("Claire")
    "He answered but didn't speak."
    cl "Hello, Sam."
    "No warmth, no edge either — just flat calm. Behind her, the faint spill of life: cheerful voices, a room full of people, children laughing. He swallowed hard."
    s "Hey, Claire. Checking on me again? You need to stop that."
    cl "Yeah. Something like that. How are you, Sam?"

    menu:
        "Tell her the truth.":
            s "I'm..."
            "{i}Alone. Sitting in the smoke. The stew going cold on the table.{/i} The words were right there."
            "He heard the children laughing behind her, and the truth went back where he kept it."
            s "I'm fine. Just finished my stew. Planning to rest, maybe sleep early."
            "The lie came out anyway, smooth and practiced, as though it had been waiting its turn."
        "Give her the practiced lie.":
            s "I'm fine. Just finished my stew. Planning to rest, maybe sleep early."
            "A lie, smooth, practiced. He never touched the stew."

    s "How about you? How are the kids? Mark?"
    cl "Everyone's doing fine. I was—"
    s "I'm glad. Really. But I've got to go. I'm tired."
    "A pause."
    cl "Of course. Sam..."
    "Silence."
    cl "It's okay, Sam. You need to let go."
    "More silence. His grip tightened on the phone. Then a burst of laughter — forced, loud, wrong."
    s "You know we're not married anymore, right? You don't have to say things like that. Go now. Happy New Year."
    cl "Yes. Happy New Year. Take care, Sam."
    s "You too, Claire."
    hide screen phone_call
    "He lowered the phone, stared at it a moment, then slipped it into his pocket. The television light flickered across his face."

    # --- The nursery (memory) -----------------------------------------------------
    stop music fadeout 3.0
    "The apartment seemed larger when it was quiet. Too large."
    "The children's laughter from Claire's call lingered, sharper now, echoing against the walls of his memory."
    scene black with dissolve_slow
    play music m_aftermath fadein 3.0
    "It pulled him back to a smaller space, warmer, cluttered with toys and blankets. A nursery. The faint, powdery smell of baby lotion."
    "The soft weight of a child in his arms, no heavier than a loaf of bread, but alive, real, everything."
    "The curve of an infant's cheek. Fingers curling instinctively around his thumb."
    "A sound — half yawn, half sigh — escaping lips still learning the world."
    window hide
    pause 2.0
    window auto
    "And then nothing. Just silence, like the one in his apartment now."
    "Thirteen years had passed, yet the grief sat where it always had, untouched by distance."
    "His marriage had cracked beneath it. His every habit was built around keeping the wound covered. But the wound never closed."

    scene bg apartment_samuel with dissolve_slow
    show vignette
    "Samuel rubbed his face, forcing the thought back down, and drew on the cigarette deeper, letting the smoke burn away the edges of memory."
    th "Work was easier. Work was safer. Work was all that was left."
    "The cigarette burned low until the heat bit into his skin. He hissed and dropped it into the ashtray." with hpunch
    "He reached for his pack. Empty. He sighed, slipped on his coat, and stepped out."

    # --- The walk -----------------------------------------------------------------
    scene bg city_street_snow with fade
    show snow light
    show vignette
    play ambient sfx_wind fadein 2.0
    play music m_title2 fadein 3.0
    call place("Greyford — 9:30 p.m.")
    "The street was still, the snow falling in a thin veil, coating the sidewalks in a fragile carpet of white."
    "Around him the neighborhood glowed. Strings of colored bulbs blinked; silhouettes shifted behind thin glass; children darted past curtains."
    "The collective pulse of a city breathing into a new year. Samuel moved through it apart, his presence quieter than the snow itself."
    "The mini market stood at the corner, its neon sign buzzing faintly. A bell chimed above the door."
    "The young man at the counter nodded. Early thirties. The type who worked holidays for the extra pay."
    "Patchy beard, hair cropped close to hide the thinning. Long nails on one hand — guitarist's nails, or something close. The kind of man with no plans later but to sleep."
    "Samuel studied him for a moment, then looked away. Four packs of Marlboros on the counter. Money changed hands. No more words than necessary."
    "Outside, he tore open the first pack. The warning met him in bold type: SMOKING KILLS. A picture of a hospital bed, a body reduced to fragility."
    s "Of course."
    "He grinned faintly, shook his head, and slid a cigarette between his lips. The lighter's flame flickered once in the winter air, then held."

    scene cg samuel_moon with dissolve_slow
    window hide
    pause 2.5
    window auto
    "Samuel tilted his head back, exhaling toward the night. Snow drifted down, gathering on his coat, his hair."
    "Above, the sky was a mass of heavy cloud, but a small break remained — just enough for the crescent moon to show itself, sharp and pale."
    "He drew hard on the cigarette, the tip flaring bright against the dark."
    th "Maybe Martha's right. Maybe a trip. A change of scenery, just once."
    stop ambient fadeout 3.0
    stop music fadeout 3.0
    window hide
    pause 1.5
    window auto

    # --- January 3rd: the drive ---------------------------------------------------
    scene bg car_day_snow with fade_long
    show snow light
    play ambient2 sfx_engine fadein 2.0
    play music m_outside2 fadein 2.0
    call place("The mountain road — January 3rd, 2025, 7:10 a.m.")
    "The road stretched long and white beneath his wheels. One hand on the wheel, the other tapping his knee in rhythm with the music."
    "From the radio came the heavy riffs of System of a Down's {i}Mr. Jack{/i} — a relic of his younger days, sharp enough to pull half-forgotten pieces of himself forward."
    "A small duffel on the back seat. His phone and police radio side by side on the passenger seat — habits he couldn't leave behind even on so-called time off."
    "Nearly dawn when he had started; now past seven. The city lay far behind, swallowed by distance and snow."
    th "Fresh air, Martha had said. Go take some fresh air."
    "Well, here he was — out where the air was as fresh as it got. He almost laughed."
    "Pines bowed heavy under snow. Ridges caught the morning light, silver mist clinging to their bases. Every few miles the road bent around cliffs that fell into valleys deep enough to vanish in shadow."
    "It was beautiful, yes — but the beauty carried weight. A reminder of how far from everything he was driving."
    "His best companion rested between his fingers: a Marlboro, burning slow, rolled across his knuckles as absently as shifting gears."

    stop music
    play sound sfx_static
    "The song cut suddenly, replaced by a burst of static." with hpunch
    disp "All available units, be advised — possible suicide in progress, Greyvale High School. Female on rooftop."
    disp "Requesting immediate assistance. Local patrol en route, limited coverage. Time stamp, oh-seven-twelve."
    "Samuel's hand moved without thinking. He grabbed the mic from its cradle, its weight as familiar as the cigarette in his other hand."
    s stern "This is Detective Harris, badge four-one-seven. Copy on Greyvale call. I'm in proximity, off duty but available. I'll respond."
    play sound sfx_static
    disp "Copy, four-one-seven. Greyvale confirms. Proceed with caution. Advise once on scene."
    s "Ten-four."
    "He took a drag and exhaled hard through his nose. The car seemed quieter now, the mountains less serene."
    "Maps recalculated toward the next exit. Greyvale lay twenty minutes north, tucked in the white folds of the hills."

    # --- Greyvale High School -----------------------------------------------------
    stop ambient2 fadeout 2.0
    scene bg school_exterior with fade
    show snow light
    play ambient sfx_wind fadein 2.0
    play music m_ritual fadein 3.0
    call place("Greyvale High School — 7:34 a.m.")
    "Greyvale greeted him with the silence small towns carry during the holidays. Holiday lights clung to lampposts, tired in the gray morning."
    "At the dark brick of the high school the emptiness gave way: thirty or forty people pressed close despite the cold."
    "Two patrol cars at odd angles, lights spinning blue and red across the falling snow. Three officers trying to push the crowd back."
    "He pulled the Yaris in just beyond the barricade. The air was sharp enough to sting his lungs."
    "One of the officers broke away and came toward him — midthirties, flushed red from the wind, his uniform dusted with snow. He extended a hand."
    officer "Detective Harris?"
    s "That's me."
    "The officer nodded in relief, as though a detective's presence might restore order. Samuel turned toward the crowd — curiosity, dread, morbid hunger."
    s stern "Go home, folks. This isn't a show. You've seen enough."
    "Something in his tone worked where the pushing hadn't. Coats pulled tight; people shuffled away into the street, leaving a cleaner silence behind."
    "As the last cluster drifted off, a girl lingered by the bike racks, too still for the freezing cold. Hair in her eyes."

    menu:
        "Look at the girl by the bike racks.":
            $ notice()
            "When Samuel glanced her way, she looked past him like he wasn't there."
            "No hugging herself against the cold, no craning to see. A strange, still child, looking at nothing — or at all of it."
            th "Shock. Kids go strange in shock."
            "He filed it there. When he looked again, she was gone."
        "Keep your eyes on the officer.":
            "He kept his attention on the officer, on the tape, on the work. From the corner of his eye, a small shape by the bike racks."
            "When he glanced her way, she looked past him like he wasn't there, and then she was gone."

    "Samuel let the cigarette between his fingers drop to the snow and nodded toward the schoolyard."
    s "Alright. Let's see it."

    stop music fadeout 3.0
    "The officer led him past the tape, boots crunching on frozen snow. Only the hum of idling patrol cars remained."
    officer "She was one of the teachers here — Maria Mallory. Thirty-eight. Married. Two kids, both students at this school. Husband's at home with them now."
    "Samuel's face stayed flat. His hand slid into his coat and came out with a small notebook and pen."
    show vignette
    "The body lay a few yards ahead. Snow gathered around it, turning crimson where it met the blood."
    call mature_show("maria_body")
    "Black leggings, a plain T-shirt. No coat, no sweater, nothing against the cold. Thin sneakers, the laces still tied neatly — but no socks."
    "She had landed chest-down, arms bent beneath her. The face, pressed into the paving stones, was unrecognizable."
    "No pockets. No purse. Nothing on the ground to suggest she had carried anything with her. Just the body, alone."
    call mature_hide
    "Samuel crouched, the pad balanced on his knee, the pen scratching."
    note_voice "Improper dress. No belongings. Sneakers, no socks."
    $ note("Improper dress. No belongings. Sneakers, no socks.")
    note_voice "Chest down, severe cranial deformation. Blood spread consistent with fall impact."
    $ note("Chest down. Cranial deformation. Blood consistent with fall.")
    "His breath fogged, mingling briefly with the faint steam still rising from the body's warmth. He closed the notebook and stood."
    s "Family informed?"
    officer "Yes. Husband's home with the kids. We've got a man there now. School psychologist too — helping the children handle it."
    s "Did you know her? The family?"
    officer "Yes. Greyvale's a small town — everybody knows everybody. Never had a single complaint from them. No disturbances, no calls."
    officer "Her husband works for the municipality. Maintains the public park, does seasonal work with the plantations."
    s "And the kids?"
    officer "Son's fourteen. Daughter's eleven."
    "The words hung in the cold, heavier than the air itself."
    "Samuel drew the last drag, then pressed the ember into the hollow of his palm where the snow had melted to slush. A sharp hiss, a curl of steam. He pocketed the butt."
    s "Can you take me to the family?"
    officer "Of course, sir."
    s "Alright. Give me a minute, and we'll leave."

    # --- Doyle on the phone -------------------------------------------------------
    play sound sfx_phone
    show screen phone_call("Raymond Doyle")
    "Raymond picked up on the third ring."
    d "Sam? Don't tell me — you ran out of smokes again and need me to send an intern with a carton."
    "Samuel barked a laugh, loud enough to startle the officer beside him."
    s "Ha! Not this time, Ray."
    s "I'm in Greyvale. Just walked a scene — female, mid-thirties, jumped from the high school roof. Married, two kids. Local force asked for support."
    d "Alright. I'll check who's available, get someone assigned to it."
    s "No need. I'll take it."
    "A pause, heavier this time."
    d "You sure about that, Sam? You're supposed to be on leave. You don't owe them your holiday."
    s "I'm sure. It's straightforward. I can handle it."
    d "After thirteen years of paperwork, you're begging me for a suicide case, huh?"
    s "Something like that."
    "He smiled faintly, though no one was there to see it."
    d "Alright, Harris. It's yours. Shouldn't be more than an open-and-shut. Get your notes in order, file the report, and don't make it into more than it is."
    s "Understood."
    d "Good man. Let me know if you need anything."
    s "Copy that."
    hide screen phone_call
    s "Alright. Let's go meet the family."

    # --- The Mallory apartment ----------------------------------------------------
    stop ambient fadeout 2.0
    scene bg mallory_living with fade_slow
    play music m_aftermath fadein 3.0
    call place("The Mallory apartment — 8:15 a.m.")
    "Five minutes through narrow streets to a three-story block, the kind where every sound carried and every neighbor knew each other's business."
    "The stairwell smelled of burnt wood, faint but sharp, clinging to the walls as they climbed. No one spoke."
    "On the second floor the door stood half-open. String lights around the archway; small ornaments arranged carefully across shelves and mantel."
    show lara neutral at right with dissolve
    l "Detective Harris? I'm Officer Lara Whitfield."
    "Brisk but respectful. Samuel gave a short nod and stepped past her. His eyes went first to the man on the sofa."
    show lara neutral at right, dimmed
    show andreas grief at center with dissolve
    "The husband sat forward, arms crossed tightly over his chest, staring into the space before him as though holding the silence together with his gaze."
    "Early forties, but grief aged him. His jaw was freshly shaved — the skin there lighter than the rest of his face. He usually wore a thick beard."
    "Large, roughened hands, marked with cuts old and new. The hands of a man used to labor."
    "The place was tidy, every surface touched by holiday preparation. Stockings above the fireplace, each embroidered with a name."
    th "Family lived here. Not just people passing time under the same roof."
    s "Detective Samuel Harris."
    an "Andreas Mallory."
    "His grip was firm despite the tremor running through him. His voice thick, wavering but not broken."
    s "Mr. Mallory, I can't pretend to know your grief. But for the sake of you and your children, I need you to focus now. Help me with what you can, while it's fresh."
    "Andreas nodded quickly, almost gratefully, as though the structure of a request gave him something solid to hold."
    an "Of course. Anything you need."
    s "Do you mind if I record this? Just for accuracy."
    an "No... no, go ahead."
    "Samuel set the phone recording on the coffee table between them, clicked his pen once, notebook open in his lap."
    s "Did you see Maria today? Before she left the house?"
    an "Yes. We... we had breakfast together. Me, her, and the kids."
    s "And then what happened?"
    an "We went to light the fireplace — me and the kids. Maria stayed behind to wash the dishes. Just quick, she said."
    an "After a while I heard the main door close. I thought she'd gone to throw the trash out... so I waited. But she didn't come back."
    an "Her phone was still here. She never went anywhere without it."
    an "Maria... why — why would she..."
    "His words dissolved. Samuel watched the trembling hands, the collapse of posture, the raw confusion in every feature."
    th "No performance. The grief is sincere."

    menu:
        "Ask about the argument first.":
            s "Did you argue with her recently?"
            an "Yes. We did. She was tense, I wanted her to relax, enjoy the holidays with the kids..."
            "His voice cracked. He pressed his hands to his face, then forced them down again."
            s "And her behavior? Did you notice anything different, recently?"
            an "I... I don't know. She was stressed, but Maria was always like that. Even when things were good, she worried. She carried too much inside. But nothing like—"
            "He stopped himself. Panic crossed his face, closer to guilt than certainty."
            th "A man who hadn't paid close attention, now punishing himself for it."
            s "Was she taking any medication? Seeing a therapist?"
            an "No. Nothing like that."
            "Samuel wrote it down. Andreas's shoulders folded forward."
            an "We both said things, I—"
            "The tears came, sudden and rough."
        "Ask about her behavior first.":
            s "Did you notice anything different in her behavior recently?"
            an "I... I don't know. She was stressed, but Maria was always like that. Even when things were good, she worried. She carried too much inside. But nothing like—"
            "He stopped himself. Panic crossed his face, closer to guilt than certainty."
            th "A man who hadn't paid close attention, now punishing himself for it."
            s "Was she taking any medication? Seeing a therapist?"
            an "No. Nothing like that."
            s "I see. Did you argue with her recently?"
            "Andreas's eyes clouded, his jaw tightening."
            an "Yes. We did. She was tense, I wanted her to relax, enjoy the holidays with the kids..."
            an "We both said things, I—"
            "His body folded forward and the tears came, sudden and rough."

    s soft "It's alright. I heard what I needed to."
    "He ended the recording and slipped the phone back into his coat."
    s "I'll take a look around, if that's alright with you."
    an "Of course."
    hide andreas
    hide lara
    with dissolve

    # --- The kitchen --------------------------------------------------------------
    scene bg mallory_kitchen with dissolve
    # ART-REQUEST (fulfilled): mallory_kitchen — small apartment kitchen, holiday breakfast spread (pancakes, juice, half cake, croissants), unwashed plates stacked in sink, Christmas lights, grey morning window.
    "The kitchen still carried the scent of pancakes, butter, and sugar — a sweetness clinging to the air like a ghost."
    "Juice in glasses, a half-finished cake, toast stacked neatly, croissants in a dish. A spread meant for a holiday morning, for family."
    "Samuel checked the sink. The dishes were not washed, contrary to Andreas's words. Plates piled neatly, untouched."
    note_voice "Meal prepared. Not cleaned. Suggests planning. Possible farewell."
    $ note("Dishes not washed — contrary to husband. Meal prepared. Possible farewell.")

    scene bg mallory_living with dissolve
    "Down the hallway: three doors. The bathroom — clean, organized, nothing out of place."
    "The second on the right — children's voices. Muffled talk, quiet sobbing. He paused, then shook his head slightly."
    th "Not yet."
    "The couple's bedroom: the air still, the bedspread tucked, side tables bare but for a lamp and a framed photograph."
    "Everything polished, arranged. No notes, no discarded items, no trace of disarray."

    # --- The children -------------------------------------------------------------
    "At the children's room the psychologist rose and came to him, whispering."
    woman "Detective Harris? I'd recommend not questioning them right now. They're devastated."
    s soft "I won't press hard. Just a few questions. It may help."
    "She hesitated, then gave a reluctant nod and stepped aside."
    "The two children sat together on one bed. The boy kept his fists clenched on his knees, jaw rigid, eyes on the floor."
    "Beside him his younger sister murmured softly to herself, voice broken by sobs, her hair hanging into her face."
    "Samuel lowered himself to one knee so his eyes were level with theirs. His tone shifted — quiet, curious, soft."
    s soft "What's your name?"
    tonia "Tonia."
    s "And you, young man? What's your name?"
    tim "Tim."
    "Their eyes did not meet his, nor each other's. Grief had sealed them inward."
    s "I won't take much of your time. I just want to know if your mother was doing anything new these last weeks. Anything she spent extra time on?"
    "Tim's knuckles whitened. He spoke without lifting his gaze."
    tim "She stayed after school sometimes. Said she was helping some of the older kids. Tutoring."
    tonia "Math and... history, I think. She was helping. She always wanted to help."
    "Her small voice cracked. Samuel wrote the words carefully, his eyes never leaving the children."
    $ note("Tutored older kids after school. Math, history. Get the list.")
    s soft "She was proud of you both. That much I can see."
    "Neither answered, but Tonia leaned into her brother's shoulder, and Tim's fists slowly unclenched, just a little."

    # --- The phone ----------------------------------------------------------------
    show andreas grief at center with dissolve
    show lara neutral at right with dissolve
    s "I'll need her phone."
    "Andreas reached for the coffee table drawer, hands trembling as he passed it over."
    an "Here. Pin 9877."
    "Lara Whitfield produced an evidence bag. Samuel slid the device in."
    s "Log it to me on a property receipt. I'll start with exigent review and get a warrant in motion."
    l "Yes sir."
    $ note("Phone left behind — she never went anywhere without it. PIN 9877.")
    note_voice "Phone left behind."
    hide andreas
    hide lara
    with dissolve

    # --- Outside: toward the hotel ------------------------------------------------
    scene bg greyvale_street with fade
    show snow heavy
    play ambient sfx_wind fadein 2.0
    "He texted Doyle to authorize exigent review of the victim's cell phone. A blunt {i}Ok{/i} came back a few seconds later."
    "Down the narrow stairwell, the burnt-wood smell still clinging to the walls, and out into the cold. Snow had thickened, heavy flakes muffling the world."
    "Samuel cupped his lighter against the wind and brought flame to another Marlboro."
    officer "What now?"
    s "I'll need somewhere to stay. And I'll need the names of the students she was tutoring. Addresses too."
    officer "I'll see to it. As for a place — there's a small hotel up the hill, near the main square. It's the only one in town."
    s "Good. Appreciate it."
    $ note("Tutoring list + addresses requested. Hotel by the square.")
    "He gave the officer a short nod of thanks, then turned and walked away, the cigarette burning steady between his fingers as the snow closed in around his tall figure."
    stop ambient fadeout 3.0
    stop music fadeout 3.0
    window hide
    pause 1.5
    window auto

    jump ch03
