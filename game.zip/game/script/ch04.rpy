## Chapter 4 — Clara Ward. Samuel POV throughout (never show the samuel sprite).

label ch04:
    call chapter_card(4, "Greyvale — January, 2025")

    # ------------------------------------------------------------------
    # Hotel room: the reports
    # ------------------------------------------------------------------
    scene bg hotel_room with fade_slow
    show snow light
    play music m_office fadein 2.0
    call place("The Greyvale Hotel — 1:04 p.m.")

    "Three days later, just after one, Samuel pushed open the door to his hotel room with a stack of folders under his arm."
    "The reports felt heavier than their weight: autopsy sheets, lab results, witness statements that said nothing. He let them drop onto the desk, black ink on white fanning across the wood."
    "He shrugged out of his coat and stood a moment, rubbing the bridge of his nose. His eyes were red-ringed from long hours and too little sleep."
    "The cigarette box on the table was already half-empty, a silent tally of his nerves."
    "The toxicology report lay on top. Patrick Hensley. Cause of death: ingestion of {i}Taxus baccata{/i}. Yew alkaloids. No doubt."
    "Poison strong enough to stop a heart within minutes. And the manner of ingestion? Coffee, almost certainly. He'd swallowed death with his morning ritual."

    $ note("Hensley — yew alkaloids (Taxus baccata). In the coffee.")
    note_voice "Hensley — yew alkaloids (Taxus baccata). In the coffee."

    "Beside it, Maria's file. No poison, no substance. Just the fall, the fractures, the cranial trauma. {i}Suicide{/i}, the medical examiner had typed."
    "But with the USB message Samuel now carried in evidence, he knew better. She hadn't jumped from despair. She'd been driven."
    "The phone analysis came back clean. No hidden files, no deleted texts, no photographs. Family chatter, the tutoring group, that six-second call from Steve Collins."
    "No CCTV at the shop, either. The cameras had been out for weeks, no money to fix them."
    "Witness reports? Worthless. A few locals had seen Hensley last, buying cigarettes or grumbling over bread deliveries. Everyone agreed: nothing unusual. Normal."
    th "Normal."
    "Two bodies in two days. Both carrying a mark of judgment: Maria cornered with words, Patrick left with a single word by his corpse."
    "He leaned forward, elbows on his knees, rubbing his dry, raw hands together. His breath came steady, but tight, as if each inhale fought against the room itself."

    # ------------------------------------------------------------------
    # Mercer's call
    # ------------------------------------------------------------------
    pause 1.0
    "He was at the desk, a second cup of coffee cooling beside him, when the phone buzzed. Mercer's name lit the screen."
    play sound sfx_phone
    show screen phone_call("Daniel Mercer")
    s "Harris."
    m shaken "Detective... We've got another body. A student this time."
    "Behind Mercer's voice: muffled chatter, the occasional sharp command. Samuel's shoulders stiffened."
    s "Go on."
    m shaken "Gym class had just finished. Four girls went to the locker room to change. They found her there. Wrists slit, still in uniform."
    m shaken "They screamed. The rest of the class rushed in, the teacher too. Whole wing was in chaos before we arrived."
    "Samuel set his cup down. The porcelain clinked."
    s "And now?"
    m neutral "Under control. We've cleared the area. The locker room's locked down. The body hasn't been touched."
    m neutral "The four who found her, we've separated them in the counselor's office with an officer watching. They're shaken to hell, but stable."
    s "What about the rest of the students?"
    m neutral "We dismissed them. Sent them home. Headmaster's keeping it as quiet as possible, but word's already spreading through town."
    "A pause. Samuel could hear his own breath against the phone."
    m shaken "Detective... you should see this one yourself."
    s "Keep the scene sealed. I'll be there in ten."
    m neutral "Understood."
    hide screen phone_call
    "He drained the last of his coffee, bitter against his tongue, and was already pulling his coat from the chair."

    scene bg car_day_snow with dissolve
    play ambient2 sfx_engine fadein 1.0
    "On the drive over, Mercer's words kept coming back. {i}A student this time.{/i}"
    "Somewhere between one light and the next, the word {i}student{/i} thinned toward a smaller one he would not let himself finish."
    "He kept his eyes on the road and drove, and did not finish it."
    stop ambient2 fadeout 1.5

    # ------------------------------------------------------------------
    # School: corridor with Lara, locker room
    # ------------------------------------------------------------------
    scene bg school_exterior with dissolve
    show snow light
    play ambient sfx_wind fadein 2.0
    call place("Greyvale High School — 1:20 p.m.")
    "By the time he pulled into the school lot his face was stone again."
    "Clusters of teenagers lingered by the gates, eyes darting to the cordon. A few craned their necks for a glimpse inside. Rumor already ran faster than any official word."
    stop ambient fadeout 1.5

    scene bg school_corridor with dissolve
    show lara neutral at right with dissolve
    "Samuel ignored them and cut straight to Officer Lara Whitfield, waiting just inside the entrance, her face set but pale."
    l "Detective."
    s "Let's see her."
    "They moved quickly through the halls. The building smelled of cleaning fluid and too many coats drying on hooks."
    l stern "Victim's name is Clara Ward. Fifteen. Teachers say she struggled. Kept to herself, withdrawn. Self-harm scars on her arms. Had been sent to the counselor more than once."
    "Samuel's jaw ticked."
    l stern "Home life's unstable. Parents fight constantly. Money problems too. Neighbors have filed a few noise complaints in the past."
    "They stopped before the locker room doors, an officer standing guard. Lara pushed the door open."

    stop music fadeout 3.0
    scene bg locker_room with fade
    show vignette
    "Inside, the room was heavy with silence, broken only by the hum of fluorescent lights."
    "The smell of blood pushed at every breath."
    "She sat against the far wall, still in her gym uniform. Her arms lay slack and pale at her sides. Two razors glinted faintly at her feet."
    "Samuel steadied himself and crouched lower."
    show lara neutral at right with dissolve
    s "Lara. Get those razors collected. Both of them. Bag each separately, and don't smudge the blades."
    s "I want swabs taken from the handles, and photographs before you touch a thing. We need to know if anyone else ever held them."
    l neutral "Yes, Detective."
    "She signaled the officer on guard, who stepped in with gloves and an evidence kit. Samuel wrote, the words tight and economical."
    $ note("Clara Ward, 15 — Body seated, wall support. Bilateral lacerations, wrist to elbow. Razors present. Bag for prints/DNA.")
    note_voice "Body seated, wall support. Bilateral lacerations. Razors present."
    "His eyes shifted to the bench, where Clara's schoolbag slouched open, notebooks fanned like wings."
    s "Bag the entire pack, untouched. We'll inventory at the station."
    l "Yes, sir."
    s "And check her locker. I want every item catalogued. Clothes, books, scraps of paper, whatever she kept in there. Photograph the locker before you move a thing."
    l stern "Understood."
    "His gaze swept the tiles: small scattered belongings, a water bottle tipped on its side, the smudge of a shoe where one of the girls must have stumbled back in shock."
    s "Get prints from the door handles, inside and out. And the bench surface. If anyone planted something, we'll know."
    "He glanced once more at the girl against the wall. A part of him wanted to look away. He didn't."
    s "And when that's done, we'll speak to the girls who found her."
    hide lara with dissolve

    # ------------------------------------------------------------------
    # Counselor's office: parents at the door, Chloe
    # ------------------------------------------------------------------
    scene bg school_corridor with dissolve
    play music m_office fadein 3.0
    "His shoes echoed down the corridor. Voices grew louder as he neared the counselor's office."
    show mercer neutral at center with dissolve
    "Mercer stood at the door, hands lifted in a gesture meant to reassure. Four sets of parents and relatives pressed around him."
    vo "They've been through enough—"
    woman "She's only a child, you can't keep them locked up like this—"
    vo "Traumatized, that's what this is! She needs rest, not questions—"
    m shaken "We just need a statement from each of them, nothing more. Please, I promise—"
    "Samuel stepped up, his coat brushing the doorway. His presence drew silence quicker than Mercer's words had."
    s "It won't take long. Ten minutes with each girl, and then they go home. But we need to know what they saw. Without that, we have nothing."
    "Reluctant nods. Mutters. No one argued further. Mercer exhaled in relief."
    hide mercer with dissolve

    scene bg counselor_office with dissolve
    "Inside the first room, a girl sat curled in the chair, feet barely reaching the floor. Twelve or so, a braid come loose, the hem of one sleeve worried to a fray."
    "Chloe Harper, by Mercer's list. Samuel drew up a chair, sat below her eye line, and left the notebook shut."
    s "Chloe. I'm Detective Harris. Just tell me what happened, in your own words. Take your time."
    chloe "We went in to change after gym. We didn't know anyone was there."
    chloe "She was just... against the wall. There was so much blood."
    "It came in pieces, around the crying. He let her get the whole of it out, then asked, easy, whether she'd seen anything else in the room. Anything wrong, apart from the blood."
    "She shook her head into her sleeve."
    s "Did you know the girl?"
    chloe "No. She was older. Upper classes. I didn't know her."
    s "That's enough. You did well."
    "Whatever had happened in that locker room, the small ones had carried nothing out of it but the sight. He'd known that before he sat down."
    "He'd sat down anyway, because the one who mattered was at the end of the hall, and you did not walk in on that one first."

    # ------------------------------------------------------------------
    # Emily
    # ------------------------------------------------------------------
    scene bg counselor_office with dissolve
    "The next room. The counselor gave him a nod and withdrew."
    show emily worried at center with dissolve
    "Emily Carter sat straight-backed, hands folded, cheeks streaked but her breathing level. Held, almost practiced. Fragile, not broken."
    s "Emily Carter? I'm Detective Harris."
    "She nodded, eyes wet but direct."
    s "You're older than the others."
    e worried "Fourteen."
    "He took in the skirt and sweater, every button aligned. Not gym clothes."
    s "You weren't in the class."
    e worried "I had a quiz. Finished early. I went to find Alice. She's my best friend."
    e worried "She was in gym, so I waited, and walked back with her and the others when they were done."
    "The sadness ran through every word, but it stayed in tune."
    s "Did you know the girl who was found?"
    e worried "Not really. I'd seen her. She was older. Once or twice I was with Alice when she had counseling, and Clara was there too."
    e worried "But I didn't know her. Not the way Alice did."
    e cry "I wish I had. Maybe then I'd understand why—"
    "She caught it and looked down."
    s "Thank you, Emily. That's enough."
    "She hesitated, then raised her eyes, wide and earnest."
    e cry "Detective? Please... don't think badly of her. She must have been hurting so much. People forget that. They just say ugly things."
    s "I won't forget."
    show emily worried
    "Something eased in her shoulders, as if she'd carried that one request all afternoon and had only now found somewhere to set it down."
    hide emily with dissolve

    # ------------------------------------------------------------------
    # Alice
    # ------------------------------------------------------------------
    scene bg counselor_office with dissolve
    "The last door. Alice Bennett, twelve. Emily's best friend, tied close to the dead girl."
    th "Tread carefully."
    show alice neutral at center with dissolve
    "She sat straight in the chair, hands folded, chin a shade raised. No tears, no tremor."
    "Not the blankness of shock. Something quieter, and more finished than that."
    "Samuel took the seat across from her and left the notebook closed on his knee."
    s "Alice. I'm Detective Harris. This won't take long."
    "The smallest nod."
    s "You and Emily were together when it happened?"
    a neutral "Yes. We had gym. Emily finished a quiz early, came to find me. We went to the locker room with Chloe and Sophie."
    s "Did you know the girl you found?"
    a neutral "Yes. I knew her. She was a friend of mine."
    s "A friend? She was older than you. How did that come about? Were your parents friends?"
    show alice cold
    "Alice's lips curled. Not a smile; the shape of one, sharp at the edge."
    a cold "I haven't seen my parents for two years."
    "The room went quiet."
    a neutral "I moved here with my grandfather. George."
    s "Ah. Apologies, I didn't know."
    "He gave her a little of himself, the way you do to take the weight off a room."
    s "I'm new here too. Still finding my way."
    "She gave him nothing back. No twitch at the mouth, no shift in the eyes. She broke the silence herself."
    a neutral "Clara had problems, Detective."
    s "What kind?"
    a neutral "People talked. Schoolmates. They called her names, pointed at the obvious, never looked under it. That's how it is here."
    "Her eyes didn't leave his."
    a neutral "It's a small town. Everyone learns your flaws—if you're poor, if your family's broken—and turns them into names. Into whispers that follow you everywhere."
    a neutral "Clara carried all of it. For years."
    s "Years."
    a neutral "Years."
    "He let it sit."
    s "You say {i}flaws{/i} like it means something. Like it's more than schoolyard talk."
    a cold "In my family, flaws weren't tolerated. If you lied. If you were weak. If you pretended to be something you weren't. There were consequences."
    s "Consequences."
    a cold "That's how I was taught. That's how it still is. Weakness, dishonesty, hypocrisy—it all shows, in the end."
    a cold "And when it shows, it has to be corrected."
    "Her hands folded tighter."
    a neutral "My grandfather believes the same. George. He says people are judged by what they carry, not what they pretend to be."
    a neutral "That's how it works. That's how it should work."
    "When she said his name there was something in her mouth that sat very close to pride."
    s "That's a hard way to see the world, Alice."
    "The corner of her mouth moved. Not a smile; something between defiance and dismissal."
    a neutral "I don't know, Detective. I'm just a kid. Doing as I'm told."

    $ note("Alice Bennett, 12 — lives with grandfather George. 'Flaws have to be corrected.'")
    note_voice "Alice Bennett, 12 — lives with grandfather George. 'Flaws have to be corrected.'"

    # The mother in the hall (off-screen)
    play sound sfx_tinnitus
    with vpunch
    ev "Where is she? Where is my daughter?!"
    "A woman's scream tore through the wall, raw, dragging every ear toward it. The words broke into sobs and climbed again."
    ev "Let me see her! Where is my Clara?!"
    "Samuel kept his face still and his hands where they lay."

    menu:
        "Watch the door.":
            "The corridor tangled beyond it: the mother's wail, a man's lower rumble, Mercer's calm stretched thin."
            "He counted the voices the way he'd been trained to. Three. Four. Somebody struck the wall with a flat hand."
        "Watch the girl.":
            $ notice()
            show alice neutral at center, breathe
            "Across from him, Alice had turned toward the door. Not flinching. Not startled."
            "Her head tilted, as though she were studying the sound instead of recoiling from it."
            th "Shock. Kids go strange in shock. They freeze, they go far away."
            "He filed it there, and let it lie."

    "Then Lara's voice, flat and certain, cut through."
    l "Enough. Come with me. This isn't the place."
    "By inches it dragged down into sobs and moved off, and left its echo behind like smoke."
    "The counselor put her head in."
    vo "Detective, the girls. They've been through enough. Can they go?"
    s "Yes."
    s "Except her. I need a little more."
    show alice neutral at center
    "Alice looked from the door back to him, smooth, unhurried, as if she'd been waiting for exactly that. The door clicked shut."
    a neutral "Those people screaming. Were they the parents?"
    s "Yes. I understand their grief."
    show alice cold
    "Her brows drew together, the first true shift in her since he'd sat down."
    a cold "How can you?"
    "Sharp, near accusing, as if she'd caught him at a lie."
    s "Because I've stood where they're standing."
    "No softening, no weight laid on it. A plain stone dropped into the quiet."
    show alice neutral
    "Her face eased."
    a neutral "I see."
    show alice smile
    "And then, almost lightly, a quick smile with something mischievous in its curve."
    a smile "You know, I don't think the psychologist will help you. But Clara kept a diary."
    a smile "Her parents don't know. I do. She told me once. Under her mattress."
    "His pen moved."
    $ note("Diary under the mattress (per Alice).")
    note_voice "Diary under the mattress (per Alice)."
    s "Thank you, Alice. That's useful."
    "The smile stayed a moment, pleased at his approval."
    show alice neutral
    "Then it folded away as her hands folded back into her lap, and the composure closed over her again."
    s "Alright. You can go now."
    hide alice with dissolve

    # ------------------------------------------------------------------
    # Corridor: Emily hugs Alice; George in shadow
    # ------------------------------------------------------------------
    scene bg school_corridor with dissolve
    "He followed her out into the corridor. Emily was waiting with her parents, her face blotched red, tears drying in uneven streaks."
    show alice neutral at midleft with dissolve
    show emily cry at midright with dissolve
    "The moment she spotted Alice, she broke from her mother's side and rushed forward, arms clinging tight around her friend's waist."
    show emily cry at center, tremble
    "Alice didn't stumble. She didn't break. She stood straight, steady."
    "Then she brought up one arm, slowly, deliberately, and laid it across Emily's shoulders."
    "Her face remained calm, unreadable, while Emily's tears soaked into her sweater."
    mrsc "Come on, sweetheart. Come on. Let's get you home."
    "After a few moments Alice released her, and Emily was folded back into her parents' arms. They moved off down the hall, the low hum of their voices shielding their daughter."
    hide emily with dissolve
    "Alice stood still a moment, watching them go. Then she turned toward the far end of the corridor."
    show george neutral at far_right, silhouette with dissolve
    "That was when Samuel saw him."
    th "George."
    "He stood half in shadow near the corner, his tall frame braced against the wall, arms crossed. Relaxed, yet immovable."
    "The kind of stillness that drew attention even when it seemed to want none. His eyes were fixed only on Alice as she walked toward him."
    show alice neutral at midright with dissolve
    "She didn't glance back. She didn't wave to Emily again. She simply walked the hall, each step even, until she reached him."
    "George pushed off the wall with one shoulder, and with a subtle tilt of his head guided her toward the exit."
    "Not once did his eyes turn toward Samuel. Not a flicker of acknowledgment."
    hide alice
    hide george
    with dissolve_slow
    "Samuel watched them leave, their footsteps fading into the building's silence."

    # ------------------------------------------------------------------
    # The yard: smoke with Mercer
    # ------------------------------------------------------------------
    scene bg school_exterior with dissolve
    show snow light
    play ambient sfx_wind fadein 2.0
    "Samuel stepped out into the yard, the cold biting sharper after the cramped corridors. He lit a cigarette and dragged deep until the smoke curled warm through his lungs."
    "Teachers ushered the last curious students home. The school stood quieter now, but the echo of screams still clung to the stone walls."
    show mercer shaken at center with dissolve
    "A few minutes later Mercer emerged, shoulders sagging, uniform disheveled. He gave Samuel a look that said more than words, and held out a hand."
    m shaken "Got another one of those?"
    "Samuel tapped the pack and slid one free. Mercer cupped it to the lighter and inhaled shakily."
    m shaken "I can't handle it today. First time I've ever seen a kid like that. It's... messed up."
    s "It is. And I hope you never have to get used to it."
    "They stood side by side in silence for a while, smoke curling upward."
    s "Do you know the Bennetts?"
    show mercer neutral
    "Mercer's jaw shifted. His eyes narrowed."
    m neutral "Yeah. Can't say I like George. He's not from here. Never quite fit. There's something... unsettling about him."
    "Samuel said nothing, letting him talk."
    m neutral "As for his granddaughter, she's just a kid, but... hell, she makes your skin crawl a little. Cold. Doesn't look at you the way other kids do."
    m neutral "But to be fair, they've settled in pretty well. George keeps himself busy. Handyman. Gardens, woodcutting, plumbing, even roofs when someone needs it."
    m neutral "He's older, but still got the strength. People hire him because he gets the job done."
    "He flicked ash into the snow, his face hard."
    m neutral "Doesn't change the fact I wouldn't want him as a neighbor."
    "Samuel took another slow drag, his mind already turning the words over."
    m shaken "Detective... do you think it's all connected? The teacher, the shopkeeper, and now this girl?"
    "Samuel dropped his cigarette and ground it under his heel. His breath misted toward the roofline."
    s "It's possible. Too many bodies in too few days. Each carrying something more than just bad luck."
    m shaken "Christ."
    s "I still need to talk to the school psychologist. Then her parents. And I'll check the girl's room."
    "Mercer gave a slow nod, eyes on the snow at their feet. Neither man spoke again for a while."
    hide mercer with dissolve
    stop ambient fadeout 1.5

    # ------------------------------------------------------------------
    # The storm drive to Markou
    # ------------------------------------------------------------------
    scene bg car_night_storm with fade
    show snow storm
    play ambient sfx_storm fadein 2.0
    play ambient2 sfx_engine fadein 1.0
    "By the time Samuel reached the edge of town, the storm had thickened. Snow blew in long, angry sheets across the road, the wipers struggling."
    "He pulled into the gravel drive of a tall two-story building, the only light on the street burning from its ground floor."
    stop ambient2 fadeout 1.0
    "The moment he opened the door, the wind cut into him like a blade. He gripped his collar high and pushed toward the entrance."
    "A brass plaque by the door read: {i}Dr. Helena Markou, Psychologist.{/i}"
    "He pressed the bell. The lock released almost at once with a low buzz."
    stop ambient fadeout 1.0

    scene bg markou_office with dissolve
    play music m_office fadein 2.0
    call place("Dr. Helena Markou — the edge of town, evening")
    "Inside, the storm dropped away. Warmth wrapped around him, carrying the faint, rich smell of burning oak."
    "He stamped the snow off his boots, hung his coat by the door. Polished panels, dim sconces, golden light."
    h "Come in, Detective. I'm in my office."
    "High bookshelves climbed the walls: leather-bound psychology tomes, modern case studies. An oriental rug. A large oak desk by the window, neat but lived-in."
    "Two green leather armchairs faced it. By the crackling fireplace, a sofa and a low table, as though inviting longer sessions than mere consultations."
    show helena neutral at center with dissolve
    "Dr. Helena Markou stood waiting. Mid-forties, sharply dressed, her glasses catching the firelight as she closed the file she'd been reading."
    h neutral "Detective Harris. Quite a storm to be out in."
    "Samuel eased into an armchair and let the warmth seep into him."
    s "You're right about the storm. It's been years since I've driven through weather like this. Almost forgot what it feels like."
    h neutral "Greyvale has a way of reminding people of things they'd rather forget. Even the weather."
    "She crossed to the fireplace to adjust a log. The light flared across her glasses."
    h neutral "Tell me, Detective—cases aside—how do you find the town so far?"
    s "Honestly? Quiet. Almost too quiet. Streets empty, rhythms slow. The kind of place that makes you wonder if you've stepped out of time."
    h neutral "That's fair. Greyvale can be charming at first glance. But the charm is thin, and behind it... people carry more shadows than they admit."
    s "I've noticed. They're not as welcoming as they'd like outsiders to believe. Polite, yes. But there's something colder underneath."
    "Helena gave a laugh, short and dry, but not unkind."
    h neutral "I'm an outsider too. You saw the plaque on my door. {i}Psychologist.{/i}"
    "Samuel raised a brow."
    h neutral "In reality, I'm a psychiatrist. But believe me, if I'd written that on the brass plate, it wouldn't have taken a week before people started calling me 'doctor for crazy people.'"
    h neutral "And from there? Crazy myself. So I chose the softer title. A small, innocent lie. Easier for them. Easier for me."
    "Samuel allowed himself a small smile."
    s "Seems even doctors have to make compromises in Greyvale."
    "She came around the desk and sat casually on its edge, one leg folded over the other. Samuel's eyes brushed there by instinct before he forced them back to his notebook."
    "He cleared his throat. The moment hadn't escaped her. She gave the smallest smile, then reached for a folder."
    h neutral "So. You want to talk about Clara Ward."
    s "Yes. I trust she had problems? More than a usual teenager?"
    show helena firm
    "The playful edge left her face. The air of practiced professionalism settled over her like a coat."
    h firm "She wasn't just troubled, Detective. Clara had a documented history of self-harm. Cutting episodes, often on her forearms. Not hidden well, either."
    h firm "Teachers noticed. Classmates noticed. She carried the scars openly."
    h firm "My diagnosis was recurrent major depressive disorder. Severe. Coupled with social anxiety."
    h firm "Prolonged withdrawal, loss of interest, recurring suicidal ideation. By fourteen, she was already at high risk. By fifteen, she was in the red zone."
    "Samuel's pen moved slowly, but his eyes stayed on her."
    h firm "She was often the target of ridicule. Other students sensed her isolation and amplified it. She internalized every word, every whisper, as self-blame."
    h firm "She came to me more than once convinced she was fundamentally flawed. That she deserved the suffering."
    h firm "Clara wasn't a typical teenager caught in the storm of adolescence. She was clinically depressed, chronically anxious, and acutely suicidal. Without constant support, she was always on the edge."
    "The only sound for a moment was the crack of the fire and the tick of a clock on the far wall."
    show helena neutral
    h neutral "There was one thing, though. Clara often spoke about Alice. Said she was the only one who seemed to understand her. That she felt safe when Alice was around."
    h neutral "Sometimes Clara told me Alice understood her better than adults ever could. Almost as if Alice knew what she was thinking before she said it."
    h neutral "It surprised me, honestly. Alice is younger, only twelve. But Clara insisted she was a steadying presence. That's all I can say about it."
    "She closed the folder with a measured hand."
    h firm "If you want my advice, speaking with her parents won't help you much."
    h firm "I know both of them. They came here for couples sessions that quickly turned into family sessions. Those were... ugly."
    h firm "They don't stay together for love. They stay together for tradition, for appearances. To show the town they're still a 'family.'"
    h firm "They're poor, but not because of bad luck. Her father is a gambling addict. And the mother... some years back, she was hooked on heroin. She clawed her way out, but the damage was carved into that household."
    show helena concerned
    h concerned "Of course, none of it is a secret. But I'd bet no one spoke ill of them after Clara's death, did they? You know why, Detective?"
    h concerned "Because everyone already knew. Everyone in this town knew what that girl was living with. What was under her skin. And nobody did anything."
    "She pushed her glasses up, and folded her arms tightly."
    h concerned "Including myself."
    "The fire popped once, the only sound between them."
    "Samuel sat still, his pen idle, and let the words weigh down the silence. Then he rose, sliding the notebook into his coat."
    s "We all live with what we didn't do, Doctor. Some of us more than others. Thank you for your time, and your information."
    "Helena gave a faint nod and offered no reply."
    hide helena with dissolve

    scene bg car_night_storm with dissolve
    show snow storm
    play ambient sfx_storm fadein 1.0
    "He pushed back through the storm and shut the car door against the howl of the wind. He sat in silence a moment, part fury, part professionalism."
    th "You're not here to feel. You're here to work."
    th "Still... It's a kid's life. A kid who'd been bleeding inside for years, and no one stopped it."
    "He struck a match and lit a Marlboro. The ember glowed bright against the dim storm."
    th "Focus on the case, Harris. Focus."
    "If Alice had been the only steady hand in Clara's chaos, then who else was there? No one, as far as the files said. Just that one girl."
    s "It's late."
    "Tomorrow he would go to the parents. Tomorrow he would try to find the diary."
    stop ambient fadeout 2.0

    # ------------------------------------------------------------------
    # The Wards
    # ------------------------------------------------------------------
    scene black with fade_slow
    "The night gave him little rest. That diary, real or imagined, gnawed at him. If it existed, it was the one voice Clara had left behind."
    "Breakfast was quick and joyless: three strong coffees and two pieces of chicken pie, swallowed for fuel. By half past nine he was back in the car."

    scene bg ward_apartment with fade
    call place("The Ward apartment — 9:52 a.m.")
    "The Wards lived on the third floor of a tired block. Paint peeled from the stairwell walls; the air smelled of damp plaster. He knocked."
    "The door opened after a long pause."
    show evelyn grief at midleft with dissolve
    "A woman, shoulders narrow, face drawn and gray with exhaustion. Evelyn Ward."
    s "Detective Harris. I'd like to speak with you for a few minutes, if that's alright."
    "The smallest nod. She stepped aside."
    "Every blind was drawn, muting the morning into perpetual dusk. The radiators off, the fireplace dark. It felt less like a home than a waiting room for grief."
    "On a sagging couch a man sat with his jaw slack, eyes fixed on nothing. Richard Ward. When Evelyn lowered herself beside him, he blinked, as though returning from a long way off."
    "Samuel took the armchair opposite. Devastated wasn't enough. They were hollowed out, each breath a reminder of absence."

    menu:
        "Ask about Clara's last days.":
            s "Did you notice anything different in your daughter's behavior these last days?"
            "Evelyn's eyes barely shifted. She shook her head slowly. Richard only stared at the floor."
            s "Did she seem more withdrawn than usual? Spending more time in her room?"
            "Another small shake. Richard gave no sign he'd heard."
            s "Any arguments? Anything she said that seemed unusual?"
            "Silence. Then a dull shake, as if Evelyn's neck could barely carry the weight."
            s "Did she ever mention someone bothering her at school? Friends, teachers, anyone?"
            "Both shook their heads, automatic, detached, as if his words dissolved before reaching them."
            "His voice wasn't reaching them."
            s "Would you mind if I had a quick look at Clara's room?"
        "Ask to see her room.":
            s "I'm sorry to ask this now. Would you mind if I had a quick look at Clara's room?"

    show evelyn grief at midleft, tremble
    "Evelyn's face changed at once. Her eyes widened, her lips tightened."
    ev "Her... room? No, I don't think—"
    "Samuel lifted a hand gently, cutting the protest before it could swell."
    s "It's fine. Forget I asked. Please, just let me use your bathroom, and I'll be on my way."
    show evelyn grief at midleft
    "At once her face relaxed, slipping back into the state it had been in before."
    ev "Of course. Down the hall, left side."
    s "Thank you."
    hide evelyn with dissolve
    "He walked the hall with measured steps, boots silent on the old carpet. But instead of turning into the bathroom, he went straight for Clara's door."

    scene bg clara_room with dissolve
    "Untouched since her death. A still-life of a teenager's life interrupted. Clothes draped carelessly over the desk chair."
    "The desk scattered with doodles: black shapes, dark figures scratched in with heavy ink. Ominous. But not unusual for a girl drowning in shadows."
    "One page showed the word {i}Liar{/i} scrawled over and over, the ink pressed so hard it had torn the paper."
    "He checked the desk and the drawers. No diary. Inside a small backpack. Not there either."
    "Alice's words echoed. He moved to the bed, gripped the mattress, and lifted it."
    play sound sfx_heartbeat
    "And there it was. The diary."
    "He slipped it into the inside pocket of his coat, the leather cover pressing against his ribs."
    th "Exigent seizure. Evidence removed before grieving parents destroy it. Log it, file for a retroactive warrant."
    "For now, the choice was already made."
    "He let the mattress fall, walked briskly to the bathroom, flushed, ran the tap, washed his hands. Quick, precise, rehearsed."

    scene bg ward_apartment with dissolve
    show evelyn grief at midleft with dissolve
    "When he stepped back into the hall, both of them were standing there, side by side, faces pale in the dim light. Their eyes fixed on him."
    "Samuel's chest tightened for an instant."
    rw "It's better to leave now, Detective."
    ev "She didn't like people in her room."
    s "Of course. Thank you, sir."
    s "And... my condolences. For both of you."
    "Neither spoke. They only watched him go, until the door closed behind him."
    hide evelyn with dissolve

    # ------------------------------------------------------------------
    # Hotel room: the diary
    # ------------------------------------------------------------------
    scene bg hotel_room with fade
    show snow light
    "On the way back he bought two take-away coffees, a plain sandwich and a fresh carton of Marlboros at a fogged corner café. The diary pressed against his ribs like a secret."
    play sound sfx_phone
    show screen phone_call("Daniel Mercer")
    s "I've secured Clara's diary. Pulled it under exigent circumstances, logged it that way. Warrant paperwork will follow."
    m neutral "Understood. Better to take the heat later than lose it for good."
    hide screen phone_call
    "He ate in sharp, distracted bites, washed it down with scalding coffee, lit a cigarette, and sat in the armchair by the window."
    "The diary's cover was worn, the corners soft with handling. He opened it."
    stop music fadeout 3.0
    "The first page began in a small, tight hand."
    note_voice "Dear diary, I am writing to share my thoughts. Alice said it will help me manage my emotions and judgment. I want to believe her. She says she does the same herself."
    "The entries came quick, the handwriting jagged in places, pressed so deep it looked carved rather than written."
    play music m_aftermath fadein 3.0
    note_voice "They fought again last night. He smashed a plate. She locked herself in the bathroom. I lay on the floor and covered my ears, but I still heard them. I always hear them."
    note_voice "My shoes are falling apart. My sleeves are too short. They laugh when I walk past, tugging at their own coats like mine is diseased."
    note_voice "I feel smaller every day. Like I'm not a person anymore, just a joke."
    note_voice "They call me 'junkie's daughter.' Sometimes they say 'whore's kid.' They say it in front of teachers. No one stops them. Everyone hears it. Everyone knows it."
    "He turned another page. The ink darker in places, smudged with old tears."
    note_voice "I cut again today. I thought it would help. It didn't. Alice told me it wouldn't."
    note_voice "She said hurting myself will never bring good attention, only pity or disgust. She said if I want things to change, I can't stay like this."
    "The next lines made Samuel pause, his jaw tightening."
    note_voice "Alice says I need to make a drastic change. That people only notice when you do something they can't ignore."
    note_voice "She said then they'll stop calling me names. Then it won't matter what they think anymore."
    "He stared at the words, smoke curling around his face."
    th "Drastic change."
    th "To Clara, Alice was the only positive voice. The only friend who told her she mattered."
    $ note("Diary: 'Alice says I need to make a drastic change.'")
    "He read on."
    note_voice "Alice understands me. She listens. She says she knows what it feels like to be judged, to have people look at you like you don't belong."
    note_voice "She's younger, but she feels older. Wiser. She tells me the truth."
    note_voice "She says nobody will ever understand me the way she does."
    "The pages grew more fragmented, swinging like a pendulum: anguish, fury, brief hope, then back to despair."
    "Always circling one constant. Alice."
    stop music fadeout 3.0

    # ------------------------------------------------------------------
    # The funeral
    # ------------------------------------------------------------------
    scene bg cemetery_day with fade_long
    play ambient sfx_wind fadein 2.0
    play music m_church fadein 3.0
    call place("Greyvale churchyard — the next morning")
    "The next morning was clear. Pale sunlight across the snow, the air sharp and unmoving. For the first time in days, the sky was open and blue."
    "Samuel hadn't planned on attending. Not family, not a friend, not even part of the town."
    "But he had read her most private confessions. He owed her the dignity of standing there."
    "The funeral drew nearly the whole of Greyvale: teachers, students, shopkeepers, the mayor stiff in his dark overcoat. The crowd overflowed beyond the fence, breath rising in pale clouds."
    "The prayers were spoken plainly. The grave was small but made with care, the stone top quality. An expense covered by the mayor, no doubt. A gesture to the town's conscience."
    th "They pay for her coffin, but not her life. They honor her death, and ignored her cries while she was alive."
    "When the coffin began to lower, the silence broke."
    ev "No— no, no, Clara—!"
    "Evelyn Ward collapsed forward, her scream tearing through the cold air. The sound of a realization settling permanent: her daughter was gone."

    # Memory: Thomas
    play sound sfx_heartbeat
    scene bg cemetery_day at memory with dissolve_slow
    "Samuel's chest clenched. The scene blurred against another: a cemetery, thirteen years earlier."
    "His baby's coffin, smaller even than Clara's, disappearing into the earth."
    "The word they had given him was SIDS, as if a neat acronym could soften the fact that death had stolen everything."
    cl "Thomas— give him back— {i}give him back{/i}—"
    "He could still hear Claire's screams, her voice cracking into hysteria, clawing at the ground, at him, at anyone."
    "And he had stood motionless. No tears, no anger. Just staring at the tiny box as it was swallowed by dirt, feeling his life collapse in on itself."
    scene black with dissolve
    pause 1.0
    scene bg cemetery_day with dissolve_slow
    "His hand lifted to his face now, brushing at the wet warmth on his cheeks. Tears, unbidden, hot against the cold air."
    "Yet his expression didn't change. His eyes stayed fixed on the coffin as the grave closed over another child who should have been spared."
    "The cries around him blurred into the same chorus of grief that had haunted him for thirteen years."

    scene cg funeral with dissolve_slow
    window hide
    pause 2.0
    window auto
    "The coffin had just disappeared into the earth when Samuel's eyes drifted sideways."
    "Among the crowd pressed closest to the grave, two small figures stood hand in hand."
    "Emily Carter was sobbing openly, shoulders quaking, tears streaking her face."
    "Beside her, Alice Bennett stood still, her grip firm on her friend's hand. No tears. No tremor. Her face calm, steady, her gaze fixed on the priest."

    scene bg cemetery_day with dissolve
    show karalis neutral at center with dissolve
    "Censer smoke still clung to the cold air. The priest stepped forward again, robes brushing the frost-darkened grass."
    "In one hand a small glass bottle of water; in the other, a thick Bible worn from years of use."
    fk "These events... these tragedies... they must not be tolerated in our community."
    fk "Evil has spread among us. And we must not turn away. We must face it with faith."
    "His voice grew sharper, a quiet fanaticism seeping into it. He lifted the Bible and recited from memory: phrases meant to console, ringing now like judgment."
    stop music fadeout 3.0
    "He paused, lifted the water, and took a long swallow. His throat worked. He wiped his mouth with the back of his hand."
    pause 1.5
    fk "Only through—"
    "The word broke into a cough."
    show karalis neutral at center, shake
    "The priest staggered, a hand pressed to his chest. The Bible slipped from his grasp and fell to the dirt."
    play sound sfx_thud
    "The bottle tipped, water spilling across the ground. His face twisted, first in confusion, then in pain. He tried to speak. Only a harsh rasp came out."
    "Murmurs broke into shouts. He lurched forward, knees buckling, hands clawing briefly at the air."
    hide karalis
    play sound sfx_thud
    with vpunch
    scene black with flash
    stop ambient
    "His head struck the frozen ground at the edge of the grave."
    "And then he lay still."
    window hide
    pause 2.0
    window auto
    "For a moment, silence."
    scene bg cemetery_day with dissolve_fast
    play music m_ritual fadein 1.0
    play ambient2 sfx_crowd fadein 0.5
    "And then panic erupted. Voices screamed. People pushed back from the grave, some trying to help, others fleeing. The mayor shouted for calm, drowned in the roar."

    menu:
        "Go to the priest.":
            "Samuel stepped forward at once, his coat snapping in the cold wind, shouldering through the scatter of black coats."
        "Look for the children.":
            $ notice()
            "His eyes went first to the place where the two girls had stood."
            "Alice had pulled Emily into her arms, turning her so the girl's face pressed against her shoulder."
            "Over Emily's shoulder, Alice's eyes were open. Wide open. Calm. Not on the crowd, not on the mayor. On the man on the ground."
            th "She's protecting her friend. Keeping her from seeing it. That's all."
            th "A kid with more sense than half the adults here."
            "He turned, and pushed toward the grave."

    "He knelt by the priest. The signs were already familiar: sudden collapse, breath stolen, lips darkening faintly."
    th "Yew. Again."
    $ note("Funeral — Fr. Karalis collapsed after drinking from his bottle. Yew again?")
    note_voice "Priest collapsed after drinking from his bottle. Yew again?"
    s "Nobody touches that bottle! Nobody touches anything!"
    stop ambient2 fadeout 3.0
    "In the chaos, his gaze caught on Alice."
    show alice neutral at center with dissolve_slow
    "She had pulled Emily into her arms, turning her so the girl's face pressed against her shoulder. Emily sobbed, muffled in Alice's sweater, unaware of what lay a few feet away."
    "Alice's own eyes, however, were wide open."
    "Calm."
    "Watching."
    window hide
    pause 2.5
    window auto
    scene black with fade_long
    stop music fadeout 3.0

    jump ch05
