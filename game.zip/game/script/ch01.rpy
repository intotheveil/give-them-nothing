## Chapter One — Alice's POV (age 10). Driftwood Bay, early winter 2023.
## Source: docs/manuscript/ch01.txt

label ch01:
    call chapter_card(1, "Driftwood Bay — Early Winter, 2023")

    # --- The candle -------------------------------------------------------------
    play music m_driftwood fadein 3.0
    scene cg alice_candle with dissolve_slow
    call cinematic("candle")

    "Alice sat at her desk with her chin in her palms."
    "The wood under her elbows was old and scarred — years of ink, and knife-marks worked into the grain by hands that were not hers."
    "It had been her father's desk once, and his father's before that, in a house that had belonged to Bennetts for the better part of a century."
    "Everything in the room had come down to her the same way. She was ten years old, and almost nothing she owned had begun with her."
    "A candle burned at her elbow. She tilted her head and watched the draft lean the flame, and the shadows it threw climb the wall and draw back, climb and draw back."
    "She watched them the way another child might watch television."

    "From above came hurried footsteps, quick and uneven, and the rise of a woman's voice. Her mother."
    "The words blurred, muffled by the ceiling boards, but Alice caught enough to know what they circled around."
    "The gathering. Tonight. The day they had been preparing for, whispered about, shaped toward, for years."

    # --- Father ----------------------------------------------------------------
    scene bg alice_room_night with dissolve
    show vignette
    play sound sfx_thud
    show alicey nightdress at midleft with dissolve
    "Her door cracked open without a knock. Her father entered in three strides, sure and swift, the air shifting with him."
    show father neutral at midright with dissolve
    "He knelt by her chair and took her small hands in his rough ones. His eyes searched hers."
    fa "Are you nervous?"
    "Alice shook her head, and a small smile crossed her lips — quick, certain, unafraid."
    fa "Of course you're not."
    "He patted her hair with the gentle pride of a craftsman inspecting finished work."
    fa "You'll do great."
    hide father with dissolve
    "The scent of him lingered as he rose: burnt wood, ash, and the faint musk of sweat. He must have set the fireplace alight only minutes ago."
    "The night was already cold enough to bite, and the sky outside promised rain. When the door closed again, silence folded over her."

    "She crossed to the bookcase — her only piece of furniture not steeped in history. New wood, sharp-edged, bought just for her."
    "World history volumes, comparative studies of religion, calligraphy textbooks, a Bible, math and science manuals — all far ahead of what most children her age would touch."
    "Education was not encouraged in that house so much as enforced."
    "On the lower shelf, softer bindings: {i}Moby-Dick{/i}, {i}Anna Karenina{/i}, {i}Pride and Prejudice{/i}. That last one had been a particular torment."
    "She would lose herself within a few pages, the story dissolving into fog. In her private, unflinching judgment, she hated it."
    "From the back of the shelf she drew out the worn spine of her favorite: {i}The Adventures of Tom Sawyer{/i}. Of all those bindings, this one truly belonged to her."
    "She carried it to the bed, curled against the quilt, and let herself sink into its pages."

    # --- Mother ----------------------------------------------------------------
    "She had barely read a handful before the hinges creaked again. Her mother stepped inside, a smile stretched wide — kind, yet tight with nerves."
    mo "Darling, I brought you your clothes for tonight. Best to get dressed soon."
    mo "Your grandpa will take you to the church, so behave, okay?"
    "Alice nodded without question. Her parents always had things to attend to, but tonight was different."
    "This was the night of her initiation. Ten years old, and at last ready. A blessing for her family. Only good things could follow."
    "She lingered with Tom Sawyer a little longer, letting the words soften the weight pressing at the edges of her thoughts. Then she rose and began to dress."
    hide alicey with dissolve
    "A girl her age might need her mother's hands to brush her hair, straighten the seams. But Alice was not like other girls."
    "Each button closed with precision. Each ribbon tied to perfection."
    "Halfway through, she heard her parents' voices below — brief farewells at the threshold. The front door shut, their steps fading into the cold night."

    # --- Grandpa ---------------------------------------------------------------
    scene bg driftwood_living with fade
    show vignette
    "The living room was dim, lit mostly by the restless blaze in the fireplace. Her grandfather stood near the flames, a cigarette between his fingers."
    "Both he and her father smoked indoors. So many of the books she'd been made to read called such a thing shameful. The irony struck her again, and she grinned."
    show george neutral at midright with dissolve
    "He was tall, broad-shouldered, the strength of his frame still evident despite his years. He split his own wood, still hunted when he could."
    "A gray stubble roughened his jaw, and the crown of his head shone faintly where time had thinned the hair away."
    show alicey neutral at midleft with dissolve
    ay "I'm ready."
    "Her grandfather drew one last, deep breath and flicked the cigarette into the fire. He turned to her with a kind smile, eyes soft."
    g soft "You look wonderful."
    ay "I want to be perfect for tonight."
    g "You are perfect. Don't worry."
    "She tilted her head, glancing toward the window."
    ay "So... is it time already?"
    g "Not quite. We'll take a walk first. It'll take the edge off."
    "Alice nodded. He was right. A walk might help. The knot in her chest eased, just a little."

    scene bg driftwood_yard_rain with dissolve
    play ambient sfx_rain fadein 2.0
    show rain
    "Outside, the evening was sharp and wet, the kind of coastal chill that sank quickly into the bones. After only a few steps George slowed."
    show george neutral at midright with dissolve
    g "This weather isn't for walking. Come on — we'll take the truck instead."
    hide george with dissolve

    # --- The truck -------------------------------------------------------------
    scene bg truck_night with dissolve
    show vignette
    play ambient2 sfx_engine fadein 1.5
    "The family owned only one car, George's old pickup. The Bennetts rarely left Driftwood Bay."
    "Its leather seats were polished, kept clean to the point of reverence. She remembered him scolding her father for treating it carelessly, and smirked as she climbed in."
    "Errands, berry-picking in the forested hills — that was the extent of her world. But tonight they weren't heading toward the coast, nor the village square."
    "George steered them past the edges of town, into the pale stretches beyond."
    show alicey worried at center with dissolve
    ay "Grandpa?"
    "He didn't answer. His smile, so steady moments ago, faltered."
    ay "Where are we going? What about tonight — the ceremony?"
    "Still silence. Only the engine and the wheels on wet gravel."

    menu:
        "Ask him again.":
            ay "Grandpa. The gathering is {i}tonight{/i}."
            "His hands tightened on the wheel. That was all the answer she got."
        "Stay quiet and watch him.":
            "She folded her hands in her lap the way she had been taught, and said nothing, and watched."

    "She lifted her eyes to the rearview mirror. For a heartbeat their gazes locked."
    "His looked heavy, uncertain, shadowed with something she had never seen before."
    hide alicey with dissolve
    play sound sfx_thud
    stop ambient2 fadeout 1.0
    "A few miles down the road the truck gave a sharp rattle, then sputtered." with vpunch
    g "Damn it."
    "He eased onto the shoulder and sat a moment with both hands on the wheel, looking at the dark ahead. Then he made himself smile."
    g "Nothing to worry about. We've run dry, that's all. Station's not far — we'll walk it."

    # --- The coast road --------------------------------------------------------
    scene bg coast_road_dusk with dissolve
    stop ambient fadeout 2.0
    play ambient sfx_wind fadein 2.0
    show george neutral at midright with dissolve
    show alicey neutral at midleft with dissolve
    g "Don't worry. The station isn't far."
    "The walk, though unexpected, had its charms. Waves crashed far below the cliff line, gulls wheeled wide arcs across the horizon."
    "The last of the sun spilled gold and violet through the thickening clouds."

    scene bg coast_station with dissolve
    show george neutral at midright with dissolve
    "After several minutes the low neon glow of a gas station came into view. Quiet, almost deserted."
    g "Go on, have a stroll. I'll fetch us some fuel."
    hide george with dissolve
    "She drifted across the cracked pavement. Six pumps, a narrow shop front, a squat row of toilets to the side."
    "Further back, at the edge of the lot, the remains of an old barrier — iron bars long rusted, some bent, others snapped off and jutting from the earth."
    "They had been set there once to keep people back from the cliff. Broken now, they kept no one from anything."

    # --- The broken rail (echoes the finale) -----------------------------------
    stop music fadeout 3.0
    play ambient sfx_wind fadein 1.0
    scene cg alice_cliff with dissolve_slow
    window hide
    pause 3.0
    window auto
    "Alice went to the gap in the rail and looked over."
    "The drop fell a long way to the water, and the wind came up it cold against her face."

    menu:
        "Step back from the edge.":
            "She took one small step back. Not from fear. Only because it seemed the proper thing to do."
            "The rocks stayed where they were, far below, patient."
        "Look a little longer.":
            "She leaned the smallest bit further, the toes of her Mary Janes at the very lip of the earth."
            "The sea broke white on the rocks and drew back, broke and drew back, and she watched it the way she had watched the candle."

    window hide
    pause 2.0
    window auto
    "She stood a while at the broken edge, looking down at the rocks, until George called her name."
    g "Alice, we're ready — let's go."
    "She turned and went back."

    # --- The walk back and the woman -------------------------------------------
    play music m_night_drive fadein 2.0
    scene bg coast_road_dusk at night with fade
    show george neutral at midright with dissolve
    show alicey worried at midleft with dissolve
    "The way back proved more tiring. After only a few minutes Alice winced, muttering that her feet hurt."
    "Shiny black Mary Janes with stiff straps and small bows — made for appearances, not distance. Every step turned into a small torment."
    g "Alright. We'll take a quick break."
    "They stood in silence until headlights appeared down the road."
    show george grim
    "Alice spotted the car first, then saw the hesitation flicker across George's face before he masked it with another smile. He raised his hand."
    "She pressed close against him, clutching his free hand. She had scarcely seen anyone from outside Driftwood Bay in her life."
    "Behind the glass, a woman at the wheel. She seemed anxious too, her hands gripping the wheel a little too tightly."
    ath "Maybe she's going to the ceremony."
    "Then she dismissed it. Why would she?"
    show george neutral
    "George did the talking, his tone courteous, practiced. After a pause, the woman nodded, and they climbed inside."
    hide george
    hide alicey
    with dissolve

    scene bg stranger_car_night with dissolve
    show rain
    # ART-REQUEST (fulfilled): stranger_car_night — back seat of a modest sedan at night, rain on glass, an anxious woman's hands tight on the wheel (no face needed).
    "The ride was quiet, heavy with unease. George kept smiling, polite, steady. Alice said nothing."
    "She watched the woman instead — the set of her jaw, the tension in her shoulders, the cut of her clothes."
    ath "She must be from the big town. She looks... different."
    g "That's us."
    "The car slowed. George leaned briefly toward the windshield with a few words of thanks, and the woman drove away, taillights fading into the night."

    # --- Night drive -----------------------------------------------------------
    scene bg truck_night with fade
    show vignette
    stop ambient fadeout 2.0
    play ambient2 sfx_engine fadein 2.0
    "The truck coughed, then roared back to life, and they continued on."
    "Night fell quickly. George never stopped driving, at least not while Alice remained awake."
    "She pressed her forehead to the cool glass, lulled by the hum of the engine and the endless dark unfurling outside."
    "Hunger gnawed at her, the kind that dulled thought and made her limbs heavy."
    "The ceremony, the gathering — those ideas blurred at the edges, slipping further away as exhaustion pressed down."

    # --- Dawn in the mountains -------------------------------------------------
    scene bg mountain_dawn with fade_slow
    play music m_night_drive fadein 3.0
    "When at last morning light spilled across her face, Alice stirred."
    "The road clung to the side of a mountain, the drop at its edge dizzying, endless. She recoiled, crawling to the other side of the cab." with hpunch
    "George laughed softly."
    g soft "It's alright. Everything's fine. Soon we'll be at our new home."
    "And so it was. By the time the sun climbed higher, they were winding into a small mountain town."
    stop ambient2 fadeout 3.0

    "The days that followed blurred together. Alice asked questions, of course — about the ceremony, about her parents, about why they had come here instead."
    "George's answers were vague but always warm. Enough to quiet her doubts, if not erase them."
    "Weeks passed. Alice enrolled in a new school. She found friends, pieced together routines. George's busy hands turned to repairs and small jobs around town."
    "As the months drifted by, the questions she once carried began to fade. Rare now, softer, less urgent."

    scene black with fade_long
    "Life seemed to settle with them."
    "But some nights, when Alice woke in the dark, she still wondered if her parents were waiting for her, somewhere..."
    extend " to finish what they had begun."
    stop music fadeout 3.0
    window hide
    pause 2.0
    window auto

    jump ch02
