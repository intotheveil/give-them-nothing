## Give Them Nothing — Chapter 5
## Source: docs/manuscript/ch05.txt
## POV: Samuel (cemetery → station → nursery → briefing → Markou),
##      Alice (school, dinner, the walk to Markou), Samuel (Markou's office).

label ch05:
    call chapter_card(5, "Greyvale — the day of Clara's funeral")

    # ------------------------------------------------------------------
    # The cemetery: chaos after the priest falls
    # ------------------------------------------------------------------
    scene bg cemetery_day with fade_slow
    play music m_ritual3 fadein 1.5
    play ambient sfx_wind fadein 2.0
    play ambient2 sfx_crowd fadein 1.0
    call place("Greyvale Cemetery — midday")

    "The moment the priest fell, the funeral fractured into chaos."
    "What had been a still, somber crowd became a surging knot of voices, shouts and movement."
    "Samuel Harris stepped forward, coat tugged tight against the bitter air, his arm lifted."
    s "Everyone calm down! Please, stay back!"
    "Some froze at his voice, startled by its command. Others pressed closer, curiosity outweighing caution."
    "People shoved, some craning their necks to see the priest's crumpled body at the grave's edge, others backing away in fear."
    "And then Evelyn Ward's voice cut through like a knife."

    show evelyn grief at center with dissolve
    ev "You!"
    "Her face was white with rage and grief. She pointed at Samuel, her hand trembling."
    ev "What are you doing here? My girl is dead, and now the priest—"
    "Her voice cracked, but she pushed on, louder."
    ev "It's you. You brought this here. You're not from this town. Why are you even here?"
    "Richard Ward staggered beside her, eyes glazed but filled with bitterness."
    rw "Leave us alone. You don't belong here!"

    "It landed like a slap. And what came after was worse than the slap."
    stop ambient2 fadeout 2.5
    "Not a roar. A settling."
    "The noise went out of the crowd where Evelyn's words had passed. Faces turned toward him one by one, and stayed turned."

    window hide
    pause 3.0
    window auto

    "No one else spoke. They didn't need to."
    "A whole churchyard simply looked at the outsider standing over their second body in a week, and let him feel the look."
    "Samuel kept his face blank, his tone steady."
    s "I'm here to do my job. That's all. Now step back. Let the medics through."

    hide evelyn with dissolve
    show leary angry at right with dissolve
    "Into that cold quiet, one voice came loud."
    "Kurt Leary. Samuel knew him from Hensley's shop, the kind of man always loudest in a corner. He jabbed a finger over the heads between them."
    kl "We never had bodies dropping like this until he showed up!"
    "No one took it up. No one had to."

    window hide
    pause 2.5
    window auto

    "It hung there in the silence, agreed with by every face that wouldn't say so."
    "That was worse than a crowd shouting back would have been."
    hide leary with dissolve

    play ambient2 sfx_crowd fadein 0.5
    show mercer neutral at left with dissolve
    "Before the hostility could swell further, Mercer pushed through, his broad frame forcing space where there was none."
    m "Enough! Step back! Everyone back!"
    "He shoved a man back with one hand, the other held up. His voice was raw with strain, but it carried the authority of someone desperate to keep order."
    show lara stern at right with dissolve
    "Beside him, Officer Lara Whitfield shouldered her way forward."
    l "Clear the area! Right now! Move back, give space!"
    "She gestured toward the road. The resistance broke unevenly."
    "Some obeyed, retreating with mutters. Others bristled and shouted, but Mercer's hands and Lara's sharp tone pushed them back a step at a time."
    hide mercer with dissolve
    hide lara with dissolve

    "The fire department arrived minutes later, the red truck forcing its way up the narrow path to the cemetery."
    "Firefighters in reflective jackets jumped down and spread their arms wide, pushing the crowd into smaller clusters."
    "Behind them an ambulance pulled in. One medic crouched at the priest's side, checking for vitals, and shook his head almost immediately."
    "The other pulled a sheet from the kit."

    "Samuel's eyes stayed fixed on the scene, but his hands were already moving. He snapped on his gloves."
    show lara neutral at right with dissolve
    s "Help me secure what we can before the crowd tramples everything."
    "She nodded quickly, pulling her own gloves from her belt."
    "They started near the priest's fallen Bible. Samuel lifted the leather-bound book gently, noting the scuff on its cover from the fall, and set it into the bag Lara held open."
    "He signaled a patrol officer to start a perimeter log and snap phone photos before anything moved. Optics mattered as much as evidence."
    "The bottle of water came next. Still half-full, its cap resting in the dirt nearby. He lifted it with care, fingers away from the rim."
    "The closest medic gave him a sharp look, but said nothing as Samuel bagged it too."
    s "Check the ground. Any scrap, paper, anything that doesn't belong."
    "Lara crouched lower, eyes scanning the grass near the grave. She lifted a small slip of white. Torn paper, faintly smudged."
    "Another word, Samuel realized. But the mud had blurred it past recognition. He bagged it anyway."
    hide lara with dissolve

    "The medics drew the sheet over the priest. A collective gasp went through the crowd, then fresh cries of prayer and panic."
    "Samuel stood, coat snapping in the wind. His eyes swept the graveyard until they found Emily Carter, sobbing violently into her father's coat as her mother pulled her back."
    "Her hands clawed at her face as though the sight had scarred her."
    "Alice stood beside her, one hand still clamped on Emily's arm."
    "Unlike Emily, she wasn't looking away."
    "When the Carters finally dragged Emily off, Alice resisted for only a moment before letting go. She stayed near the grave, her gaze following the medics as they lifted the priest onto the stretcher."

    show alice neutral at center with dissolve
    "Too still. Too attentive."

    menu:
        "Send her off.":
            "Samuel didn't let himself linger on it. A crowd still churned at his back, and evidence waited under his boots."
        "Study her a moment.":
            $ notice()
            "He let himself look. She wasn't staring the way children stare at a body: fixed, frightened, unable to look away."
            "Her eyes moved. The stretcher, the medics' hands, the bagged bottle, the gap in the crowd. Then back."
            "She was taking in the scene the way he took in a scene."
            th "Numb. That's all. She's watched her best friend buried and a priest fall dead in the same hour. Kids go flat in shock."

    "He walked toward her, the evidence bags heavy in his hand. Behind him the firemen pushed the crowd farther back, leaving a circle of relative calm around the grave."
    stop ambient2 fadeout 2.0
    s "You should go."
    "Alice didn't move. Her eyes shifted to him, calm, curious, too composed for twelve."
    a "I'd rather not go home right now. Not before lunch."
    "Her voice was steady, her face blank, but the words hung in the air with a strange weight."
    s "Why not?"
    a "Because when George tells me to do something, he doesn't like when I disobey. I don't want to make him upset."
    "Most children would have said it dramatically, inflating a scolding into a punishment. Alice spoke with gravity, every syllable certain."
    "She meant it. If she disobeyed, she would be in trouble. And not the kind of slammed doors or raised voices."
    "Samuel didn't like the weight behind her tone. But the graveyard wasn't the place to analyze it."
    s "Alright. Then for now, go with Officer Whitfield. Stay close to her until I'm finished here."
    play sound sfx_static
    "He tapped his radio, logging it aloud."
    s "Juvenile transport, with officer escort."
    $ note("Juvenile transport, Alice Bennett, with officer escort.")
    note_voice "Juvenile transport, Alice Bennett, with officer escort."

    show alice neutral at midright with move
    show lara neutral at left with dissolve
    s "Lara. Take Alice outside the graveyard, away from the crowd. Stay with her until I catch up."
    "Lara gave a short nod and bent slightly, a hand on Alice's shoulder."
    l "Come on, sweetheart. Let's get you some air."
    "Alice didn't resist. She cast one last look toward the grave, then let herself be led away. Small, but unnervingly composed."
    hide alice with dissolve
    hide lara with dissolve

    "The mayor's voice still carried faintly, calling the town to unity and faith. The people weren't listening."
    "They huddled in tight groups, muttering about curses, outsiders, sins."
    play sound sfx_thud
    "The ambulance doors shut with a metallic thud that echoed across the cemetery."
    "The siren didn't wail. The priest was already gone."
    "Samuel knelt again by the grave. Bottle, paper scrap, disturbed dirt. All bagged. But he kept looking."
    th "He doesn't like when I disobey."

    # ------------------------------------------------------------------
    # The chapel: the priest's effects
    # ------------------------------------------------------------------
    scene bg chapel_interior with dissolve
    show vignette
    play music m_church2 fadein 2.0
    # ART-REQUEST (fulfilled): small village chapel interior (vestry, lectern, candles), daylight through narrow windows.
    "Inside the chapel, Samuel and Mercer worked quickly but thoroughly."
    show mercer neutral at right, dimmed with dissolve
    "From the vestry and the altar table: reading glasses in a worn leather case, a small wooden crucifix, a rosary, a pocket notebook of sermon notes in tight script, a ring of old brass keys."
    "From the lectern, his Bible, still open at the passage he had recited, and a second bottle of water resting in a tray, untouched."
    "Mercer swept up the priest's pen and a few loose sheets where he had marked references. Everything went into separate bags, labeled and logged."
    "When it was done, Samuel closed his notebook. The chapel was silent again, the air heavy with candle smoke."
    s "That's it. Let's wrap it."
    hide mercer with dissolve

    scene bg cemetery_day with dissolve
    show snow light
    "Outside, snowflakes drifted lightly at first, but the wind was picking up, carrying the promise of another storm. The grave markers blurred in the growing white."
    show lara neutral at left with dissolve
    show alice neutral at midright with dissolve
    "At the gate, Lara stood waiting. Beside her, Alice, hands tucked into her sleeves, hair stirred by the wind."
    "The two had been speaking quietly. Both looked up when he approached."
    s "I'll take her home."
    a "Alright."
    hide lara with dissolve
    hide alice with dissolve
    "Samuel opened the passenger door for her. Alice climbed in without a word, her small hands smoothing the skirt over her knees."

    # ------------------------------------------------------------------
    # The drive to the Bennett house
    # ------------------------------------------------------------------
    scene bg car_day_snow with dissolve
    show snow heavy
    stop ambient fadeout 1.5
    play ambient2 sfx_engine fadein 1.5
    play music m_outside2 fadein 2.0

    "The heater roared faintly, filling the cabin with dry warmth. The road out of town was nearly deserted."
    "For a while neither spoke. The only sound was snow brushing the windshield."
    show alice neutral at midright with dissolve

    menu:
        "Ask how she got to the funeral.":
            s "How did you get to the funeral? Did George bring you?"
            a "No. George is usually occupied. I walk."
            s "Even in weather like this?"
            show alice smile
            "Alice laughed softly, a quick burst that fogged the glass."
            a "Yes. It's nothing too weird. I'm used to it."
            s "Tougher than half the officers I know."
            show alice neutral
            "She didn't answer. So he asked the other thing."
            s "What about your parents?"
            "That drew silence. Her gaze stayed fixed forward, lips pressed."
            s "Is something wrong?"
            a "I'm not allowed to talk or ask about them. It's for my own good."
        "Ask about her parents.":
            s "Your parents. Where are they?"
            "That drew silence. Her gaze stayed fixed forward, lips pressed."
            s "Is something wrong?"
            a "I'm not allowed to talk or ask about them. It's for my own good."
            "He let it sit. Tried an easier door."
            s "How did you get to the funeral? Did George bring you?"
            a "No. George is usually occupied. I walk."
            s "Even in weather like this?"
            show alice smile
            "Alice laughed softly, a quick burst that fogged the glass."
            a "Yes. It's nothing too weird. I'm used to it."
            show alice neutral
            "The lightness didn't reach back to the other answer. It hadn't been meant to."

    "Samuel's grip tightened slightly on the wheel."
    s "What's that supposed to mean? Not allowed?"
    "This time she turned her head, her eyes meeting his. Clear. Unwavering."
    a "It's okay. George is my grandfather. He takes good care of me. He gets things done. And I'm grateful."
    "Samuel held her look a moment, then nodded faintly. He didn't press further. Not now."
    hide alice with dissolve
    "The rest of the drive passed in silence. The houses grew sparser, the road bending toward the edge of Greyvale."
    a "There."

    # ------------------------------------------------------------------
    # The Bennett house
    # ------------------------------------------------------------------
    scene bg bennett_house_day with dissolve
    show snow heavy
    stop ambient2 fadeout 1.0
    play ambient sfx_wind fadein 1.5

    "The house stood back from the road, framed by a high wooden fence and a wide garden, surprisingly well kept despite the season."
    "Snow dusted the hedges. The path was cleared to bare stone. Plants trimmed, boundaries neat, nothing out of place."
    "Shutters closed tight. Wood dark and polished by years of care."
    "Samuel walked Alice to the front door and knocked. The sound echoed through the winter air."
    stop music fadeout 1.0
    play sound sfx_thud
    show george grim at center with dissolve_fast
    "The door swung open before his knuckles had left the wood."
    "George Bennett filled the frame. Tall, broad-shouldered, his face set in hard lines. As though he'd been standing just behind it, waiting."
    show alice neutral at left with dissolve
    "His eyes went to Alice first."
    g "What is he doing here?"
    "Alice opened her mouth. George cut across her."
    g "And what's this? You got in a car with a stranger?"
    g "Go. To your room. Now."
    "Alice dipped her head once, said nothing, and vanished into the house without hesitation. Her steps were light and swift, fading up the stairs."
    hide alice with dissolve_fast
    "Samuel hadn't moved to intervene. It wasn't his place. Only once she was gone did he speak, low but sincere."
    s "Apologies. I didn't want to let her walk home in this storm."
    "George made a noise in his throat, half growl, half grunt, his eyes narrowing."
    "Then, without a word more, he pushed the door shut."
    hide george with dissolve_fast
    play sound sfx_thud
    "The latch clicked into place. The sound was final."
    "Samuel stood on the porch a moment, snowflakes gathering on his coat, before he turned back to the car."

    # ------------------------------------------------------------------
    # The drive back: control
    # ------------------------------------------------------------------
    scene bg car_day_snow with dissolve
    show snow storm
    stop ambient fadeout 1.0
    play ambient2 sfx_engine fadein 1.0
    play music m_outside2 fadein 2.0

    "The drive back was slow, the snow thickening, the road narrowing beneath the storm."
    "One hand on the wheel. The other tapping an unlit cigarette against the ashtray. His thoughts were circling the Bennett house."
    th "George isn't just strict. He's dominant."
    "The way Alice obeyed, without a breath of hesitation, without a glance back. That wasn't respect, and it wasn't a child's defiant obedience either."
    "It was drilled into her. Conditioned."
    th "Abuse?"
    "He hadn't seen marks. Not yet. But control like that, forbidding her even to speak of her parents, left a different kind of scar."
    th "I don't want to make him upset."
    "With her, it hadn't sounded like a complaint. It had sounded like a warning."
    th "Why can't she talk about her parents?"
    "If they were estranged, or dead, or dangerous themselves, why not just say so? Unless George wanted the silence. Unless the silence served him."
    $ note("George: dominant. Child forbidden to speak of parents.")
    note_voice "George: dominant. Child forbidden to speak of parents."
    "He'd talk to Mercer. See whether anyone had looked too closely at George Bennett and his granddaughter since they arrived."
    "For now, there was still the case. Three bodies in a week, and the evidence piling up in uneven layers."

    # ------------------------------------------------------------------
    # Hotel room: Doyle
    # ------------------------------------------------------------------
    scene bg hotel_room_day with fade
    stop ambient2 fadeout 1.0
    stop music fadeout 2.0
    call place("The Greyvale Hotel — afternoon")

    "He parked, braced against the storm, and went up to his room. The diary waited on the table. But there was one call to make first."
    play sound sfx_phone
    show screen phone_call("Raymond Doyle")
    s "Captain. I've got updates."
    d angry "Harris. You better have something, because all I've got on my desk are calls from Greyvale's mayor, county officials, and a goddamn state rep asking why a priest dropped dead at a funeral in broad daylight."
    "Samuel pinched the bridge of his nose."
    s "It happened right in front of me. Same pattern as Hensley. Sudden collapse, signs of poisoning. We collected the bottle he drank from. Forensics will confirm, but I'll bet it's yew again."
    "Doyle swore hard, the sound muffled but venomous."
    d angry "Christ, Sam. Do you know what this means? We're not chasing a troubled kid, or a bad marriage turned ugly."
    d angry "We're hunting a serial. A goddamn serial killer in a town of less than three thousand people. And we've got nothing. No suspects, no witnesses, no goddamn trail."
    s "We've got breadcrumbs. Notes. That USB. The paper scraps with words cut out. There's a message in it. Someone's judging, picking targets for their flaws."
    d angry "Breadcrumbs don't catch killers. You've been there a week and now I've got three bodies and a goddamn panic brewing in a town that should've been a quiet assignment."
    d angry "You realize how this looks? Like we sent our best man to shuffle paper in Greyvale, and instead he brought the devil to town."

    menu:
        "Push back.":
            "Samuel's jaw tightened, but his voice stayed calm."
            s "I didn't bring anyone. Whoever's behind this was already here. I'm just uncovering the trail."
            d angry "Trail? Sam, there isn't a trail. There's a goddamn ghost running circles around us."
        "Take it.":
            "Samuel let it land. Doyle needed somewhere to put it, and Samuel had been a wall for worse."
            "Then, quietly, only the one correction."
            s "Whoever's behind this was already here, Ray. I'm just uncovering the trail."
            d angry "Trail? There isn't a trail. There's a goddamn ghost running circles around us."

    d angry "Do you have a single suspect? A name? A face?"
    "Samuel's silence was answer enough."
    d angry "Then get one. I don't care if you shake every house in that town. I don't care if you piss off every councilman. We cannot afford another body, you understand? Not one more."
    "Samuel rubbed his temple, his eyes on the diary."
    s "I understand."
    d angry "Good. Because if there's another, the feds are going to crawl all over this, and they'll burn both of us in the process."
    d angry "Find me a suspect, Sam. Fast. Or pack it up and come home."
    play sound sfx_beep
    hide screen phone_call
    "The line went dead."
    "He looked at the diary, its cover half-shadowed in the lamplight. The last thing Clara Ward had left behind."
    th "A suspect. A face. A ghost doesn't leave trails."
    th "But someone had to put the knife in her hand. Someone had to drop poison in their cups."
    "He called Mercer on the way out, clipped."
    s "Meet me at the department. You should be done with the priest's family by now."

    # ------------------------------------------------------------------
    # Station office: Karalis file, the Bible
    # ------------------------------------------------------------------
    scene bg station_office with fade
    play music m_office fadein 2.0
    call place("Greyvale Police Department — evening")

    "The station was half-dark when Samuel stepped in, snow dripping from his coat."
    show mercer neutral at left with dissolve
    "Mercer waited in a side office, a file open on the desk, his face pale with fatigue."
    s "What do we have?"
    m "Father Dimitrios Karalis. Fifty-six. Born and raised here in Greyvale, serving the parish nearly thirty years."
    m "Married. His wife, Anna, has been away the last three days, visiting their children. No history of illness, no record of enemies."
    m "People described him as stern but fair. Everyone knew him."
    "He closed the file with a heavy hand."
    m "Detective, this wasn't random. He was as rooted in this town as the cemetery we buried Clara in."

    play sound sfx_thud
    show lara stern at right with dissolve_fast
    "Before Samuel could answer, the door banged open. Lara rushed in, coat still dusted with snow, the priest's Bible pressed carefully to her chest."
    l "I found something."
    "She set the book down, opened it to the middle, and with two fingers turned it so the men could see."
    stop music fadeout 1.5
    "In the margin, in heavier ink that pressed fresh indentations visible under the lamp:"

    scene black with dissolve_slow
    play music m_ritual fadein 3.0
    window hide
    pause 1.0
    window auto
    note_voice "Your voice was false. Silence is purer."
    window hide
    pause 2.0
    window auto

    scene bg station_office with dissolve_slow
    show vignette
    show mercer shaken at left
    show lara stern at right
    with dissolve
    "The handwriting was sharp, deliberate. Letters cut into the paper rather than flowing across it."
    m shaken "Holy hell..."
    "Samuel didn't move. The same style. The same cold judgment threaded through Maria's USB, through Hensley's scrap."
    $ note("Bible margin: 'Your voice was false. Silence is purer.'")
    th "Liar. Weakness. Silence."
    "A pattern of judgment. Maybe not random. Maybe a taxonomy forming."
    $ note("LIAR — WEAKNESS — SILENCE. A taxonomy?")
    note_voice "LIAR — WEAKNESS — SILENCE. A taxonomy?"
    "He straightened slowly, his hand resting on the open Bible."
    s "We have a serial killer."
    "Mercer pointed at the evidence bag before Samuel could."
    m neutral "That scrap's cut from thicker stock. Not notebook paper. Could be from a hymn book."
    "Samuel gave a brief nod. He hadn't noticed."
    "The statement hung in the room like frost. Lara shifted, lips pressed tight. Mercer's eyes darkened. They had known it in their bones already. Hearing it was worse."
    s "And the person who's doing this... believes they're a judge. Criticizing. Weighing. Passing sentence."
    "He let the silence stretch. Then he turned to Mercer."
    s "Can you run a background check on George Bennett?"
    m "Of course. But... why George?"
    s "Because his granddaughter told me this: Weakness. Dishonesty. Hypocrisy. It all shows in the end. And when it does, it has to be corrected."
    s "That's not childhood wisdom. That's what George is teaching her. Or better: enforcing on her."
    "The disgust was visible on both their faces. Lara's jaw tightened, her eyes flashing."
    m "That's not something you drill into a twelve-year-old. That's—"
    "He cut himself short, anger simmering."
    "Samuel closed the Bible gently and slid it into the evidence bag. His expression remained unreadable."
    m "I'll dig. As much as I can. But don't expect much. He's clean on the surface. When they moved here, I checked him out myself. Nothing in the system. Not even a speeding ticket."
    s "Check again. This time, deeper."
    m "Alright."
    "The storm's whistle leaked faintly through the windows. Samuel turned to Lara."
    s "What about yew? Anyone local who'd know the plant? Where it grows, who's been buying it?"
    show lara neutral
    l "Nick Green. Runs the nursery just outside of town, near the old mill road. People go to him for anything green. Hedges, garden plants, specialty orders."
    l "If anyone knows about yew in this area, it's him."
    s "Good. Let's pay him a visit."
    m "I'll stay and start pulling everything I can on Bennett."
    s "Do that."
    hide mercer with dissolve
    hide lara with dissolve

    # ------------------------------------------------------------------
    # Green's Nursery
    # ------------------------------------------------------------------
    scene bg car_night_storm with dissolve
    show snow storm
    stop music fadeout 2.0
    play ambient2 sfx_engine fadein 1.0
    "Snow was piling against the curbs, the wind sharper than before. The engine coughed before the heater began to hum."
    "Past shuttered shops and houses already swallowed in snow. Fifteen minutes later, the headlights caught a wooden sign. Green's Nursery."
    stop ambient2 fadeout 1.0

    scene bg nursery_greenhouse with dissolve
    play music m_office fadein 2.0
    "A squat building with a glasshouse attached, its roof glowing faintly from inside. Rows of covered plants. Tools arranged neatly under awnings."
    "Inside, the air was damp and rich with soil. The smell of green life, clashing with the death they'd carried all week."
    show nick neutral at center with dissolve
    "Behind the counter stood a stocky man in his late forties, wiping soil-stained hands on his apron."
    ng "Detective. Officer. What brings you out here in this weather?"
    show lara neutral at right, dimmed with dissolve
    l "Nick Green. Sorry to bother you. We've got some questions about yew."
    "His brows lifted. He waved them deeper into the greenhouse, where lamps glowed warm against rows of potted shrubs. The air smelled of damp soil and resin."
    ng "Yew? Yes, of course. Common enough around here. You'd be surprised how many people keep it without realizing what it is."

    menu:
        "Ask where it grows.":
            s "Give me examples."
            call ch05_yew_where
            call ch05_yew_how
        "Ask how easy it is to kill with.":
            s "Start with the poison. How hard is it to make it kill?"
            call ch05_yew_how
            s "And where would someone get it? Give me examples."
            call ch05_yew_where

    "Nick leaned his arms on the counter, his expression serious."
    ng "Detective, if someone is using yew in this town, they didn't have to buy it. It's everywhere. Every hedge you passed on your way here could be the source."
    "Samuel shut his notebook, jaw tightening."
    th "Widespread. Accessible. Invisible. A perfect weapon for someone who wanted judgment to look like chance."
    $ note("Yew: every hedge in Greyvale. Resin on hands for hours.")
    note_voice "Yew: every hedge in Greyvale. Resin on hands for hours."
    s "Thank you, Mr. Green. That's what I needed."
    ng "If you want samples tested or plants cataloged, I can help. But finding the source? That'll be near impossible."
    "Samuel and Lara exchanged a look."
    s "Near impossible. That's exactly what this bastard wants."
    "He slid a business card across the counter."
    s "If you think of anything — someone asking strange questions, anyone taking cuttings, anything out of place — call me directly. Day or night."
    ng "I'll keep my eyes open."
    s "Let's go, Lara."
    hide nick with dissolve
    hide lara with dissolve
    jump ch05_car_lara

label ch05_yew_where:
    "Nick pointed toward a long row of tall, dark evergreens beyond the glass, needles bristling even in the storm."
    ng "Those hedges you see in half the gardens? Yew. People like them because they grow thick, make good privacy screens."
    ng "You'll find them around schools, old estates, even the cemetery. Hardy plant, grows in poor soil, easy to trim."
    ng "There's ornamental yew too. Dwarf varieties for decoration. Shrubs in front yards, sometimes even potted inside lobbies. No shortage of it in Greyvale."
    show lara neutral at right
    l "So anyone could just... walk outside and cut some?"
    ng "Easily."
    return

label ch05_yew_how:
    ng "Every trimming has enough toxin to cause trouble if someone knows what they're doing. The leaves, the seeds — almost the entire plant is poisonous, except the fleshy red berries."
    ng "But the seeds inside those berries? Lethal. Doesn't take much to crush them into powder or steep them in water."
    "Samuel scribbled quickly."
    s "Could someone without training use it? Or would they need knowledge?"
    ng "Knowledge helps, but you don't need to be a chemist. Anyone with curiosity could look it up. Even an amateur could make an extract dangerous enough to kill."
    ng "A concentrated tea. Ground seeds in food or drink."
    ng "But anyone handling it would reek of resin for hours. On clothes, under nails. You'd know if you leaned close enough."
    return

label ch05_car_lara:
    scene bg car_night_storm with dissolve
    show snow storm
    play ambient sfx_storm fadein 1.5
    "The cold hit them hard. By the time they reached the car, the windshield was already dusted white."
    "The heater groaned to life. Samuel rubbed his palms together, watching the storm whip the glass."
    show lara stern at midright with dissolve
    "Lara buckled in, jaw tight, tapping her glove against her knee."
    l "Everything about this feels... too perfect."
    l "The blackmail, the words left behind, the poison. It's all too well-orchestrated. Like someone's rehearsed it."
    "Samuel struck a match, lit a cigarette, and leaned back."
    s "That's because they have. Whoever this is, they've been planning for a long time."
    "Lara exhaled sharply, staring out at the snow."
    hide lara with dissolve
    stop ambient fadeout 2.0
    stop music fadeout 2.0

    # ------------------------------------------------------------------
    # Next morning: briefing
    # ------------------------------------------------------------------
    scene bg station_office with fade_long
    play music m_office fadein 2.0
    call place("Greyvale Police Department — next morning")

    "By morning the storm had eased. The streets were still caked with snow, the air brittle with cold, but the department hummed with purpose."
    "Samuel sat in the cramped conference room, blinds half-drawn, a fresh mug of coffee cooling by his hand."
    show mercer neutral at left with dissolve
    show lara neutral at right with dissolve
    m "Toxicology came back this morning. No doubt about it. The priest's bottle contained yew alkaloids, same as Patrick Hensley."
    m "Autopsy confirms the same. Cardiac arrest brought on by poisoning. We've got a consistent method."
    l "So it's official. Three bodies. Same killer."
    "Samuel tapped ash into the tray, his eyes on Mercer."
    s "And Bennett?"
    "Mercer leaned forward, opening a thin file."
    m "This one's strange. George Bennett's house was bought outright, in cash. No loans, no mortgage. Title cleared and clean."
    m "He's registered as originating from Driftwood Bay. Small coastal village, three hours south. Barely more than a cluster of houses."
    s "Driftwood Bay..."
    stop music fadeout 2.0
    m "I dug deeper last night. No criminal record, no financial trail, no ties outside Driftwood Bay."
    play music m_ritual2 fadein 3.0
    m "Only thing that surfaced was a missing-persons report. Two sisters went missing there about two years ago."
    m "File's barebones, just a couple of patrol notes. Investigation went cold almost immediately. When I asked Driftwood Bay PD for the file, they were quick to dismiss it."
    show lara stern
    l "That's all?"
    m "That's all. No follow-up, no statements worth a damn. Like it was buried before it started."
    m "Locals don't talk about it. Driftwood Bay's like a wall. Outsiders get shrugs, silence, or ghost stories. If Bennett came from there, whatever shaped him didn't make it into a report."
    $ note("Bennett: cash purchase. Driftwood Bay. Two sisters missing, file buried.")
    note_voice "Bennett: cash purchase. Driftwood Bay. Two sisters missing, file buried."
    "Samuel's fingers drummed once against the folder. He reached for his cigarette case, stopped short, and closed it with a snap."
    s "I'll tell you both what I'm going to do."
    s "George Bennett leaves nothing on paper. But Alice has been under observation. If anyone has something solid, it'll be in her file."
    m "The school's psychologist?"
    s "Dr. Markou. She's already talked with Clara. She's seen Alice too. If I can get those notes, we stop guessing about George's influence and start reading it in black and white."
    l "You think she'll hand that over?"
    s "She'll understand it's part of the investigation."
    "He stood, slipping the case back into his coat."
    s "One way or another, I'll get it."
    hide mercer with dissolve
    hide lara with dissolve
    stop music fadeout 2.0

    # ------------------------------------------------------------------
    # Markou's office: the refusal
    # ------------------------------------------------------------------
    scene bg markou_office with fade
    show snow light
    play music m_office fadein 2.0
    call place("Dr. Markou's office")

    "Snow clung to his shoulders as he came in out of the gray morning. The lobby smelled of oak smoke and polish. A clock ticked with the slow certainty of a metronome."
    "He didn't bother with pleasantries. He hung his coat and pushed into Helena Markou's office."
    show helena neutral at center with dissolve
    "She was already standing, one hand on the back of her chair, the other flattening a page in an open notebook. Professionally neutral."
    h "Detective Harris."
    s "I need Alice Bennett's file."
    "No softening, no lead-in. The words landed like a stamp on wet paper."
    "Helena's eyes flicked to the door as it clicked shut, then back to his face."
    h "You're direct."
    s "I'm out of time. Three deaths in a week. One of them a child, the last in front of half the town."
    s "Whoever's doing this writes in judgments. And the only person I've heard use the same language is a twelve-year-old repeating her grandfather."
    "Helena drew out the chair and sat, folding her hands on the desk."
    h "You're referring to 'flaws' and 'correction.'"
    s "That's right."
    h "And you believe access to her confidential record will — what? Prove a murderer's philosophy?"
    s "I believe it will tell me whether Alice is speaking in her own voice or someone else's. Whether she's a mirror, or a mouthpiece."
    s "And whether George Bennett is more than a strict guardian."
    h "You've seen abused children before, Detective?"
    s "Yes."
    h concerned "Then you know how thin the ice is. You know how quickly a child's trust fractures when adults with badges treat them as sources instead of patients."
    "She slid the notebook aside, revealing a neat stack of folders."
    h firm "I won't give you her file."

    menu:
        "Settle for a redacted summary.":
            call ch05_markou_redacted
            call ch05_markou_emergency
            call ch05_markou_safe
        "Call it an emergency.":
            call ch05_markou_emergency
            call ch05_markou_redacted
            call ch05_markou_safe
        "Ask if Alice is safe in that house.":
            call ch05_markou_safe
            call ch05_markou_redacted
            call ch05_markou_emergency

    "The fire cracked behind her. The room had the calm of a cathedral and the tension of a wire."
    s "Then meet me halfway. Tell me, as a clinician, whether what she says is indoctrination, or precocity. Whether she parrots phrases, or believes them. No names. No details. Just the shape."
    h "You're a clever man. You know that even answering that much is a step down a slope designed for speed."
    s "I'll take the slope. Children are dying."
    "She adjusted her glasses."
    h "Children have always been dying. Some by their own hands, some because men decide their flaws demand correction. That isn't solved by handing you a girl's insides on paper."
    s "You can document a case history without betraying a patient. You can speak in generalities."
    h "I can. And I won't."
    "Samuel's knuckles whitened against the desk. He forced them flat. Took it in. Recalibrated."
    "He opened his hands, palms up, as if offering something invisible."
    s "You told me yesterday that this town knew what Clara lived with and did nothing. You included yourself in that failure."
    h concerned "Yes. I did."
    s "And today you're choosing the same caution that kept everyone comfortable while a girl wrote that she was made of glass."
    h firm "No. Today I am choosing the only thing that has ever kept children like Alice from being ground between the police and the mob: a line."
    h "You want me to move it because you are desperate. Desperation is how bad detectives excuse broken rules. Don't make me watch you become one of them."
    "The clock ticked. Samuel's fingers twitched toward a cigarette he couldn't light in here. He rubbed at the scar in his palm."
    s "Then give me process. Tell me how to request a court order for a limited review."
    s "Tell me what threshold a judge needs. A clinician's affidavit, a risk assessment, a sworn statement that a child's worldview has been weaponized."
    "She reached for a pen, then set it back down."
    h "You won't get it before another body falls, if that is where your fear rests."
    s "My fear rests in a sentence written inside a priest's Bible. 'Your voice was false. Silence is purer.'"
    s "Someone thinks they are cleansing this town. If Alice has been taught to admire that righteousness, I need to know."
    show helena concerned
    "Her gaze softened by a degree. Not enough to yield."
    h "And if she has been taught to survive by sounding like the person who feeds her? If mimicry is safety? If the words are shield and not sword? You would still turn them into evidence."
    s "I would turn them into understanding."
    "It came out closer to pleading than he liked. He reined it back."
    s "And maybe a way to stop whoever is putting poison in people's hands."
    "Helena folded her arms."
    h firm "No file, Detective. Not today. Not on my discretion. If a judge compels me, I will comply to the word of the order and not a syllable more. Until then, I am her doctor."
    "The fire murmured. Snow whispered against the window. He felt the old pulse behind his eyes: frustration, tempered by the part of him that respected a line held."
    s "Then we're done for now."
    "The smallest dip of her chin."
    h neutral "For now."
    $ note("Markou: no file. 'For now.'")
    note_voice "Markou: no file. 'For now.'"
    hide helena with dissolve

    scene bg greyvale_street with dissolve
    show snow heavy
    play ambient sfx_wind fadein 1.5
    "Outside, the snow pressed harder. He buttoned his coat, jaw tight."
    th "For now."
    "But children were bleeding out in locker rooms. Priests were dropping in front of crowds."
    "And George Bennett's granddaughter spoke in judgments like scripture."
    "'For now' wasn't going to last. He lit a cigarette on the steps, the smoke torn by the snow."
    stop ambient fadeout 2.0
    stop music fadeout 2.5

    # ------------------------------------------------------------------
    # Alice POV: the restroom
    # ------------------------------------------------------------------
    scene black with fade_slow
    pause 0.8
    scene bg school_corridor with dissolve
    play music m_outside fadein 2.0
    call place("Greyvale High — 12:15 p.m.")

    "Alice paced slowly near the tiled entrance of the girls' restroom, her shoes clicking faintly."
    "Mid-break. The corridors buzzed with scattered voices and laughter. She was waiting for Emily, probably doodling in the library again."
    stop music fadeout 1.0
    "Then came the noise. Muffled at first, then sharper. A squeal, a stifled sob, scuffling against ceramic."
    "Someone was being shoved inside. Alice tilted her head toward the door, then pushed it open."

    scene bg school_restroom with dissolve
    "The air smelled of disinfectant and damp cotton."
    "Three older girls, fifteen or maybe sixteen, had another pressed hard against the mirror, her cheek smearing on the glass. Her shoulders shook as she sobbed."
    bully "Think you can flirt with Johnathan? He's mine. Everyone knows it."
    "The others laughed, forcing the girl closer to the mirror, her breath fogging the cold surface."
    show alice neutral at center with dissolve
    "Alice lingered in the doorway, quiet, her gray-brown eyes flicking across the scene. They hadn't noticed her yet."
    "The sobbing girl's gaze caught Alice's reflection in the mirror. Pleading, wordless."
    "Alice stepped further in. She didn't look at the girl doing the barking. She tilted her head slightly, as if measuring the room rather than the people in it."
    "Then her gaze locked on the tall one with the braided hair. The leader."
    a "I'm pretty sure the janitor cleans the restrooms during the twelves. Lunch break."
    "She let it hang a beat, her tone flat as stone."
    a "So he'll be here any minute now."
    "The bully froze. Her grip slackened. Doubt crossed her face, then calculation."
    bully "She's right. Let's go."
    "One spat on the floor. Another shot Alice a look sharp enough to cut. None of them spoke as they left."
    "The room fell quiet except for the hitching sobs of the girl at the mirror. A streak of moisture smeared down the glass where her cheek had been."
    "She stumbled to the sink, splashed cold water on her blotched face, dried it on her sleeve, and pulled her bag onto her shoulder."
    "Not once did she look at Alice."

    scene bg school_corridor with dissolve
    play music m_outside fadein 2.0
    "The girl pushed out into the hallway, past Emily, who stood just outside clutching her books to her chest. The two locked eyes, and the girl was gone."
    show emily smile at midleft with dissolve
    e "Alice! I've been looking everywhere for you."
    show alice smile at midright with dissolve
    "Alice's lips curved faintly. An echo of warmth."
    a "And I was waiting for you."
    e "Good. Because I didn't want to eat alone."
    "They walked side by side toward the cafeteria. After a few steps, Emily leaned closer."
    show emily worried
    e "What happened in there? That girl looked... upset."
    show alice neutral
    a "She was being bullied."
    e "Oh."
    a "I don't like bullies. They remind me of George."
    "A flicker of unease crossed Emily's face. But Alice's didn't shift. No drama, no complaint. Just fact."
    show emily smile
    e "Well... I'm glad you were there. She was lucky you showed up."
    "Alice's eyes lingered on the crowded room beyond the doors. Then a small nod."
    a "Maybe."

    # ------------------------------------------------------------------
    # Cafeteria: Emily's nightmares
    # ------------------------------------------------------------------
    scene bg cafeteria with dissolve
    show emily worried at midleft
    show alice neutral at midright
    with dissolve
    "They found a table near the windows. Emily picked at her bread roll, her gaze on the scratches in the tabletop."
    e "My parents... they said I should start seeing Dr. Elena. After... you know. Everything that happened."
    "Alice looked at her calmly, waiting."
    e "I don't know if it will help. I wake up almost every night. Nightmares. I see her face. The way it was..."
    "She stopped, swallowing hard, eyes glistening."
    "Without hesitation, Alice reached across the table and took her hand. Her grip was steady, warm."
    a "It's okay. It will pass if you focus on your daily tasks. Hold on to the good memories."
    "Emily sniffled and managed a weak smile."
    show alice smile
    a "And if there aren't enough... make more."
    "Emily squeezed her hand, holding on like it was a lifeline."

    scene bg school_corridor with dissolve
    show emily worried at midleft
    show alice neutral at midright
    with dissolve
    "Afterward they walked the wide hall in silence, sun slanting through tall windows, catching the frost on the glass."
    "Then Emily spoke, careful, as if testing whether the words should be said aloud."
    e "I heard my parents talking yesterday..."
    "She hugged her books tighter."
    e "They believe George is involved... you know. With what's been happening."
    "Alice kept walking, eyes forward, her silence deliberate. Emily glanced at her, waiting."
    a "I don't know. George is different from the time we came here. I hardly see him when I'm home."
    a "He's always doing things. Outside, in the garden, around the house. I'm in my room, studying or reading."
    "Plain words, delivered without hesitation. They hung between them with a weight that made Emily's brow crease."
    e "Still... it makes me nervous."
    hide emily with dissolve
    hide alice with dissolve
    stop music fadeout 2.0

    # ------------------------------------------------------------------
    # The walk home
    # ------------------------------------------------------------------
    scene bg greyvale_street with dissolve
    show snow light
    play ambient sfx_wind fadein 2.0
    play music m_outside fadein 2.0
    "School ended, and Alice set out on the long walk home. Twenty-five minutes through snow. Her small steps stretched it longer."
    "She didn't mind. The cold didn't bother her, and neither did the solitude. She welcomed it. Her time to let the noise of the day fall away."
    "Even after two years in Greyvale, some things were still hard to get used to. School, for one."
    "Before, she had been homeschooled. A special, advanced program that pressed her far beyond her age. History, philosophy, mathematics, sciences. Lessons tailored to sharpen her."
    "Now: crowded classrooms, dozens of students shifting and whispering, a new teacher for every subject, each measuring her with grades and tests."
    "Learning had been hers alone before. Now it was a performance, divided into parts, weighed and tallied."

    # ------------------------------------------------------------------
    # Dinner with George
    # ------------------------------------------------------------------
    scene bg bennett_house_day with dissolve
    show snow light
    "Her knuckles were red from the cold when she knocked."
    show george neutral at center with dissolve
    "George stood in the doorway, tall and immovable. His eyes narrowed briefly. A single nod. No greeting. Just passage."
    stop ambient fadeout 1.0
    stop music fadeout 2.0

    scene bg bennett_dining with dissolve
    "The house was warmer, heavy with woodsmoke. Her bag went into her room, neatly set aside. Then she returned to the table."
    show george neutral at midleft with dissolve
    show alice neutral at midright with dissolve
    "George was already setting down two bowls of porridge. Not a trace of surprise crossed her face. It was always this."
    "They ate in silence. George slow, every motion deliberate."
    g "We will need to travel soon. We will go to another place."
    play sound sfx_thud
    "Alice's spoon slipped and clattered against the bowl, splattering porridge onto her wrist. The heat bit her skin. She didn't flinch."
    "George's eyes lifted to her, steady, unblinking. She lowered her gaze, picked up the spoon, and resumed eating."
    a "Are we going back home?"
    g "No. Somewhere else."
    a "Why do we need to go?"
    g "Because I said so."
    a "Alright."
    "Only the scrape of spoons after that. The crackle of the fire. The wind clawing at the shutters."
    "Then, before she could stop herself, something in her broke the silence. The words pushed up, almost too loud for the room."
    a "What about Emily? She is my friend."
    "For the first time all meal, George looked at her fully. Heavy. Assessing. His reply came almost indifferent."
    g neutral "You don't need friends. Not now."
    "The fire popped in the hearth. Alice's pulse thudded in her ears. She clenched the spoon tighter, breathing evenly, keeping her face steady."
    "Inside, her thoughts coiled tighter, hotter. Outside, the mask held."
    "George finished, set his bowl down with a dull scrape of porcelain on wood, and rose. He smoothed his shirt and reached for his coat by the door."
    g "I have things to take care of. I will be late."
    hide george with dissolve
    play sound sfx_thud
    "A gust of cold air spilled in. Then he was gone. The latch clicked shut."
    show alice neutral at center with move
    "Alice alone in the dim room, the half-empty bowls cooling on the table, the silence pressing in like another wall."
    "Her thoughts twisted over themselves, sharper with every turn. Confusion. Panic. Anger. Clawing inside her chest, too strong to contain."
    ath "Losing control is weakness. And weakness is intolerable."

    scene black
    with vpunch
    play sound sfx_tinnitus
    "The scream tore out of her before she realized it, shrill and raw, scraping her throat until it burned, until the sound faltered and died."
    window hide
    pause 2.0
    window auto
    "Then only her ragged breath, echoing in the empty house. As though the house itself had heard, and would not forget."
    scene bg bennett_dining with dissolve_slow
    show alice neutral at center with dissolve
    "Alice stood. Straightened her back. Smoothed her skirt."
    "Piece by piece, her posture rebuilt itself, as if the scream had never been. Her face calm again."
    "She lifted her coat from the peg, slipped it on, and buttoned it carefully."
    hide alice with dissolve

    scene bg bennett_house at night with dissolve
    show snow heavy
    show vignette
    play ambient sfx_wind fadein 1.5
    "When she opened the door, the cold met her full in the face. She welcomed it. It bit her skin and cleared the heat from her head."
    "There was distance to cover. A long walk ahead. But she had time."
    stop ambient fadeout 2.0

    # ------------------------------------------------------------------
    # Markou's office: Alice arrives
    # ------------------------------------------------------------------
    scene bg markou_office with fade
    show vignette
    play music m_office fadein 2.0
    "An hour later, snow clinging to her coat, Alice pushed open the psychologist's door. The warmth hit her like a wave."
    "Her hair was damp, her cheeks raw. She looked smaller than usual, her coat weighed down with ice."
    show helena concerned at midleft with dissolve
    h "Alice! Good heavens, what on earth are you doing out in this weather?"
    show alice sad at midright with dissolve
    "Helena guided her to the armchair by the fire and draped a blanket across her lap. She checked her pulse at the wrist without comment, then returned with a steaming mug."
    h "Here. Careful, it's hot."
    "Alice cupped the tea in both hands, staring into the steam."
    a "I can't handle it anymore, Dr. Markou. I need someone to talk to."
    h "You're talking to me now, Alice. And that's good."
    "Alice shook her head. Her lips pressed tight, then parted again with effort."
    a "No. Not just you. I... I need to talk to the detective."
    "The room went still. Helena's brows rose, then her expression softened. She brushed damp hair from Alice's face."
    h "You want to talk to Detective Harris?"
    show alice neutral
    a "Yes. He should know. I want him to know."
    "Helena studied her a long moment, weighing something. Then she laid her hand over Alice's and smiled."
    h neutral "Of course, my dear. If that's what you want, I'll call him right now."
    "Alice's shoulders eased for the first time since she stepped inside."
    h "Detective Harris? It's Dr. Markou. You need to come to my office immediately. There's someone here who wishes to speak with you."
    hide helena with dissolve
    hide alice with dissolve

    # ------------------------------------------------------------------
    # Samuel POV: Alice's account
    # ------------------------------------------------------------------
    scene bg markou_office with fade
    show vignette
    "Samuel parked out front, the engine ticking as it cooled. He pulled his collar high and crossed the path in quick, deliberate steps."
    "Inside, warmth and oak smoke. Alice curled in the armchair by the fire, a blanket across her lap. Helena seated just beside her. Both turned as he entered."
    show helena neutral at midleft, dimmed with dissolve
    show alice neutral at midright with dissolve
    "He gave Helena a short nod, then crouched in front of Alice so his eyes were level with hers."
    s "Hello, Alice. You asked for me. What's wrong?"
    "Her small hands were folded tightly in her lap. Her voice came calm, steady, threaded with an odd weight."
    a "I need to share some things with you, Detective."
    s "I'm listening."
    h "I can step out if that makes it easier."
    "Alice's hand shot out and caught Helena's sleeve. Not pleading. Precise."
    a "No. Stay. It's better if you both hear it. For everyone's sake."
    "Helena hesitated, caught between her training and the quiet steel in the girl's voice. Then she sank back, guarded."
    s "Alright. We'll do this together."
    "Alice smoothed the blanket over her knees and drew a slow breath, preparing her words with a care most adults never managed."
    play music m_ritual2 fadein 3.0
    a "As you both know, I am not from here. I am from a small coastal village. Life there was different. Especially inside the family."
    a "My family were believers. Too devoted. And their belief had strict guidelines to follow."
    "Her fingers tightened slightly in the blanket."
    a "Of course, the previous generation — like George — was also enforcing it. Maybe even more than my parents did."
    "Samuel's eyes flicked to Helena. Her expression stayed neutral, but her posture had stiffened."

    menu:
        "Believe her.":
            "He let the words come and took them as given. A frightened child, finally talking. That was what the room was for."
        "Watch her hands.":
            $ notice()
            "He kept his eyes below her face. Her hands folded tighter exactly when she said 'George'. Not before. Not after."
            "And the rest of her stayed composed. Too finished, like a drawing someone had already erased and redone."
            th "Fear. Kids who live with a man like that learn to hold still. The hands are the only thing that tells the truth."

    s "Enforcing how, Alice? With rules? With punishment?"
    a "Both."
    "Flat. Not dramatized. But the certainty behind it made the room feel tighter."
    a "So, in this belief, I had a role to play. I am not sure what. I only know I needed to extend my knowledge in all major topics. More than other kids my age. That is why I was homeschooled too."
    th "Accelerated education. Indoctrination disguised as discipline."
    show helena concerned at midleft, dimmed
    h "Alice, when you say 'belief,' what do you mean exactly? A religion? A sect?"
    a "It's... devotion. To purity. To truth. To being stronger than weakness."
    "A chill traced down Samuel's spine. His jaw worked once."
    s "And George. He taught you that?"
    "A small nod. Slow. Deliberate."
    a "In my family, I was taught that part of my role was to distinguish the pure from the impure in people."
    a "Of course, this meant I was constantly corrected, disciplined, put into long sessions of visual and verbal examples."
    a "I was reminded that weak people are not worth anything. And that we should use them only to justify our means."
    "Samuel's pen stilled halfway across the page."
    $ note("Alice: family 'devoted to purity.' Role: distinguish pure from impure.")
    a "Yet my parents were not like George. He scolded them. Argued with them. I witnessed it myself."
    "The firelight flickered across her face."
    a "Then, one day, he took me and brought me here. I wasn't able to see my parents again. He said he did what he had to do. And he told me it was part of my training."
    "Samuel's chest tightened."
    s "Alice... do you know what he meant by that?"
    show alice sad
    a "No. And every time I ask him if I can see my family again, he gets angry."
    $ note("Taken from parents by George. 'Part of my training.'")
    "Helena's hands, folded neatly until now, tightened on the armrest. She didn't speak."
    a "And today... he told me that he will soon finish his work here. And that we will leave again."
    "The silence stretched. Samuel's thumb brushed the spine of his notebook."
    s "Work. He used that word?"
    a "Yes. Work."
    th "Finish his work here."
    "A twelve-year-old might not know what that meant. But Samuel had heard killers use the same phrasing."
    a "Today he said he has work to do. Preparations. And that he will be late."
    "Her eyes went to the fire, reflecting the flames."
    a "So I came here. To Mrs. Markou."
    "Preparations. The word hooked him, heavy with implication, vague enough to be useless. His cigarette hand twitched against his knee."
    s "Preparations for what, Alice?"
    a "He didn't say."
    $ note("'He will finish his work here.' Preparations tonight.")
    note_voice "'He will finish his work here.' Preparations tonight."
    s "Did he bring this belief here, Alice? The same rules?"
    show alice neutral
    a "Of course."
    "She lifted her eyes from the mug and met his directly for the first time in minutes."
    a "George doesn't leave things behind. He says truth doesn't change with place. He carries it everywhere, and so must I."
    a "George says I don't need friends. He says they make you weak, pull you away from what matters."
    a "That's why he doesn't like Emily. He says she clouds my judgment."

    window hide
    pause 1.5
    window auto
    stop music fadeout 3.0
    jump ch06

# ----------------------------------------------------------------------
# Markou duel: Samuel's three angles (called in the order the player picks)
# ----------------------------------------------------------------------
label ch05_markou_redacted:
    s "You can give me a redacted summary. Initial impressions. Risk flags. I don't need the raw session transcripts."
    h "You don't need any of it. The law is not on your side here. Nor am I inclined to stretch it in spirit."
    h "Confidentiality for a minor is not a courtesy; it's a scaffold. You kick at it, she falls."
    return

label ch05_markou_emergency:
    "He stepped closer and planted his hands on the edge of the desk."
    s "We have a serial killer. That scaffold won't mean much if there's a fourth grave."
    h "And if trampling a child's privacy today buys you nothing and costs her everything tomorrow?"
    h "You are talking about burning a bridge you may need to cross again. If the girl is truly in danger, she will come to people like me before she goes to people like you."
    s "You've treated Clara. You of all people know how small this town lets children become."
    s "If Alice is a lever in someone's hand — if George has turned her into an instrument — keeping this sealed helps him, not her."
    h "Speculation. You want me to violate a child's confidentiality on speculation."
    s "I'm asking you to exercise professional judgment in a state of emergency."
    h "And I'm exercising it by saying no."
    return

label ch05_markou_safe:
    s "Tell me this. Do you believe Alice is safe in that house?"
    "Helena breathed once, unblinking."
    h "If I believed she was in immediate physical danger, you would not need to ask me for her file. You would already have a court order and a child removed. That is not what I see."
    s "Immediate physical danger. So not bruises. Not burns. But the other kind."
    s "The kind that teaches a child the world is a courtroom and she is the judge's apprentice."
    h "You are not wrong to be afraid of ideas. They are harder to document than injuries. And they last longer. But your fear does not license me."
    return
