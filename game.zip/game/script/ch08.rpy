## Chapter Eight — the cell, the interrogation, the bars, the transport.
## POV: Samuel (window, interrogation, transport) / George (cell, Alice's visit).

label ch08:
    call chapter_card(8, "Greyvale — the night of the arrest")

    # ------------------------------------------------------------------
    # The window over the square (Samuel POV)
    # ------------------------------------------------------------------
    scene bg square_fires with fade_slow
    show vignette
    play music m_judgment fadein 3.0
    play ambient2 sfx_crowd fadein 2.0
    call place("Greyvale police station — second floor, dusk")

    "By dusk the crowd outside the station had doubled, and it had stopped being a crowd."
    "Samuel watched it from the second-floor window with a cold cup of coffee going colder in his hand."
    "They stood in the square in the blue dark, a hundred of them now, more, their faces lit orange from below by the little fires some of them had lit in oil drums against the cold."
    "They were not shouting yet, which was worse than shouting."
    "They had settled into the patient, upright waiting of people who believe they have been wronged and have found, at last, the thing responsible."
    "Now and then a voice went up and the mass around it stirred and murmured and went still again, the way a fire breathes."
    "Samuel had been a policeman long enough to know that a crowd that waits is a crowd that has decided, and only lacks the moment."
    "And they had never, Samuel thought, needed much convincing."
    "He had spent the day learning George Bennett the way you learn a man only after you have arrested him: too late and all at once. The George the town handed him was a shape with a hole in the middle of it."
    "Two years the man had lived out at the tree line, and two years the town had hired his hands and never once asked him in."
    "He fixed their roofs and their fences and their frozen pipes, took his pay, said little, and went home to the edge of the woods."
    "They had let him stay the way you let a stray stay at the edge of the yard — useful, watched, unloved, and the first thing your eye goes to when something turns up missing."
    "A town that has spent two years not trusting a man needs almost nothing, when the bodies come, to hate him. The outsider is always the readiest answer."
    th "I'm the valley's other outsider. Some other morning, with some other set of dead, they'd have lit those fires for me."
    "Above him, on the third floor, in the narrow holding cell Greyvale kept for drunks and thieves, George Bennett sat and said nothing."
    "He had said nothing since the house. Not in the car, not at the booking desk while Lara logged his belt and his boot-laces and the few worn things from his pockets."
    "Not when Samuel had read him his rights slowly and clearly and given him every opening a man could want to speak into. He had answered his name. He had answered nothing else."
    "He had the terrible patience of the crowd below turned inside out — a man waiting, too, for a thing he had long since decided was coming."

    play sound sfx_phone
    "The phone on Mercer's desk rang. Mercer looked at it, and looked at Samuel, and Samuel set down the cold coffee and picked it up, because there was only one person it would be."
    show screen phone_call("Raymond Doyle")
    s tired "Harris."
    d neutral "It's out. The city paper. Online an hour ago, print by morning. {i}Cult Killings Grip Mountain Town; Local Man Held.{/i}"
    d "They've got the word cult, they've got the word ritual, they've got a photograph of your George holding his hands out for the cuffs like he's done it a hundred times."
    d "By noon tomorrow it will be on every screen in the country. The mayor's been on to the county. They want him moved."
    s "Moved where?"
    d neutral "County seat. Proper remand facility, two hours down the mountain. Somewhere with walls that mean it and men to watch them."
    d "You've seen the square, Sam. You cannot hold a man that town wants dead in a cell with a lock a determined child could pick."
    d "One night. That's what you've got. First light they send a transport up and it takes him down, and he becomes the county's problem and the state's."
    s "First light's a long way off."
    d "Then make the night count."
    d "You've got him for one night in your own house, Sam, before he's gone behind county walls and a county lawyer and never says another word."
    d "Whatever you're going to get out of George Bennett, you get it tonight. Because tomorrow he stops being a frightened old man in a small-town cell and becomes a case."
    d "And cases don't confess."
    hide screen phone_call
    "The line clicked. Samuel stood a while longer at the glass, watching the town he had promised an answer by dark."
    $ note("Transfer to county at first light.")
    note_voice "Transfer to county at first light."
    m "Detective? You going up?"
    s "Give me a minute."
    s "I want to know who I'm talking to first."

    # ------------------------------------------------------------------
    # The cell (George POV)
    # ------------------------------------------------------------------
    stop music fadeout 3.0
    stop ambient2 fadeout 2.0
    scene bg holding_cell with fade_slow
    show vignette
    play ambient2 sfx_crowd fadein 3.0
    call place("Holding cell — third floor")

    "The cell was six feet by eight, and George Bennett had measured every inch of it in the first hour, out of an old habit he had never lost."
    gth "Know the size of the box they put you in. Know the door. Know the hinges. Know the time between the guard's steps."
    "He had been putting himself in boxes his whole life and getting himself out of them. Some cold and certain part of him understood that this was the box he did not get out of."
    "They had taken his laces and his belt so he could not hang himself. That was almost funny."
    gth "As if a man who kept himself and the girl alive two years by never once giving in to despair would quit now, with the work half done."
    gth "I will not give them that. I will not give them anything."
    "Giving them nothing was the only country he had left."
    "He kept his hands loose on his knees and his breathing slow and let the noise of the crowd come up through the floor, and he did the arithmetic of it the way he did the arithmetic of everything."
    gth "Three days. I needed three more days."
    "The money was lifted and counted and waiting where he'd cached it; the fuel was staged."
    "Renner had the truck and the route and the crossing arranged, had named his price and been paid half. The other half was to change hands the night they left."
    gth "Three days and she'd have been out of this valley. Gone the way we went before. Quiet, complete. A door closing on an empty house."
    "He had felt the danger coming for weeks — felt it the way he felt weather in his bad shoulder — and he had done what he always did when he felt it, which was move."
    "He had simply, this once, been three days too slow."
    play music m_driftwood fadein 4.0
    "That was where the nights had gone — the nights the girl heard the truck on the gravel and he told her only that he had work."
    "The nights the whole town would later decide were a killer going out to kill."
    gth "I was building the road out."
    "Week after week, after she was asleep, he had driven the black roads down the far side of the mountain with his lights low, over the gorge and out toward the county highway."
    "He met Renner in the places Renner chose and never the same one twice: a closed filling station, a timber yard."
    "Once, a lay-by above the gorge, where the wind came up the drop so hard it rocked the truck."
    "And there in the cab with the engine ticking they had built the escape a piece at a time. Cash counted out under the dome light and counted again."
    "A name for the girl that was not her name, on paper good enough to cross with. A route that ran south and then west and then off the edge of anywhere either of them had ever been."
    "Renner asking no questions — that was what you paid Renner for, the not-asking — only naming his figure and his conditions and his crossing."
    "And George paying, and driving home in the last of the dark, and pausing on the stair outside her door out of a habit of listening, and lying down for two hours before the valley woke."
    "Ordinary, careful, criminal, invisible work: the work of a man moving a child out of danger by the only means a man with no past he could show would ever have."
    "And every night of it was now a night with no alibi he could give. To explain where he had been was to explain who he had been with, and what he had been buying, and why—"
    "—and there was a man on the far side of the gorge, twenty-five miles off, who could stand up and say {i}George Bennett was over here with me the whole of that night.{/i}"
    gth "A mountain and an hour's road away from your dead girl. And I'll go into the ground before I say his name aloud."
    "Renner moved people who could not be moved. Renner did not exist, as far as any badge in the world was concerned."
    "The day George handed a detective the thread that led to Renner was the day he handed over the whole architecture: the money, the route, the fact of the flight."
    "The fact that the child in this town's mouth as the killer's granddaughter was a child he had taken out of a house in the night without her parents' leave, and run with across half a country."
    gth "Say one true thing and you say all of them."
    "He had learned that lesson young, in a colder house than this, and it had never once been wrong."
    "So he would say nothing. He would give the detective his name and give him silence and give the rope its due."
    "The only thing in the whole business he could not make himself hold still and look at directly was the question of why."
    "Why the deaths. Why the marks he had heard the officers murmur about, the words, the staging that stank — he made himself use the word, {i}stank{/i} — of the very thing he had spent his life first serving and then fleeing."
    "He looked at the question the way you look at the sun: sideways, for less than a second. Then he looked away."
    gth "A man can go blind that way. I went half-blind already, years ago, refusing to look at it."

    # Memory: the boy on the boards
    scene bg driftwood_front_room at memory with dissolve_slow
    call place("Driftwood Bay — long ago")
    "His son had been six the first time George made him kneel."
    "It came up now, uninvited, the way the old things came up in boxes: the cold front room of the house in Driftwood, the salt smell that lived in every wall."
    "The boy's thin knees on the bare boards. The boy's voice, high and careful, going through the recitation he had fumbled at the gathering that afternoon and shamed them both."
    "{i}A blessing shared is a blessing halved. Weakness named is weakness bled.{/i}"
    "On and on, the whole cold catechism, and every time the boy stumbled George made him start again from the top."
    "Not in anger — that was the thing George had believed, then, that made it holy — but in love."
    "Because the world was a machine that ground weak men to nothing, and the only kindness a father could do was to make his son too hard to grind."
    "The boy had cried, once, near the end. Silent, the tears just running while his mouth kept going."
    "And George had crouched to his level the way his own father had crouched to his, and wiped the boy's face with his thumb, almost tender."
    stop music fadeout 2.0
    window hide
    pause 1.5
    window auto
    g grim "Stop."
    g "You do not give them water."
    window hide
    pause 1.0
    window auto
    g "You give them nothing."
    window hide
    pause 2.5
    window auto
    "And the boy had stopped. Had learned to stop."
    "Had grown into a hard, closed, correct man who married a hard woman and got a daughter of his own, and set about, with the total confidence of the well-taught, making her too hard to grind."

    scene bg holding_cell with dissolve_slow
    show vignette
    play music m_driftwood fadein 3.0
    "George had done that. Whatever else was true, that was true and his: he had taken a soft-faced boy and built the machine that built the girl."
    gth "I was so sure."
    "That was the part he could not get past, waiting in his own box for his own grinding — not that he had been cruel, but that he had been cruel and certain."
    "Certain it was love. Certain it was mercy. And the certainty had felt exactly, indistinguishably, like the thing he now knew it was not."
    play sound sfx_thud
    "Boots in the corridor. The measured tread of the detective, coming up."
    "George straightened his back against the wall, put his hands loose on his knees, gave his face to the middle distance, and made himself, once more, into nothing they could use."
    stop music fadeout 2.0
    stop ambient2 fadeout 2.0

    # ------------------------------------------------------------------
    # Interrogation (Samuel POV)
    # ------------------------------------------------------------------
    scene bg interrogation with fade
    show vignette
    play music m_george fadein 3.0
    call place("Second-floor office — night")

    "Samuel had them bring George down to the little second-floor office instead of questioning him through the bars."
    th "Bars give a man something to be brave against. I don't want him brave. I want him tired, and warm, in an ordinary chair across an ordinary desk."
    show george neutral at center with dissolve
    "He did not turn on the recorder. He set it on the desk, in plain view, and left it dark."
    "George's eyes went to it once and understood the message — {i}this is not for the file yet; this is just us{/i} — and filed the understanding away behind his face and gave nothing back."
    "Samuel had run a thousand of these. He knew inside the first minute this was going to be one of the hard ones, and some worn-out part of him was almost glad of it, the way you are glad of a real winter."
    "He took out his cigarettes and put two on the desk and pushed one across."
    s "They took your tobacco with your laces. Bureaucracy. Go ahead."
    "George looked at the cigarette. For a moment Samuel thought he wouldn't. Then the old man's hand came out, unhurried, and took it."
    "Samuel lit it for him and lit his own, and for a little while the two of them sat in the small room and smoked and said nothing, and that was fine."
    th "No hurry. Hurry is the crowd's disease, and Doyle's. I have all night, and I mean to spend it."
    s neutral "Four we're calling murder."
    s "A teacher we were quick to write off as a suicide, until I found the blackmail. A shopkeeper, poisoned over his own counter. A priest, in front of his whole church. And a girl of fourteen, laid out in the snow."
    "He tapped ash."
    s "Laid out, as it happens, on the grave of a fifth. Clara Ward, fifteen, wrists opened in a school locker room, days ago. Suicide, everyone agreed."
    s "I'm less sure than everyone lately. Somebody left your granddaughter's best friend on that dead girl's grave like a note pinned to a door."
    s "I'm not going to ask you if you did it. You'll say no or you'll say nothing, and either way we're no further on. So let's not do that part."
    "George smoked, and watched him, and said nothing, exactly as promised."
    s "Here's what I'll do instead. I'll tell you what I know. And you can sit there and let me be wrong, if I'm wrong."
    "He opened the folder he had not needed to bring and did not look at."

    th "Three keys to this lock. Where he came from. The girl. The hours he can't account for."
    $ ch08_keys = set()
label ch08_keys_menu:
    if len(ch08_keys) == 3:
        jump ch08_keys_done
    menu:
        "Driftwood." if "driftwood" not in ch08_keys:
            $ ch08_keys.add("driftwood")
            call ch08_key_driftwood
        "Alice." if "alice" not in ch08_keys:
            $ ch08_keys.add("alice")
            call ch08_key_alice
        "The alibi." if "alibi" not in ch08_keys:
            $ ch08_keys.add("alibi")
            call ch08_key_alibi
    jump ch08_keys_menu

label ch08_key_driftwood:
    if len(ch08_keys) > 1:
        th "Go back to the start of him. The place he came from."
    s "Driftwood Bay. Little place on the coast, three hours south, the kind of town that doesn't answer the phone when a detective calls."
    s "You came from there. You and the girl, two years back, cash for the house, no mortgage, no paper trail worth the name."
    "He let it sit."
    s "Funny town, Driftwood. I made some calls. People there don't talk about it, and the ones who do, talk about it the way you talk about a church you left."
    s "And the year you came up out of it with a ten-year-old girl and no mother and no father in the picture — that same year, two sisters went missing off that coast."
    s "Girls. Never found. Investigation went cold so fast it was never warm."
    show george grim at center, shake
    "He watched George's face while he said it, and saw the thing he had come up the stairs to see. Not guilt — he had expected guilt, and this was not it — but something rawer, gone almost before it surfaced."
    "The big frame flinched a quarter-inch. The eyes went, for half a heartbeat, to the door, and to the window, and back."
    "The reflex of a man who has spent every day of two years believing his past was buried, and has just heard a stranger speak its name aloud."
    "It lasted less than a second. George's face closed over it like water over a stone."
    th "Right country. Wrong map, maybe. But the right country."
    $ note("Driftwood — flinch at the sisters.")
    note_voice "Driftwood — flinch at the sisters."
    s soft "I don't know what you did in Driftwood. Maybe nothing. Maybe everything."
    s "But you ran from it, and you brought a child with you, and you've spent two years in this valley being a man nobody could get a look at."
    s "And now the people around that child are dying in a language that sounds an awful lot like the church you left."
    "Silence. But George's jaw had set, and his breathing had changed — slowed, deepened, the deliberate control of a man holding a door shut from the inside."
    "Samuel let the silence run a long time."
    return

label ch08_key_alice:
    "Samuel changed the ground under the silence."
    s neutral "Let's talk about Alice."
    show george neutral at center, breathe
    "And there it was: the only thing in the room that reached the old man. Not a flinch. Something worse."
    "A stillness that went one degree stiller, the whole big frame of him gathering, bracing, the way a man braces over the one part of himself he cannot afford to have touched."
    s "She's twelve years old and she has nobody. You understand what happens to her now? Tonight she's with the psychiatrist, on a kindness. Tomorrow she's the state's."
    s "And the state is going to want to know exactly what I want to know — where she came from, who her people were, what happened to them."
    s "It is going to pull that thread all the way back to Driftwood, and it is going to keep pulling until it finds whatever you ran from. Unless someone gives it a reason not to."
    "He leaned in, no threat in his voice, which was the threat."
    s "You've spent two years keeping that child out of the hands of whatever's back there. One night in a cell and it's out of your hands entirely — unless you talk to me."
    s "I'm the only man in this building who can steer where that thread goes. Help me, and I can protect her. Sit there, and I can't protect anyone."
    "It was a good key. Samuel felt it turn even as he said it, felt the old man's whole being lean toward the girl like a plant toward light."
    "For one held breath he thought the wall was going to come down."
    stop music fadeout 2.0
    if "alibi" in ch08_keys:
        "Then George Bennett spoke — more than one word, for the first time since his own front door — and his voice was gravel dragged over gravel."
    else:
        "Then George Bennett spoke, for the first time since his own front door, and his voice was gravel dragged over gravel."
    g grim "You want to protect her."
    "It was not a question. The old man's eyes came up off the middle distance and fixed on Samuel's."
    "There was something in them Samuel could not read — something that in another man he'd have called grief, and in this one looked more like warning."
    g "Then be careful what you decide she is."
    g "All of you. Whoever ends up choosing what that girl is—"
    "He stopped. His jaw worked once."
    menu:
        "Ask what he means.":
            $ notice("t08_stair")
            s soft "Choosing what she is. What is she, George?"
            "For a second the old man's mouth stayed open on the shape of the next word. His eyes went past Samuel, to the door, and down — toward the stair, toward wherever the girl was sleeping tonight."
            "Not the look of a man protecting a secret about himself. The look of a man standing between something and the light."
            "Then the door closed again."
            g "Be careful. That's all."
            th "Grief. A grandfather who knows what his church did to that kid and can't say it. That's all that is."
        "Hear a grandfather's guilt.":
            "Samuel let it lie. He had heard grandfathers before, and fathers, and what they sounded like when they finally understood what they'd made of a child."
            "And then the door closed again, and the last of it came out flat and final."
            g "Be careful. That's all."
            call tell_missed("t08_stair")
    g "That's the only thing I've got to say to you, and it's more than I meant to."
    s "Careful how, George?"
    "But he was gone again, back behind the gray, and Samuel knew the tone of a door that had shut for the night."
    $ note("'Be careful what you decide she is.'")
    note_voice "'Be careful what you decide she is.'"
    play music m_george fadein 3.0
    return

label ch08_key_alibi:
    if len(ch08_keys) == 3:
        "He tried the last key anyway, because you always tried it."
    else:
        "He went straight at the hours, because the hours were the whole of it."
    s stern "Where were you, the night the Carter girl died."
    s "You were out of your house. Your own granddaughter says she heard you leave, heard you come home after two. That's the whole night, George. That's every hour that matters."
    s "So tell me where you were. Give me one name, one place, one man who saw you, and I will get up from this desk and start taking your case apart instead of building it."
    s "An innocent man gives me something."
    "He watched George Bennett hear the lifeline and understand it completely — Samuel saw the understanding, clear as print — and set it down untouched."
    g neutral "Nothing."
    s "You were somewhere. A man is somewhere."
    window hide
    pause 1.0
    window auto
    g "Nothing."
    "George closed his eyes."

    menu (screen="read_choice", subject="him"):
        "His eyes.":
            $ read_miss("r08_silence")
        "His mouth.":
            $ read_miss("r08_silence")
        "His silence.":
            $ read_hit("r08_silence")
            "Not a card held close. A door held shut from the inside, with the whole weight of the man against it."
    $ note("Bennett: no alibi offered. 'Nothing.'")
    note_voice "Bennett: no alibi offered. 'Nothing.'"
    return

label ch08_keys_done:
    "And somewhere in the last of it, Samuel felt it — the small, wrong, snagging thing, so quiet under the noise of the evidence that he almost missed it."
    "He had sat across from a hundred guilty men refusing to give up their alibis, and their silence had a texture. A smugness. The held card of a man who knows the truth would sink him."
    "This was not that. This was the silence of a man refusing a rope thrown to him in a flood. Refusing it deliberately. Choosing the water."
    th "There's only one reason I've ever known a man to do that. Because the shore the rope is tied to is worse than drowning."
    "The thought went through him and was gone before he could hold it, buried under the fires in the square and the graves and the photograph on every screen by morning."
    "He was too tired and too pressed and too far in to chase a feeling down a hole. But it had been there, for a second, snagging, and no weight of exhaustion quite pressed it flat again."
    "He stood, and gathered the folder he hadn't opened."
    s tired "They're moving you at first light. County."
    s "Once you're down there, I can't help you, and I won't be able to hurt you either, and everything you didn't say tonight, you'll wish you had."
    "He paused at the door."
    s soft "Think about the girl, George. Whatever else. Think about who's going to decide what she is."
    "George raised his eyes."
    "For a moment the two men looked at each other across the small warm room — two outsiders in a town that wanted them both gone, each carrying a weight the other couldn't see."
    g neutral "I have thought about nothing else..."
    extend " for two years."
    "And Samuel, who heard in it only the grief of a grandfather who had ruined a child and knew it, nodded once, and went out, and left the old man to the dark."
    hide george with dissolve
    stop music fadeout 3.0

    # ------------------------------------------------------------------
    # Dawn: Alice at the bars (George POV)
    # ------------------------------------------------------------------
    scene bg holding_cell with fade_long
    show vignette
    call place("Holding cell — the gray hour before dawn")

    "They brought Alice to him in the gray hour before they moved him."
    "George Bennett understood, when he heard the small footsteps on the stair, that whatever mercy this was meant to be, it was the last one he would get, and that it would cost him more than the rope."
    show helena concerned at midright with dissolve
    "The psychiatrist came first — Markou, the sharp-eyed woman, her face tight with the wrongness of what she was allowing, and allowing all the same."
    "The child had begged through the whole of the night and would not be quieted. In an hour the old man would be gone down the mountain, perhaps out of the girl's life for good."
    "And Helena Markou had judged, in the end, that a child forbidden her goodbye carries the deeper wound."
    show alice cry at midleft with dissolve
    "Behind her came a young officer, and behind him, small in a coat too big for her, the child."
    "They stopped the girl a careful distance from the bars. Markou crouched to her, murmured something, kept one hand on her shoulder."
    "Rules. Protections. The whole apparatus of adults deciding they knew what stood in the room with them."
    a cry "Grandpa."
    "The girl's voice broke on the word, and her face crumpled, and tears came."
    "To every soul in that corridor but one she was exactly and only what she appeared to be: a frightened child brought to see the last of her family behind bars."
    a "They said— they won't tell me anything— Grandpa, tell them it isn't true. Tell them."
    "George looked at her, and could not speak, and the not-speaking was not the wall this time. It was the flashback taking him, whole, the way they took him now."

    # Memory: the girl in the rain
    scene bg driftwood_yard_rain at memory with dissolve_slow
    show rain
    play ambient sfx_rain fadein 2.0
    play music m_driftwood fadein 3.0
    "She had been five."
    "His son had made her stand in the yard in the rain — some failure, some softness, a doll she'd loved too openly, George never learned which."
    show alicey sad at center with dissolve
    "Made her stand there in the cold coastal rain until she learned that comfort was a thing you did not need and did not show."
    "George had watched from the window of the little house, watched his granddaughter's thin shoulders in the rain."
    "And he had seen, laid over her, the shape of a six-year-old boy on bare boards forty years gone, and something in him that had been set hard since before that boy was born had cracked straight across."
    "He had gone out. He had not planned to; he had simply been unable, for the first time in his life, not to."
    "He walked into his son's yard and his son's discipline and picked the child up out of the rain without a word, and carried her inside."
    "His son had stared at him — stared at him, the man who had taught him the rule — and George had met the stare and said nothing, and dried the girl's hair with his own shirt."
    stop ambient fadeout 2.0
    "And later, when the house was asleep, he had crept to her room the way a thief creeps, and sat on the edge of her bed, and told her — whispering, ashamed, defiant—"
    g soft "You're not weak. The rain is just rain."
    g "There are things they'll tell you you have to be. You do not have to be what they make you. Not all of it. Not the coldest parts."
    "He had given her, in secret, in the dark, against everything he had ever believed and taught and enforced, the one thing he had never given his son and never given himself: the permission to be soft."
    "He had thought he was saving her. He had gone on thinking it, right up until this valley, this winter, these graves."
    hide alicey with dissolve_slow
    "He was less sure than he had been. Some nights the old fear came and sat on his chest and asked him quietly what, exactly, he had saved."
    "Whether the softness he had smuggled to her in the dark had grown up into a girl — or had only been folded, neat and deep, over something he had never had the courage to name."
    "He did not answer the fear. He never answered it. He had gotten very good, across two years, at not answering it."
    "And he did not intend to start tonight, in a cell, with the answer maybe waiting for him at the far end of one more thought he refused to think."
    stop music fadeout 2.0

    scene bg holding_cell with dissolve_slow
    show vignette
    show helena concerned at midright
    show alice cry at midleft
    with dissolve
    a cry "Grandpa. Please."
    "He came back to the cell, to the bars, to the weeping child three feet away."
    "Markou glanced at her watch and murmured to the officer, and the two adults stepped back a few paces to give, in their kindness, the old man and the girl a moment that was almost private."
    hide helena with dissolve
    window hide
    pause 1.0

    # The mask drops — silence, no music.
    scene cg bars with dissolve_slow
    pause 2.5
    window auto
    "And in that moment — in the two seconds when no other eyes in the world were on her face but his — Alice stopped crying."
    "Not slowly. All at once, the way you set down something you have been carrying only because someone was watching."
    "The tears stayed on her cheeks, wet and real, but the thing behind them simply went out, like a lamp."
    "What looked at George Bennett out of his granddaughter's eyes across those three feet of cold air was not a child, and was not grieving, and was not afraid."
    "It was calm. It was patient. It considered him the way she must have considered all of them at the end, weighing, and finding the weight."
    "And it let him see it — deliberately, as a gift or a test or a mercy of its own, because he was the one person on earth who already knew and would never, could never, say."
    gth "There you are."
    "He did not know if the thought was grief or love or the final closing of the sun he had refused for two years to look at."
    gth "There you are. I made you. I ran across the whole world with you and I could not run far enough, because I was carrying the thing I was running from."
    window hide
    pause 2.0
    window auto
    "She held his eyes a moment longer. Then, unhurried, she picked the child back up — put it on the way you put on a coat — and the tears meant something again, and her lip trembled."
    "She whispered, so low that only he could hear it, in a voice with nothing at all underneath:"
    a "It's alright, Grandpa. I'll be alright. I always am."
    "And George Bennett opened his mouth."
    "It would have taken four words. {i}It's her. Watch her.{/i}"
    "Four words to the psychiatrist, to the officer, to the detective who had all but begged him — and the thread would swing off his own neck and onto hers."
    "He would not hang, and the town would have its answer, and the dying, perhaps, would stop."

    menu:
        "Say it. \"It's her. Watch her.\"":
            "He drew the breath for it. His tongue found the first word."
            "And the word would not come. His jaw held the way it had held on the boards, forty years ago, with his own father's thumb on his face."
            "Because the four words were every one of them a confession."
        "Say nothing.":
            "He did not try. He knew before he opened his mouth what was behind the four words."
            "Every one of them a confession."

    "That the doctrine had not failed. That the cold house and the bare boards and the rain and the forty years of it had worked — had come to fruit at last in this small calm patient girl."
    "That he had spent his life building the machine and his last two years pretending he had unbuilt it."
    "That the thing he had refused for two years to look at was standing three feet away, weeping on command, wearing the very face he had helped it learn."
    "To name her was to say aloud, in front of witnesses, that everything he was, was true. He had run from that sentence across a whole country. He found he could not run to it now."
    "And under all of it, deeper than the shame, older than the doctrine, was the thing that had put him out in the rain when she was five."
    gth "She's mine. And I failed her. And a man does not answer his own failure by handing the child of it to a rope."
    "He closed his mouth."

    scene bg holding_cell with dissolve
    show vignette
    show helena neutral at midright
    show alice cry at midleft
    with dissolve
    g grim "Go on, now."
    "Roughly, to the girl, to the child, to whatever she was."
    g "Go with the doctor. Be good."
    "The old words. The only benediction his kind had."
    window hide
    pause 1.0
    window auto
    g soft "Give them nothing."
    "Something moved, very deep, behind Alice's eyes — there and gone, unreadable, his last sight of whatever lived in her."
    "Then Markou's hand was on her shoulder and the child was turning, and the small footsteps went back down the stair."
    hide alice
    hide helena
    with dissolve_slow
    "George Bennett sat down against the cold block wall and put his hands loose on his knees and gave his face to the middle distance, and waited, now, for the only thing left that was coming for him."
    window hide
    pause 2.0
    window auto

    # ------------------------------------------------------------------
    # Transport at first light (Samuel POV)
    # ------------------------------------------------------------------
    scene bg square_day with fade_long
    show snow light
    show vignette
    play ambient sfx_wind fadein 2.0
    play ambient2 sfx_crowd fadein 3.0
    play music m_square fadein 3.0
    call place("Greyvale square — first light")

    "The transport came up the mountain at first light, and the town was already awake to meet it."
    "Samuel had not slept. He stood at the second-floor window with his fourth coffee and watched the square fill in the gray."
    "It was worse in the daylight than it had been in the dark. In the dark a crowd is a mass. In the daylight it is faces."
    "Faces he knew now: the baker, the man from the hardware, the mother of two who'd fussed her children through the hotel breakfast his first morning here."
    "All of them out in the cold with the fires burned down to ash at their feet and the same terrible patience on them, sharpened overnight to an edge."
    "Word had gone through them that George Bennett was being taken down the mountain."
    th "They haven't come to stop it. They've come to see it. They've come in case."
    "He had spent the small hours on the phone trying to make it safer and gotten nowhere."
    "He had asked Doyle for more men and been told there were no more men. He had asked to move George in the dead of night, unannounced, and been told the county van ran on the county's clock, and the county's clock said dawn."
    "He had asked, last, whether they could take the old service track by the mine instead of Route Nine, and been told it was under four feet of snow and that he was, frankly, overthinking a twenty-minute drive down a public road."
    "So he had watched the sky go gray and the square fill, and now the van was here."
    "A county remand vehicle, white, boxy, two county officers in it and a cage in the back. Nosing up the last of the road through the parting crowd, it looked exactly as fragile as Doyle had promised the cell would be."
    "Samuel went down."
    s stern "I don't like the route."
    "He said it in the cold of the yard to the senior county man, a heavyset sergeant named Poole, who had the unbothered look of a man who did this for a living and had never done it here."
    s "Route Nine's a single lane most of the way down, cliff on one side, gorge on the other. Bad bends. And half this town has a truck."
    "Poole glanced at the crowd the way you glance at weather."
    poole "It's the only road down, Detective. Unless you want to wait for a helicopter that isn't coming."
    "He signed Samuel's transfer sheet without reading it."
    poole "We've done harder towns than this. They shout, they film it, they go home to their dinner. Twenty minutes and he's ours."
    $ note("Route Nine: single lane, cliff one side, gorge the other.")
    note_voice "Route Nine: single lane, cliff one side, gorge the other."
    s "I'll follow you down."
    poole "Suit yourself."

    show george grim at center with dissolve
    "They brought George out into the morning. He came the way he had gone in — upright, silent, his cuffed hands before him and his eyes on nothing."
    "The sound the crowd made when he appeared was not the roar Samuel had braced for but something lower and more frightening: a long exhaled {i}there he is{/i} that ran through the mass and drew it a step tighter."
    crowd "There he is."
    "The officers walked him fast across the yard through a corridor of it. Phones up, faces contorting, a woman spitting."
    "A man's voice cracking as it screamed the Carter girl's name, and then Clara's, and then a name that was just a sound."
    "George did not look at any of them. He looked, once, up and to the left, at the high window where the psychiatrist's car had been an hour ago and was not now."
    th "Looking for the girl. Not finding her. A grandfather's last search for the child he raised."
    "That was all Samuel made of it."
    hide george with dissolve
    "Then they put him in the cage and shut the door on him, and he was gone from view behind the mesh."
    "The van pulled out. The crowd did not stop it."
    "The crowd, in ones and twos and then in a slow gathering current, began to follow it — on foot, and then in trucks that coughed to life along the square, headlights coming on in the gray."
    "A slow procession, forming in the transport's wake, down toward the mouth of Route Nine."
    "Samuel ran for his car. He was reaching for the door when Mercer caught his arm — Mercer white-faced, a phone in his hand, Doyle's voice small and urgent leaking out of it."
    "The square was emptying downhill now, fast, the whole weight of the town pouring after the little white van toward the one narrow road off the mountain."
    "Samuel stood for one second with his hand on the cold door, and the certainty went through him at last, complete and far too late."
    th "Ray was right about everything except the hour. They're not going to wait for the county. They're not going to wait for anything."
    stop ambient2 fadeout 1.5

    scene bg route_nine_brakes with dissolve
    # ART-REQUEST (fulfilled): Route Nine bends at gray dawn from behind a windshield, pines, gorge white on the right, a long chain of red brake lights ahead.
    show snow light
    show vignette
    play ambient2 sfx_engine fadein 1.0
    "Samuel got the car started and went down after them, into the bends, too fast, the gorge dropping away white on his right."
    "Up ahead through the pines the brake lights were already blooming — a whole town's worth of them, red in the gray morning."
    "Slowing. Stopping. Piling up in the road where the van had stopped."
    "Where something had stopped it."
    "He put his hand on the horn and drove down into the thing he had built."
    stop music fadeout 2.0
    stop ambient2 fadeout 2.0
    scene black with fade_slow
    pause 1.0

    jump ch09
