## Chapter Twelve — The Long Road Down
## Source: docs/manuscript/ch12.txt (Samuel POV). Samuel's sprite is never shown.

label ch12:
    call chapter_card(12, "Route Nine — a gray Thursday")

    # --- The Petrous step ---------------------------------------------------
    scene bg petrous_exterior with fade_slow
    show snow light
    show vignette
    play ambient sfx_wind fadein 2.0
    play music m_aftermath fadein 3.0
    call place("The Petrous house, Greyvale — a little after two")
    # ART-REQUEST (fulfilled): exterior of the Petrous house — front step, porch light, snow; Markou and the child on the step, car at the curb.

    "Helena Markou saw them off from the Petrous' step."
    "To Samuel, watching from the car, she had the look of a woman doing a thing she had every wish to refuse and no ground on which to."
    show helena concerned at left with dissolve
    show alice neutral at midright with dissolve
    "She had brought the child down herself, the small holdall packed and checked, the coat buttoned."
    "She stood now with one hand on Alice's shoulder in the cold, and the hand stayed there, Samuel saw, past the moment that asked for it."
    "He understood the look on her face, because some cornered version of it was on his own."
    "A clinician who trusted her own eye above any instrument, who had read something in this child across a dozen warm hours, and could not, on her life, have told a review board what it was."
    "So she gave the child over. She had no cause to do otherwise, and every cause to do exactly this: the file, the tragedy, the plain arithmetic of an orphan needing a bed the city had and Greyvale did not."
    "She crouched once to Alice's level and said something low, the same as she had said at her own door weeks ago."
    h concerned "You can come to me. Any hour."
    a "I will. Thank you, Dr. Markou."
    "Alice meant it, or wore meaning it so well that the seam did not show."
    "Then Markou straightened and met Samuel's eyes over the child's head, and held them a beat too long."
    "What passed between the two adults was not words and was not comfort."
    "It was the shared, unspeakable, unprovable dread of two people handing something over that they could not name and could not keep."
    h concerned "Drive carefully, Detective."
    "It came out with a weight the words did not carry on their own."
    s tired "Always do."
    "He did not look at her while he said it. She read faces the way he did, and he had one truth in him now that he could not let even her see."
    hide helena with dissolve
    hide alice with dissolve
    stop music fadeout 3.0

    # --- The drive down ------------------------------------------------------
    scene bg car_day_snow with fade
    stop ambient fadeout 1.5
    play ambient2 sfx_engine fadein 2.0
    play music m_outside2 fadein 3.0
    call place("Route Nine — heading down off the mountain")

    "They left Greyvale a little after two on a gray Thursday, the sky low and heavy with the snow it had not yet decided to drop."
    "For the first twenty minutes neither of them said anything at all."
    show alice neutral at right with dissolve
    "Alice sat in the passenger seat with a small bag at her feet, everything the world had left her folded into a canvas holdall a caseworker had packed."
    "She was, in every particular the eye could catch, exactly what she appeared to be: a child being taken away from the only place she knew, by a tired man with a bruised face who was the nearest thing to a friend she had left."
    "The heater ticked. The wipers stood idle against a windshield the snow kept threatening and withholding."
    "Route Nine unspooled ahead of them, cliff wall rising on the left, the gorge falling away on the right. The same road they had carried George down four days before."
    "Samuel drove it carefully, both hands on the wheel, and did not look at the girl beside him any more than a man drives past a thing he is afraid of."

    # --- The pinch -----------------------------------------------------------
    scene bg route_nine_pinch with dissolve_slow
    show snow light
    "The pinch came up on them about eleven miles down, where the cliff wall crowded in and the guardrail on the gorge side ran out into thirty yards of nothing."
    "Samuel felt his hands tighten on the wheel a half-second before his mind had caught up with why."
    "He had stood in it four nights ago with the sleet in his collar and a torch in his hand. Now he had to drive through it at forty miles an hour with the thing that had made it sitting a foot from his elbow."
    "The snow had been kind to it, the way snow is kind to everything. A thin skin of white over the churned ground, softening the ruts the crowd's boots had cut."
    "But under the white, in one long patch below the broken rail, the ground showed through darker. A stain the frost had set into the earth like dye into cloth, spread the way a spilled thing spreads."
    "A man's whole finish, printed on a roadside, and four days of weather had not been enough to lift it out."
    "Samuel made his face do nothing, and he did not slow down, because to slow down was to say a thing aloud in a car where he had decided to say nothing at all."

    menu:
        "Watch the road.":
            "He kept his eyes on the white line and the broken rail and let the place go by him, and did not give himself the test."
            "But he felt her head turn beside him, all the same. He felt it the way you feel a draught."
        "Watch her look at the stain.":
            $ notice()
            "He caught it in the edge of his eye and hated himself for looking for it. It was the only test he had left that she could not see him giving."
            "Her head turned as the pinch went by. Her eyes went to the broken rail and down to the dark patch under it, and rested there, unhurried."
            "The way a passenger's eyes rest on any mildly interesting thing at the side of a road. A stalled car. A dead deer. A view."
            "No flinch. No held breath, no quick glance away, no small performance of a child not-looking at something frightening."
            "Only a mild, clean attention, held for a moment and then released."
            th "Kids go strange. Kids go numb. You know that."
            "He knew that. He also knew it was not what he had just seen."

    "Then she was watching the mountains again, and the place where a man had been pulled apart on her account slid off behind them and became road."
    "Her face through all of it had stayed exactly as smooth as the snow."
    $ note("Route Nine. She looked at it like a view.")
    note_voice "Route Nine. She looked at it like a view."

    scene bg car_day_snow with dissolve
    show alice neutral at right
    "He knew what she was. He had spent two sleepless nights arriving at it, and he carried it now in the car like a live round in a chamber."
    "He had made himself a plan: watch her, learn her, and somewhere in the four hours down to the city decide what a man does with a truth he cannot prove, and cannot say, and cannot, God help him, un-know."
    "That was the plan. It lasted, more or less, until she spoke."
    a "You don't have to be careful with me, Detective."
    a "Everyone's been so careful. You can just talk. I'd like it if someone just talked."
    "It was so exactly the thing a lonely grieving child would say, in a voice with such an ordinary small weariness in it, that Samuel felt the live round shift in the chamber."
    "His certainty of two nights bent, just slightly, like a straight stick put into water."

    # --- The game ------------------------------------------------------------
    scene bg car_day_snow with fade
    show alice neutral at right
    "He had interrogated killers who could not do what she did."
    "A comment about the snow. A question about the city. An observation so bright and so sideways that he answered it before he thought, and then another, and another."
    "Until without deciding to he was talking, and the car had become a warm place with two people in it instead of a rolling cell."
    "Not one of the men he'd sat across steel tables from could have done what this twelve-year-old was doing without lifting her voice above the heater: taking a hard, closed, forty-seven-year-old man and, mile by mile, opening him."
    "He tried, in the first hour, to run it the other way. That was his trade, and he was not going to be gutted like a trout by a seventh-grader without at least putting a line in the water himself."
    s neutral "Driftwood. What do you remember of it? The village. The sea."
    a "Salt in everything. A gray church. My father's hands."
    a "And a cold that lived in the walls."
    "All of it true, he was sure, and all of it nothing. A handful of pretty stones held out to a man panning for gold."
    a smile "Did you grow up near the sea, Detective? Did you love it, or were you afraid of it?"
    "He was halfway into an answer about a childhood he never discussed before he shut his mouth."
    "And beside him, he could have sworn, something was quietly, warmly amused."
    s neutral "Was the winter hard on you? The funerals. The fear in the town."
    a neutral "Of course. Everyone was frightened."
    a "Isn't it strange, how frightened people turn cruel? How they need someone to blame. Have you seen that, in your work? How fear takes ordinary people and makes them into something worse?"
    "And he had. God knew he had. He had watched it kill a man in a road four days back."
    "He was three sentences into agreeing with her, into being understood by her, before he heard what had happened."
    "She had lifted his own probe out of his hands and set it back in them as a gift."
    "Twice more he cast, and twice more she simply was not where the hook came down."
    "Somewhere past the second hour he stopped. Not beaten. Because he had understood a thing that chilled him worse than her cleverness."
    "She was enjoying it. Not cruelly. The way a gifted child enjoys the rare pleasure of a game played against someone who can nearly keep up."
    "Because she found the wound. Of course she found the wound; she had found it weeks ago, across a notebook, and she had a map of it now."
    "Not asking. Never asking. Only leaving small warm openings a lonelier man than he wanted to admit he was could not help but step into."
    a "Were you ever married, Detective?"
    s tired "Long time ago."
    a "Children?"

    menu:
        "\"No.\"":
            s neutral "No—"
            "It was the professional answer, and the safe one, and the true-enough one. He had it in his mouth."
            "And then the road bent, and bent again, and a third time, and the silence lasted all three curves, and it would not hold."
            s hurt "...One. A long time ago. He didn't— he wasn't with us long."
        "\"One.\"":
            "He should have said no. It was the professional answer and the safe one."
            "He heard himself, instead, after a silence that lasted three curves of the road, say it."
            s hurt "One. A long time ago. He didn't— he wasn't with us long."

    "He felt her attention change. Not sharpen. Soften, or seem to."
    a sad "I'm sorry."
    "She let a mile go by."
    a sad "Is that why you were kind to me? At the funeral. In the car, before."
    "A pause weighted like a stone dropped down a well."
    a sad "Because you know what it is. To have the one that's yours taken."
    "There it was: the hook set so gently he'd swallowed it before he felt the barb."
    "He understood, coldly, in the part of him that never slept, exactly what was being done to him and by whom."
    "And understood in the same instant that it changed nothing. The thing she was reaching for was real, and you cannot armor a wound by naming the hand that presses it."

    # --- The middle stretch --------------------------------------------------
    scene bg mountain_road_dusk with fade_slow
    show alice neutral at right
    "They came down through the pines into the long middle stretch of the road, the gorge deepening beside them."
    a "What's it like? The city. Where you're taking me."
    a "I've never been. George never took me anywhere. Are the people— are they kind, mostly? In a big place like that. Where nobody knows you and you don't know them."
    "Samuel knew exactly what that city did with children who arrived in it unclaimed. He did not want to answer, and made himself."
    s neutral "It's big. It's easy to be nobody in. That cuts both ways."
    s "Nobody knowing you means nobody watching out for you. But it means nobody's already decided what you are, either. You'd get to start clean. New school, new faces, none of this following you in."
    s soft "There's good people in it. You just have to find them. Same as anywhere."
    "He heard himself selling it, the way you sell a hard thing to a child, and believed the half of it that was kind."
    a "A whole city of people who don't know me yet."
    "Something in the way she said it. The small satisfaction in it, turned over and set down, private and pleased, like a door she had found unlocked."
    "The fine hairs stood along Samuel's arms for a reason he did not, in the moment, let himself chase."
    show alice smile
    "Then she smiled a small tired child's smile at the glass, and it was gone, and she was only a lonely girl looking down the road at a frightening new place."
    th "That's all it ever was."
    show alice neutral
    a "Can I ask you something, and you'll tell me the truth? Everyone tells me the soft version. You don't, I think. I think you're the only one who wouldn't."
    s "Ask."
    a "Did my grandfather do those things?"
    a "They say he did. Everyone says he did, and then he died, and now it's like it was never even a question. But you were there. You know more than anyone."
    "She turned her head then, and her gray eyes were on the side of his face, patient, waiting."
    a "Did George kill those people?"
    stop music fadeout 2.0
    "Samuel Harris had the receipt and the nineteen seconds of tape locked in his room, and the whole ruinous truth locked in his chest."
    "He drove down a mountain road beside the girl who had done it, and could not, for a long moment, make a sound."
    "It was not a question. It was a test. She was reading him the way he was reading her, learning exactly how much the last dangerous man in her life knew."
    "And it was also, in the same breath, a real child asking after her dead grandfather. The mask and the face grown so wholly into one another that he did not think even she could have found the seam."

    menu:
        "\"I don't know.\"":
            s tired "I don't know."
            "He said it at last, carefully. It was the first lie he had told her, and it cost him."
            s tired "There are things about it that don't sit right with me. That's the truth. There are things I'm still trying to understand."
            "Something moved behind the gray eyes. He watched for it and he saw it: the flicker, for a hair of a second, of a mind adjusting, recalculating, filing away a new and important fact."
            "Then it was gone before he could read it."
        "\"No.\"":
            s stern "N—"
            "The truth got as far as his teeth. He felt the shape of it, and heard where it would go, and swallowed it."
            s tired "...I don't know."
            "It was the first lie he had told her, and it cost him."
            s tired "There are things about it that don't sit right with me. That's the truth. There are things I'm still trying to understand."
            $ notice()
            "Something moved behind the gray eyes, and this time he saw it whole. The flicker of a mind that had heard the swallowed word and weighed it, and was filing it away beside everything else she knew of him."
            th "She's twelve. She heard a man stumble over her grandfather. That's all."
        "Say nothing.":
            "He said nothing. The road said nothing. The heater ticked, and the silence stretched until it was its own answer, and he could not let it be that."
            s tired "I don't know."
            "It was the first lie he had told her, and it cost him."
            s tired "There are things about it that don't sit right with me. That's the truth. There are things I'm still trying to understand."
            "Something moved behind the gray eyes: the flicker, for a hair of a second, of a mind adjusting. Then it was gone."

    show alice sad
    "Her lip trembled, and she looked back at the road."
    a sad "I hope he didn't. I know I'm not supposed to. But he was all I had, and I hope he didn't."
    "And Samuel felt his two-night certainty thin to nothing. Become absurd, monstrous, the fever-dream of a broken man."
    th "Look at her. She is twelve and her hands are folded and she is crying for a dead man, and you have built a serial killer out of a schoolgirl because you could not bear to have failed."
    "For one long stretch of white road Samuel Harris very nearly, with something close to relief, believed her."
    "Not the fact of it. The fact was locked in his hotel room, and no weeping child on earth could touch that. It was the meaning of the fact that thinned."
    "It was not the reason failing. It was the reason drowning, quietly, in the ordinary flood of a human being in the next seat."
    "And she knew it. It was the whole of her method, worked now on him as it had been worked on a teacher and a shopkeeper and a lonely girl with a diary."
    "Get close, and stay close, and be warm and near, until the person beside her could no longer believe of her the thing that was true."

    # --- Dusk: the coin ------------------------------------------------------
    scene bg car_day_snow at night with fade_slow
    show vignette
    show alice sad at right
    play music m_aftermath fadein 3.0
    "For a while, then, they did not talk at all, and the not-talking was worse than the talk."
    "The light went from gray to a deep failing blue, and the gorge filled up with dark first, the way water fills a glass from the bottom."
    "The car became a small lit box moving through a country that was losing its color, and the girl sat in the glow of the dash with her cheek against the cold window."
    a sad "Emily collected buttons."
    a sad "And leaves. And once a coin so old you couldn't see the face on it anymore. She kept them in a tin."
    a sad "And if she liked you she'd just give you one, right out of the tin, like it was nothing. Like she had a thousand."
    "A small breath fogged the glass."
    a sad "She gave me the coin. The one with no face. She said it was her best one, and that was why I should be the one to have it."
    a sad "I still have it. It's in the bag."
    "Samuel heard the grief in it and could not find the bottom of it, because there was no bottom. Because the grief was true."
    "The girl beside him had loved Emily Carter. He could hear it, the way you can hear a true note under a hundred false ones."
    "And she had knelt in the snow and poisoned her all the same, and kept the coin. Both of those were one girl, mourning the friend she had murdered and meaning every tear of it."
    "It was the most frightening thing he had ever sat beside, and it looked exactly like the most human."
    "For a long stretch of the dark descent he drove and grieved, honestly, alongside the child, for the child she had killed. And hated himself for it, and could not stop."
    "The not-being-able-to-stop was the softest and most fatal thing in him. It was precisely the thing she had spent four hours finding."
    $ note("The coin with no face. 'It's in the bag.'")

    # --- The creed -----------------------------------------------------------
    stop music fadeout 3.0
    "After a while she stirred, and wiped the fog from the glass with her sleeve, and drew her knees up into the seat. Small, the holdall of her whole life at her feet."
    show alice neutral
    a "Can I tell you something I've never told anybody? About my family. About what they were like."
    s soft "If you want to."
    play music m_ritual3 fadein 6.0
    a "They believed people are what they carry."
    a "Not what they say. Not what they pretend to be. Everybody's carrying something, and some people are strong enough to carry it in the open."
    a "And some people are weak and hide it and lie about it. And the lying— the pretending you're something you're not— that was the worst thing there was. Worse than being weak."
    a "They taught me to see it. To look at a person and know which one they were."
    "She was watching the side of his face again, the last gray light on her cheek."
    a "The strong ones and the pretenders. I've always been able to see it. It's the first thing I see about anybody."
    "There it was, laid in his lap in a child's mild voice: the whole cold gospel written in cult-tongue on the bodies of five people. False purity cannot endure. The weak do not endure."
    "Recited to him now as a family recipe, by the girl who had written it."
    "His certainty came back all at once, whole and cold. And with it the other thing, the thing that had no business in a detective: an ache, enormous and useless, for the child this creed had eaten."
    $ note("'People are what they carry.' Strong ones and pretenders. Her words.")
    "He knew even as he opened his mouth that it was the wrong thing to show her. That he would be handing her something."

    menu:
        "Tell her.":
            "He did it anyway, because he was not, in the end, and to his own ruin, the machine he had spent thirteen years trying to be."
        "Keep driving.":
            "He kept his eyes on the road. He held it behind his teeth for one mile, and half of another."
            "And then he could not stop himself, because he was not, in the end, and to his own ruin, the machine he had spent thirteen years trying to be."

    s hurt "You don't have to keep it."
    "It came out rougher than he'd meant. Scraped."
    s hurt "Whatever they put in you. However early they started. A kid doesn't choose the house she's born in, and she is not the house. Not all the way down."
    "He stopped, and started again, worse at this than he had been at anything in years."
    s soft "You're twelve. There's people whose whole job is helping kids set down things that got loaded on them too young to say no."
    s soft "It can be set down, Alice. That's all I'm telling you. Somebody should've told you a long time ago that it can be set down."
    "The car was quiet a long moment."
    "When Alice answered her voice was gentle, and there was something in it that had not been there before. Something that had finished considering him."
    a neutral "You're kind. You really are. I wasn't sure, at first."
    a "When I first met you, you didn't feel anything— or you didn't show it— and I thought, there's a strong one. There's one who carries it and doesn't pretend and doesn't break."
    "She looked out at the dark coming up out of the gorge."
    a "But you're just sad, aren't you. Underneath all of it. You're just as sad and soft as everybody, you only hid it better and longer."
    "A pause, small and final, a stone settling to the bottom of a well."
    a "That's alright. I don't mind. I just thought you were something you weren't."
    "Samuel heard it land two ways at once, and could stop neither."
    "One way, a wounded child had seen through a tired man's armor to the grief underneath. That was true."
    "The other way was colder, and older, and carried no mercy at all. A judge closing a file she had kept open on him since the first day."
    "Weighing the last strong thing in her small cold world, and finding it, in the end, a pretender like the rest."
    "The verdict came down somewhere in the car. He did not let himself hear it."
    "But the animal in him, the one that had been standing up in the dark since the first day, heard it, and lay down, and went cold."

    # --- The valley station --------------------------------------------------
    scene bg mountain_road_dusk at night with dissolve_slow
    show vignette
    "Before he could find anything to say, the road bent a last time out of the trees."
    "Down in the blue dark of the valley floor, where the mountain road ran out at last onto the flat, a scatter of hard white light stood alone against the coming night."
    scene bg valley_station_night with fade_slow
    show vignette
    "A gas station. Six pumps under a lit canopy."
    "A low shop, a squat row of toilets off to one side. And beyond them, at the edge of the lot, the black drop of the gorge behind a run of old barrier rail, some of it bent, some of it gone."
    show alice neutral at right with dissolve
    "Beside him, without a word, Alice went very still."
    "The amber tank light glowed on the dash. The long day's fuel nearly gone, the last hour of road still between them and the city."
    "He put on his signal, though there was no one for miles to see it, and slowed, and turned in toward the hard white light."
    "Every hair on him had quietly stood. He put it down to the long day and the girl's silence, and did not look too hard at whether that was the whole of it."
    "Her eyes were on the lit island as it swung toward them. Fixed. Unblinking. She did not so much as glance at the road, or at him."
    stop ambient2 fadeout 3.0
    "As he brought the car in under the canopy and the cold light washed over them both, he felt it come up off her small silent shape and fill the car."
    "Not fear. Nothing so warm as fear."
    "A kind of attention, wide and patient and old. The attention of a thing that has arrived, at last, somewhere it knows."
    $ note("Valley floor. Six pumps, toilets, a broken rail at the drop.")

    jump ch13
