label ch03:
    call chapter_card(3, "Greyvale — January 3rd, 2025")

    # --- The hotel lobby ---------------------------------------------------
    scene bg hotel_lobby with fade_slow
    play music m_office fadein 2.0
    call place("The Greyvale Hotel — morning")

    "The hotel stood just off the main square, a modest three-story building with a sloped roof and a neon sign that buzzed faintly against the snow."
    "Inside, the lobby was warm. Pine cleaner, faint wood polish. A small Christmas tree leaned in one corner, its lights still glowing though the holiday had already passed."
    "The clerk behind the counter straightened as Samuel approached. Early twenties, tidy hair, the expression of someone unused to late-night visitors."
    s "I'll need a room."
    extend " Indefinitely."
    "The clerk blinked, but began to type, hands clumsy against the keys."
    clerk "Of course, sir. No problem."
    "He slid a form across. Samuel signed without hesitation. The young man hesitated before handing over the key, and his curiosity leaked into his voice."
    clerk "If you don't mind me asking... was she crazy? That teacher in town... she jumped in a T-shirt at minus ten?"
    "Samuel looked at him once, his face unreadable, then slid the key from his hand without answering."
    "The silence was sharper than a reply. The clerk fidgeted, suddenly aware of the weight of his own words."
    "Samuel stepped into the elevator, then glanced back, voice blunt and dry."
    s "I'm planning to smoke in there. I'm sure you don't mind."
    clerk "Sir—"
    "The doors slid shut on the rest."

    # --- Hotel room: the phone ---------------------------------------------
    scene bg hotel_room_day with dissolve
    "A hushed corridor, a room near the end. A double bed, a desk with a lamp, curtains drawn against the snow."
    play sound sfx_thud
    "He closed the door with more force than he intended. The slam echoed briefly, then left the room in silence again."
    "Almost at once, a sharp pang twisted his stomach. He hadn't eaten since morning, and the day had burned through whatever reserves he had left."
    th "Fuel first. The case will keep an hour."
    "A wrapped croissant and a plain sandwich, packed for the trip. Practical, nothing more. He sat on the edge of the bed, food in one hand, notebook in the other."
    "He set his phone beside him and replayed the recording of Andreas Mallory's interview."
    an "...she stayed to wash the dishes... the door closed... I thought she went to throw the trash out..."
    "Samuel listened with eyes narrowed, cigarette burning in the ashtray. He let the pauses, the tone, the weight of guilt settle in his mind."
    "In the margins, small notes: {i}Dishes not washed. Phone left behind. Preplanned breakfast table.{/i}"
    "He leaned back, exhaled smoke through his nose, and stared at the ceiling."
    th "Suicide doesn't fit. Not cleanly."
    "Not by hands, maybe — but someone had put her on that roof all the same. By words. By pressure. By something that left no mark for a coroner to find."
    "He had seen grief before, and despair. He knew their shapes by now. This was a different shape."
    "He set the notebook aside and pulled Maria's phone from his coat. No password change, no special protections. He opened the call log first."
    "Family calls over Christmas. New Year's greetings. Relatives, a few minutes to nearly an hour. Nothing unusual for the holidays."
    "But one entry stood out."
    "December 31st, late evening. {i}Steve Collins.{/i} Duration: six seconds."
    th "Six seconds isn't a conversation. Barely enough for a wrong number."
    extend " Or for someone to lose their nerve."
    $ note("Steve Collins — 6 sec call — NYE.")
    note_voice "Steve Collins — 6 sec call — NYE."
    "Into the messages. Her husband, the children's reminders, short notes with relatives. All the usual rhythm of family life."
    "But one chat drew his attention. A group named {i}Evening Study Group{/i}."
    "Eight participants. Three boys, five girls, their names lined up neatly, familiar from what Andreas had said."
    "And there it was, buried among them: Steve Collins."
    "Samuel paused, cigarette halfway to his lips."
    th "So. The same boy who called her on New Year's Eve."
    "He copied the names carefully, circled Steve's and marked it twice."
    "Outwardly, the chat was harmless — reminders, small encouragements, schedules for extra lessons. But harmless things could hide teeth."
    "He locked the phone and leaned back until the chair creaked. A nervous boy who'd dialed and lost his nerve in six seconds — or something else entirely."
    "He drew on the cigarette and let the smoke go slow, already deciding where he'd press first."

    # --- Mercer at the door -------------------------------------------------
    "The phone screen dimmed. Going through the device had taken longer than expected, but it was worth it. Every call, every thread, every scrap mattered."
    play sound sfx_thud
    "A knock. Three short, deliberate raps."
    "Samuel slid the phone back into his coat and opened the door."
    show mercer neutral at center with dissolve
    "Officer Daniel Mercer. The man who had greeted him at the schoolyard. Samuel hadn't looked at him properly then. He did now."
    "Late thirties, though his face carried more years than that. Eyes sore and rimmed red, the mark of bad sleep carried too long. Nails cut too close, raw at the edges, as if gnawed in idle moments."
    "Collar askew, belt cinched too tight, hair plastered down on one side by water and a flat hand rather than a comb. Presentable, but strangely unsettled."
    m "Detective Harris."
    m "The names and addresses you asked for. The students Mrs. Mallory was tutoring."
    "Samuel took the folder and scanned it. The list matched the group chat. And there it was again, in print. {i}Steve Collins.{/i}"
    s "Good. Thank you, Mercer."
    "The officer nodded once, waiting."
    s "I'll let you know as soon as I find something. For now, you'd better get some rest. We'll catch up tomorrow."
    m "Understood, Detective."
    "He turned as if to leave, then paused. His voice dropped lower, careful, almost hesitant."
    m "Do you think... there's something behind it? Something more than just a suicide?"
    "Samuel's smile came easy, but thin."
    s "We'll catch up tomorrow."
    "Polite. Dismissive. No room for argument. Mercer gave a respectful nod, and left."
    hide mercer with dissolve

    # --- Greyvale street ----------------------------------------------------
    scene bg greyvale_street with fade
    show snow light
    play music m_outside fadein 2.0
    play ambient sfx_wind fadein 2.0
    call place("Greyvale — 10:30 a.m.")
    "Collins' address. Nine minutes' walk. The clerk barely glanced up as he passed."
    "Outside, the air was sharp but cleaner, the snow down to a faint drizzle of flakes. Bakers setting trays behind glass. A grocer sweeping snow from his step."
    "Most shops stayed shuttered. In small towns like this, nothing really started until after Epiphany, January sixth."
    "His boots crunched over salt. Life moved slower here — measured, deliberate. For a fleeting moment he imagined it: a small business, quiet mornings, peace wrapped in routine."
    "His face hardened almost at once."
    th "I'd rot here. Boredom would finish me before anything else."
    "At the end of the main district stood Collins' building: three stories of weathered stone, dignified in its way. The kind of construction that belonged to another time."
    "Samuel paused on the pavement, ember glowing in the mid-morning light."
    th "Steve Collins lives here."
    stop ambient fadeout 1.5

    # --- The Collins home: Magda at the door --------------------------------
    scene bg stairwell with dissolve
    # ART-REQUEST (fulfilled): old stone stairwell / ground-floor apartment corridor (Collins building entrance)
    play music m_office fadein 2.0
    "Damp stone and cleaning detergent, the scent that never quite leaves old stairwells. Ground floor, Collins family."
    "Not a bell. Just his knuckles against wood."
    "The latch clicked."
    show magda neutral at center with dissolve
    "Magda Stewart. Widowed four years. Early forties by the report, but her appearance leaned younger — too young."
    "Rose-colored makeup, lipstick in the same shade. A pinkish blouse, a short denim skirt, stockings. Her smile was pleasant. Her eyes evaluated him in a single glance."
    mg "Detective Harris?"
    s "Yes, ma'am. I'm here about your son, Steve. I'd like to ask a few questions."
    "She leaned against the doorframe, arms folded loosely."
    mg "Yes, I heard about... Maria Mallory. About twenty minutes ago, a neighbor called me. Tragic."
    "She tilted her head, lips pursing in mock sadness."
    mg "But I haven't told Steve yet. I can't stand to see him upset. Maybe you should tell him instead. You're the professional."
    th "She can't stand to see him sad."
    "Samuel's jaw tightened, though he kept his face neutral. Yet the opportunity was there. The boy's raw reaction would tell him more than any polished story later."
    "Something in this house didn't sit right."
    s "Alright, Mrs. Stewart. I will speak with your son."
    mg "Steve's in his room. I'll be in the kitchen, finishing my... power juice."
    "A faint smile, too casual for the moment, and she turned away."
    hide magda with dissolve

    # --- Steve's bedroom ----------------------------------------------------
    scene bg collins_bedroom with dissolve
    "He knocked twice on the closed door."
    stv "Come in, Ma."
    "Irritated. Samuel pushed the door open."
    s "Not your mother, Steve."
    show steve panic at center with dissolve
    "He closed the door, pulled out a chair, and sat facing the boy."
    s "Detective Harris."
    stv "What do you want? I don't have the weed, alright? Jo's got it — it's at his place. Get the fuck out, man, leave me alone."
    "Too fast. Guilty reflex more than thought."

    menu:
        "Press him. Hard.":
            "Samuel didn't raise a hand. He didn't need to. He let the name fall like a dropped weight."
            s "I'm not here for that. I'm here about Maria Mallory."
            show steve panic at center, tremble
            "The name landed like a blow. Steve froze, the color draining from his face."
        "Give him room.":
            "Samuel raised a hand, calm and steady. Let the boy see he wasn't the enemy. Not yet."
            s "Not here for that. Relax. I'm here about Maria Mallory."
            "Even gently, the name landed like a blow. Steve froze, the color draining from his face."

    stv "Wh... what about her? She told you something?"
    "Samuel let the silence drag. He lit a cigarette, the flame flaring briefly, then leaned back, eyes fixed on the boy."
    s "She didn't need to tell me anything. You're telling me plenty right now."
    stv "No — she was just my teacher, that's all."
    s "Teachers don't usually leave their students white as chalk at the mention of their name."
    s "So I'll ask once. What was going on between you and Maria?"
    "Steve's breathing quickened. His gaze darted to the door, then back, as if weighing escape."
    stv "We... we started talking. After class. She said I was smart, different."
    s "When?"
    "The boy's hands went to his hair, fingers pulling."
    stv "Few months ago. Three... maybe a little more."
    stv "She said no one could ever know. Not my mom, not anyone. Just us."
    stv "She told me she needed me. That I wasn't like the others. She promised it was real."
    "Samuel exhaled smoke slowly through his nose."
    s "Evenings. At school?"
    stv "Yeah. Sometimes. Sometimes her place too."
    $ note("Affair. Began three months ago. Evening meetings. School + her home.")
    note_voice "Affair. Began three months ago. Evening meetings. School + her home."
    show steve panic at center, shake
    stv "I didn't do anything to her! I swear — I didn't make her—"
    "Samuel closed the notebook with a snap."
    s "That's not what I asked."
    "The boy flinched, burying his face in his hands. His voice rose, thin and frantic."
    stv cry "Please don't tell anyone. Don't tell my mom. Maria told you? Why would she — why would she say something? It's not my fault!"
    "Samuel's hand lifted, cutting through the spiral."
    s "Nobody needs to know. Not yet."
    s "And no, Steve — Maria didn't tell me. She couldn't. She's dead."
    show steve cry at center, tremble
    play sound sfx_tinnitus
    "The boy's face collapsed. His mouth opened, closed. His chest heaved. His hands clawed at his hair, as though he could wake himself from it."
    "Samuel leaned forward, voice steady, anchoring him."
    s "Listen to me. Stay here. Stay with what's real. You understand?"
    s "She's gone. Now I need to know — did anyone else know about the two of you?"
    "Steve's eyes went to the floor. He said nothing."
    s "Answer me, Steve. Did anyone else know?"
    "The silence stretched. Samuel's pen tapped the notebook, once, twice."
    "Then the doorknob turned."
    show steve panic at midleft with move
    show magda neutral at midright with dissolve
    "Magda stepped in on a perfume of fruit and powder. Her eyes didn't seem to register the weight of the air in the room."
    mg "Oh, my boy. You're devastated. It's alright — we'll find another teacher to help you."
    "She knelt to hug him, smoothing his hair as if nothing in the world had changed."
    "Samuel rolled his eyes, sharp and visible."
    "Over his mother's shoulder, Steve's wide eyes stayed locked on him."
    th "No."
    "Samuel drew a card from his coat and placed it quietly on the boy's desk as he rose."
    s "You've got my number now. If you remember anything — anything at all — you call me. Doesn't matter when."
    "Steve gave the faintest nod, lips pressed tight. His mother was still murmuring empty comforts. She hadn't even noticed."
    hide magda
    hide steve
    with dissolve

    # --- Walking: the dots --------------------------------------------------
    scene bg greyvale_street with fade
    show snow light
    play music m_outside fadein 2.0
    play ambient sfx_wind fadein 2.0
    "The door clicked shut behind him. Perfume and stale air gave way to the bite of cold. He lit a cigarette and let the smoke steady him."
    "He walked without direction. Dots. Faint, scattered, refusing to join."
    "Maria Mallory had died by her own hand. A T-shirt, leggings, no socks. Not an accident. A final breakfast, neat and deliberate. A silent farewell."
    "But then the cracks. She had been sleeping with a boy — sixteen, trembling in his bedroom like a child caught stealing."
    "Too raw to be false. Too fragile to have planned something darker. Steve was weak, cowardly even. But blackmail required a coldness, a control the boy did not possess."
    th "And was he honest, that no one else knew? Secrets have weight. They press outward. Someone always catches the scent."
    th "Blackmail. That fits."
    "A teacher exposed with a student. In a town like Greyvale, that wasn't a scandal — it was a permanent stain. Her children marked forever."
    "Enough to make her climb a roof. Enough to make her jump."
    th "Speculation. Words chasing smoke. I need something concrete."
    stop ambient fadeout 1.5

    # --- The long day of interviews (condensed) -----------------------------
    scene bg greyvale_street with dissolve
    call place("Greyvale — afternoon")
    "The hours bled together. Address to address, name after name. First the boys, then the girls."
    "Parents hovering close. Children speaking in low, uncertain voices. All said the same things."
    woman "She helped him with his lessons, yes. She was kind. Strict in her way, but never unfair."
    "No resentment. No whispered secrets. Nothing useful."
    "By late afternoon he had run the circuit. His notebook was fuller, but not sharper."
    "At the corner mini market: a bag of chips, a packet of crackers, a soda bottle. Junk, but enough to fill the space where a meal should be."

    # --- Hotel, night -------------------------------------------------------
    scene bg hotel_lobby at night with fade
    show vignette
    play music m_office fadein 2.0
    "Night had set in by the time he returned. The clerk was lost in a paperback. In the sitting room the big fireplace roared, armchairs empty around it, shadows stretching long."
    "Samuel didn't linger."
    scene bg hotel_room with dissolve
    show vignette
    "The silence was deeper upstairs, broken only by the hum of the radiator."
    "Chips first — cheap, oily, loud in the teeth. Then crackers, dry but steady. Soda straight from the bottle, the fizz sharp against his throat."
    "Between bites he turned the pages, cross-checking his observations against the meager results of the day."
    th "Nothing to move on."
    "Still he chewed and wrote, his mind running circles while the clock ticked past eight."
    "At some point the notes blurred, the pen slipped from his hand, and Samuel drifted into sleep sitting upright on the bed."
    stop music fadeout 3.0
    scene black with fade_long

    # --- Dawn: the dining room ----------------------------------------------
    scene bg hotel_room with fade_slow
    call place("January 4th — 6:00 a.m.")
    "The faint wash of dawn crept past the curtains, pale and cold. He stirred, groaned, straightened his stiff back."
    "The notebook still lay open on the blanket. A hot shower burned the chill from his bones, though the heaviness in his head lingered."

    scene bg hotel_dining with dissolve
    play music m_office fadein 2.0
    "Downstairs, the dining room was already open. The fireplace still smoldered from the night before."
    "He filled a plate, poured a coffee, and took a seat with his back to the wall, notebook and phone set neatly beside his tray."
    "The coffee was thin and bitter. He pushed it aside after a sip. But the chicken pie surprised him — golden crust, rich with herbs and soft meat."
    "His eyes wandered, as they always did."
    "An elderly couple, neat, deliberate, sharing toast and jam in low voices as though the world outside didn't matter."
    "A young mother corralling two boys in sweaters. One tugged her sleeve for another croissant. The other stared dreamily at the fire."
    "At the far end, a man in a dark coat sat alone over a newspaper. His eyes never left the page, though he hadn't turned it once."
    th "Small-town lives. Ordinary routines. And in the middle of all this quiet, a teacher climbed a roof and ended her life."
    "He finished the last bite of pie and wiped his hands. Something nagged at him."
    "The roof. He hadn't gone up himself. And as far as he remembered, neither had the local uniforms. Too focused on the crowd, the fall, the mess below."
    th "If she left anything — a note, a sign — it won't be at her home. It'll be at the place she ended it."

    menu:
        "Call Doyle first. Keep the captain calm.":
            "Business first. Keep the city off his back while he still had a thread to pull."
            jump ch03_doyle_first
        "Straight to the school. Doyle can wait.":
            jump ch03_mercer_first

label ch03_doyle_first:
    call ch03_doyle_dawn
    call ch03_mercer_dawn
    jump ch03_rooftop

label ch03_mercer_first:
    call ch03_mercer_dawn
    "Halfway to the gates, he remembered the captain and dialed with his thumb."
    call ch03_doyle_dawn
    jump ch03_rooftop

label ch03_doyle_dawn:
    play sound sfx_phone
    show screen phone_call("Raymond Doyle")
    d "Sam. Didn't expect to hear from you before the sun."
    s "I wanted to update you. Interviewed the family, checked the tutoring students. Nothing concrete. I'll give it a few more hours, then wrap it up."
    "A low chuckle on the line."
    d "Knew you'd have it under control. Greyvale's a quiet place — don't go digging too deep for trouble that isn't there."
    "Samuel allowed himself the faintest smile."
    s "Wouldn't dream of it."
    hide screen phone_call
    return

label ch03_mercer_dawn:
    scene bg greyvale_street with dissolve
    show snow light
    play ambient sfx_wind fadein 2.0
    "Outside, the air cut colder, the streets just beginning to stir. He lit a cigarette and scrolled to Mercer's number."
    play sound sfx_phone
    show screen phone_call("Daniel Mercer")
    m "Mercer..."
    "Groggy. Heavy with sleep."
    s "It's Harris. I need access to the school rooftop. Now."
    m "The roof? We didn't... uh, no one went up there yesterday."
    s "That's why I'm calling you."
    "He drew smoke into his lungs and exhaled hard."
    s "Meet me at the school gates in twenty. Bring the keys."
    m "Understood, Detective. I'll be there."
    hide screen phone_call
    "Snow crunched under his boots, his breath rising in slow plumes."
    return

    # --- The school rooftop -------------------------------------------------
label ch03_rooftop:
    scene bg school_exterior with fade
    show snow light
    play music m_outside fadein 2.0
    call place("Greyvale High School — morning")
    "It took three full smokes before Mercer showed. Samuel stood at the gate, hands buried in his pockets, eyes narrowed in quiet irritation."
    show mercer neutral at center with dissolve
    "Mercer half-jogged the last stretch, fumbling with his duty belt, nearly tripping on a patch of ice."
    m "Detective. Sorry — I came as quick as I could."
    "Samuel exhaled the last drag and flicked the butt into the snow."
    s "You're here now. Let's go."
    hide mercer with dissolve
    stop ambient fadeout 1.5

    scene bg school_corridor with dissolve
    "The building was still and echoing. Chalk and detergent. Their boots clapped against the linoleum, the holiday silence making every sound sharper."
    "Up the stairwell, each step creaking, the air colder as they climbed. At the heavy metal door, Mercer fumbled with the lock, hands unsteady from the chill or his nerves."
    "Samuel waited, arms crossed, with the patience of a man used to worse delays."
    "The lock clicked. A wash of cold air swept in, carrying the scent of snow and iron."

    scene bg school_rooftop with fade
    show snow light
    play ambient sfx_wind fadein 2.0
    show mercer neutral at right, dimmed with dissolve
    "They crossed the roof in slow, deliberate arcs. Vent housings. The low parapet. The patches where the snow had thinned."
    "Nothing. No footprints but their own, no scrap of paper caught in the wind. No sign of Maria's final moments except the silent void she'd left behind."
    "Samuel exhaled through his nose, half sigh, half growl."
    s "Well... it was a positive thought to begin with."
    s "Perhaps we can check her office while we're here."
    show mercer neutral at right
    "Mercer nodded quickly, eager to be useful."
    hide mercer with dissolve
    stop ambient fadeout 1.5

    # --- Teachers' office: the USB ------------------------------------------
    scene bg teachers_office with dissolve
    play music m_office fadein 2.0
    "The teachers' common office smelled of paper and stale coffee. A row of desks, each with a small wooden nameplate. Maria Mallory's sat neatly in the center."
    show mercer neutral at right, dimmed with dissolve
    "Samuel slid into her chair. Assignments stacked, notes folded, homework neatly arranged. The bin under the desk was empty."
    th "Too orderly. Almost sterile."
    "He powered on the computer. File history, browsing logs, her school email. Nothing out of place. No flagged messages, no unusual searches."
    "Then he noticed it. A USB stick, lying on the desk. Plain, unmarked."
    "He slotted it into the front port. Nothing. Another port. Still nothing. The drive didn't register."
    show mercer neutral at right
    m "Maybe it's broken."
    s "Maybe. Or maybe it isn't school property. Could be blocked by their security system — unregistered devices, possible virus risk."
    m "You think so?"
    "Samuel leaned back and fixed him with a dry look. For a few seconds they stared at each other, the silence awkward, drawn out. Then Samuel smirked faintly."
    s "We've got the same bullshit in central department."
    m relieved "Guess some things don't change."
    "Mercer chuckled once, nervous but easing. Samuel turned the device over in his fingers, voice low, half to himself."
    s "If it's not school property... doesn't explain why it was just lying here."
    s "Everything else on this desk is neat, organized to the point of obsession. And this—"
    "He set the USB down in the exact spot it had been. Dead center."
    s "—was left in the middle. Like it was waiting to be found."
    "Mercer shifted on his feet, hanging on every word."
    s "And as it seems, it wasn't. Maria couldn't have used it. So why was it left here?"
    m "Do you think it means something?"
    "A grin tugged at the corner of Samuel's mouth."
    s "Well, we can't know that. Not yet. What we can do is register it as evidence. Then we'll have your department run the checks."
    m "Of course."
    "They logged the item and sealed it in a small bag. Nothing in the desk disturbed, everything returned as they'd found it."
    s "Alright. That's all we can do here."
    hide mercer with dissolve

    # --- The station: the message -------------------------------------------
    scene bg station_office with fade
    call place("Greyvale Police Station")
    "The station sat on a side street, weathered stone and concrete. Civil offices on the first floor, the officers on the second, a narrow jail on the third for drunks and petty thieves."
    "Walls once white, now dulled to gray and bluish-dark. Corners peeled. The air smelled of dust and stale coffee."
    "A cramped office on the second floor. An old desktop humming on a metal desk, its tower scarred with years of fingerprints."
    show mercer neutral at right with dissolve
    "Samuel placed the USB carefully on the surface."
    s "Let's see what we've got."
    "Mercer slid it into the port. For a moment, nothing. Then the system chimed, and the drive appeared."
    "One file. {i}doc1.pdf{/i}"
    "Samuel's jaw tightened. Mercer opened it. A single page of text."
    stop music
    window hide
    scene black with dissolve_slow
    pause 1.0
    window auto
    "{i}You are a lying whore of a woman.{/i}"
    "{i}Do as you've been told or everyone will know.{/i}"
    "{i}Don't make me send the photograph to everyone.{/i}"
    window hide
    pause 1.5
    window auto
    scene bg station_office with dissolve
    show mercer shaken at right with dissolve
    play music m_office fadein 3.0
    m shaken "Christ..."
    "Samuel's eyes lingered on the words, cold and even. Proof."
    s "Looks like blackmail."
    "No triumph in it. Only confirmation of what he'd already known."
    "They wasted no time. Mercer called in the department's IT technician: balding, wire-rim glasses, a coffee stain on his shirt. Within an hour, he turned to them."
    tech "School computer. Timestamp matches thirteen days before she died."
    s "Which user?"
    tech "That's the problem. There's no user list. The library terminals at the school are open — no logins, no IDs. Anyone can sit down, type, print."
    tech "Security doesn't restrict external devices either. Kids bring in USB sticks for posters, essays, whatever."
    s "So it's untraceable."
    tech "Short of someone leaving fingerprints on the keyboard — yes."
    "Proof of blackmail, yes. A culprit? Still smoke in the air."
    $ note("Maria was pushed.")
    note_voice "Maria was pushed."
    hide mercer with dissolve

    # --- Doyle ---------------------------------------------------------------
    "Samuel stepped into the corridor, colder and stiller than before, and leaned against the wall by a cracked window."
    play sound sfx_phone
    show screen phone_call("Raymond Doyle")
    d "Sam. Thought you'd be ready to head back by now. You find yourself a souvenir in Greyvale?"
    "A short laugh, rough and humorless."
    s "Something like that. Listen, Ray — we've got more here than a simple suicide."
    d "Go on."
    s "She didn't jump because of despair. She was pushed — blackmailed."
    "He lit a cigarette, smoke curling past the windowpane."
    s "We found a USB on her desk. File on it reads: 'You are a lying whore of a woman. Do as you've been told or everyone will know. Don't make me send the photograph to everyone.'"
    d "Christ."
    s "Our IT confirmed it was created on one of the school's public terminals. No user IDs, no tracking. Could've been anyone — students, staff, a stranger."
    d "So it's real. Not gossip. Someone had her by the throat."
    s "Exactly. And if she believed the photograph existed, she'd know what it meant for her kids. The shame in a town like this... she never would've recovered."
    d "Alright. You've got something solid. Stay on it, Sam. But don't spook the locals. Keep it tight. I'll make sure you've got the department's backing if you need it."
    s "Don't worry. Greyvale's quiet. I'll be quieter."
    d "Good man. Keep me updated."
    hide screen phone_call
    "One last drag. Outside the window, snow lay over the rooftops of the town."

    # --- The second body ----------------------------------------------------
    show mercer neutral at center with dissolve
    s "Keep your eyes and ears open. Be discreet. Nobody needs to know about the blackmail yet."
    s "If word gets out, the culprit will hide — or vanish altogether. For now, we keep the initial statement. Anxiety. Suicide. Let it linger."
    m "Understood, Detective."
    "Samuel was pulling on his coat when the phone on the duty desk began to ring. Shrill, cutting through the stillness."
    play sound sfx_phone
    m "Greyvale PD."
    "Silence, and a muffled voice on the other end. Mercer's eyebrows drew tight. The color drained from his face."
    show mercer shaken at center
    m shaken "Detective..."
    extend " We have another body."
    stop music fadeout 2.0
    "The room seemed to grow colder, the hum of the old building pressing close. Samuel's cigarette flared."
    s shocked "Where?"
    "Mercer set the receiver back in its cradle."
    m shaken "Name's Patrick Hensley. Mid-forties. Owned the general store on Birch Street."
    "Samuel remembered the storefront from his walk. A faded sign, shuttered for the holiday."
    s "What happened?"
    m "Collapsed in his shop. Caller says he was alone when it happened. Neighbors found him locked inside."
    "Samuel flicked his cigarette into the metal ashtray and pulled his coat tight."
    s "Alright. Let's go."
    hide mercer with dissolve

    # --- The drive -----------------------------------------------------------
    scene bg greyvale_street with fade
    show snow light
    play ambient2 sfx_engine fadein 1.5
    play music m_outside fadein 2.0
    "The snow had thinned to a soft dusting, the holiday silence stretched taut over Greyvale."
    "Mercer drove. The engine coughed, then growled to life. Old buildings rolled past in muted grays and whites."
    "Neither man spoke. Another body. Another piece in a pattern Samuel had barely begun to see."
    "Birch Street. Stone walls, narrow windows, a faded awning sagging under snow. A small knot of bystanders outside, their breath fogging in the cold."
    "Blue lights painted the shopfront in flickers. Samuel rubbed his temple with two fingers."
    s "Let's see what we've got."
    stop ambient2 fadeout 1.0
    stop music fadeout 2.0

    # --- Hensley's store -----------------------------------------------------
    scene bg hensley_store with fade
    call place("Hensley's General Store — Birch Street")
    "The bell above the door gave a weak jangle. The air inside was heavy: dust, damp cardboard, and something sour beneath."
    "Two tired fluorescents, one buzzing in uneven rhythm. Shelves half-stocked, flour and sugar beside gaps, cans scattered without order. Freezers humming, panes fogged with frost."
    "Paint peeled from the walls. The floor needed more than a mop. It needed years undone."
    "At the front counter lay Patrick Hensley."
    call mature_show("hensley_body")
    "Face down, one arm draped over the edge as though reaching for something in the fall. His head rested in a shallow pool of coffee, streaked darker where his split lip had bled."
    "A broken mug lay shattered on the floor just beyond his hand."
    "Samuel crouched, notebook already in hand."

    menu:
        "Look at the body first.":
            "He studied the man methodically. The skin had a strange pallor, drained faster than it should have."
            "Lips tinged bluish-purple, teeth visible through them as if clenched before death. The fingernails carried the same discoloration, like bruises pressing outward."
            "One leg bent awkwardly beneath him, the calf stiff, the tendon in the neck corded even in death."
            "Then the counter. A trace of vomit at its edge, acidic, sharp in scent."
        "Look at the counter first.":
            "The counter first. Spilled coffee, dark and cold. Shards of ceramic. A trace of vomit at the edge, acidic, sharp in scent."
            "Only then the man. A strange pallor. Lips tinged bluish-purple, teeth visible as if clenched before death. Fingernails discolored like bruises pressing outward."
            "The posture rigid, locked where the body had seized. The tendon in the neck corded with unnatural tension even in death."

    "It looked sudden. Violent. Not the slow collapse of a man with a weak heart."
    $ note("Face down, counter. Coffee spilled. Mug broken. Rigor tight. Cyanosis lips/fingertips. Vomit trace.")
    note_voice "Face down, counter. Coffee spilled. Mug broken. Rigor tight. Cyanosis lips/fingertips. Vomit trace."
    "He set the pen against his lip a moment."
    th "Something ingested. Poison?"
    "But he didn't write the word. Not yet."
    call mature_hide
    "Outside, Mercer was calling orders to keep the crowd back, his tone more confident now than at the school."
    "Among the spilled coffee and shards, a flash of white. Samuel leaned closer, careful not to disturb the liquid."
    "A slip of paper, no bigger than a coin. Torn, not cut. Ragged edges. Not printer stock. Thicker, pulpier, like the page of a book."
    play music m_ritual fadein 3.0
    "He lifted it with tweezers and held it to the light."
    window hide
    pause 1.0
    window auto
    "{size=+12}{b}WEAKNESS{/b}{/size}"
    "The single word stood stark against the blank scrap. Deliberate. Placed here, like a signature."
    $ note("WEAKNESS — torn, thick pulpy stock.")
    note_voice "WEAKNESS — torn, thick pulpy stock."

    show mercer neutral at right with dissolve
    "He sealed it into a clean evidence bag and handed it to Mercer, who had stepped in with the cold trailing after him."
    s "Log this separately. Exact location — countertop, just right of the mug."
    s "Bag the fragments too. Every piece. And the liquid — get a sample of what's left in the cup. We'll send it for tox."
    s "Don't mop anything, don't dump anything. Even the stains go to lab."
    s "Swab the counter near his face. Both the liquid and that vomit trace. Gloves on, double bags. We'll need tox screens."
    "Mercer worked briskly, gloved hands moving. Samuel looked at the victim again. Bluish lips, stiff posture, hands curled tight."
    th "Not a weak heart. Something sharper."
    s "Also — get a list of everyone who came in here yesterday. Deliveries, customers. If there's CCTV, we'll want that too. Even if it's grainy."
    "Mercer glanced up at the word in the bag."
    m "You think this means something?"
    s "A man doesn't die facedown in his own shop with a scrap like this by chance. We keep it tight. Register everything. No shortcuts."
    "The silence of the shop seemed to weigh heavier now."

    # --- Mercer on Hensley ---------------------------------------------------
    s "What do you know about Hensley?"
    m "Not much. He wasn't wealthy. Always bitter, telling anyone who'd listen that the town was dying, that life was unfair. Spent more time complaining than working."
    s "Go on."
    m "He also skimmed. Shelves marked one price, he'd ring it higher. If a customer caught it, he laughed it off as a mistake. If not, he pocketed the difference."
    "Samuel glanced at the evidence bag."
    s "Complainer. And a cheat."
    show mercer shaken at right
    m shaken "That's about right."
    th "Two deaths. Two judgments."
    extend " Someone is keeping score."
    $ note("Two deaths, two judgments. Someone is keeping score.")
    note_voice "Two deaths, two judgments. Someone is keeping score."
    s "What about his family? Wife, kids?"
    m "No. He was a loner. Lived above the shop, kept to himself."
    "Samuel nodded slowly, jotting it down. Alone, bitter, dishonest. Another life judged and ended."
    play sound sfx_thud
    "He closed the notebook with a snap."
    hide mercer with dissolve
    stop music fadeout 3.0
    pause 1.0

    jump ch04
