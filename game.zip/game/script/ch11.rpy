## Chapter Eleven — Samuel POV. The Petrous kitchen; 2 a.m. and the right light;
## the column; the second column; dawn and nothing provable; Thursday.

label ch11:
    call chapter_card(11, "Greyvale — the Petrous house")

    scene bg greyvale_street with fade_slow
    show snow light
    play music m_aftermath fadein 3.0
    play ambient sfx_wind fadein 2.0
    call place("Greyvale — the next afternoon")

    "He went to see her the next afternoon, and told himself it was to keep a promise to a dead man."
    "The county had put Alice, for now, in the care of a foster family on the good side of the square."
    "The Petrous: an older couple with grown children and a spare room, and a reputation for taking in the hard cases the system had nowhere else to file."
    "It was temporary. Everyone said so. In a week, two at the most, when the paperwork caught up with the tragedy, she would be driven down the mountain to the city and processed into the machinery of the state."
    "A girl with no parents anyone could name and no living kin, and a grandfather barely cold in the ground for four murders. God alone knew what became of a child with a file like that."
    "Samuel had spent the morning on the phone slowing it down. Calling in an old marker with a county caseworker, buying the girl a few more days in a warm house before the city took her."
    th "This is what George died to buy her. I'm only finishing the old man's work."
    $ note("Petrous house — temporary. City Thursday.")
    note_voice "Petrous house — temporary. City Thursday."

    # --- Markou at the door ----------------------------------------------------
    show helena neutral at center with dissolve
    "Helena Markou met him at the Petrous' door with her coat already on and her face unreadable."
    h neutral "She's calmer. Eating. Sleeping, more than I'd have thought."
    h neutral "Children are more durable than we let ourselves believe. And less."
    "She studied him a moment, the way she studied everyone, and he had the old sense of being read by a better reader."
    h concerned "You look worse than she does, Detective. Whatever it is you're doing up here instead of going home, it's costing you more than it's costing her."
    s tired "I'm keeping an eye on her placement."
    h neutral "Mm."
    "She did not believe him, plainly, but she had long since stopped expecting the truth from policemen."
    h neutral "She asked after you, in fact. Twice."
    "Something moved behind the glasses."
    h concerned "She said you were kind to her, in the car. That you understood."
    "And there it was: the small cold thing, turning over in him at the word {i}understood{/i}, so quiet under the ordinary afternoon that he almost let it pass."
    "He had felt it on the mountain, kneeling by George in the red snow. He had felt it in the interrogation room, watching an old man take a rope over a sentence."
    "He had felt it, he realized now, further back than either. In a warm office, weeks ago, the first time a twelve-year-old had turned her calm gray eyes on him."
    "Something in the trained animal underneath his reason had stood up in the dark, and not known why."
    "He put it down, the way he always put it down."
    hide helena with dissolve
    "He went inside."

    # --- The composed kitchen --------------------------------------------------
    scene bg petrous_kitchen with fade
    stop ambient fadeout 2.0
    "The kitchen was composed like something painted to hang over the words {i}safe{/i} and {i}warm{/i}."
    "Samuel stood in the doorway one held second and took the whole of it in the way he took in a scene, because everything, now, was a scene."
    "The low gold light of a shaded lamp, and the last gray day at the window behind it. A kettle just off the boil, breathing its thread of steam."
    "A jar of winter branches on the sill, bare and careful. The scrubbed table, the cloth, a plate of cut apple going faintly brown at the edges, a child's schoolbook open to a map of an old war."
    show alice neutral at center with dissolve
    "And at the center of it, in the chair the light fell on best, the girl. Small, neat, her hair brushed, her hands quiet."
    "Arranged in the frame as exactly and as artlessly as the branches in the jar."
    "So that a man coming in out of the cold would feel the safety of the room close over him before he had taken a single step — and would not think to ask who had composed it."
    "Or why every warm room this child had ever sat in arranged itself, somehow, around her."
    "It was the most reassuring picture Samuel had stood in for a week. That was the thing he could not get past: how good it was. How completely it worked."
    show alice smile
    "She looked up when he came in, and her face did the thing a child's face does when a trusted adult appears. It opened, it warmed, it reached."
    "It was flawless. And Samuel felt the animal in the dark stand up again, and could not, for the life of him, say why."
    a smile "Detective Harris. You came back."
    s soft "Told you I would."
    "He eased down into the chair across from her, careful of the tape on his ribs."
    petrous "Coffee, Detective. And something for you, sweetheart."
    "Mrs. Petrous set a coffee in front of him and a plate in front of the girl, and withdrew to the far end of the house with the tact of a woman who had done this before."
    "Then it was the two of them in the warm kitchen, the detective and the child."
    "Samuel did the thing he had come to do, which was watch her. And told himself the thing he had come to tell himself, which was that he was watching over her."
    s soft "How are they treating you here?"
    a neutral "They're kind."
    "She turned a page she wasn't reading."
    a neutral "Mrs. Petrous cries when she thinks I can't see. I think she does it for me, a little. So I don't have to."

    menu:
        "Watch her face as she says it.":
            $ notice()
            "Nothing in her face moved with the words. No catch, no glance toward the far end of the house. An observation, set down neat as a cup on a saucer."
            th "A bright child being too honest about a grown-up's grief. That's all it is."
        "Let it pass.":
            "She said it without complaint, the way you'd remark on weather."
            "Samuel felt the small snag come and go, and told himself it was only a bright child being too honest about a grown-up's grief."

    s soft "And you? How are you doing, Alice. Truly."
    show alice sad
    "She was quiet a moment. When she looked up her eyes were wet."
    "It was real. He could see that it was real, and that was the thing he could not get past even then. That the wet was real."
    a sad "Everyone keeps asking me that. And I don't know how to say it so it's the right amount."
    a sad "Emily's gone. And George. And I don't — there's no one left who's mine."
    a sad "Everyone in this house is being so careful with me, like I'll break. And I keep thinking, I'm not going to break."
    a cry "And I don't know if that's because I'm strong, or because there's something wrong with me that I don't."
    "She looked at him, direct, and the question underneath the question reached him exactly where a man who had buried a child and not wept was softest."
    a cry "Is there something wrong with me, that I'm not breaking?"

    menu:
        "\"Some people hold it.\"":
            s soft "No. There's nothing wrong with you. Some people hold it. That's all."
            s soft "Holding it isn't the same as not feeling it."
        "\"I don't know.\"":
            s tired "I don't know, Alice. I'm not the one to—"
            "He stopped. The honest answer sat in his mouth and would not stay there. Something older answered over the top of it, from thirteen years down, from a graveside in the rain."
            s soft "No. There's nothing wrong with you. Some people hold it. That's all."
            s soft "Holding it isn't the same as not feeling it."

    "He heard himself say it, and meant it, and it was the truest kindest thing he had said to anyone in a week."
    "And he watched it land in her, and did not see — could not let himself see — that he had just told the child exactly what she wanted to be told."
    "That she had asked the question in the precise shape that would draw the answer out of the one wound in him she had found, weeks ago, across a notebook, and had been quietly turning ever since."
    show alice neutral
    a neutral "They're going to send me away."
    "She said it after a while, looking back down at the book."
    a sad "To the city. Mrs. Petrous heard the man on the phone. I'll go somewhere with a lot of other children and no one will know me."
    "A pause, small and perfectly weighted."
    a sad "You're the only one who ever really talked to me like a person, Detective. Not like a case."
    s soft "Nobody's sending you anywhere you won't be looked after."
    "He did not hear how much he had just promised, or to whom."
    show alice smile
    "He stayed twenty minutes. She showed him the book: history, the Peloponnesian War, far ahead of her grade."
    s "Why'd Athens lose, then?"
    a smile "Because they thought they were too clever to lose. They sent everything to Sicily. And then the plague. And then they had nothing left to send."
    "A quick precise brightness that would have delighted any teacher alive."
    "Somewhere in the ordinary warmth of it the animal in the dark lay down again and slept, because it had no words, and the rest of him had too many."
    "When he stood to go, she looked up."
    a smile "Come back?"
    s soft "I will."
    "He meant that too."
    hide alice with dissolve
    "He carried the snag out with him into the cold and could not name it."
    "He drove back to the hotel through the white streets telling himself he had done a decent thing, keeping an eye on a frightened orphan."
    "He got exactly as far as the hotel door before the day caught up with him, and he understood that he was not going to sleep."

    # --- 2 a.m.: the right light -----------------------------------------------
    scene bg hotel_room at night with fade_slow
    show vignette
    play music m_office fadein 3.0
    call place("The Greyvale Hotel — 2 a.m.")

    "He didn't sleep that night, and around two he gave up pretending to, and turned on the lamp, and got out the file."
    "He told himself, spreading it across the hotel bed, that he was doing the only decent thing left."
    "Building the case against the real killer, the one still out there, so that George Bennett's name might one day be lifted out of the mud, and the child protected from whatever had made her family disappear."
    "That was the story he worked under. He was a good enough detective to know, even as he worked, that it was not quite the true one. And disciplined enough not to look at the true one yet."
    "He started where a case starts: at the beginning, with the paper, reading it cold, the way he would read a stranger's work."
    "And the paper had changed."
    "Evidence did not change. But the light you read it in did, and a fact seen in the wrong light and a fact seen in the right one were two different facts wearing the same clothes."
    "He had read all of this before. He had read it certain of George Bennett, and every line had arranged itself obligingly around that certainty, the way iron filings arrange around a magnet."
    "Now the magnet was gone, burned to nothing on a mountain road, and the filings lay where they truly fell."
    "He read them again in the plain lamp light and felt the floor of the world begin, quietly, to move."

    "He came to the diary last, because he had been, he understood, avoiding it. Clara Ward's diary."
    "He had read it weeks ago in this same room and closed it certain of one thing: that a broken child had had exactly one point of light in her collapsing world, and that the light had not been enough."
    note_voice "Alice understands me. She listens. She says nobody will ever understand me the way she does."
    "He had read it, weeks ago, as the one warm thing in a cold story. He read it now, in the right light, and it was the coldest thing he had ever held."
    stop music fadeout 3.0
    note_voice "Alice says I need to make a drastic change. That people only notice when you do something they can't ignore."
    note_voice "She said then they'll stop calling me names. Then it won't matter what they think anymore."
    "He sat with that line a long time, the lamp humming, his cracked rib a dull clock ticking in his side."
    th "A drastic change. Do something they can't ignore."
    "To a girl the whole town knew was cutting herself. A girl in the red zone. A girl one bad night from the edge."
    "He had read it, the first time, as a friend fumbling toward comfort. He read it now as a hand at the small of a back, at the top of a long stair."
    $ note("Diary: a hand at the small of a back.")
    "Every entry he had taken for solace he saw now for what it was. Not the one voice keeping Clara alive, but the one voice, patient and trusted and constant, walking her by careful degrees toward the door."
    note_voice "She said hurting myself will never bring good attention. She said if I want things to change, I can't stay like this."
    "The counselor had wanted Clara to stay. The parents, useless as they were, had wanted her to stay."
    "Only the friend had told her, gently, lovingly, in a private diary no adult was ever meant to read, that staying was the thing she must not do."
    "And Samuel had had this. For weeks. He had held the confession of it in his own two hands and read it as its opposite."
    "Because a twelve-year-old had sat across a small table from him and told him, with the quick pleased little smile he had taken for a child being helpful, exactly where to find it."
    scene bg counselor_office at memory with dissolve
    a smile "She keeps it under her mattress. I don't think her parents know, but I do."
    scene bg hotel_room at night with dissolve
    show vignette
    play sound sfx_heartbeat
    th "Alice gave me the diary."
    "Samuel put it down on the blanket very carefully, as though it might go off."
    "He sat in the lamplight and made himself look, at last, at the thing he had been not-looking at all week. All his life."

    # --- The column: interactive deduction -------------------------------------
    play music m_ritual fadein 3.0
    "He did it the way he did everything, when it mattered: with a pen and a clean page and no mercy, laying the facts out in a column and refusing them the comfort of a story."
    "Who was present."
    "He wrote the deaths down the left side of the page. The teacher, the shopkeeper, the student, the pastor, the girl. Beside each, he would write who had been near it."

    $ ch11_alice_marks = 0

label ch11_col_maria:
    note_voice "Maria Mallory. The roof. A T-shirt and leggings at minus ten. No socks."
    menu:
        "Who was near it?"

        "George Bennett.":
            th "George did odd jobs around this town. A handyman's rounds aren't a hand on a back. Nothing puts him on that roof."
            jump ch11_col_maria
        "Steve Collins.":
            th "The boy was in love with her, and terrified. Six seconds on New Year's Eve. Terrified boys don't write blackmail that calm."
            jump ch11_col_maria
        "Alice.":
            $ ch11_alice_marks += 1
            th "A school library terminal. A school full of children used those terminals."
            th "I can't place her on that roof. Not yet. I write her name in pencil and I don't like my hand while I do it."
        "Kurt Leary.":
            th "Kurt Leary shouts in squares. He doesn't whisper on rooftops."
            jump ch11_col_maria
        "No one I can place.":
            th "Honest. No one I can place. A question mark."

label ch11_col_hensley:
    note_voice "Patrick Hensley. His counter. Yew in the coffee. WEAKNESS."
    menu:
        "Who was near it?"

        "George Bennett.":
            th "His rounds touched the store. That's why it looked like him. Touched isn't near. Touched is what someone wanted me to see."
            jump ch11_col_hensley
        "Steve Collins.":
            th "Nothing ties the boy to Hensley. Nothing but my wanting it to be someone."
            jump ch11_col_hensley
        "Alice.":
            $ ch11_alice_marks += 1
            th "A schoolgirl buying sweets at a counter. Every child in Greyvale did that. I can't place her there. Not with anything I could say out loud."
        "Kurt Leary.":
            th "Half the town bought cigarettes off Hensley. Leary among them. That's a customer, not a killer."
            jump ch11_col_hensley
        "No one I can place.":
            th "No one I can place. The yew grows in every second hedge. A question mark."

label ch11_col_clara:
    note_voice "Clara Ward. The locker room. Wrists."
    menu:
        "Who was near it?"

        "George Bennett.":
            th "George never met Clara Ward that I know of. Her diary never once says his name."
            jump ch11_col_clara
        "Steve Collins.":
            th "Steve Collins had his own drowning to do. He isn't in her pages."
            jump ch11_col_clara
        "Alice.":
            $ ch11_alice_marks += 1
            "Clara Ward, walked to her death down the pages of a diary by a friend the whole town had thought a mercy."
            "And it was Alice who had been that friend. Alice who had steered her. Alice who had then, with a small smile in a counselor's office, told the detective exactly where to find the diary."
            "His hand, writing it, began very slightly to go cold."
        "Kurt Leary.":
            th "Leary wouldn't have known the girl's name until it was on a coffin."
            jump ch11_col_clara
        "No one I can place.":
            th "No. Someone was near her. Someone was on every page of that diary."
            jump ch11_col_clara

label ch11_col_karalis:
    note_voice "Father Karalis. In front of his church. The water bottle."
    menu:
        "Who was near it?"

        "George Bennett.":
            th "Nothing puts George near that pulpit or that bottle. Nothing but the shape I'd already drawn around him."
            jump ch11_col_karalis
        "Steve Collins.":
            th "The boy was nowhere near the front. Nothing puts him near that bottle."
            jump ch11_col_karalis
        "Alice.":
            $ ch11_alice_marks += 1
            "Dropped in front of his whole congregation. And among the congregation, calm in the chaos, not flinching, a twelve-year-old girl."
            "Holding Emily's face to her shoulder. Eyes open. Watching."
            "Samuel had noted her composure at the time, and filed it under a strange way for a child to grieve."
        "Kurt Leary.":
            th "Leary shouted after. Shouting after was all Leary ever did."
            jump ch11_col_karalis
        "No one I can place.":
            th "No. A church full of people screamed. One of them didn't flinch."
            jump ch11_col_karalis

label ch11_col_emily:
    note_voice "Emily Carter. The cemetery. The cocoa. Midnight."
    menu:
        "Who was near it?"

        "George Bennett.":
            th "Vale Cross. 11:52. Thirty-one liters. Twenty-five miles of gorge. The clock doesn't lie."
            jump ch11_col_emily
        "Steve Collins.":
            th "Nothing ties the boy to Emily Carter. She wouldn't have crossed a town in a storm for him."
            jump ch11_col_emily
        "Alice.":
            $ ch11_alice_marks += 1
            "Emily Carter had climbed out of a warm house into a midnight storm without her phone, for someone."
            "Samuel had said it himself, standing over her body: no careful frightened child goes into the dark like that except for someone she loves and trusts entirely."
            "And the someone Emily Carter loved and trusted entirely, the best friend she had crossed a town in the snow to meet, was Alice."
        "Kurt Leary.":
            th "Leary was in the square by morning, howling for a rope. He'd never have got that girl out of her bed."
            jump ch11_col_emily
        "No one I can place.":
            th "No. No careful child walks into a storm at midnight for no one."
            jump ch11_col_emily

label ch11_column_done:
    "And around every one of them, the frame."
    "The confession in Markou's warm office: the preparations, the {i}he doesn't like Emily{/i}, the whole shape of George handed to Samuel by the frightened granddaughter. Hours, it turned out, before Emily died."
    "The testimony that put George out on the night. {i}I heard him come home after two.{/i}"
    "Every arrow that had ever pointed at the old man had passed, at some point, through the small calm hands of the child the old man had died to protect."
    if ch11_alice_marks >= 5:
        "Five lines on the page. Two of them in pencil he had not earned. Three of them in ink he could not rub out."
    else:
        "Five lines on the page. Three of them in ink he could not rub out."
    $ note("Column: Clara — A. Karalis — A. Emily — A. Every arrow through her hands.")
    "At the foot of the column, he wrote one word."
    play sound sfx_tinnitus
    note_voice "ALICE"
    "The detective in him wrote it all down and saw the pattern close like a trap."
    "And the other thing in him, the older thing, the wound worn to the shape of a child, rose up in the same instant and began, in a voice he had trusted his whole life, to talk him out of it."
    th "She is twelve years old."
    "That was the first and the last of it, and it was a wall a mile high."
    th "Twelve. A child. Children do not do these things. The world is not built to allow it."
    th "There's no poison in a schoolbag. No calculation behind a grieving face. No murder in a girl who reads Tom Sawyer and keeps another child's drawings pinned to her wall."
    th "Listen to yourself, Harris. Listen to what you're building at two in the morning in a cold room with a cracked rib and no sleep."
    th "You put your own child in the ground and never wept. And now, at the far end of the worst week of your life, you look at an orphan you swore over a dead man's body to protect — and see a monster."
    th "Because a monster is easier to look at than a little girl who has lost everyone."
    th "This is not detection. This is grief. This is the crack in you finally running all the way through."
    th "Doyle would take your badge. Markou would sit you down in the green chair. And they would be right."
    "He almost stopped there. He wanted to stop there."
    "It would have been so easy, and so kind to himself, to close the file and call it a broken man's fever and drive home to Martha in the morning, and let the county take the orphan south, and never know."
    "But Samuel Harris had never once, in thirty years, been able to stop at the easy place. And he did not stop now."
    "He picked the pen back up."

    # --- The second column: George ----------------------------------------------
    "Because there was a second column, and the wound could not touch it, because it was not about the child at all. It was about the old man."
    note_voice "George Bennett."
    "George Bennett had been innocent. That was not instinct now. That was a receipt, and nineteen seconds of tape."
    "George had been twenty-five miles away buying diesel while Emily Carter died. And he had known — must have known, sitting in that cell — that he had only to say where he had been, and the whole edifice would fall."
    "And George Bennett had said nothing. Had taken the rope."
    "Had sat in a warm room while a detective all but begged him, and had chosen, deliberately, with his eyes open, to be beaten to death in a road rather than speak one saving sentence."
    "Samuel had known, on the mountain, that this meant George was protecting someone."
    "He had let himself believe — because the wound needed him to believe it — that the old man was shielding the girl from the past. From the cult. From whatever had made her family vanish. A grandfather's last kindness."
    "He saw now that he had built that reading for exactly the same reason he had built the reading of the diary: because the true one was unbearable."
    th "Set it out plain."
    th "A man is innocent of a murder. A man can prove it with a word. A man chooses to die instead. Why?"
    "Only one why survives the receipt."
    th "Because the word that clears him is a word that damns someone he loves more than his own life."
    "To give himself an alibi, he would have to give the police the real killer. And the real killer was the one person on this earth George Bennett would climb into a grave to keep from being named."
    "There was only one person alive that George Bennett had loved that much."
    "Samuel had it from the old man's own mouth. The last real warning George ever gave him."

    scene bg interrogation at memory with dissolve
    g grim "Be careful what you decide she is."
    scene bg hotel_room at night with dissolve
    show vignette

    "He had heard it, in the interrogation room, as a strange man's warning about a strange girl. He heard it now as the truth, offered and refused in the same breath."
    "By a man who could not save himself without destroying her, and could not destroy her even to save himself."
    "{i}Be careful what you decide she is.{/i} Because he knew what she was, and could not say it."
    "And was asking the only thing he had left to ask: that when Samuel found out, as George clearly feared he might, he would be gentler with the knowing than George had ever managed to be."
    th "He didn't die protecting Alice from a killer."
    th "He died protecting the world from her. And her from the rope."
    "Both at once. Both true. It was the most terrible arithmetic Samuel had ever done, and it balanced, and it left nothing standing."
    $ note("George: innocent. Silent. Protecting HER.")
    note_voice "George: innocent. Silent. Protecting HER."

    "And the last thing fell into place then: the splinter he had carried off the mountain and been unable to draw."
    "That clean and certain conscience he had seen the crowd wear as it killed a man in the road. The look of a court that has weighed a life and found it wanting, and feels only lighter for the ending of it."
    "He had told himself he had seen that certainty somewhere close that week and could not place it. He could place it now."
    "He had seen it in a warm office, and a cold cemetery, and a foster family's kitchen. In a pair of calm gray eyes that did not flinch at a dying priest or a screaming mother or a friend gone into the ground."
    "The town had killed George in a fit of the exact thing that had been killing the town."
    "He had watched the judge's certainty pass into a mob and had not recognized it, because he had first seen it, and refused it, in the face of a child."

    # --- Dawn: nothing provable -------------------------------------------------
    stop music fadeout 3.0
    scene bg hotel_room with fade_long
    play music m_aftermath2 fadein 3.0
    call place("Dawn")

    "Dawn found him still on the edge of the bed, the file spread and cold, the lamp gone yellow and sick in the growing light."
    "Samuel Harris was in possession, at last, of the whole truth. And of the second thing that came with it, which was that the truth was worth exactly nothing."
    "He made himself walk it the way a prosecutor would walk it, because that was the only test that mattered, and he already knew how it came out."
    th "What do I have?"
    "A diary that showed, to any eye but his newly opened one, a lonely girl and a kind young friend. A child who had not cried enough at a funeral. A best friend who had snuck out at night, as teenagers do."
    "A grandfather who had died without an alibi he could have given. And the alibi, when it surfaced, cleared the grandfather and pointed at no one."
    "Least of all a twelve-year-old orphan, currently eating toast in a foster kitchen two streets away."
    th "A pattern. Patterns aren't evidence. Certainty in a pair of gray eyes isn't a thing you put in an evidence bag and hand to a jury."
    "He made himself work the leads, one at a time, the way the county would if he could ever make them look. And one at a time they died in his hands."
    "The poison was yew, and yew grew wild in every second hedge in the valley. Whoever steeped it had worn gloves and long since burned the making of it."
    "There would be nothing in that cold house now but a swept floor and a dead grate."
    "Emily Carter had walked into the storm with her own phone left charging on her nightstand. Which meant there had been another. A quiet one, a line the two girls had talked on that no parent had known."
    "A phone bought for cash and gone silent the night Emily died: no carrier, no record. A handset lying now at the bottom of some gorge, because a careful person does not keep the one thread that ties her to the dead."
    "There were no prints."
    "There were no witnesses, because the only witness to each death had been the one who caused it. And the one who caused it was twelve years old and grieving, and had wept, on cue, in every room that mattered."
    "She had killed five people, and an old man had died for it, and a whole town had done the killing."
    "And there was not one scrap of paper in the world that would make a single living soul believe a word of it."
    $ note("Nothing I can prove.")
    note_voice "Nothing I can prove."

    "His phone lay on the blanket beside the file. Doyle's number was the second one down."

    menu:
        "Call Doyle and tell him.":
            "He picked up the phone. His thumb found the name."
            "And before it could press, he heard the call the way he would have heard it from the other end, because he would have taken it himself, from any other man who came to him at dawn with this."
            th "The detective who put his own infant in the ground and never grieved. Who arrested an innocent man and watched him beaten to death."
            th "Who hasn't slept in a week, with a cracked rib and a thousand-yard stare, saying in a level voice that the real killer is a grieving twelve-year-old girl."
            "Doyle would not hear a case. Doyle would hear a man coming apart at the exact seam everyone had always known was there."
            "They would take his badge, gently, for his own good. And they would take the orphan south to the city on schedule, and be kind to her the whole way."
            "They would set her down in a new place among new people. Unwatched. Unsuspected. Unmarked. With a fresh town to weigh."
            "He put the phone down on the blanket, face down, very carefully."
        "Say nothing.":
            "He did not reach for the phone. He knew precisely what would happen if he said it aloud, to Doyle, to the county, to Markou."
            "They would not hear a case. They would hear a man coming apart at the exact seam everyone had always known was there."
            "They would take his badge, gently, for his own good, and take the orphan south on schedule, and be kind to her the whole way."
            "And they would set her down in a new place among new people. Unwatched. Unsuspected. Unmarked. With a fresh town to weigh."

    "And Samuel understood, sitting in the yellow dawn, that he had become George Bennett."
    th "I'm the man who knows, and can't say."
    "He was holding the same unbearable knowledge the old man had carried down into the road rather than speak. The knowledge of what she was."
    "And he was learning, in real time, the thing that had kept George silent for two years: that to say it was to be disbelieved, or to be believed and destroy her."
    "Both of those roads ran out into a dark a man could not make himself walk."
    "He had judged George in that cell for his silence. He took the judgment back now, whole, in the cold light."
    "They were moving her Thursday. Two days. A caseworker and a county car down Route Nine to the city, and the file closed behind her, and the girl gone into the world."
    th "I won't let a stranger drive her."
    "He told himself it was to watch her, and that was true."
    "He told himself it was because he could not let her vanish into the state unmarked, with no one alive who knew. And that was true."
    "He told himself, too, in the smallest and most dangerous chamber of himself, that there might yet be a child somewhere down inside the thing in that kitchen."
    "The five-year-old George had pulled out of the rain. The girl who read Tom Sawyer."
    "And that if any man alive could reach her, it was the one who had lost a child and might, God help him, still want to save one."
    "He did not look too closely at that last chamber. It was the one he trusted least to keep shut in front of her."

    play sound sfx_phone
    show screen phone_call("County Caseworker")
    "He picked up the phone and called the caseworker, and offered, in the flat easy voice of a man doing a colleague a favor, to drive the Bennett girl down to the city himself."
    s "I'm headed back that way Thursday regardless. And the child knows me. Trusts me. It might go easier on her with a face she knows."
    woman "Oh — Detective, that would be a real help. Honestly. You've been so good with her."
    hide screen phone_call
    "The caseworker was grateful. Of course she was. It was one less long cold drive on a bad road."
    $ note("Thursday. I drive.")
    note_voice "Thursday. I drive."

    "Samuel set the phone down and sat a while longer as the room filled with gray morning."
    "An innocent man newly in the ground, and the guilt of it still on him like a smell no soap could reach. The whole ruinous truth locked up inside him, with nowhere on earth to put it."
    "And two days now between him and a car, and a road, and a girl."
    stop music fadeout 4.0
    scene black with fade_long
    "And the long white miles down the mountain to the city, and somewhere out along them, small and patient in the dark—"
    "A gas station."
    window hide
    pause 2.0
    window auto

    jump ch12
