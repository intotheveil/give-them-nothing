## Story systems ##############################################################
##
## chapter cards, place captions, phone-call tag, Samuel's notebook, insight,
## CG gallery, chapter select. Script writers use only the helpers documented
## in docs/vn_spec.md.

define CHAPTERS = [
    ("ch01", "One", "The Initiation"),
    ("ch02", "Two", "Greyvale"),
    ("ch03", "Three", "Six Seconds"),
    ("ch04", "Four", "The Diary"),
    ("ch05", "Five", "False Voices"),
    ("ch06", "Six", "The Coin With No Face"),
    ("ch07", "Seven", "Laid Out"),
    ("ch08", "Eight", "Give Them Nothing"),
    ("ch09", "Nine", "Route Nine"),
    ("ch10", "Ten", "Nineteen Seconds"),
    ("ch11", "Eleven", "The Hub of the Wheel"),
    ("ch12", "Twelve", "The Long Road Down"),
    ("ch13", "Thirteen", "Every Road"),
]

define GALLERY = [
    ("alice_candle", "The Candle"), ("alice_cliff", "The Broken Rail"),
    ("samuel_moon", "New Year's Eve"), ("funeral", "Clara's Funeral"),
    ("cocoa", "Cocoa Under Stars"), ("george_wrists", "Wrists Together"),
    ("route_nine", "Route Nine"), ("bars", "There You Are"),
    ("forecourt", "The Forecourt"), ("coin", "The Coin With No Face"),
    ("samuel_alone", "Ink and Routine"),
]

default persistent.chapters_seen = set()
default current_chapter = 1
default notebook = []        # list of (chapter_number, text)
default insight = 0          # how often the player noticed what Samuel would not

# Chapter title card -----------------------------------------------------------
screen chapter_card(num, title, subtitle):
    zorder 50
    add "ink"
    vbox:
        xalign 0.5 yalign 0.46
        spacing 18
        text "CHAPTER [num!u]" font "fonts/Cinzel.ttf" size 30 color "#7f93ab" xalign 0.5 kerning 8
        text title font "fonts/Cinzel.ttf" size 72 color "#dfe8f2" xalign 0.5 kerning 3
        add Solid("#9fb8d466", xsize=420, ysize=1) xalign 0.5
        if subtitle:
            text subtitle font "fonts/CormorantGaramond-Italic.ttf" size 36 color "#9fb0c4" xalign 0.5

label chapter_card(n, subtitle=""):
    $ current_chapter = n
    $ persistent.chapters_seen.add(n)
    $ _label, _word, _title = CHAPTERS[n - 1]
    window hide
    stop ambient fadeout 1.0
    stop ambient2 fadeout 1.0
    scene black with fade_slow
    show screen chapter_card(_word, _title, subtitle) with dissolve_slow
    pause 3.2
    hide screen chapter_card with dissolve_slow
    return

# Place / time caption --------------------------------------------------------
screen place_caption(txt):
    zorder 40
    frame:
        xpos 60 ypos 50
        background Frame("gui/notify.png", 16, 5, 40, 5)
        padding (28, 10, 40, 12)
        text txt font "fonts/CormorantGaramond-Italic.ttf" size 32 color "#c9d6e6"
    timer 4.5 action Hide("place_caption", transition=dissolve)

label place(txt):
    show screen place_caption(txt) with dissolve
    return

# Phone call tag --------------------------------------------------------------
screen phone_call(who):
    zorder 40
    frame:
        xalign 0.97 ypos 50
        background Frame("gui/notify.png", 16, 5, 40, 5)
        padding (28, 10, 34, 12)
        hbox:
            spacing 14
            text "ON THE LINE" font "fonts/Cinzel.ttf" size 20 color "#7f93ab" yalign 0.5
            text who font "fonts/CormorantGaramond.ttf" size 32 color "#dfe8f2" yalign 0.5

# Notebook --------------------------------------------------------------------
init python:
    def note(text):
        """Add a line to Samuel's notebook and flash a notification."""
        entry = (store.current_chapter, text)
        if entry not in store.notebook:
            store.notebook.append(entry)
            renpy.notify("Notebook updated")

    def notice():
        """Player noticed something about Alice that Samuel let slide."""
        store.insight += 1

screen notebook():
    tag menu
    use game_menu(_("Notebook"), scroll="viewport"):
        vbox:
            spacing 10
            if not notebook:
                text "The pages are blank. Nothing yet." font "fonts/CormorantGaramond-Italic.ttf" size 34
            $ last = None
            for ch, txt in notebook:
                if ch != last:
                    $ last = ch
                    null height 16
                    text "— Chapter [CHAPTERS[ch-1][1]] —" font "fonts/Cinzel.ttf" size 24 color "#7f93ab"
                text txt font "fonts/CormorantGaramond-Italic.ttf" size 34 color "#d3dce7"

# Gallery ---------------------------------------------------------------------
screen gallery():
    tag menu
    use game_menu(_("Gallery"), scroll="viewport"):
        grid 3 4:
            spacing 24
            for key, title in GALLERY:
                vbox:
                    spacing 6
                    if renpy.seen_image("cg " + key):
                        imagebutton:
                            idle Transform("cg " + key, size=(400, 225))
                            hover Transform("cg " + key, size=(400, 225), matrixcolor=BrightnessMatrix(0.12))
                            action Show("gallery_view", img="cg " + key)
                        text title size 24 color "#9fb0c4"
                    else:
                        add Solid("#0d1420", xsize=400, ysize=225)
                        text "— locked —" size 24 color "#4a5566"
            for i in range(12 - len(GALLERY)):
                null

screen gallery_view(img):
    modal True
    zorder 200
    add img
    button:
        xfill True yfill True
        background None
        action Hide("gallery_view")
    key "game_menu" action Hide("gallery_view")

# Chapter select --------------------------------------------------------------
screen chapter_select():
    tag menu
    use game_menu(_("Chapters"), scroll="viewport"):
        vbox:
            spacing 14
            for i, (lbl, word, title) in enumerate(CHAPTERS, 1):
                if i in persistent.chapters_seen:
                    textbutton "[word!u] — [title]" action Start(lbl)
                else:
                    textbutton "[word!u] — ......" action None
