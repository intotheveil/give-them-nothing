## Story systems ##############################################################
##
## chapter cards, place captions, phone-call tag, Samuel's notebook, insight,
## CG gallery, chapter select. Script writers use only the helpers documented
## in docs/vn_spec.md.

define CHAPTERS = [
    ("ch01", "One", "The Initiation"),
    ("ch02", "Two", "Greyvale"),
    ("ch03", "Three", "Six Seconds"),
    ("ch04", "Four", "The Diary"),
    ("ch05", "Five", "False Voices"),
    ("ch06", "Six", "The Coin With No Face"),
    ("ch07", "Seven", "Laid Out"),
    ("ch08", "Eight", "Give Them Nothing"),
    ("ch09", "Nine", "Route Nine"),
    ("ch10", "Ten", "Nineteen Seconds"),
    ("ch11", "Eleven", "The Hub of the Wheel"),
    ("ch12", "Twelve", "The Long Road Down"),
    ("ch13", "Thirteen", "Every Road"),
]

define GALLERY = [
    ("alice_candle", "The Candle"), ("alice_cliff", "The Broken Rail"),
    ("samuel_moon", "New Year's Eve"), ("funeral", "Clara's Funeral"),
    ("cocoa", "Cocoa Under Stars"), ("george_wrists", "Wrists Together"),
    ("route_nine", "Route Nine"), ("bars", "There You Are"),
    ("forecourt", "The Forecourt"), ("coin", "The Coin With No Face"),
    ("samuel_alone", "Ink and Routine"),
]

default persistent.chapters_seen = set()
default current_chapter = 1
default notebook = []        # list of (chapter_number, text)
default insight = 0          # how often the player noticed what Samuel would not
default tells = set()        # ids (see core/interact_data.rpy) noticed this run
default full_run = False     # True only when the run began at "Begin" (label start)

# Persistent, across runs (docs/design/interactivity.md §4.3, §5):
default persistent.tells_seen = set()      # every tell ever noticed, any run
default persistent.pages_seen = set()      # ending tiers reached: {1, 2, 3}
default persistent.last_full_tier = None   # tier of the last full run
default persistent.second_read = False     # replay mode: margin notes where a tell was missed

# Visible consequences (docs/design/interactivity.md §3): one log of what the player
# chose, read later by callbacks that change a line of texture, never an outcome.
default choices = {}         # menu id -> option key (last pick wins)
default refused = set()      # menu ids where the player tried a refused choice

# Reads (spec §1): read id -> True (hit) / False (miss) / None (the null read).
default reads = {}
default clues = set()        # board cards earned (System 2 reads these when it exists)

# Chapter title card -----------------------------------------------------------
screen chapter_card(num, title, subtitle):
    zorder 50
    add "ink"
    add "snow light" alpha 0.5
    vbox:
        xalign 0.5 yalign 0.46
        spacing 18
        text "CHAPTER [num!u]" font "fonts/Cinzel.ttf" size 30 color "#7f93ab" xalign 0.5 kerning 8
        text title font "fonts/Cinzel.ttf" size 72 color "#dfe8f2" xalign 0.5 kerning 3
        add Solid("#9fb8d466", xsize=420, ysize=1) xalign 0.5
        if subtitle:
            text subtitle font "fonts/CormorantGaramond-Italic.ttf" size 36 color "#9fb0c4" xalign 0.5

label chapter_card(n, subtitle=""):
    $ current_chapter = n
    $ persistent.chapters_seen.add(n)
    $ sync_tells_seen()
    $ _label, _word, _title = CHAPTERS[n - 1]
    window hide
    stop ambient fadeout 1.0
    stop ambient2 fadeout 1.0
    scene black with fade_slow
    show screen chapter_card(_word, _title, subtitle) with dissolve_slow
    pause 3.2
    hide screen chapter_card with dissolve_slow
    return

# Place / time caption --------------------------------------------------------
screen place_caption(txt):
    zorder 40
    frame:
        xpos 60 ypos 50
        background Frame("gui/notify.png", 16, 5, 40, 5)
        padding (28, 10, 40, 12)
        text txt font "fonts/CormorantGaramond-Italic.ttf" size 32 color "#c9d6e6"
    timer 4.5 action Hide("place_caption", transition=dissolve)

label place(txt):
    show screen place_caption(txt) with dissolve
    return

# Phone call tag --------------------------------------------------------------
screen phone_call(who):
    zorder 40
    frame:
        xalign 0.97 ypos 50
        background Frame("gui/notify.png", 16, 5, 40, 5)
        padding (28, 10, 34, 12)
        hbox:
            spacing 14
            text "ON THE LINE" font "fonts/Cinzel.ttf" size 20 color "#7f93ab" yalign 0.5
            text who font "fonts/CormorantGaramond.ttf" size 32 color "#dfe8f2" yalign 0.5

# Notebook --------------------------------------------------------------------
init python:
    def note(text):
        """Add a line to Samuel's notebook and flash a notification."""
        entry = (store.current_chapter, text)
        if entry not in store.notebook:
            store.notebook.append(entry)
            renpy.notify("Notebook updated")

    def notice(tid=None):
        """Player noticed something about Alice that Samuel let slide.
        tid is a TELLS id; it feeds the ending page and Second Read. notice() with
        no id still counts (old scripts) but can't be shown later."""
        if tid is None:
            store.insight += 1
            return
        if tid not in store.tells:
            store.tells.add(tid)
            store.insight += 1
        # persistent.tells_seen is NOT written here: persistent data doesn't roll back, so a
        # pick the player rolls back and changes would stay "seen". It's synced from `tells`
        # at every chapter card and at the ending (sync_tells_seen).

    def sync_tells_seen():
        persistent.tells_seen.update(store.tells)

    def chose(mid, opt, refused_try=False):
        """First line of a menu option: remember it. refused_try marks a refused choice
        (one the character tries and fails to take)."""
        store.choices[mid] = opt
        if refused_try:
            store.refused.add(mid)

    def picked(mid, opt):
        """True if the player picked opt at menu mid. Unset -> False -> the shipped text plays."""
        return store.choices.get(mid) == opt

    def clue(cid):
        """A board card earned (the board itself is System 2, not built yet)."""
        store.clues.add(cid)

    def read_hit(rid):
        """The player picked the right tell. No feedback chrome: the sharper line that
        follows in the script is the feedback. The pick is fixed against rollback."""
        ch, who, key, tid, cid, txt = READS[rid]
        store.reads[rid] = True
        if tid:
            notice(tid)          # Alice reads feed insight
        if cid:
            clue(cid)
        if txt:
            note(txt)
        renpy.fix_rollback()

    def read_miss(rid):
        store.reads[rid] = False
        renpy.fix_rollback()

    def read_null(rid):
        store.reads[rid] = None
        renpy.fix_rollback()

    def ending_tier(n=None):
        """1, 2 or 3 from how many tells the player noticed this run."""
        import math
        n = n or len(TELLS)
        if store.insight >= math.ceil(TIER_TOP * n):
            return 3
        if store.insight <= math.floor(TIER_LOW * n):
            return 1
        return 2

    def chapter_has_unseen_tells(n):
        return any(ch == n and tid not in persistent.tells_seen for tid, (ch, _l, _p, _m) in TELLS.items())

    def second_read_epigraph():
        if all(tid in persistent.tells_seen for tid in TELLS):
            return SECOND_READ_EPIGRAPH["all"]
        return SECOND_READ_EPIGRAPH.get(persistent.last_full_tier, SECOND_READ_EPIGRAPH[1])

# Reads: the prompt screen (spec §1.5). Used as `menu (screen="read_choice", subject="her"):`.
# It sits in the textbox area so it reads as part of the prose: a small Cinzel header, one
# amber rule, three terse options in a row. No timer, no feedback chrome.
screen read_choice(items, subject="him"):
    style_prefix "read"
    window:
        style "window"          # the say window's skin and position, so the prompt sits where the prose does
        vbox:
            xalign 0.5
            yalign 0.4
            spacing 14
            text ("READ THE ROOM" if subject == "room" else ("READ HER" if subject == "her" else "READ HIM")):
                font "fonts/Cinzel.ttf" size 20 color "#7f93ab" kerning 8 xalign 0.5
            add Solid("#c9a46a66", xsize=220, ysize=1) xalign 0.5
            hbox:
                xalign 0.5
                spacing 70
                for i in items:
                    textbutton i.caption action i.action

screen read_choice(items, subject="him"):
    variant "small"
    style_prefix "read"
    window:
        style "window"
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 10
            text ("READ THE ROOM" if subject == "room" else ("READ HER" if subject == "her" else "READ HIM")):
                font "fonts/Cinzel.ttf" size 20 color "#7f93ab" kerning 8 xalign 0.5
            add Solid("#c9a46a66", xsize=220, ysize=1) xalign 0.5
            hbox:
                xalign 0.5
                spacing 40
                for i in items:
                    textbutton i.caption action i.action

style read_button is default
style read_button_text is default:
    font "fonts/CormorantGaramond-Italic.ttf"
    size 34
    color "#d3dce7"
    hover_color "#ffffff"
    hover_underline True

# Second Read: the later Samuel writes in the margin where the player looked away.
# Writers put `call tell_missed("tXX_id")` at the end of every branch that does NOT
# notice the tell. Outside Second Read (or once the tell has been noticed in any run)
# it does nothing.
label tell_missed(tid):
    if persistent.second_read and persistent.finished and tid not in persistent.tells_seen:
        $ renpy.say(mn, TELLS[tid][3])
    return

screen notebook():
    tag menu
    use game_menu(_("Notebook"), scroll="viewport"):
        vbox:
            spacing 10
            if not notebook:
                text "The pages are blank. Nothing yet." font "fonts/CormorantGaramond-Italic.ttf" size 34
            $ last = None
            for ch, txt in notebook:
                if ch != last:
                    $ last = ch
                    null height 16
                    text "— Chapter [CHAPTERS[ch-1][1]] —" font "fonts/Cinzel.ttf" size 24 color "#7f93ab"
                text txt font "fonts/CormorantGaramond-Italic.ttf" size 34 color "#d3dce7"

# Gallery ---------------------------------------------------------------------
screen gallery():
    tag menu
    use game_menu(_("Gallery"), scroll="viewport"):
        grid 3 4:
            spacing 24
            for key, title in GALLERY:
                vbox:
                    spacing 6
                    if renpy.seen_image("cg " + key):
                        imagebutton:
                            idle Transform("cg " + key, size=(400, 225))
                            hover Transform("cg " + key, size=(400, 225), matrixcolor=BrightnessMatrix(0.12))
                            action Show("gallery_view", img="cg " + key)
                        text title size 24 color "#9fb0c4"
                    else:
                        add Solid("#0d1420", xsize=400, ysize=225)
                        text "— locked —" size 24 color "#4a5566"
            for i in range(12 - len(GALLERY)):
                null

screen gallery_view(img):
    modal True
    zorder 200
    add img
    button:
        xfill True yfill True
        background None
        action Hide("gallery_view")
    key "game_menu" action Hide("gallery_view")

# Chapter select --------------------------------------------------------------
screen chapter_select():
    tag menu
    use game_menu(_("Chapters"), scroll="viewport"):
        vbox:
            spacing 14
            if persistent.finished:
                # Second Read unlocks after one full run. Dots mark chapters that still hold
                # tells never noticed; never a number.
                hbox:
                    spacing 24
                    text "SECOND READ" font "fonts/Cinzel.ttf" size 24 color "#7f93ab" yalign 0.5
                    textbutton ("on" if persistent.second_read else "off") action ToggleField(persistent, "second_read")
                text second_read_epigraph() font "fonts/CormorantGaramond-Italic.ttf" size 30 color "#c9a46a"
                null height 12
            for i, (lbl, word, title) in enumerate(CHAPTERS, 1):
                if i in persistent.chapters_seen:
                    hbox:
                        spacing 14
                        textbutton "[word!u] — [title]" action Start(lbl)
                        if persistent.finished and chapter_has_unseen_tells(i):
                            text "●" size 16 color "#c9a46a" yalign 0.5
                else:
                    textbutton "[word!u] — ......" action None
