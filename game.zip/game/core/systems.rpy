## Story systems ##############################################################
##
## chapter cards, place captions, phone-call tag, Samuel's notebook, insight,
## CG gallery, chapter select. Script writers use only the helpers documented
## in docs/vn_spec.md.

define CHAPTERS = [
    ("ch01", "One", "The Initiation"),
    ("ch02", "Two", "Greyvale"),
    ("ch03", "Three", "Six Seconds"),
    ("ch04", "Four", "The Diary"),
    ("ch05", "Five", "False Voices"),
    ("ch06", "Six", "The Coin With No Face"),
    ("ch07", "Seven", "Laid Out"),
    ("ch08", "Eight", "Give Them Nothing"),
    ("ch09", "Nine", "Route Nine"),
    ("ch10", "Ten", "Nineteen Seconds"),
    ("ch11", "Eleven", "The Hub of the Wheel"),
    ("ch12", "Twelve", "The Long Road Down"),
    ("ch13", "Thirteen", "Every Road"),
]

define GALLERY = [
    ("alice_candle", "The Candle"), ("alice_cliff", "The Broken Rail"),
    ("samuel_moon", "New Year's Eve"), ("funeral", "Clara's Funeral"),
    ("cocoa", "Cocoa Under Stars"), ("george_wrists", "Wrists Together"),
    ("route_nine", "Route Nine"), ("bars", "There You Are"),
    ("forecourt", "The Forecourt"), ("coin", "The Coin With No Face"),
    ("samuel_alone", "Ink and Routine"),
]

default persistent.chapters_seen = set()
default current_chapter = 1
default notebook = []        # list of (chapter_number, text)
default insight = 0          # how often the player noticed what Samuel would not
default tells = set()        # ids (see core/interact_data.rpy) noticed this run
default full_run = False     # True only when the run began at "Begin" (label start)

# Persistent, across runs (docs/design/interactivity.md §4.3, §5):
default persistent.tells_seen = set()      # every tell ever noticed, any run
default persistent.pages_seen = set()      # ending tiers reached: {1, 2, 3}
default persistent.last_full_tier = None   # tier of the last full run
default persistent.second_read = False     # replay mode: margin notes where a tell was missed

# Visible consequences (docs/design/interactivity.md §3): one log of what the player
# chose, read later by callbacks that change a line of texture, never an outcome.
default choices = {}         # menu id -> option key (last pick wins)
default refused = set()      # menu ids where the player tried a refused choice

# Reads (spec §1): read id -> True (hit) / False (miss) / None (the null read).
default reads = {}

# The board (spec §2): the player's pencil next to Samuel's ink.
default clues_found = []     # card ids in the order found
default pins = {}            # card id -> (suspect id, chapter pinned)      PENCIL, the player's
default ink = {}             # card id -> (suspect id, struck)              INK, Samuel's, scripted
default board_new = 0        # cards not yet seen on the board (quick-menu badge)
default board_closed = False # after the ch11 column the board is read-only
default board_sel = None     # the card selected on the board screen

# Chapter title card -----------------------------------------------------------
screen chapter_card(num, title, subtitle):
    zorder 50
    add "ink"
    add "snow light" alpha 0.5
    vbox:
        xalign 0.5 yalign 0.46
        spacing 18
        text "CHAPTER [num!u]" font "fonts/Cinzel.ttf" size 30 color "#7f93ab" xalign 0.5 kerning 8
        text title font "fonts/Cinzel.ttf" size 72 color "#dfe8f2" xalign 0.5 kerning 3
        add Solid("#9fb8d466", xsize=420, ysize=1) xalign 0.5
        if subtitle:
            text subtitle font "fonts/CormorantGaramond-Italic.ttf" size 36 color "#9fb0c4" xalign 0.5

label chapter_card(n, subtitle=""):
    $ current_chapter = n
    $ persistent.chapters_seen.add(n)
    $ sync_tells_seen()
    $ _label, _word, _title = CHAPTERS[n - 1]
    window hide
    stop ambient fadeout 1.0
    stop ambient2 fadeout 1.0
    scene black with fade_slow
    play sound sting_chapter
    show screen chapter_card(_word, _title, subtitle) with dissolve_slow
    pause 3.2
    hide screen chapter_card with dissolve_slow
    return

# Place / time caption --------------------------------------------------------
screen place_caption(txt):
    zorder 40
    frame:
        xpos 60 ypos 50
        background Frame("gui/notify.png", 16, 5, 40, 5)
        padding (28, 10, 40, 12)
        text txt font "fonts/CormorantGaramond-Italic.ttf" size 32 color "#c9d6e6"
    timer 4.5 action Hide("place_caption", transition=dissolve)

label place(txt):
    show screen place_caption(txt) with dissolve
    return

# Phone call tag --------------------------------------------------------------
screen phone_call(who):
    zorder 40
    frame:
        xalign 0.97 ypos 50
        background Frame("gui/notify.png", 16, 5, 40, 5)
        padding (28, 10, 34, 12)
        hbox:
            spacing 14
            text "ON THE LINE" font "fonts/Cinzel.ttf" size 20 color "#7f93ab" yalign 0.5
            text who font "fonts/CormorantGaramond.ttf" size 32 color "#dfe8f2" yalign 0.5

# Notebook --------------------------------------------------------------------
init python:
    def note(text):
        """Add a line to Samuel's notebook and flash a notification.
        If the text is a board card's note (CLUES), the card is found too."""
        entry = (store.current_chapter, text)
        if entry not in store.notebook:
            store.notebook.append(entry)
            renpy.notify("Notebook updated")
            renpy.sound.play(audio.sting_note)
        cid = NOTE_CARD.get(text)
        if cid:
            clue(cid)

    def notice(tid=None):
        """Player noticed something about Alice that Samuel let slide.
        tid is a TELLS id; it feeds the ending page and Second Read. notice() with
        no id still counts (old scripts) but can't be shown later."""
        if tid is None:
            store.insight += 1
            return
        if tid not in store.tells:
            store.tells.add(tid)
            store.insight += 1
            if tid in TELL_CARD:
                clue(TELL_CARD[tid])
        # persistent.tells_seen is NOT written here: persistent data doesn't roll back, so a
        # pick the player rolls back and changes would stay "seen". It's synced from `tells`
        # at every chapter card and at the ending (sync_tells_seen).

    def sync_tells_seen():
        persistent.tells_seen.update(store.tells)

    def chose(mid, opt, refused_try=False):
        """First line of a menu option: remember it. refused_try marks a refused choice
        (one the character tries and fails to take)."""
        store.choices[mid] = opt
        if refused_try:
            store.refused.add(mid)

    def picked(mid, opt):
        """True if the player picked opt at menu mid. Unset -> False -> the shipped text plays."""
        return store.choices.get(mid) == opt

    NOTE_CARD = {row[3]: cid for cid, row in CLUES.items() if row[3]}

    def clue(cid):
        """A card lands in the tray. If Samuel has an opinion about it, he inks it at once."""
        if cid in store.clues_found:
            return
        store.clues_found.append(cid)
        store.board_new += 1
        sid = CLUES[cid][4]
        if sid and not store.board_closed:
            ink_pin(cid, sid)

    def ink_pin(cid, sid):
        store.ink[cid] = (sid, False)

    def strike(cid):
        if cid in store.ink:
            store.ink[cid] = (store.ink[cid][0], True)

    def strike_at_receipt():
        for cid in STRIKE_AT_RECEIPT:
            strike(cid)

    def pin(cid, sid):
        """The player's pencil. Never validated, never corrected."""
        if store.board_closed or cid not in store.clues_found:
            return
        store.pins[cid] = (sid, store.current_chapter)

    def unpin(cid):
        if not store.board_closed:
            store.pins.pop(cid, None)

    def board_close():
        """After the ch11 column: Samuel re-inks the Clara, Karalis and Emily cards to Alice and the
        case goes in a box. The board stays readable, read-only."""
        for cid in REINK_TO_ALICE:
            if cid in store.clues_found:
                store.ink[cid] = ("alice", False)
        store.board_closed = True
        store.board_sel = None

    def suspects_open():
        return [s for s in SUSPECTS if s[3] <= store.current_chapter]

    def board_cards(sid, kind):
        """kind 'ink' / 'pencil': the card ids shown under a suspect column, in found order."""
        src = store.ink if kind == "ink" else store.pins
        return [cid for cid in store.clues_found if cid in src and src[cid][0] == sid]

    def tray_cards(chapter=None):
        return [cid for cid in store.clues_found if cid not in store.pins and cid not in store.ink
                and (chapter is None or CLUES[cid][0] == chapter)]

    def pencil_under_alice_early():
        return any(sid == "alice" and ch <= 6 for sid, ch in store.pins.values())

    def read_hit(rid):
        """The player picked the right tell. No feedback chrome: the sharper line that
        follows in the script is the feedback. The pick is fixed against rollback."""
        ch, who, key, tid, cid, txt = READS[rid]
        store.reads[rid] = True
        if tid:
            notice(tid)          # Alice reads feed insight
        if cid:
            clue(cid)
        if txt:
            note(txt)
        renpy.fix_rollback()

    def read_miss(rid):
        store.reads[rid] = False
        renpy.fix_rollback()

    def read_null(rid):
        store.reads[rid] = None
        renpy.fix_rollback()

    def ending_tier(n=None):
        """1, 2 or 3 from how many tells the player noticed this run."""
        import math
        n = n or len(TELLS)
        if store.insight >= math.ceil(TIER_TOP * n):
            return 3
        if store.insight <= math.floor(TIER_LOW * n):
            return 1
        return 2

    def chapter_has_unseen_tells(n):
        return any(ch == n and tid not in persistent.tells_seen for tid, (ch, _l, _p, _m) in TELLS.items())

    def second_read_epigraph():
        if all(tid in persistent.tells_seen for tid in TELLS):
            return SECOND_READ_EPIGRAPH["all"]
        return SECOND_READ_EPIGRAPH.get(persistent.last_full_tier, SECOND_READ_EPIGRAPH[1])

# Reads: the prompt screen (spec §1.5). Used as `menu (screen="read_choice", subject="her"):`.
# It sits in the textbox area so it reads as part of the prose: a small Cinzel header, one
# amber rule, three terse options in a row. No timer, no feedback chrome.
screen read_choice(items, subject="him"):
    style_prefix "read"
    window:
        style "window"          # the say window's skin and position, so the prompt sits where the prose does
        vbox:
            xalign 0.5
            yalign 0.4
            spacing 14
            text ("READ THE ROOM" if subject == "room" else ("READ HER" if subject == "her" else "READ HIM")):
                font "fonts/Cinzel.ttf" size 20 color "#7f93ab" kerning 8 xalign 0.5
            add Solid("#c9a46a66", xsize=220, ysize=1) xalign 0.5
            hbox:
                xalign 0.5
                spacing 70
                for i in items:
                    textbutton i.caption action i.action

screen read_choice(items, subject="him"):
    variant "small"
    style_prefix "read"
    window:
        style "window"
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 10
            text ("READ THE ROOM" if subject == "room" else ("READ HER" if subject == "her" else "READ HIM")):
                font "fonts/Cinzel.ttf" size 20 color "#7f93ab" kerning 8 xalign 0.5
            add Solid("#c9a46a66", xsize=220, ysize=1) xalign 0.5
            hbox:
                xalign 0.5
                spacing 40
                for i in items:
                    textbutton i.caption action i.action

style read_button is default
style read_button_text is default:
    font "fonts/CormorantGaramond-Italic.ttf"
    size 34
    color "#d3dce7"
    hover_color "#ffffff"
    hover_underline True

# Second Read: the later Samuel writes in the margin where the player looked away.
# Writers put `call tell_missed("tXX_id")` at the end of every branch that does NOT
# notice the tell. Outside Second Read (or once the tell has been noticed in any run)
# it does nothing.
label tell_missed(tid):
    if persistent.second_read and persistent.finished and tid not in persistent.tells_seen:
        $ renpy.say(mn, TELLS[tid][3])
    return

screen notebook():
    tag menu
    use game_menu(_("Notebook"), scroll="viewport"):
        vbox:
            spacing 10
            if not notebook:
                text "The pages are blank. Nothing yet." font "fonts/CormorantGaramond-Italic.ttf" size 34
            $ last = None
            for ch, txt in notebook:
                if ch != last:
                    $ last = ch
                    null height 16
                    text "— Chapter [CHAPTERS[ch-1][1]] —" font "fonts/Cinzel.ttf" size 24 color "#7f93ab"
                text txt font "fonts/CormorantGaramond-Italic.ttf" size 34 color "#d3dce7"

# Gallery ---------------------------------------------------------------------
screen gallery():
    tag menu
    use game_menu(_("Gallery"), scroll="viewport"):
        grid 3 4:
            spacing 24
            for key, title in GALLERY:
                vbox:
                    spacing 6
                    if renpy.seen_image("cg " + key):
                        imagebutton:
                            idle Transform("cg " + key, size=(400, 225))
                            hover Transform("cg " + key, size=(400, 225), matrixcolor=BrightnessMatrix(0.12))
                            action Show("gallery_view", img="cg " + key)
                        text title size 24 color "#9fb0c4"
                    else:
                        add Solid("#0d1420", xsize=400, ysize=225)
                        text "— locked —" size 24 color "#4a5566"
            for i in range(12 - len(GALLERY)):
                null

screen gallery_view(img):
    modal True
    zorder 200
    add img
    button:
        xfill True yfill True
        background None
        action Hide("gallery_view")
    key "game_menu" action Hide("gallery_view")

# The board ---------------------------------------------------------------------
# Columns are suspects; cards under them are Samuel's ink (Crimson) and the player's pencil
# (Cormorant Italic). Two clicks per pin: a card, then a column. A selected pencil card
# clicked again comes off. Read-only once the board is down (ch11) and in the reveal.

define BOARD_INK = "#e6edf5"
define BOARD_PENCIL = "#9fb0c4"
define BOARD_STRUCK = "#6b7787"
define BOARD_AMBER = "#c9a46a"

screen board_card(cid, kind, readonly=False, dim=False):
    # kind: "ink" | "pencil" | "tray"
    $ _label = CLUES[cid][1]
    $ _tip = CLUES[cid][2]
    $ _struck = kind == "ink" and ink[cid][1]
    $ _selected = (board_sel == cid)
    if readonly or (kind == "ink" and board_closed):
        $ _action = NullAction()
    elif kind == "pencil" and _selected:
        $ _action = [Function(unpin, cid), SetVariable("board_sel", None)]
    else:
        $ _action = SetVariable("board_sel", None if _selected else cid)
    button:
        xsize 260
        ysize 56
        padding (10, 6, 10, 6)
        background (Solid(BOARD_AMBER + "33") if _selected else Solid("#ffffff0a"))
        hover_background Solid("#ffffff18")
        tooltip _tip
        action _action
        if kind == "ink":
            text ("{s}" + _label + "{/s}" if _struck else _label):
                font "fonts/CrimsonText-Regular.ttf" size 24 color (BOARD_STRUCK if _struck else BOARD_INK) yalign 0.5
        else:
            text ("{alpha=0.6}" + _label + "{/alpha}" if dim else _label):
                font "fonts/CormorantGaramond-Italic.ttf" size 24 color BOARD_PENCIL yalign 0.5

screen board_column(s, readonly=False, early_only=False):
    $ sid, name, role, opens, side = s
    vbox:
        xsize 280
        spacing 6
        # the header is the pin target
        button:
            xsize 280
            padding (10, 8, 10, 8)
            background (Solid(BOARD_AMBER + "22") if (board_sel and not readonly) else None)
            hover_background Solid("#ffffff10")
            action ([Function(pin, board_sel, sid), SetVariable("board_sel", None)] if (board_sel and not readonly and not board_closed) else NullAction())
            hbox:
                spacing 10
                if side:
                    add Transform(side, size=(80, 80)) yalign 0.5
                vbox:
                    yalign 0.5
                    text name font "fonts/Cinzel.ttf" size 20 color "#dfe8f2"
                    if sid == "alice" and board_closed:
                        text "ALICE" font "fonts/CrimsonText-Regular.ttf" size 20 color BOARD_INK
                    elif role:
                        text role font "fonts/CormorantGaramond-Italic.ttf" size 20 color "#7f93ab"
        add Solid("#9fb8d433", xsize=280, ysize=1)
        viewport:
            ysize 540
            scrollbars "vertical"
            mousewheel True
            vbox:
                spacing 4
                for cid in board_cards(sid, "ink"):
                    use board_card(cid, "ink", readonly)
                for cid in board_cards(sid, "pencil"):
                    use board_card(cid, "pencil", readonly, dim=(early_only and pins[cid][1] > 6))

screen board():
    tag menu
    on "show" action SetVariable("board_new", 0)
    on "hide" action SetVariable("board_sel", None)
    add "gui/overlay/game_menu.png"
    add Solid("#0d1420e6")
    key "game_menu" action Return()
    key "dismiss" action SetVariable("board_sel", None)
    frame:
        background None
        xfill True yfill True
        padding (40, 24, 40, 16)
        vbox:
            spacing 10
            fixed:
                xfill True
                ysize 44
                text ("The board is down." if board_closed else "THE BOARD") font "fonts/Cinzel.ttf" size 30 color "#dfe8f2" kerning 4 yalign 0.5
                if not board_closed:
                    text ("Click a column to pin it there." if board_sel else "Pencil is yours. Ink is his.") font "fonts/CormorantGaramond-Italic.ttf" size 26 color "#7f93ab" xalign 1.0 yalign 0.5
            hbox:
                spacing 24
                for s in suspects_open():
                    use board_column(s)
            add Solid("#9fb8d433", xfill=True, ysize=1)
            fixed:
                xfill True
                ysize 40
                text ("THE TRAY" if tray_cards() else "The tray is empty.") font "fonts/Cinzel.ttf" size 20 color "#7f93ab" kerning 6 yalign 0.5
                textbutton _("Return") action Return() xalign 1.0 yalign 0.5
            viewport:
                xfill True
                ysize 150
                scrollbars "horizontal"
                mousewheel "horizontal"
                hbox:
                    spacing 24
                    $ _last = None
                    for cid in tray_cards():
                        if CLUES[cid][0] != _last:
                            $ _last = CLUES[cid][0]
                            text ("— " + CHAPTERS[_last - 1][1] + " —") font "fonts/Cinzel.ttf" size 18 color "#4a5566" yalign 0.5
                        use board_card(cid, "tray")
            $ _tip = GetTooltip()
            if _tip:
                text _tip font "fonts/CormorantGaramond-Italic.ttf" size 26 color "#c9d6e6"
            else:
                null height 34

screen board():
    variant "small"
    tag menu
    on "show" action SetVariable("board_new", 0)
    on "hide" action SetVariable("board_sel", None)
    add "gui/overlay/game_menu.png"
    add Solid("#0d1420e6")
    key "game_menu" action Return()
    viewport:
        xfill True yfill True
        scrollbars "vertical"
        mousewheel True
        vbox:
            spacing 14
            xoffset 20
            fixed:
                xfill True
                ysize 44
                text ("The board is down." if board_closed else "THE BOARD") font "fonts/Cinzel.ttf" size 30 color "#dfe8f2" kerning 4 yalign 0.5
                textbutton _("Return") action Return() xalign 1.0 yalign 0.5
            text ("Click a column to pin it there." if board_sel else "Pencil is yours. Ink is his.") font "fonts/CormorantGaramond-Italic.ttf" size 26 color "#7f93ab"
            grid 3 2:
                spacing 20
                for s in suspects_open():
                    use board_column(s)
                for i in range(6 - len(suspects_open())):
                    null
            text "THE TRAY" font "fonts/Cinzel.ttf" size 20 color "#7f93ab" kerning 6
            hbox:
                box_wrap True
                spacing 16
                for cid in tray_cards():
                    use board_card(cid, "tray")
            $ _tip = GetTooltip()
            if _tip:
                text _tip font "fonts/CormorantGaramond-Italic.ttf" size 26 color "#c9d6e6"

# Prompted pin: "Pin it." right after a key clue. Always refusable.
screen pin_choice(cid):
    style_prefix "read"
    window:
        style "window"
        vbox:
            xalign 0.5
            yalign 0.4
            spacing 12
            text ("PIN IT — " + CLUES[cid][1].upper()) font "fonts/Cinzel.ttf" size 20 color "#7f93ab" kerning 6 xalign 0.5
            add Solid(BOARD_AMBER + "66", xsize=220, ysize=1) xalign 0.5
            hbox:
                xalign 0.5
                spacing 40
                for sid, name, role, opens, side in suspects_open():
                    textbutton name action Return(sid)
                textbutton "Leave it in the tray." action Return(None)

label pin_prompt(cid):
    if cid in clues_found and not board_closed:
        call screen pin_choice(cid)
        if _return:
            $ pin(cid, _return)
    return

# The reveal (ch11, 2 a.m.): the board, read-only. Pencil pinned before the cemetery (ch <= 6)
# is drawn at full strength; later pins at 60%. No numbers, no verdict.
screen board_reveal():
    modal True
    zorder 200
    add "gui/overlay/game_menu.png"
    add Solid("#0d1420f0")
    frame:
        background None
        xfill True yfill True
        padding (40, 24, 40, 16)
        vbox:
            spacing 12
            text "2 A.M. THE BOARD." font "fonts/Cinzel.ttf" size 30 color "#dfe8f2" kerning 4
            hbox:
                spacing 24
                for s in suspects_open():
                    use board_column(s, readonly=True, early_only=True)
            add Solid("#9fb8d433", xfill=True, ysize=1)
            textbutton _("Continue") action Return() xalign 0.5

# Chapter select --------------------------------------------------------------
screen chapter_select():
    tag menu
    use game_menu(_("Chapters"), scroll="viewport"):
        vbox:
            spacing 14
            if persistent.finished:
                # Second Read unlocks after one full run. Dots mark chapters that still hold
                # tells never noticed; never a number.
                hbox:
                    spacing 24
                    text "SECOND READ" font "fonts/Cinzel.ttf" size 24 color "#7f93ab" yalign 0.5
                    textbutton ("on" if persistent.second_read else "off") action ToggleField(persistent, "second_read")
                text second_read_epigraph() font "fonts/CormorantGaramond-Italic.ttf" size 30 color "#c9a46a"
                null height 12
            for i, (lbl, word, title) in enumerate(CHAPTERS, 1):
                if i in persistent.chapters_seen:
                    hbox:
                        spacing 14
                        textbutton "[word!u] — [title]" action Start(lbl)
                        if persistent.finished and chapter_has_unseen_tells(i):
                            text "●" size 16 color "#c9a46a" yalign 0.5
                else:
                    textbutton "[word!u] — ......" action None
