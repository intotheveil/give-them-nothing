## Characters ##################################################################
##
## Speakers with an image= tag drive their sprite: `s stern "..."` swaps the
## shown samuel sprite to "samuel stern". See docs/vn_spec.md for the full list.

# Every speaker inherits the animated click-to-continue marker.
define -1 adv = Character(kind=adv, ctc="ctc_mark", ctc_position="nestled")

# Narration and inner voice.
define narrator = Character(None, what_color="#d3dce7")
define th = Character(None, what_italic=True, what_color="#a9bbd0")          # Samuel's thoughts
define ath = Character(None, what_italic=True, what_color="#c4bdd6")         # Alice's inner voice
define gth = Character(None, what_italic=True, what_color="#b8ac98")         # George's inner voice
define eth = Character(None, what_italic=True, what_color="#e0b9a0")         # Emily's inner voice
define note_voice = Character(None, what_font="fonts/CormorantGaramond-Italic.ttf",
                              what_color="#c9d6e6", what_size=40)               # notebook scrawl

# Principal cast.
define s   = Character("Samuel", image="samuel", who_color="#9fb8d4")
define a   = Character("Alice", image="alice", who_color="#c9c3d9")
define ay  = Character("Alice", image="alicey", who_color="#c9c3d9")
define g   = Character("George", image="george", who_color="#b5a68c")
define e   = Character("Emily", image="emily", who_color="#e2ae90")
define h   = Character("Dr. Markou", image="helena", who_color="#93bba8")
define m   = Character("Mercer", image="mercer", who_color="#8fa2ba")
define l   = Character("Lara", image="lara", who_color="#a3b7cc")
define d   = Character("Doyle", image="doyle", who_color="#b9a88e")
define ma  = Character("Martha", image="martha", who_color="#d8ba90")

# Supporting cast with sprites.
define an  = Character("Andreas", image="andreas", who_color="#8e9aab")
define stv = Character("Steve", image="steve", who_color="#8e9aab")
define mg  = Character("Magda", image="magda", who_color="#c99aa8")
define ng  = Character("Nick Green", image="nick", who_color="#8fae8f")
define kl  = Character("Leary", image="leary", who_color="#b98a7e")
define ev  = Character("Evelyn", image="evelyn", who_color="#8e9aab")
define fk  = Character("Father Karalis", image="karalis", who_color="#a99fc0")
define fa  = Character("Father", image="father", who_color="#8e9aab")

# Voices without sprites.
define mo     = Character("Mother", who_color="#8e9aab")
define jc     = Character("James Crown", who_color="#8e9aab")
define cl     = Character("Claire", who_color="#8e9aab")
define rw     = Character("Richard Ward", who_color="#8e9aab")
define tim    = Character("Tim", who_color="#8e9aab")
define tonia  = Character("Tonia", who_color="#8e9aab")
define chloe  = Character("Chloe", who_color="#8e9aab")
define clerk  = Character("Clerk", who_color="#8e9aab")
define tech   = Character("Technician", who_color="#8e9aab")
define poole  = Character("Sgt. Poole", who_color="#8e9aab")
define carter = Character("Mr. Carter", who_color="#8e9aab")
define mrsc   = Character("Mrs. Carter", who_color="#8e9aab")
define petrous = Character("Mrs. Petrous", who_color="#8e9aab")
define att    = Character("Attendant", who_color="#8e9aab")
define kaft   = Character("Kaftanis", who_color="#8e9aab")
define bully  = Character("Older girl", who_color="#8e9aab")
define officer = Character("Officer", who_color="#8e9aab")
define woman  = Character("A woman", who_color="#8e9aab")
define vo     = Character("A voice", who_color="#8e9aab")
define crowd  = Character("The crowd", who_color="#b98a7e")
define disp   = Character("Dispatch", who_color="#7fa0a8", what_font="fonts/CormorantGaramond.ttf")

# Second Read margin note: the later Samuel, writing in the margin of his own file.
# Amber is the one warm accent the palette allows. Used only by `label tell_missed`.
define mn = Character(None, what_font="fonts/CormorantGaramond-Italic.ttf", what_color="#c9a46a",
                      what_size=30, what_xpos=120)
