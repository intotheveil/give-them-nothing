## Mature mode (18+) and cinematic clips ######################################
##
## Mature content = graphic depictions of the ADULT deaths only (Maria Mallory,
## Patrick Hensley, Father Karalis, George Bennett, Samuel's wound). Scenes involving
## the children (Clara, Emily, Alice) are never shown graphically, in any mode.
##
## Assets (registered automatically by core/art_defs.rpy when the files exist):
##   game/art/mature/mx <key>.webp     -> image "mx <key>"     (still, 18+ only)
##   game/movies/mature/<key>.webm     -> image "mxclip <key>" (clip, 18+ only)
##   game/movies/cine/<key>.webm       -> image "cine <key>"   (clip, every mode)
## Script slots:  call mature_show("hensley_body") ... call mature_hide   /   call cinematic("greyvale_snow")
## Missing assets are skipped silently, so slots can exist before the art does.

default persistent.mature = None      # None = not asked yet, False = standard, True = 18+

init python:
    def mature_on():
        return persistent.mature is True

    def mature_asset(key):
        """Return the image name for a mature slot, or None if unavailable/disabled."""
        if not mature_on():
            return None
        for name in ("mxclip " + key, "mx " + key):
            if renpy.has_image(name, exact=True):
                return name
        return None

label mature_show(key, hold=2.0):
    # Shown as an overlay ABOVE the current scene; `call mature_hide` reveals it again.
    $ _mx = mature_asset(key)
    if _mx:
        show expression _mx as mature_overlay zorder 60 with dissolve_slow
        window hide
        $ renpy.pause(hold)
        window auto
    return

label mature_hide:
    if renpy.showing("mature_overlay"):
        hide mature_overlay with dissolve
    return

label cinematic(key, hold=4.0):
    # A short cut-in clip over the current scene; it removes itself afterwards.
    if renpy.has_image("cine " + key, exact=True):
        show expression ("cine " + key) as cine_overlay zorder 55 with dissolve_slow
        window hide
        $ renpy.pause(hold)
        hide cine_overlay with dissolve_slow
        window auto
    return

# First-launch content gate ---------------------------------------------------
screen content_gate():
    modal True
    zorder 300
    add "ink"
    add "snow light" alpha 0.4
    vbox:
        xalign 0.5 yalign 0.45
        xmaximum 1200
        spacing 26
        text "CONTENT WARNING" font "fonts/Cinzel.ttf" size 44 color "#dfe8f2" xalign 0.5 kerning 6
        text "{i}Give Them Nothing{/i} deals with suicide, self-harm, the deaths of children and mob violence.":
            size 34 color "#c9d6e6" xalign 0.5 text_align 0.5
        text "Mature mode (18+) adds graphic imagery of the adult characters' deaths. Scenes involving children are never shown graphically.":
            size 30 color "#93a2b6" xalign 0.5 text_align 0.5
        null height 10
        hbox:
            xalign 0.5 spacing 60
            textbutton _("Standard") action [SetField(persistent, "mature", False), Return()]
            textbutton _("Mature — I am 18 or older") action [SetField(persistent, "mature", True), Return()]
        text "You can change this any time in Preferences." size 26 color "#6e7f95" xalign 0.5

label splashscreen:
    if persistent.mature is None:
        call screen content_gate
    return
