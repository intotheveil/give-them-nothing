## Interactivity data (tables only) ############################################
##
## Spec: docs/design/interactivity.md. Helpers live in core/systems.rpy.
##
## TELLS: every insight opportunity (a moment the player may look at Alice when
## Samuel would not). id -> (chapter, short label, page line, margin note).
##   short label : used on the Tier II ending page ("Did I see it? ...")
##   page line   : used on the Tier III ending page (first person, Samuel)
##   margin note : Second Read, shown where the player missed the tell
## Lines marked "shipped" are the v0.1 ending text; the rest are DRAFT lines in
## Samuel's voice, for the author (A. Damon) to approve or rewrite.

define TELLS = {
    "t02_bikeracks": (2, "The bike racks.",
        "I saw it the first morning. A girl by the bike racks who looked past me like I was weather, and was gone. I wrote down the teacher.",   # shipped
        "A girl by the bike racks looked past me like I was weather. I kept my eyes on the officer."),
    "t04_scream": (4, "The head tilt.",
        "I saw the head tilt. She watched a mother scream the way you'd watch a bird on a wire. I wrote down shock.",   # shipped
        "She tilted her head at the scream, the way you'd study a sound. I was counting voices."),
    "t04_hug": (4, "The arm on Emily.",
        "I saw her lay an arm on Emily like a thing she'd watched done. I wrote down a friend.",
        "She laid that arm on Emily slowly, like a thing learned. I was looking at the one who cried."),
    "t04_funeral": (4, "Her eyes at the funeral.",
        "I saw her hold Emily's face at the funeral, eyes open, calm, watching the room. I wrote down grief. Kids go strange.",   # shipped
        "Over Emily's shoulder her eyes were open, calm, on the man on the ground. I went to the priest."),
    "t05_scene": (5, "How she worked the scene.",
        "I saw her take in a crime scene the way I take one in. I wrote down numb.",
        "Her eyes worked the scene the way mine do. Stretcher, hands, the bagged bottle. I sent her off."),
    "t05_steps": (5, "Her steps on the stair.",
        "I saw her go up that stair light and quick, no fear in it. I wrote down drilled.",
        "Light, unhurried steps up the stair. Not a frightened child's. I was watching the old man."),
    "t05_hands": (5, "Her hands on his name.",
        "I saw her hands fold tighter on his name and nowhere else. I wrote down fear.",
        "Her hands folded tighter exactly on 'George'. Not before. Not after. I took the words as given."),
    "t06_dash": (6, "The dash light.",
        "I saw a face with no fear in it, after that week. I wrote down emptied.",
        "In the dash light her face had no fear in it at all. I kept my eyes on the road."),
    "t06_card": (6, "My card in her hand.",
        "I saw her look at my card the way you'd look at a key. I wrote down that I gave it to her.",
        "She looked at my card a long moment. It wasn't gratitude. I didn't let it be anything."),
    "t07_fire": (7, "'After two.'",
        "I saw her give me 'after two' without reaching for it. I wrote down certainty.",
        "'After two.' No search for the number. It was ready. I was being kind."),
    "t08_stair": (8, "The old man's eyes.",
        "I saw the old man look toward where she slept when he said 'what she is'. I wrote down grief.",
        "When he said 'what she is', the old man looked toward where she was sleeping. I heard guilt."),
    "t10_hub": (10, "The hub.",
        "I saw the shape at the center of the wheel, small and sitting very straight. I looked away in the same second.",
        "The hub had a shape. Small, very straight, in my passenger seat. I let it go."),
    "t11_face": (11, "Mrs. Petrous' tears.",
        "I saw nothing move in her face when she said a kind woman cried for her. I wrote down honest.",
        "Nothing moved in her face as she said it. Neat as a cup on a saucer. I let it pass."),
    "t11_amount": (11, "'The right amount.'",
        "I saw her measure grief like a dose. I answered her like a father.",
        "'The right amount,' she said, of grief. I heard a child who didn't know how much to feel."),
    "t12_stain": (12, "The stain on Route Nine.",
        "I saw her look at the stain on Route Nine like a view. I wrote down nothing.",   # shipped
        "She looked at the stain on Route Nine like a view. I watched the road and felt her head turn."),
    "t12_flicker": (12, "The swallowed word.",
        "I saw her hear the word I swallowed, and file it. I said 'I don't know.'",
        "Something filed itself behind her eyes when I lied. I didn't look hard enough to see it whole."),
    "t12_coin": (12, "'It's in the bag.'",
        "I saw she tells me where things are. The diary. The coin. I wrote down grief.",
        "'It's in the bag.' She told me where the diary was, too. I heard only grief."),
    "t13_bag": (13, "The bag.",
        "I saw her take the bag to the toilet. Everything she owned. I let her go.",
        "She took the bag with her. I told myself a child takes everything she owns."),
}

## READS: Samuel reading people (spec §1). id -> (chapter, subject, correct option key,
## tell id or None, clue id or None, notebook line on a hit). The option labels and hit
## lines live in the scripts (menu (screen="read_choice") blocks). Clue ids are reserved
## for the board (System 2) and are recorded in `clues` until it exists.
define READS = {
    "r02_andreas":   (2,  "him",  "jaw",     None,         "c02_shaved",  "Andreas — shaved for the breakfast. Planned a morning."),
    "r02_tim":       (2,  "him",  "fists",   None,         None,          "Tim, 14 — angry. Holding it for his sister."),
    "r03_magda":     (3,  "her",  "eyes",    None,         None,          "Magda — measures before she mourns."),
    "r03_steve":     (3,  "him",  "door",    None,         "c03_door",    "Steve — watches the door when asked who knew."),
    "r04_emily":     (4,  "her",  "unsaid",  None,         None,          "Emily Carter, 14 — kind. Holding a request."),
    "r04_hug":       (4,  "her",  "arm",     "t04_hug",    "c04_arm",     "Alice — steady. Held Emily up."),
    "r04_markou":    (4,  "her",  "arms",    None,         None,          "Markou — 'Including myself.' Meant it."),
    "r04_evelyn":    (4,  "her",  "eyes",    None,         None,          "E. Ward — the room stays shut. Hers to keep."),
    "r05_crowd":     (5,  "room", "crowd",   None,         "c05_silence", "Greyvale: agreed in silence."),
    "r05_steps":     (5,  "her",  "steps",   "t05_steps",  "c05_steps",   "Alice — obeys without a sound. Drilled."),
    "r05_doyle":     (5,  "him",  "under",   None,         None,          "Doyle — scared. Loudest yet."),
    "r05_markou":    (5,  "her",  "folders", None,         None,          "Markou: the file was on the desk. 'For now.'"),
    "r06_card":      (6,  "her",  "face",    "t06_card",   "c06_card",    "Gave her my card. She looked at it a long time."),
    "r07_leary":     (7,  "him",  "voice",   None,         None,          "Leary — voice shook. Fear wearing a fist."),
    "r07_george":    (7,  "him",  None,      None,         None,          ""),   # the null read: a face he cannot read
    "r08_silence":   (8,  "him",  "silence", None,         "c08_silence", "Silence — not a guilty man's."),
    "r10_attendant": (10, "him",  "sure",    None,         None,          "Attendant, 19 — sure. Nobody told him what to remember."),
    "r11_markou":    (11, "her",  "eyes",    None,         None,          "Markou — worried. Not for me."),
    "r11_amount":    (11, "her",  "amount",  "t11_amount", None,          "'The right amount.'"),
    "r12_markou":    (12, "her",  "hand",    None,         None,          "Markou held on too long."),
    "r12_coin":      (12, "her",  "bag",     "t12_coin",   None,          "'It's in the bag.' She tells me where things are."),
    "r13_bag":       (13, "her",  "bag",     "t13_bag",    None,          "She took the bag."),
}

## THE BOARD (spec §2). Pencil = the player, ink = Samuel.
## SUSPECTS: id, name, role line, chapter it opens, side image. Mirrors the ch11 column menu plus Andreas.
define SUSPECTS = [
    ("andreas", "Andreas Mallory",   "the husband",       2, "side andreas grief"),
    ("steve",   "Steve Collins",     "the student, 16",   3, "side steve panic"),
    ("george",  "George Bennett",    "the grandfather",   4, "side george neutral"),
    ("alice",   "Alice Bennett",     "witness, 12",       4, "side alice neutral"),
    ("leary",   "Kurt Leary",        "the loud one",      5, "side leary angry"),
    ("nobody",  "No one I can place", "",                 2, None),
]

## CLUES: id -> (chapter, card label <= 28 chars, tooltip <= 140 chars, note text that creates it (None =
## created by a tell or a read instead), Samuel's ink: suspect id or None).
## Base cards come from the shipped note() lines (note() looks its text up here). Conditional cards come
## from TELL_CARD (a noticed tell) or READS (a read hit).
define CLUES = {
    # ch02
    "c02_dress":     (2, "No socks at minus ten",        "Improper dress. No belongings. Sneakers, no socks.", "Improper dress. No belongings. Sneakers, no socks.", None),
    "c02_fall":      (2, "Blood consistent with fall",   "Chest down. Cranial deformation. Blood consistent with a fall.", "Chest down. Cranial deformation. Blood consistent with fall.", None),
    "c02_dishes":    (2, "Dishes not washed",            "Dishes not washed, contrary to the husband. Meal prepared. A farewell?", "Dishes not washed — contrary to husband. Meal prepared. Possible farewell.", None),
    "c02_tutoring":  (2, "Tutored older kids",           "Tutored older kids after school. Math, history.", "Tutored older kids after school. Math, history. Get the list.", None),
    "c02_phone":     (2, "Phone left behind",            "She never went anywhere without it. PIN 9877.", "Phone left behind — she never went anywhere without it. PIN 9877.", None),
    "c02_racks":     (2, "The girl by the bike racks",   "A girl by the bike racks looked past me like I wasn't there, and was gone.", None, None),
    "c02_shaved":    (2, "Andreas shaved for it",        "Freshly shaved for a holiday breakfast. A man who had planned a morning.", None, None),
    # ch03
    "c03_sixsec":    (3, "Six seconds, NYE",             "Steve Collins. A six-second call on New Year's Eve.", "Steve Collins — 6 sec call — NYE.", None),
    "c03_affair":    (3, "Three months",                 "An affair. Began three months ago. Evening meetings, the school and her home.", "Affair. Began three months ago. Evening meetings. School + her home.", None),
    "c03_pushed":    (3, "Maria was pushed",             "Blackmail. 'Do as you've been told.' A school library terminal. Maria was pushed.", "Maria was pushed.", None),
    "c03_hensley":   (3, "Hensley at his counter",       "Face down at the counter. Coffee spilled. Cyanosis, lips and fingertips. Rigor tight.", "Face down, counter. Coffee spilled. Mug broken. Rigor tight. Cyanosis lips/fingertips. Vomit trace.", None),
    "c03_weakness":  (3, "WEAKNESS",                     "A torn scrap, thick pulpy stock.", "WEAKNESS — torn, thick pulpy stock.", None),
    "c03_score":     (3, "Someone is keeping score",     "Two deaths, two judgments. Someone is keeping score.", "Two deaths, two judgments. Someone is keeping score.", None),
    "c03_door":      (3, "Steve watched the door",       "Asked who else knew, the boy listened for the kitchen.", None, None),
    # ch04
    "c04_yew":       (4, "Yew in the coffee",            "Hensley: yew alkaloids (Taxus baccata). In the coffee.", "Hensley — yew alkaloids (Taxus baccata). In the coffee.", None),
    "c04_clara":     (4, "Clara, the locker room",       "Clara Ward, 15. Seated against the wall. Lacerations wrist to elbow. Razors present.", "Clara Ward, 15 — Body seated, wall support. Bilateral lacerations, wrist to elbow. Razors present. Bag for prints/DNA.", None),
    "c04_flaws":     (4, "'Flaws have to be corrected'", "Alice Bennett, 12, lives with her grandfather George. 'Flaws have to be corrected.'", "Alice Bennett, 12 — lives with grandfather George. 'Flaws have to be corrected.'", None),
    "c04_tilt":      (4, "Head tilt at the scream",      "She turned toward the mother's scream and tilted her head, like studying a sound.", None, None),
    "c04_diarytip":  (4, "Diary under the mattress",     "Clara kept a diary. Under her mattress. Per Alice.", "Diary under the mattress (per Alice).", None),
    "c04_arm":       (4, "An arm on Emily",              "She laid her arm on Emily slowly. Deliberately.", None, None),
    "c04_drastic":   (4, "'A drastic change'",           "Diary: 'Alice says I need to make a drastic change.'", "Diary: 'Alice says I need to make a drastic change.'", None),
    "c04_karalis":   (4, "The priest's water bottle",    "Fr. Karalis drank from his bottle mid-sermon and fell. Yew again?", "Funeral — Fr. Karalis collapsed after drinking from his bottle. Yew again?", None),
    "c04_eyes":      (4, "Eyes open at the funeral",     "Over Emily's shoulder her eyes were open, calm, on the man on the ground.", None, None),
    # ch05
    "c05_dominant":  (5, "George: dominant",             "George: dominant. The child forbidden to speak of her parents.", "George: dominant. Child forbidden to speak of parents.", "george"),
    "c05_margin":    (5, "Bible margin: a false voice",  "Bible margin: 'Your voice was false. Silence is purer.'", "Bible margin: 'Your voice was false. Silence is purer.'", "george"),
    "c05_taxonomy":  (5, "LIAR — WEAKNESS — SILENCE",    "LIAR, WEAKNESS, SILENCE. A taxonomy?", "LIAR — WEAKNESS — SILENCE. A taxonomy?", None),
    "c05_yewhedge":  (5, "Yew in every hedge",           "Yew grows in every hedge in Greyvale. Resin stays on the hands for hours.", "Yew: every hedge in Greyvale. Resin on hands for hours.", None),
    "c05_driftwood": (5, "Driftwood Bay. Two sisters",   "Bennett: cash purchase. Driftwood Bay. Two sisters missing, the file buried.", "Bennett: cash purchase. Driftwood Bay. Two sisters missing, file buried.", "george"),
    "c05_markou":    (5, "Markou: no file",              "Markou: no file. 'For now.'", "Markou: no file. 'For now.'", None),
    "c05_silence":   (5, "Greyvale agreed in silence",   "Leary was only the mouth. The rest agreed without a sound.", None, None),
    "c05_steps":     (5, "Her steps on the stair",       "Light, unhurried steps up the stair. Not a frightened child's.", None, None),
    "c05_hands":     (5, "Her hands on his name",        "Her hands folded tighter exactly on 'George'. Not before. Not after.", None, None),
    "c05_purity":    (5, "'Devoted to purity'",          "Alice: a family 'devoted to purity.' Her role: to tell pure from impure.", "Alice: family 'devoted to purity.' Role: distinguish pure from impure.", "george"),
    "c05_training":  (5, "'Part of my training'",        "Taken from her parents by George. 'Part of my training.'", "Taken from parents by George. 'Part of my training.'", "george"),
    "c05_finish":    (5, "'He will finish his work'",    "'He will finish his work here.' Preparations tonight.", "'He will finish his work here.' Preparations tonight.", "george"),
    # ch06
    "c06_carry":     (6, "'Safer if I don't carry it'",  "'Safer if I don't carry it.' He leaves at night.", "'Safer if I don't carry it.' He leaves at night.", "george"),
    "c06_resents":   (6, "Resents the friendship",       "George resents the friendship. Per Alice.", "George resents the friendship (per Alice).", "george"),
    "c06_notruck":   (6, "No truck at the house",        "No truck at the house that night. Gave her my card.", "No truck at the house. Gave her my card.", "george"),
    "c06_dash":      (6, "No fear, in the dash light",   "In the dash light her face had no fear in it at all.", None, None),
    "c06_card":      (6, "My card in her hand",          "She looked at my card a long moment. It wasn't gratitude.", None, None),
    # ch07
    "c07_emily":     (7, "Emily, arranged",              "Emily Carter, 14. Cyanosis. Arranged. 'Sacrifice is the highest purity.'", "Emily Carter, 14. Cyanosis. Arranged. Note: 'Sacrifice is the highest purity.'", "george"),
    "c07_button":    (7, "Button and drawing",           "A button and a drawing on the Ward grave. Unexplained.", "Button + drawing, Ward grave — unexplained.", None),
    "c07_nocup":     (7, "No cup. No phone.",            "No cup. No phone. Tracks gone under the snow.", "No cup. No phone. Tracks gone under snow.", "george"),
    "c07_trusted":   (7, "Someone she trusted",          "Someone she trusted asked her to come.", "Someone she trusted asked her to come.", "george"),
    "c07_aftertwo":  (7, "Home after two",               "George out all night. Home after two, per Alice.", "George out all night. Home after two (per Alice).", "george"),
    "c07_fire":      (7, "'After two', no search",       "She gave me 'after two' without reaching for it.", None, None),
    # ch08
    "c08_flinch":    (8, "Driftwood: the flinch",        "Driftwood. He flinched at the sisters.", "Driftwood — flinch at the sisters.", "george"),
    "c08_careful":   (8, "'Be careful what you decide'", "'Be careful what you decide she is.'", "'Be careful what you decide she is.'", None),
    "c08_noalibi":   (8, "No alibi. 'Nothing.'",         "Bennett: no alibi offered. 'Nothing.'", "Bennett: no alibi offered. 'Nothing.'", "george"),
    "c08_stair":     (8, "He looked toward the stair",   "When he said 'what she is', the old man looked toward where she was sleeping.", None, None),
    "c08_silence":   (8, "Not a guilty man's silence",   "Not a card held close. A door held shut from the inside.", None, None),
    # ch09
    "c09_noword":    (9, "Guilty men talk",              "He never said a word. Guilty men talk.", "He never said a word. Guilty men talk.", None),
    "c09_protecting":(9, "A man protecting somebody",    "A man protecting somebody.", "A man protecting somebody.", None),
    # ch10
    "c10_bag":       (10, "Packed bag for two",          "A packed bag for two. Cash. Papers. A route away from everything.", "Packed bag for two. Cash. Papers. Route away from everything.", None),
    "c10_receipt":   (10, "Vale Cross, 11:52",           "Vale Cross Services. 31 litres. 11:52 p.m., the night of E.C.", "Vale Cross Services — 31 L — 11:52 p.m. — night of E.C.", None),
    "c10_footage":   (10, "Footage: 11:51",              "Footage: G.B. at the pump, 11:51. Twenty-five miles from the cemetery.", "Footage: G.B. at the pump, 11:51. 25 miles from the cemetery.", None),
    "c10_notkill":   (10, "George did not kill Emily",   "George Bennett did not kill Emily Carter.", "George Bennett did not kill Emily Carter.", None),
    "c10_steered":   (10, "I was steered.",              "I was steered.", "I was steered.", None),
}

## A noticed tell that adds a card (read hits carry their card in READS).
define TELL_CARD = {
    "t02_bikeracks": "c02_racks", "t04_scream": "c04_tilt", "t04_funeral": "c04_eyes", "t05_hands": "c05_hands",
    "t06_dash": "c06_dash", "t07_fire": "c07_fire", "t08_stair": "c08_stair",
    "t04_hug": "c04_arm", "t05_steps": "c05_steps", "t06_card": "c06_card",
}
## The ch10 receipt: Samuel strikes his own ink on the Emily cards.
define STRIKE_AT_RECEIPT = ["c06_resents", "c06_notruck", "c07_emily", "c07_nocup", "c07_trusted", "c07_aftertwo"]
## The ch11 column: he re-inks the Clara, Karalis and Emily cards to Alice, and the board goes in a box.
define REINK_TO_ALICE = ["c04_clara", "c04_karalis", "c07_emily", "c07_trusted", "c07_aftertwo"]
## Prompted pins: card id -> caption (DRAFT).
define PIN_PROMPTS = {
    "c03_pushed": "Who wrote it?", "c04_drastic": "Who does this point to?", "c05_taxonomy": "Whose taxonomy?",
    "c07_trusted": "Who did she trust?", "c09_protecting": "Protecting who?",
}
## Reveal lines (ch11, 2 a.m.), DRAFT.
define BOARD_REVEAL_SOME = "Under her name, in pencil, cards he did not remember pinning."
define BOARD_REVEAL_NONE = "Under her name, nothing. Not one mark. He had seen to that."

# Ending tiers, as fractions of len(TELLS) so they scale when more tells are added.
define TIER_LOW = 0.30   # at or below floor(TIER_LOW * N) noticed -> Tier I  ("I went home.")
define TIER_TOP = 0.75   # at or above ceil(TIER_TOP * N) noticed  -> Tier III ("I gave myself nothing.")

# Chapter-select epigraphs for Second Read, keyed to the last full run's tier (DRAFT).
define SECOND_READ_EPIGRAPH = {
    1: "Read it again. Look where he didn't.",
    2: "Read it again. She was there every time.",
    3: "Read it again. You already know what you'll find.",
    "all": "There's nothing left in the margins. He saw it too.",
}
