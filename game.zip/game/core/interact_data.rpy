## Interactivity data (tables only) ############################################
##
## Spec: docs/design/interactivity.md. Helpers live in core/systems.rpy.
##
## TELLS: every insight opportunity (a moment the player may look at Alice when
## Samuel would not). id -> (chapter, short label, page line, margin note).
##   short label : used on the Tier II ending page ("Did I see it? ...")
##   page line   : used on the Tier III ending page (first person, Samuel)
##   margin note : Second Read, shown where the player missed the tell
## Lines marked "shipped" are the v0.1 ending text; the rest are DRAFT lines in
## Samuel's voice, for the author (A. Damon) to approve or rewrite.

define TELLS = {
    "t02_bikeracks": (2, "The bike racks.",
        "I saw it the first morning. A girl by the bike racks who looked past me like I was weather, and was gone. I wrote down the teacher.",   # shipped
        "A girl by the bike racks looked past me like I was weather. I kept my eyes on the officer."),
    "t04_scream": (4, "The head tilt.",
        "I saw the head tilt. She watched a mother scream the way you'd watch a bird on a wire. I wrote down shock.",   # shipped
        "She tilted her head at the scream, the way you'd study a sound. I was counting voices."),
    "t04_hug": (4, "The arm on Emily.",
        "I saw her lay an arm on Emily like a thing she'd watched done. I wrote down a friend.",
        "She laid that arm on Emily slowly, like a thing learned. I was looking at the one who cried."),
    "t04_funeral": (4, "Her eyes at the funeral.",
        "I saw her hold Emily's face at the funeral, eyes open, calm, watching the room. I wrote down grief. Kids go strange.",   # shipped
        "Over Emily's shoulder her eyes were open, calm, on the man on the ground. I went to the priest."),
    "t05_scene": (5, "How she worked the scene.",
        "I saw her take in a crime scene the way I take one in. I wrote down numb.",
        "Her eyes worked the scene the way mine do. Stretcher, hands, the bagged bottle. I sent her off."),
    "t05_steps": (5, "Her steps on the stair.",
        "I saw her go up that stair light and quick, no fear in it. I wrote down drilled.",
        "Light, unhurried steps up the stair. Not a frightened child's. I was watching the old man."),
    "t05_hands": (5, "Her hands on his name.",
        "I saw her hands fold tighter on his name and nowhere else. I wrote down fear.",
        "Her hands folded tighter exactly on 'George'. Not before. Not after. I took the words as given."),
    "t06_dash": (6, "The dash light.",
        "I saw a face with no fear in it, after that week. I wrote down emptied.",
        "In the dash light her face had no fear in it at all. I kept my eyes on the road."),
    "t06_card": (6, "My card in her hand.",
        "I saw her look at my card the way you'd look at a key. I wrote down that I gave it to her.",
        "She looked at my card a long moment. It wasn't gratitude. I didn't let it be anything."),
    "t07_fire": (7, "'After two.'",
        "I saw her give me 'after two' without reaching for it. I wrote down certainty.",
        "'After two.' No search for the number. It was ready. I was being kind."),
    "t08_stair": (8, "The old man's eyes.",
        "I saw the old man look toward where she slept when he said 'what she is'. I wrote down grief.",
        "When he said 'what she is', the old man looked toward where she was sleeping. I heard guilt."),
    "t10_hub": (10, "The hub.",
        "I saw the shape at the center of the wheel, small and sitting very straight. I looked away in the same second.",
        "The hub had a shape. Small, very straight, in my passenger seat. I let it go."),
    "t11_face": (11, "Mrs. Petrous' tears.",
        "I saw nothing move in her face when she said a kind woman cried for her. I wrote down honest.",
        "Nothing moved in her face as she said it. Neat as a cup on a saucer. I let it pass."),
    "t11_amount": (11, "'The right amount.'",
        "I saw her measure grief like a dose. I answered her like a father.",
        "'The right amount,' she said, of grief. I heard a child who didn't know how much to feel."),
    "t12_stain": (12, "The stain on Route Nine.",
        "I saw her look at the stain on Route Nine like a view. I wrote down nothing.",   # shipped
        "She looked at the stain on Route Nine like a view. I watched the road and felt her head turn."),
    "t12_flicker": (12, "The swallowed word.",
        "I saw her hear the word I swallowed, and file it. I said 'I don't know.'",
        "Something filed itself behind her eyes when I lied. I didn't look hard enough to see it whole."),
    "t12_coin": (12, "'It's in the bag.'",
        "I saw she tells me where things are. The diary. The coin. I wrote down grief.",
        "'It's in the bag.' She told me where the diary was, too. I heard only grief."),
    "t13_bag": (13, "The bag.",
        "I saw her take the bag to the toilet. Everything she owned. I let her go.",
        "She took the bag with her. I told myself a child takes everything she owns."),
}

## READS: Samuel reading people (spec §1). id -> (chapter, subject, correct option key,
## tell id or None, clue id or None, notebook line on a hit). The option labels and hit
## lines live in the scripts (menu (screen="read_choice") blocks). Clue ids are reserved
## for the board (System 2) and are recorded in `clues` until it exists.
define READS = {
    "r02_andreas":   (2,  "him",  "jaw",     None,         "c02_shaved",  "Andreas — shaved for the breakfast. Planned a morning."),
    "r02_tim":       (2,  "him",  "fists",   None,         None,          "Tim, 14 — angry. Holding it for his sister."),
    "r03_magda":     (3,  "her",  "eyes",    None,         None,          "Magda — measures before she mourns."),
    "r03_steve":     (3,  "him",  "door",    None,         "c03_door",    "Steve — watches the door when asked who knew."),
    "r04_emily":     (4,  "her",  "unsaid",  None,         None,          "Emily Carter, 14 — kind. Holding a request."),
    "r04_hug":       (4,  "her",  "arm",     "t04_hug",    "c04_arm",     "Alice — steady. Held Emily up."),
    "r04_markou":    (4,  "her",  "arms",    None,         None,          "Markou — 'Including myself.' Meant it."),
    "r04_evelyn":    (4,  "her",  "eyes",    None,         None,          "E. Ward — the room stays shut. Hers to keep."),
    "r05_crowd":     (5,  "room", "crowd",   None,         "c05_silence", "Greyvale: agreed in silence."),
    "r05_steps":     (5,  "her",  "steps",   "t05_steps",  "c05_steps",   "Alice — obeys without a sound. Drilled."),
    "r05_doyle":     (5,  "him",  "under",   None,         None,          "Doyle — scared. Loudest yet."),
    "r05_markou":    (5,  "her",  "folders", None,         None,          "Markou: the file was on the desk. 'For now.'"),
    "r06_card":      (6,  "her",  "face",    "t06_card",   "c06_card",    "Gave her my card. She looked at it a long time."),
    "r07_leary":     (7,  "him",  "voice",   None,         None,          "Leary — voice shook. Fear wearing a fist."),
    "r07_george":    (7,  "him",  None,      None,         None,          ""),   # the null read: a face he cannot read
    "r08_silence":   (8,  "him",  "silence", None,         "c08_silence", "Silence — not a guilty man's."),
    "r10_attendant": (10, "him",  "sure",    None,         None,          "Attendant, 19 — sure. Nobody told him what to remember."),
    "r11_markou":    (11, "her",  "eyes",    None,         None,          "Markou — worried. Not for me."),
    "r11_amount":    (11, "her",  "amount",  "t11_amount", None,          "'The right amount.'"),
    "r12_markou":    (12, "her",  "hand",    None,         None,          "Markou held on too long."),
    "r12_coin":      (12, "her",  "bag",     "t12_coin",   None,          "'It's in the bag.' She tells me where things are."),
    "r13_bag":       (13, "her",  "bag",     "t13_bag",    None,          "She took the bag."),
}

# Ending tiers, as fractions of len(TELLS) so they scale when more tells are added.
define TIER_LOW = 0.30   # at or below floor(TIER_LOW * N) noticed -> Tier I  ("I went home.")
define TIER_TOP = 0.75   # at or above ceil(TIER_TOP * N) noticed  -> Tier III ("I gave myself nothing.")

# Chapter-select epigraphs for Second Read, keyed to the last full run's tier (DRAFT).
define SECOND_READ_EPIGRAPH = {
    1: "Read it again. Look where he didn't.",
    2: "Read it again. She was there every time.",
    3: "Read it again. You already know what you'll find.",
    "all": "There's nothing left in the margins. He saw it too.",
}
