## Audio ######################################################################
##
## Channels: music (built-in), sound (built-in, one-shots),
## ambient (looping bed, e.g. wind), ambient2 (second looping bed).

init python:
    renpy.music.register_channel("ambient", "sfx", loop=True)
    renpy.music.register_channel("ambient2", "sfx", loop=True)

# Music (from the Last Seen soundtrack) ----------------------------------------
define audio.m_title = "audio/music/title.ogg"          # main theme, opening, ending
define audio.m_title2 = "audio/music/title2.ogg"        # theme variant, reflective
define audio.m_outside = "audio/music/outside1.ogg"     # Greyvale exteriors, walking
define audio.m_outside2 = "audio/music/outside2.ogg"    # roads, driving, snow
define audio.m_church = "audio/music/church1.ogg"       # funeral, cemetery, solemn
define audio.m_church2 = "audio/music/church2.ogg"      # grief, aftermath of a death
define audio.m_ritual = "audio/music/ritual1.ogg"       # dread, the killer's hand
define audio.m_ritual2 = "audio/music/ritual2.ogg"      # Driftwood, the doctrine
define audio.m_ritual3 = "audio/music/ritual3.ogg"      # climaxes: mob, gas station
define audio.m_aftermath = "audio/music/aftermath1.ogg" # quiet loss
define audio.m_aftermath2 = "audio/music/aftermath2.ogg"# heavy loss, epilogue
define audio.m_office = "audio/music/office.ogg"        # interiors, investigation, Markou

# Sound -----------------------------------------------------------------------
define audio.sfx_wind = "audio/sfx/wind.ogg"            # loop on ambient
define audio.sfx_storm = "audio/sfx/storm.ogg"          # loop on ambient
define audio.sfx_rain = "audio/sfx/rain.ogg"            # loop on ambient
define audio.sfx_engine = "audio/sfx/engine.ogg"        # loop on ambient2 (car interior)
define audio.sfx_crowd = "audio/sfx/crowd.ogg"          # loop on ambient2 (mob, square)
define audio.sfx_static = "audio/sfx/static.ogg"        # one-shot: radio crackle
define audio.sfx_phone = "audio/sfx/phone_ring.ogg"     # one-shot: phone ring
define audio.sfx_heartbeat = "audio/sfx/heartbeat_one.ogg"  # one-shot (loop it on ambient2 for tension)
define audio.sfx_thud = "audio/sfx/thud.ogg"            # one-shot: impact, door, fall
define audio.sfx_tinnitus = "audio/sfx/tinnitus.ogg"    # one-shot: shock
define audio.sfx_beep = "audio/sfx/beep.ogg"            # one-shot: monitor, phone beep
