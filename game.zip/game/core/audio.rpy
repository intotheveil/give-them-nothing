## Audio ######################################################################
##
## Channels: music (built-in), sound (built-in, one-shots),
## ambient (looping bed, e.g. wind), ambient2 (second looping bed).

init python:
    renpy.music.register_channel("ambient", "sfx", loop=True)
    renpy.music.register_channel("ambient2", "sfx", loop=True)

# Music: the original score (20 cues, docs/soundtrack_list.md), delivered 2026-10-05 -----------
define audio.m_theme = "audio/music/theme.ogg"                 # 1  main theme: title, credits
define audio.m_driftwood = "audio/music/driftwood.ogg"         # 2  the village, the doctrine, George's memories
define audio.m_night_drive = "audio/music/night_drive.ogg"     # 3  ch1, the truck
define audio.m_records = "audio/music/records.ogg"             # 4  precinct, the apartment, his loneliness
define audio.m_greyvale = "audio/music/greyvale.ogg"           # 5  town exteriors
define audio.m_snow_road = "audio/music/snow_road.ogg"         # 6  driving the mountain roads
define audio.m_notebook = "audio/music/notebook.ogg"           # 7  interviews, evidence, deduction
define audio.m_markou = "audio/music/markou.ogg"               # 8  Markou's office
define audio.m_alice = "audio/music/alice.ogg"                 # 9  Alice's scenes
define audio.m_emily = "audio/music/emily.ogg"                 # 10 Emily
define audio.m_emily_reprise = "audio/music/emily_reprise.ogg" # 11 Emily's loss, the Carters
define audio.m_judgment = "audio/music/judgment.ogg"           # 12 the killer's hand, dread
define audio.m_funeral = "audio/music/funeral.ogg"             # 13 Clara's funeral, the cemetery by day
define audio.m_grief = "audio/music/grief.ogg"                 # 14 aftermath of each death, Thomas
define audio.m_square = "audio/music/square.ogg"               # 15 the town turning, the mob forming
define audio.m_route_nine = "audio/music/route_nine.ogg"       # 16 the van, the attack
define audio.m_george = "audio/music/george.ogg"               # 17 George's cell, his death, his innocence
define audio.m_nineteen = "audio/music/nineteen.ogg"           # 18 the receipt, the footage, "I was steered"
define audio.m_forecourt = "audio/music/forecourt.ogg"         # 20 after the attack, the hospital, the epilogue
define audio.m_long_road = "audio/music/long_road.ogg"         # 19 ch12, the car ride with Alice
# Old placeholder names (the Last Seen tracks) kept as aliases so nothing old breaks:
define audio.m_title = audio.m_theme
define audio.m_title2 = audio.m_theme
define audio.m_outside = audio.m_greyvale
define audio.m_outside2 = audio.m_snow_road
define audio.m_church = audio.m_funeral
define audio.m_church2 = audio.m_grief
define audio.m_ritual = audio.m_judgment
define audio.m_ritual2 = audio.m_driftwood
define audio.m_ritual3 = audio.m_square
define audio.m_aftermath = audio.m_grief
define audio.m_aftermath2 = audio.m_forecourt
define audio.m_office = audio.m_notebook

# Stingers (short, one-shot) --------------------------------------------------
define audio.sting_chapter = "audio/sfx/sting_chapter.ogg"   # every chapter card (5 s)
define audio.sting_word = "audio/sfx/sting_word.ogg"         # a torn-paper judgment found (3 s)
define audio.sting_note = "audio/sfx/sting_note.ogg"         # "Notebook updated" (1.5 s)
define audio.sting_reveal = "audio/sfx/sting_reveal.ogg"     # "So it's you." (6 s)

define audio.sfx_wind = "audio/sfx/wind.ogg"            # loop on ambient
define audio.sfx_storm = "audio/sfx/storm.ogg"          # loop on ambient
define audio.sfx_rain = "audio/sfx/rain.ogg"            # loop on ambient
define audio.sfx_engine = "audio/sfx/engine.ogg"        # loop on ambient2 (car interior)
define audio.sfx_crowd = "audio/sfx/crowd.ogg"          # loop on ambient2 (mob, square)
define audio.sfx_static = "audio/sfx/static.ogg"        # one-shot: radio crackle
define audio.sfx_phone = "audio/sfx/phone_ring.ogg"     # one-shot: phone ring
define audio.sfx_heartbeat = "audio/sfx/heartbeat_one.ogg"  # one-shot (loop it on ambient2 for tension)
define audio.sfx_thud = "audio/sfx/thud.ogg"            # one-shot: impact, door, fall
define audio.sfx_tinnitus = "audio/sfx/tinnitus.ogg"    # one-shot: shock
define audio.sfx_beep = "audio/sfx/beep.ogg"            # one-shot: monitor, phone beep
