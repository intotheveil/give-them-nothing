## Languages ###################################################################
##
## The one place a language is registered. Adding one is a pipeline, not a patch:
## docs/i18n.md (tools/i18n.py does the mechanical steps). Translations live in
## game/tl/<language>/; English is the source (Ren'Py language None).

# (Ren'Py language name, label in Preferences). The label is written in its own
# script and never translated, so a player can always find their language.
define LANGUAGES = [
    (None, "English"),
    ("japanese", "日本語"),
]

# Fallback fonts for scripts the Latin fonts (Crimson, Cormorant, Cinzel) lack:
# (regular file, heavy file, [(first, last code point), ...]). The heavy file stands in
# for Cinzel and the bold cuts. Shipped files are SUBSETS made by
# `python tools/i18n.py fonts` from the full fonts in art_src/fonts/ (docs/i18n.md).
define I18N_FALLBACK_FONTS = [
    ("fonts/NotoSerifJP-Regular.otf", "fonts/NotoSerifJP-Medium.otf", [
        (0x2015, 0x2015),   # horizontal bar ― (Japanese dash)
        (0x2E80, 0x2FDF),   # CJK radicals
        (0x3000, 0x30FF),   # CJK punctuation, hiragana, katakana
        (0x31F0, 0x31FF),   # katakana extensions
        (0x3400, 0x4DBF),   # CJK extension A
        (0x4E00, 0x9FFF),   # CJK unified ideographs
        (0xF900, 0xFAFF),   # CJK compatibility ideographs
        (0xFF00, 0xFFEF),   # full-width forms
    ]),
]

# Languages that join sentences without a space (see sentence_sep()). Line breaking
# is per language too: game/tl/<language>/i18n_style.rpy sets gui.language.
define I18N_NO_SPACE = {"japanese"}

# Every Latin font file the game names. Each becomes an alias for a FontGroup that
# sends the fallback ranges to the fallback font, so the hard-coded font paths in the
# screens and Characters keep working in every language with no per-screen edits.
define I18N_LATIN_FONTS = [
    "fonts/CrimsonText-Regular.ttf", "fonts/CrimsonText-Italic.ttf",
    "fonts/CrimsonText-Bold.ttf", "fonts/CrimsonText-BoldItalic.ttf",
    "fonts/CormorantGaramond.ttf", "fonts/CormorantGaramond-Italic.ttf",
    "fonts/Cinzel.ttf",
]

init 1 python:
    def _i18n_font_groups():
        groups = {}
        for latin in I18N_LATIN_FONTS:
            heavy = "Cinzel" in latin or "Bold" in latin
            g = FontGroup()
            for regular, bold, ranges in I18N_FALLBACK_FONTS:
                for first, last in ranges:
                    g.add(bold if heavy else regular, first, last)
            g.add(latin, None, None)
            groups[latin] = g
        return groups

    # FontGroup.add refuses alias names, so build every group before installing the aliases.
    config.font_name_map.update(_i18n_font_groups())

    # First launch picks the player's system language when we have it (ja_JP -> japanese).
    config.enable_language_autodetect = True

    def sentence_sep():
        """The space between two sentences joined in code ("" in Japanese)."""
        return "" if _preferences.language in I18N_NO_SPACE else " "

