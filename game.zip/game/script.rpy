## Give Them Nothing — entry point.
## Chapters live in game/script/chNN.rpy and chain into each other.

define config.side_image_only_not_showing = True

label start:
    jump ch01

define config.main_menu_music = "audio/music/title.ogg"
default persistent.finished = False
