# Line breaking for Japanese (kinsoku rules). Written by tools/i18n.py new; see docs/i18n.md.
translate japanese python:
    gui.language = "japanese-normal"
