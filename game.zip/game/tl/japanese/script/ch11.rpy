# TODO: Translation updated at 2026-10-11 10:23

# game/script/ch11.rpy:13
translate japanese ch11_7676dbd6:

    # "He went to see her the next afternoon, and told himself it was to keep a promise to a dead man."
    "翌日の午後、彼は彼女に会いに行った。死んだ男との約束を守るためだと、自分に言い聞かせて。"

# game/script/ch11.rpy:14
translate japanese ch11_8d0302be:

    # "The county had put Alice, for now, in the care of a foster family on the good side of the square."
    "郡は当面、Aliceを広場の良い側に住む里親家庭に預けていた。"

# game/script/ch11.rpy:15
translate japanese ch11_2f97a6d1:

    # "The Petrous: an older couple with grown children and a spare room, and a reputation for taking in the hard cases the system had nowhere else to file."
    "Petrous家。成人した子供たちと空いた部屋を持つ年配の夫婦で、制度が他にどこにも収めようのない難しい子を引き取ることで知られていた。"

# game/script/ch11.rpy:16
translate japanese ch11_f50f1866:

    # "It was temporary. Everyone said so. In a week, two at the most, when the paperwork caught up with the tragedy, she would be driven down the mountain to the city and processed into the machinery of the state."
    "一時的なことだった。誰もがそう言った。一週間、長くても二週間、書類が悲劇に追いつけば、彼女は山を下って都市へ運ばれ、州という機械の中で処理されていく。"

# game/script/ch11.rpy:17
translate japanese ch11_c177f99a:

    # "A girl with no parents anyone could name and no living kin, and a grandfather barely cold in the ground for four murders. God alone knew what became of a child with a file like that."
    "誰も名前を挙げられない両親と、生きている身内のない少女。そして四件の殺人の罪で、土の中でまだ冷えきってもいない祖父。そんな書類を背負った子供がどうなるのか、神のみぞ知るだった。"

# game/script/ch11.rpy:18
translate japanese ch11_67aecda3:

    # "Samuel had spent the morning on the phone slowing it down. Calling in an old marker with a county caseworker, buying the girl a few more days in a warm house before the city took her."
    "Samuelは午前中を電話に費やし、それを遅らせていた。郡のケースワーカーに昔の貸しを返してもらい、都市に連れて行かれる前に、暖かい家での数日を少女のために買っていた。"

# game/script/ch11.rpy:19
translate japanese ch11_53b6b312:

    # th "This is what George died to buy her. I'm only finishing the old man's work."
    th "これが、Georgeが命を捨ててあの子に買ってやったものだ。俺はあの老人の仕事を仕上げているだけだ。"

# game/script/ch11.rpy:21
translate japanese ch11_e9f94d84:

    # note_voice "Petrous house — temporary. City in a week, two at most."
    note_voice "Petrous家――一時的。一週間で都市へ、長くて二週間。"

# game/script/ch11.rpy:27
translate japanese ch11_b2463532:

    # "Helena Markou met him at the Petrous' door with her coat already on and her face unreadable."
    "Helena MarkouはPetrous家の戸口で彼を迎えた。すでにコートを着て、表情は読めなかった。"

# game/script/ch11.rpy:28
translate japanese ch11_c2a4d4a5:

    # h neutral "She's calmer. Eating. Sleeping, more than I'd have thought."
    h neutral "落ち着いてきています。食べていますし、眠っています。思っていたよりもずっと。"

# game/script/ch11.rpy:29
translate japanese ch11_bb631a1d:

    # h neutral "Children are more durable than we let ourselves believe. And less."
    h neutral "子供というのは、私たちが信じようとするより丈夫なものです。そして、もろくもある。"

# game/script/ch11.rpy:30
translate japanese ch11_3a051f9e:

    # "She studied him a moment, the way she studied everyone, and he had the old sense of being read by a better reader."
    "彼女は少しのあいだ彼を観察した。誰に対してもそうするように。そして彼は、自分より優れた読み手に読まれているという、あの昔ながらの感覚を覚えた。"

# game/script/ch11.rpy:31
translate japanese ch11_2bf03b6e:

    # h concerned "You look worse than she does, Detective. Whatever it is you're doing up here instead of going home, it's costing you more than it's costing her."
    h concerned "あの子より、あなたのほうがひどい顔をしていますよ、刑事さん。家に帰らずにここで何をしているにせよ、それはあの子よりあなたのほうに高くついています。"

# game/script/ch11.rpy:32
translate japanese ch11_11dd8bf4:

    # s hurt "I'm keeping an eye on her placement."
    s hurt "あの子の預け先を見守っているだけです。"

# game/script/ch11.rpy:33
translate japanese ch11_fde42f3e:

    # h neutral "Mm."
    h neutral "ふむ。"

# game/script/ch11.rpy:34
translate japanese ch11_d8703f8c:

    # "She did not believe him, plainly, but she had long since stopped expecting the truth from policemen."
    "信じていないのは明らかだった。だが彼女はとうの昔に、警官に真実を期待するのをやめていた。"

# game/script/ch11.rpy:35
translate japanese ch11_dc7ffbf7:

    # h neutral "She asked after you, in fact. Twice."
    h neutral "実を言うと、あの子があなたのことを尋ねていました。二度も。"

# game/script/ch11.rpy:36
translate japanese ch11_c8b364c0:

    # "Something moved behind the glasses."
    "眼鏡の奥で、何かが動いた。"

# game/script/ch11.rpy:43
translate japanese ch11_d44e00da:

    # "Worry. Not for him. She was asking him something, and had no way to ask it that would not sound mad."
    "憂慮。彼に対するものではない。彼女は彼に何かを尋ねていた。そして、正気を疑われずにそれを尋ねる術を持たなかった。"

# game/script/ch11.rpy:46
translate japanese ch11_3fba5ee7:

    # h concerned "She said you were kind to her, in the car. That you understood."
    h concerned "車の中で、あなたが優しくしてくれたと言っていました。わかってくれた、と。"

# game/script/ch11.rpy:47
translate japanese ch11_d07a57f7:

    # "And there it was: the small cold thing, turning over in him at the word {i}understood{/i}, so quiet under the ordinary afternoon that he almost let it pass."
    "そして、それがあった。{i}わかってくれた{/i}という言葉に、彼の中で寝返りを打つ、小さく冷たいもの。ありふれた午後の下であまりに静かで、彼はもう少しで見過ごすところだった。"

# game/script/ch11.rpy:48
translate japanese ch11_2cb4dd2e:

    # "He had felt it on the mountain, kneeling by George in the red snow. He had felt it in the interrogation room, watching an old man take a rope over a sentence."
    "山の上で、赤い雪の中のGeorgeのそばに膝をついていたときにも、それを感じた。取調室で、老人がひと言より縄を選ぶのを見ていたときにも、それを感じた。"

# game/script/ch11.rpy:49
translate japanese ch11_d396388f:

    # "He had felt it, he realized now, further back than either. In a warm office, weeks ago, the first time a twelve-year-old had turned her calm gray eyes on him."
    "そして今になって気づいた。そのどちらよりも前から、それを感じていたのだと。何週間も前の暖かい部屋で、十二歳の少女が初めて、その落ち着いた灰色の目を彼に向けたときに。"

# game/script/ch11.rpy:50
translate japanese ch11_c1c4b4fa:

    # "Something in the trained animal underneath his reason had stood up in the dark, and not known why."
    "理性の下にいる、訓練された獣の中の何かが、闇の中で立ち上がり、なぜなのかもわからずにいた。"

# game/script/ch11.rpy:51
translate japanese ch11_e64af61e:

    # "He put it down, the way he always put it down."
    "彼はそれを押さえつけた。いつも押さえつけてきたように。"

# game/script/ch11.rpy:53
translate japanese ch11_57dcf116:

    # "He went inside."
    "彼は中に入った。"

# game/script/ch11.rpy:58
translate japanese ch11_8530c322:

    # "The kitchen was composed like something painted to hang over the words {i}safe{/i} and {i}warm{/i}."
    "台所は、{i}安全{/i}と{i}温もり{/i}という言葉の上に掛けるために描かれた絵のように、整えられていた。"

# game/script/ch11.rpy:59
translate japanese ch11_af87b110:

    # "Samuel stood in the doorway one held second and took the whole of it in the way he took in a scene, because everything, now, was a scene."
    "Samuelは戸口で一瞬、息を止めたように立ち、現場を見て取るやり方で、そのすべてを見て取った。今は何もかもが現場だったからだ。"

# game/script/ch11.rpy:60
translate japanese ch11_8a15dd40:

    # "The low gold light of a shaded lamp, and the last gray day at the window behind it. A kettle just off the boil, breathing its thread of steam."
    "笠をかぶったランプの低い金色の光と、その奥の窓に残る最後の灰色の日。沸いたばかりで火から下ろされたやかんが、細い湯気の糸を吐いている。"

# game/script/ch11.rpy:61
translate japanese ch11_98de8107:

    # "A jar of winter branches on the sill, bare and careful. The scrubbed table, the cloth, a plate of cut apple going faintly brown at the edges, a child's schoolbook open to a map of an old war."
    "窓辺の瓶には、冬枝が裸で、慎ましく挿してある。磨かれたテーブル、クロス、切ったリンゴの皿は縁がうっすら茶色くなりかけ、子供の教科書が古い戦争の地図のページで開かれている。"

# game/script/ch11.rpy:63
translate japanese ch11_1a4f4ba7:

    # "And at the center of it, in the chair the light fell on best, the girl. Small, neat, her hair brushed, her hands quiet."
    "そしてその中心、光がいちばんよく当たる椅子に、少女がいた。小さく、こぎれいで、髪をとかし、両手を静かにして。"

# game/script/ch11.rpy:64
translate japanese ch11_86ef5007:

    # "Arranged in the frame as exactly and as artlessly as the branches in the jar."
    "瓶の中の枝と同じくらい正確に、同じくらい作為なく、額縁の中に配置されて。"

# game/script/ch11.rpy:65
translate japanese ch11_6825d6d9:

    # "So that a man coming in out of the cold would feel the safety of the room close over him before he had taken a single step — and would not think to ask who had composed it."
    "寒い外から入ってきた男が、一歩も踏み出さないうちに部屋の安全に包み込まれるのを感じるように――そして、誰がそれを整えたのかと問おうとも思わないように。"

# game/script/ch11.rpy:66
translate japanese ch11_ab1549d8:

    # "Or why every warm room this child had ever sat in arranged itself, somehow, around her."
    "あるいは、この子がこれまで座ったどの暖かい部屋も、なぜか彼女を中心に配置されていたのはなぜかと。"

# game/script/ch11.rpy:67
translate japanese ch11_c08347cb:

    # "It was the most reassuring picture Samuel had stood in for a week. That was the thing he could not get past: how good it was. How completely it worked."
    "この一週間でSamuelが身を置いたなかで、最も安心させる絵だった。そこが、彼にはどうしても引っかかるのだった。それがどれほどよくできているか。どれほど完璧に効いているか。"

# game/script/ch11.rpy:69
translate japanese ch11_be862fd1:

    # "She looked up when he came in, and her face did the thing a child's face does when a trusted adult appears. It opened, it warmed, it reached."
    "彼が入っていくと彼女は顔を上げ、その顔は、信頼する大人が現れたときに子供の顔がすることをした。開き、温まり、手を伸ばした。"

# game/script/ch11.rpy:70
translate japanese ch11_ffef1906:

    # "It was flawless. And Samuel felt the animal in the dark stand up again, and could not, for the life of him, say why."
    "完璧だった。そしてSamuelは、闇の中の獣がまた立ち上がるのを感じ、どうしても、その理由を言うことができなかった。"

# game/script/ch11.rpy:71
translate japanese ch11_be19635c:

    # a smile "Detective Harris. You came back."
    a smile "Harris刑事。戻ってきてくれたんですね。"

# game/script/ch11.rpy:72
translate japanese ch11_1ee1832f:

    # s soft "Told you I would."
    s soft "来ると言っただろう。"

# game/script/ch11.rpy:73
translate japanese ch11_cbb59b38:

    # "He eased down into the chair across from her, careful of the tape on his ribs."
    "肋骨のテープに気をつけながら、彼は向かいの椅子にゆっくりと腰を下ろした。"

# game/script/ch11.rpy:74
translate japanese ch11_ce68d7c4:

    # petrous "Coffee, Detective. And something for you, sweetheart."
    petrous "コーヒーをどうぞ、刑事さん。それから、お嬢ちゃんにはこれをね。"

# game/script/ch11.rpy:75
translate japanese ch11_fc7b82ee:

    # "Mrs. Petrous set a coffee in front of him and a plate in front of the girl, and withdrew to the far end of the house with the tact of a woman who had done this before."
    "Petrous夫人は彼の前にコーヒーを、少女の前に皿を置き、家の奥の端へと下がっていった。こういうことを前にもしたことのある女の心得をもって。"

# game/script/ch11.rpy:76
translate japanese ch11_cdbc0c37:

    # "Then it was the two of them in the warm kitchen, the detective and the child."
    "そうして、暖かい台所には二人きりになった。刑事と子供。"

# game/script/ch11.rpy:77
translate japanese ch11_d2c3e3c8:

    # "Samuel did the thing he had come to do, which was watch her. And told himself the thing he had come to tell himself, which was that he was watching over her."
    "Samuelはするために来たことをした。彼女を見ることだ。そして自分に言い聞かせるために来たことを、自分に言い聞かせた。自分は彼女を見守っているのだと。"

# game/script/ch11.rpy:78
translate japanese ch11_15c45e44:

    # s soft "How are they treating you here?"
    s soft "ここでは、よくしてもらっているかい？"

# game/script/ch11.rpy:79
translate japanese ch11_9ac82be4:

    # a neutral "They're kind."
    a neutral "親切です。"

# game/script/ch11.rpy:80
translate japanese ch11_751fae5e:

    # "She turned a page she wasn't reading."
    "彼女は読んでいないページをめくった。"

# game/script/ch11.rpy:81
translate japanese ch11_a3002758:

    # a neutral "Mrs. Petrous cries when she thinks I can't see. I think she does it for me, a little. So I don't have to."
    a neutral "Petrousさんは、私が見ていないと思うと泣くんです。少しは、私のために泣いてくれているんだと思います。私が泣かなくて済むように。"

# game/script/ch11.rpy:86
translate japanese ch11_f0d2f83d:

    # "Nothing in her face moved with the words. No catch, no glance toward the far end of the house. An observation, set down neat as a cup on a saucer."
    "言葉に合わせて、彼女の顔は何ひとつ動かなかった。声の詰まりもなく、家の奥へ向ける視線もない。受け皿に置いたカップのようにきちんと置かれた、ひとつの観察。"

# game/script/ch11.rpy:87
translate japanese ch11_f9ae2c4e:

    # th "A bright child being too honest about a grown-up's grief. That's all it is."
    th "賢い子が、大人の悲しみについて正直すぎるだけだ。それだけのことだ。"

# game/script/ch11.rpy:89
translate japanese ch11_51112ce5:

    # "She said it without complaint, the way you'd remark on weather."
    "彼女は不満げな様子もなく、天気のことでも口にするようにそう言った。"

# game/script/ch11.rpy:90
translate japanese ch11_ca16a9d8:

    # "Samuel felt the small snag come and go, and told himself it was only a bright child being too honest about a grown-up's grief."
    "Samuelは小さな引っかかりが現れては消えるのを感じ、賢い子が大人の悲しみについて正直すぎるだけだと、自分に言い聞かせた。"

# game/script/ch11.rpy:93
translate japanese ch11_f4fd685f:

    # s soft "And you? How are you doing, Alice. Truly."
    s soft "それで、君は？　どうしているんだ、Alice。本当のところ。"

# game/script/ch11.rpy:95
translate japanese ch11_15022ba2:

    # "She was quiet a moment. When she looked up her eyes were wet."
    "彼女はしばらく黙っていた。顔を上げたとき、目が濡れていた。"

# game/script/ch11.rpy:96
translate japanese ch11_55971f59:

    # "It was real. He could see that it was real, and that was the thing he could not get past even then. That the wet was real."
    "本物だった。本物だということが彼には見て取れた。そしてそれが、そのときでさえ、彼にはどうしても越えられないことだった。その濡れが、本物だということが。"

# game/script/ch11.rpy:97
translate japanese ch11_df4e12fc:

    # a sad "Everyone keeps asking me that. And I don't know how to say it so it's the right amount."
    a sad "みんな、それを訊くんです。でも、ちょうどいい量になるような言い方が、私にはわからなくて。"

# game/script/ch11.rpy:108
translate japanese ch11_683cb24a:

    # "As if grief came measured, and she had been working out the dose."
    "まるで悲しみが計量されて届くもので、彼女はその服用量を計算していたかのように。"

# game/script/ch11.rpy:109
translate japanese ch11_7894bf68:

    # th "Orphaned twice in a month. Of course she can't tell how much to feel."
    th "ひと月に二度も身寄りをなくしたんだ。どれだけ感じればいいかわからなくて当然だ。"

# game/script/ch11.rpy:110
translate japanese ch11_d977783e:

    # a sad "Emily's gone. And George. And I don't — there's no one left who's mine."
    a sad "Emilyはいなくなりました。Georgeも。それで、私には――私のものだと言える人が、もう誰もいないんです。"

# game/script/ch11.rpy:111
translate japanese ch11_ccf04882:

    # a sad "Everyone in this house is being so careful with me, like I'll break. And I keep thinking, I'm not going to break."
    a sad "この家の人はみんな、私が壊れてしまうみたいに、すごく気をつかってくれます。でも私、ずっと考えてるんです。私は壊れないって。"

# game/script/ch11.rpy:112
translate japanese ch11_702b7e85:

    # a cry "And I don't know if that's because I'm strong, or because there's something wrong with me that I don't."
    a cry "それが私が強いからなのか、それとも壊れないなんて、私のどこかがおかしいからなのか、わからないんです。"

# game/script/ch11.rpy:113
translate japanese ch11_59c4582c:

    # "She looked at him, direct, and the question underneath the question reached him exactly where a man who had buried a child and not wept was softest."
    "彼女はまっすぐに彼を見た。そして問いの下にある問いが、子供を埋めて泣かなかった男の、いちばん柔らかい場所に正確に届いた。"

# game/script/ch11.rpy:114
translate japanese ch11_2992c513:

    # a cry "Is there something wrong with me, that I'm not breaking?"
    a cry "壊れないなんて、私、どこかおかしいんでしょうか？"

# game/script/ch11.rpy:118
translate japanese ch11_13ab51a2:

    # s soft "No. There's nothing wrong with you. Some people hold it. That's all."
    s soft "いや。君はどこもおかしくない。抱えていられる人もいる。それだけのことだ。"

# game/script/ch11.rpy:119
translate japanese ch11_de3f2979:

    # s soft "Holding it isn't the same as not feeling it."
    s soft "抱えていることは、感じていないこととは違う。"

# game/script/ch11.rpy:122
translate japanese ch11_7a47d7bc:

    # s tired "I don't know, Alice. I'm not the one to—"
    s tired "わからないよ、Alice。私はそれを言える人間じゃ――"

# game/script/ch11.rpy:123
translate japanese ch11_128e6ee8:

    # "He stopped. The honest answer sat in his mouth and would not stay there. Something older answered over the top of it, from thirteen years down, from a graveside in the rain."
    "彼は言葉を切った。正直な答えは口の中にあり、そこに留まってはいなかった。もっと古い何かが、その上から答えた。十三年の底から、雨の中の墓前から。"

# game/script/ch11.rpy:124
translate japanese ch11_13ab51a2_1:

    # s soft "No. There's nothing wrong with you. Some people hold it. That's all."
    s soft "いや。君はどこもおかしくない。抱えていられる人もいる。それだけのことだ。"

# game/script/ch11.rpy:125
translate japanese ch11_de3f2979_1:

    # s soft "Holding it isn't the same as not feeling it."
    s soft "抱えていることは、感じていないこととは違う。"

# game/script/ch11.rpy:127
translate japanese ch11_c09c6305:

    # "He heard himself say it, and meant it, and it was the truest kindest thing he had said to anyone in a week."
    "彼は自分がそう言うのを聞き、本心からそう言った。それはこの一週間に彼が誰かにかけた言葉のなかで、最も真実で、最も優しい言葉だった。"

# game/script/ch11.rpy:128
translate japanese ch11_12859bca:

    # "And he watched it land in her, and did not see — could not let himself see — that he had just told the child exactly what she wanted to be told."
    "そして彼はそれが彼女の中に着地するのを見つめ、見えなかった――見ることを自分に許せなかった――自分がいま、その子が言ってほしかったことを正確に言ったのだということが。"

# game/script/ch11.rpy:129
translate japanese ch11_eebd34c1:

    # "That she had asked the question in the precise shape that would draw the answer out of the one wound in him she had found, weeks ago, across a notebook, and had been quietly turning ever since."
    "彼女が、彼の中のたったひとつの傷から答えを引き出すのにぴったりの形で、問いを投げたのだということが。何週間も前に、手帳越しに彼女が見つけ、それ以来静かにひねり続けてきた傷から。"

# game/script/ch11.rpy:131
translate japanese ch11_927cf6ac:

    # a neutral "They're going to send me away."
    a neutral "私、よそへやられるんです。"

# game/script/ch11.rpy:132
translate japanese ch11_9778acf1:

    # "She said it after a while, looking back down at the book."
    "しばらくして、また本に目を落としながら、彼女はそう言った。"

# game/script/ch11.rpy:133
translate japanese ch11_c1ce18c8:

    # a sad "To the city. Mrs. Petrous heard the man on the phone. I'll go somewhere with a lot of other children and no one will know me."
    a sad "都市へ。Petrousさんが電話の男の人の話を聞いたんです。他の子供がたくさんいて、誰も私を知らないところへ行くんです。"

# game/script/ch11.rpy:134
translate japanese ch11_709fc7fa:

    # "A pause, small and perfectly weighted."
    "間。小さく、完璧に重さを量った間。"

# game/script/ch11.rpy:135
translate japanese ch11_3de06154:

    # a sad "You're the only one who ever really talked to me like a person, Detective. Not like a case."
    a sad "私をちゃんと人間として話してくれたのは、刑事さんだけなんです。事件の一件としてじゃなくて。"

# game/script/ch11.rpy:136
translate japanese ch11_a021eaf3:

    # s soft "Nobody's sending you anywhere you won't be looked after."
    s soft "誰も君を、面倒を見てもらえないところへやったりはしない。"

# game/script/ch11.rpy:137
translate japanese ch11_f2973943:

    # "He did not hear how much he had just promised, or to whom."
    "自分がいま、どれほどのことを、誰に約束したのか、彼には聞こえていなかった。"

# game/script/ch11.rpy:139
translate japanese ch11_484fd68c:

    # "He stayed twenty minutes. She showed him the book: history, the Peloponnesian War, far ahead of her grade."
    "彼は二十分いた。彼女は本を見せてくれた。歴史、ペロポネソス戦争。学年をはるかに先取りしたものだった。"

# game/script/ch11.rpy:140
translate japanese ch11_08c17923:

    # s "Why'd Athens lose, then?"
    s "じゃあ、アテナイはなぜ負けた？"

# game/script/ch11.rpy:141
translate japanese ch11_3c0ce3ce:

    # a smile "Because they thought they were too clever to lose. They sent everything to Sicily. And then the plague. And then they had nothing left to send."
    a smile "自分たちは賢すぎて負けるはずがないと思っていたからです。シチリアにすべてを送り込んで。それから疫病。そしてもう、送るものが何も残っていなかったんです。"

# game/script/ch11.rpy:142
translate japanese ch11_7d3322f8:

    # "A quick precise brightness that would have delighted any teacher alive."
    "素早く、正確な聡明さ。どんな教師でも喜んだだろう。"

# game/script/ch11.rpy:143
translate japanese ch11_245264f2:

    # "Somewhere in the ordinary warmth of it the animal in the dark lay down again and slept, because it had no words, and the rest of him had too many."
    "そのありふれた温もりのどこかで、闇の中の獣はまた横たわって眠った。獣には言葉がなく、彼の残りの部分には言葉がありすぎたからだ。"

# game/script/ch11.rpy:144
translate japanese ch11_9b4e22e9:

    # "When he stood to go, she looked up."
    "彼が帰ろうと立ち上がると、彼女は顔を上げた。"

# game/script/ch11.rpy:145
translate japanese ch11_b4d16463:

    # a smile "Come back?"
    a smile "また来てくれますか？"

# game/script/ch11.rpy:146
translate japanese ch11_ed83845a:

    # s soft "I will."
    s soft "来るよ。"

# game/script/ch11.rpy:147
translate japanese ch11_8c532165:

    # "He meant that too."
    "それも本心だった。"

# game/script/ch11.rpy:149
translate japanese ch11_e89dc671:

    # "He carried the snag out with him into the cold and could not name it."
    "彼はその引っかかりを抱えたまま寒さの中へ出ていき、それに名前をつけられなかった。"

# game/script/ch11.rpy:150
translate japanese ch11_f8c36174:

    # "He drove back to the hotel through the white streets telling himself he had done a decent thing, keeping an eye on a frightened orphan."
    "白い通りを抜けてホテルへ車を走らせながら、まともなことをしたのだと自分に言い聞かせた。怯えた孤児を見守ってやったのだと。"

# game/script/ch11.rpy:151
translate japanese ch11_a6ab1e31:

    # "He got exactly as far as the hotel door before the day caught up with him, and he understood that he was not going to sleep."
    "ホテルの扉にちょうど辿り着いたところで、その日が彼に追いついた。そして彼は、自分が眠らないだろうことを悟った。"

# game/script/ch11.rpy:159
translate japanese ch11_3ef7da9c:

    # "He didn't sleep that night, and around two he gave up pretending to, and turned on the lamp, and got out the file."
    "その夜、彼は眠らなかった。二時ごろ、眠ったふりをするのをやめ、ランプをつけ、ファイルを取り出した。"

# game/script/ch11.rpy:160
translate japanese ch11_7c50b29d:

    # "He told himself, spreading it across the hotel bed, that he was doing the only decent thing left."
    "ホテルのベッドの上にそれを広げながら、彼は自分に言い聞かせた。残された唯一のまともなことをしているのだと。"

# game/script/ch11.rpy:161
translate japanese ch11_bec64031:

    # "Building the case against the real killer, the one still out there, so that George Bennett's name might one day be lifted out of the mud, and the child protected from whatever had made her family disappear."
    "本当の殺人者、まだどこかにいる者を追う事件を組み立てているのだと。いつかGeorge Bennettの名を泥の中から拾い上げるために。そして、あの子の家族を消し去った何かから、あの子を守るために。"

# game/script/ch11.rpy:162
translate japanese ch11_8d57c86b:

    # "That was the story he worked under. He was a good enough detective to know, even as he worked, that it was not quite the true one. And disciplined enough not to look at the true one yet."
    "それが、彼が自分にあてがって働いている物語だった。働きながらも、それが本当の物語とは少し違うとわかる程度には、彼は優れた刑事だった。そして、まだ本当の物語を見ないでいられる程度には、自分を律していた。"

# game/script/ch11.rpy:163
translate japanese ch11_3a752d38:

    # "He started where a case starts: at the beginning, with the paper, reading it cold, the way he would read a stranger's work."
    "彼は事件の始まる場所から始めた。最初から、書類から。見知らぬ他人の仕事を読むように、冷たく読んでいった。"

# game/script/ch11.rpy:164
translate japanese ch11_df7f158a:

    # "And the paper had changed."
    "そして書類は変わっていた。"

# game/script/ch11.rpy:165
translate japanese ch11_b35b2f6a:

    # "Evidence did not change. But the light you read it in did, and a fact seen in the wrong light and a fact seen in the right one were two different facts wearing the same clothes."
    "証拠は変わらない。だが、それを読む光は変わる。間違った光の中で見た事実と、正しい光の中で見た事実は、同じ服を着た二つの別の事実だった。"

# game/script/ch11.rpy:166
translate japanese ch11_42310478:

    # "He had read all of this before. He had read it certain of George Bennett, and every line had arranged itself obligingly around that certainty, the way iron filings arrange around a magnet."
    "これはすべて前にも読んでいた。George Bennettだと確信して読み、すべての行がその確信のまわりに素直に並んだ。磁石のまわりに砂鉄が並ぶように。"

# game/script/ch11.rpy:167
translate japanese ch11_290a1a17:

    # "Now the magnet was gone, burned to nothing on a mountain road, and the filings lay where they truly fell."
    "今、磁石は消えていた。山道で燃え尽きて跡形もなく。そして砂鉄は、本当に落ちるべき場所に落ちていた。"

# game/script/ch11.rpy:168
translate japanese ch11_3d43675a:

    # "He read them again in the plain lamp light and felt the floor of the world begin, quietly, to move."
    "飾り気のないランプの光の中でそれをもう一度読み、彼は世界の床が、静かに、動きはじめるのを感じた。"

# game/script/ch11.rpy:170
translate japanese ch11_a6245e77:

    # "He came to the diary last, because he had been, he understood, avoiding it. Clara Ward's diary."
    "日記には最後に辿り着いた。避けていたからだと、彼は悟った。Clara Wardの日記。"

# game/script/ch11.rpy:171
translate japanese ch11_1d6fb3ae:

    # "He had read it weeks ago in this same room and closed it certain of one thing: that a broken child had had exactly one point of light in her collapsing world, and that the light had not been enough."
    "何週間も前に同じこの部屋でそれを読み、ひとつのことを確信して閉じた。壊れた子供には、崩れゆく世界にたったひとつの光の点があり、その光では足りなかったのだと。"

# game/script/ch11.rpy:172
translate japanese ch11_4068a497:

    # note_voice "Alice understands me. She listens. She says nobody will ever understand me the way she does."
    note_voice "Aliceは私をわかってくれる。話を聞いてくれる。Aliceみたいに私をわかってくれる人は、この先ひとりもいないって、Aliceは言う。"

# game/script/ch11.rpy:173
translate japanese ch11_c31361a0:

    # "He had read it, weeks ago, as the one warm thing in a cold story. He read it now, in the right light, and it was the coldest thing he had ever held."
    "何週間も前、彼はそれを冷たい物語の中のたったひとつの温かいものとして読んだ。今、正しい光の中で読むと、それは彼がこれまで手にしたなかで最も冷たいものだった。"

# game/script/ch11.rpy:175
translate japanese ch11_ce976fa3:

    # note_voice "Alice says I need to make a drastic change. That people only notice when you do something they can't ignore."
    note_voice "Aliceは、私は思い切った変化を起こさなきゃいけないって言う。みんなが気づくのは、無視できないことをしたときだけだって。"

# game/script/ch11.rpy:176
translate japanese ch11_44d28faa:

    # note_voice "She said then they'll stop calling me names. Then it won't matter what they think anymore."
    note_voice "そうすれば、みんな私の悪口を言わなくなるって。そうすれば、みんながどう思おうともう関係なくなるって。"

# game/script/ch11.rpy:177
translate japanese ch11_6bd401c9:

    # "He sat with that line a long time, the lamp humming, his cracked rib a dull clock ticking in his side."
    "彼はその一行と長いあいだ向き合っていた。ランプが唸り、ひびの入った肋骨が脇腹で鈍い時計のように時を刻んでいた。"

# game/script/ch11.rpy:178
translate japanese ch11_fa0df5aa:

    # th "A drastic change. Do something they can't ignore."
    th "思い切った変化。無視できないことをする。"

# game/script/ch11.rpy:179
translate japanese ch11_c66ec0f7:

    # "To a girl the whole town knew was cutting herself. A girl in the red zone. A girl one bad night from the edge."
    "町じゅうが自傷をしていると知っていた少女に。危険域にいる少女に。ひどい夜ひとつで縁を越えてしまう少女に。"

# game/script/ch11.rpy:180
translate japanese ch11_d9723c98:

    # "He had read it, the first time, as a friend fumbling toward comfort. He read it now as a hand at the small of a back, at the top of a long stair."
    "最初に読んだとき、彼はそれを、慰めようと手探りする友達の言葉として読んだ。今は、背中のくびれに添えられた手として読んだ。長い階段のいちばん上で。"

# game/script/ch11.rpy:182
translate japanese ch11_416c6ac3:

    # "Every entry he had taken for solace he saw now for what it was. Not the one voice keeping Clara alive, but the one voice, patient and trusted and constant, walking her by careful degrees toward the door."
    "慰めだと受け取っていたすべての記述が、今はその正体を見せていた。Claraを生かしていたただひとつの声ではなく、辛抱強く、信頼され、絶えることのないただひとつの声が、注意深く少しずつ、彼女を扉へと歩かせていたのだ。"

# game/script/ch11.rpy:183
translate japanese ch11_9bd03f02:

    # note_voice "She said hurting myself will never bring good attention. She said if I want things to change, I can't stay like this."
    note_voice "自分を傷つけても、いい注目は集まらないってAliceは言った。変わってほしいなら、このままじゃいられないって。"

# game/script/ch11.rpy:184
translate japanese ch11_483fcdeb:

    # "The counselor had wanted Clara to stay. The parents, useless as they were, had wanted her to stay."
    "カウンセラーはClaraに留まってほしかった。両親も、役立たずではあったが、留まってほしかった。"

# game/script/ch11.rpy:185
translate japanese ch11_28a6ee5b:

    # "Only the friend had told her, gently, lovingly, in a private diary no adult was ever meant to read, that staying was the thing she must not do."
    "友達だけが彼女に告げた。優しく、愛情をこめて、どんな大人も読むはずのなかった秘密の日記の中で、留まることこそしてはならないことなのだと。"

# game/script/ch11.rpy:186
translate japanese ch11_41cee4ff:

    # "And Samuel had had this. For weeks. He had held the confession of it in his own two hands and read it as its opposite."
    "そしてSamuelはこれを持っていた。何週間も。その告白を自分の両手に抱えながら、正反対のものとして読んでいた。"

# game/script/ch11.rpy:187
translate japanese ch11_666502f6:

    # "Because a twelve-year-old had sat across a small table from him and told him, with the quick pleased little smile he had taken for a child being helpful, exactly where to find it."
    "なぜなら十二歳の少女が小さなテーブル越しに座り、子供が役に立とうとしているのだと彼が受け取った、素早い、満足げな小さな微笑みとともに、それがどこにあるかを正確に教えたからだ。"

# game/script/ch11.rpy:189
translate japanese ch11_6974b005:

    # a smile "She keeps it under her mattress. I don't think her parents know, but I do."
    a smile "マットレスの下にしまってるんです。あの子の両親は知らないと思います。でも、私は知ってます。"

# game/script/ch11.rpy:193
translate japanese ch11_ef577941:

    # th "Alice gave me the diary."
    th "Aliceが、俺に日記を渡したんだ。"

# game/script/ch11.rpy:194
translate japanese ch11_e591d67f:

    # "Samuel put it down on the blanket very carefully, as though it might go off."
    "Samuelはそれを、暴発でもするかのように、ひどく慎重に毛布の上に置いた。"

# game/script/ch11.rpy:195
translate japanese ch11_f9adccbe:

    # "He sat in the lamplight and made himself look, at last, at the thing he had been not-looking at all week. All his life."
    "彼はランプの光の中に座り、ついに、自分に見させた。この一週間ずっと見ないでいたものを。生涯ずっと。"

# game/script/ch11.rpy:199
translate japanese ch11_c975baa9:

    # "He did it the way he did everything, when it mattered: with a pen and a clean page and no mercy, laying the facts out in a column and refusing them the comfort of a story."
    "大事なときにいつもそうするように、彼はそれをやった。ペンときれいなページを用意し、容赦なく、事実を一列に並べ、物語という慰めを与えることを拒んで。"

# game/script/ch11.rpy:200
translate japanese ch11_055c6f84:

    # "Who was present."
    "誰がそこにいたか。"

# game/script/ch11.rpy:201
translate japanese ch11_0afafa89:

    # "He wrote the deaths down the left side of the page. The teacher, the shopkeeper, the student, the pastor, the girl. Beside each, he would write who had been near it."
    "ページの左端に、死を書き並べた。教師、店主、生徒、神父、少女。それぞれの横に、誰がその近くにいたかを書いていく。"

# game/script/ch11.rpy:208
translate japanese ch11_5438af9d:

    # "[BOARD_REVEAL_SOME]"
    "[BOARD_REVEAL_SOME!t]"

# game/script/ch11.rpy:210
translate japanese ch11_d58d7442:

    # "[BOARD_REVEAL_NONE]"
    "[BOARD_REVEAL_NONE!t]"

# game/script/ch11.rpy:213
translate japanese ch11_col_maria_98947c4c:

    # note_voice "Maria Mallory. The roof. A T-shirt and leggings at minus ten. No socks."
    note_voice "Maria Mallory。屋上。零下十度でTシャツとレギンス。靴下なし。"

# game/script/ch11.rpy:218
translate japanese ch11_col_maria_84e057ba:

    # th "George did odd jobs around this town. A handyman's rounds aren't a hand on a back. Nothing puts him on that roof."
    th "Georgeはこの町で半端仕事をしていた。便利屋の巡回は、背中に添えた手じゃない。あの屋上にあいつを置くものは何もない。"

# game/script/ch11.rpy:221
translate japanese ch11_col_maria_03329c1c:

    # th "The boy was in love with her, and terrified. Six seconds on New Year's Eve. Terrified boys don't write blackmail that calm."
    th "あの少年は彼女に恋をしていて、怯えていた。大晦日の六秒。怯えた少年に、あんなに落ち着いた脅迫文は書けない。"

# game/script/ch11.rpy:223
translate japanese ch11_col_maria_3923c94d:

    # th "I gave him room once. He filled it with the truth."
    th "一度、あの少年に余地をやった。あいつはそれを真実で埋めた。"

# game/script/ch11.rpy:225
translate japanese ch11_col_maria_1fa8ea09:

    # th "I leaned on him once. He broke the way honest boys break."
    th "一度、あの少年を締め上げた。正直な子が崩れるように崩れた。"

# game/script/ch11.rpy:229
translate japanese ch11_col_maria_1bee2c8d:

    # th "A school library terminal. A school full of children used those terminals."
    th "学校図書館の端末。学校じゅうの子供があの端末を使っていた。"

# game/script/ch11.rpy:230
translate japanese ch11_col_maria_a25988ef:

    # th "I can't place her on that roof. Not yet. I write her name in pencil and I don't like my hand while I do it."
    th "あの屋上にあの子を置くことはできない。まだ。鉛筆であの子の名前を書く。書きながら、自分の手が気に入らない。"

# game/script/ch11.rpy:232
translate japanese ch11_col_maria_9242b958:

    # th "Kurt Leary shouts in squares. He doesn't whisper on rooftops."
    th "Kurt Learyは広場で怒鳴る男だ。屋上で囁く男じゃない。"

# game/script/ch11.rpy:235
translate japanese ch11_col_maria_5b2a7e89:

    # th "Honest. No one I can place. A question mark."
    th "正直に言えば、誰も置けない。疑問符。"

# game/script/ch11.rpy:238
translate japanese ch11_col_hensley_305f618f:

    # note_voice "Patrick Hensley. His counter. Yew in the coffee. WEAKNESS."
    note_voice "Patrick Hensley。彼のカウンター。コーヒーにイチイ。弱さ。"

# game/script/ch11.rpy:243
translate japanese ch11_col_hensley_6b9c0834:

    # th "His rounds touched the store. That's why it looked like him. Touched isn't near. Touched is what someone wanted me to see."
    th "あいつの巡回はあの店にも及んでいた。だからあいつに見えた。及んでいたことは、近くにいたことじゃない。及んでいたことは、誰かが俺に見せたかったものだ。"

# game/script/ch11.rpy:246
translate japanese ch11_col_hensley_eeb6c4d7:

    # th "Nothing ties the boy to Hensley. Nothing but my wanting it to be someone."
    th "あの少年とHensleyを結ぶものは何もない。誰かであってほしいという、俺の願いのほかには。"

# game/script/ch11.rpy:250
translate japanese ch11_col_hensley_c04268f2:

    # th "A schoolgirl buying sweets at a counter. Every child in Greyvale did that. I can't place her there. Not with anything I could say out loud."
    th "カウンターで菓子を買う女子生徒。Greyvaleの子供なら誰でもしていた。あそこにあの子を置くことはできない。口に出して言えるようなものでは、何ひとつ。"

# game/script/ch11.rpy:252
translate japanese ch11_col_hensley_55d42a65:

    # th "Half the town bought cigarettes off Hensley. Leary among them. That's a customer, not a killer."
    th "町の半分がHensleyの店で煙草を買っていた。Learyもそのひとりだ。それは客であって、殺人者じゃない。"

# game/script/ch11.rpy:255
translate japanese ch11_col_hensley_a361ecac:

    # th "No one I can place. The yew grows in every second hedge. A question mark."
    th "思い当たる者はいない。イチイは生垣の二つにひとつに生えている。疑問符。"

# game/script/ch11.rpy:258
translate japanese ch11_col_clara_d3d69599:

    # note_voice "Clara Ward. The locker room. Wrists."
    note_voice "Clara Ward。ロッカールーム。手首。"

# game/script/ch11.rpy:263
translate japanese ch11_col_clara_15a3f9b1:

    # th "George never met Clara Ward that I know of. Her diary never once says his name."
    th "俺の知る限り、GeorgeはClara Wardに会ったこともない。あの子の日記には、一度もあいつの名前が出てこない。"

# game/script/ch11.rpy:266
translate japanese ch11_col_clara_bbb58a72:

    # th "Steve Collins had his own drowning to do. He isn't in her pages."
    th "Steve Collinsは、自分が溺れるのに手一杯だった。あの子のページには出てこない。"

# game/script/ch11.rpy:270
translate japanese ch11_col_clara_5f0f1513:

    # "Clara Ward, walked to her death down the pages of a diary by a friend the whole town had thought a mercy."
    "Clara Ward。町じゅうが救いだと思っていた友達に、日記のページを伝って死へと歩かされた。"

# game/script/ch11.rpy:271
translate japanese ch11_col_clara_cd9171ef:

    # "And it was Alice who had been that friend. Alice who had steered her. Alice who had then, with a small smile in a counselor's office, told the detective exactly where to find the diary."
    "そしてその友達こそが、Aliceだった。彼女を誘導したのはAliceだった。そしてそのあと、カウンセラー室で小さく微笑みながら、日記がどこにあるかを刑事に正確に教えたのも、Aliceだった。"

# game/script/ch11.rpy:272
translate japanese ch11_col_clara_b924af42:

    # "His hand, writing it, began very slightly to go cold."
    "それを書く彼の手が、ほんのわずかに冷えはじめた。"

# game/script/ch11.rpy:274
translate japanese ch11_col_clara_d5719ffa:

    # th "Leary wouldn't have known the girl's name until it was on a coffin."
    th "Learyは、あの子の名前が棺に載るまで知りもしなかっただろう。"

# game/script/ch11.rpy:277
translate japanese ch11_col_clara_19dea09f:

    # th "No. Someone was near her. Someone was on every page of that diary."
    th "違う。誰かがあの子の近くにいた。あの日記のすべてのページに、誰かがいた。"

# game/script/ch11.rpy:281
translate japanese ch11_col_karalis_157ddff7:

    # note_voice "Father Karalis. In front of his church. The water bottle."
    note_voice "Karalis神父。教会の前。水のボトル。"

# game/script/ch11.rpy:286
translate japanese ch11_col_karalis_75f2b5e8:

    # th "Nothing puts George near that pulpit or that bottle. Nothing but the shape I'd already drawn around him."
    th "あの説教壇にも、あのボトルにも、Georgeを近づけるものは何もない。俺がすでにあいつのまわりに描いていた輪郭のほかには。"

# game/script/ch11.rpy:289
translate japanese ch11_col_karalis_c55337f3:

    # th "The boy was nowhere near the front. Nothing puts him near that bottle."
    th "あの少年は前のほうには近づいてもいなかった。あのボトルにあいつを近づけるものは何もない。"

# game/script/ch11.rpy:293
translate japanese ch11_col_karalis_a34b3ba0:

    # "Dropped in front of his whole congregation. And among the congregation, calm in the chaos, not flinching, a twelve-year-old girl."
    "会衆全員の前で倒れた。そして会衆の中に、混乱のさなかで落ち着き払い、ひるみもしない十二歳の少女がいた。"

# game/script/ch11.rpy:294
translate japanese ch11_col_karalis_cb7e7572:

    # "Holding Emily's face to her shoulder. Eyes open. Watching."
    "Emilyの顔を自分の肩に押し当てて。目を開けて。見つめて。"

# game/script/ch11.rpy:295
translate japanese ch11_col_karalis_3c3fc910:

    # "Samuel had noted her composure at the time, and filed it under a strange way for a child to grieve."
    "Samuelは当時、彼女の落ち着きに目を留め、子供にしては変わった悲しみ方だ、という項目に分類していた。"

# game/script/ch11.rpy:297
translate japanese ch11_col_karalis_412e2c1f:

    # th "Leary shouted after. Shouting after was all Leary ever did."
    th "Learyは後から怒鳴った。後から怒鳴る、Learyがやったのはそれだけだ。"

# game/script/ch11.rpy:300
translate japanese ch11_col_karalis_f162c82e:

    # th "No. A church full of people screamed. One of them didn't flinch."
    th "違う。教会いっぱいの人間が悲鳴を上げた。その中のひとりだけが、ひるまなかった。"

# game/script/ch11.rpy:304
translate japanese ch11_col_emily_ad4615b3:

    # note_voice "Emily Carter. The cemetery. The cocoa. Midnight."
    note_voice "Emily Carter。墓地。ココア。真夜中。"

# game/script/ch11.rpy:309
translate japanese ch11_col_emily_634d5034:

    # th "Vale Cross. 11:52. Thirty-one liters. Twenty-five miles of gorge. The clock doesn't lie."
    th "Vale Cross。十一時五十二分。三十一リットル。峡谷を挟んで二十五マイル。時計は嘘をつかない。"

# game/script/ch11.rpy:312
translate japanese ch11_col_emily_9372598a:

    # th "Nothing ties the boy to Emily Carter. She wouldn't have crossed a town in a storm for him."
    th "あの少年とEmily Carterを結ぶものは何もない。Emilyがあいつのために、嵐の中で町を横切りはしなかっただろう。"

# game/script/ch11.rpy:316
translate japanese ch11_col_emily_c7649b5e:

    # "Emily Carter had climbed out of a warm house into a midnight storm without her phone, for someone."
    "Emily Carterは暖かい家を抜け出し、電話も持たずに真夜中の嵐の中へ出ていった。誰かのために。"

# game/script/ch11.rpy:317
translate japanese ch11_col_emily_28662c9e:

    # "Samuel had said it himself, standing over her body: no careful frightened child goes into the dark like that except for someone she loves and trusts entirely."
    "Samuel自身が、彼女の遺体を前にしてそう言ったのだ。用心深く怯えた子供が、あんなふうに闇の中へ出ていくのは、心から愛し、すっかり信頼している誰かのためだけだと。"

# game/script/ch11.rpy:318
translate japanese ch11_col_emily_7cc922fb:

    # "And the someone Emily Carter loved and trusted entirely, the best friend she had crossed a town in the snow to meet, was Alice."
    "そしてEmily Carterが心から愛し、すっかり信頼していた誰か、雪の中を町を横切って会いに行った親友は、Aliceだった。"

# game/script/ch11.rpy:320
translate japanese ch11_col_emily_ac963248:

    # th "I went to the button first, that morning. The one true thing on that grave was a goodbye."
    th "あの朝、俺は真っ先にボタンへ向かった。あの墓の上でただひとつ本物だったのは、別れの挨拶だった。"

# game/script/ch11.rpy:322
translate japanese ch11_col_emily_f1a8bf0d:

    # th "Leary was in the square by morning, howling for a rope. He'd never have got that girl out of her bed."
    th "Learyは朝には広場にいて、縄を寄こせと吠えていた。あいつにあの子をベッドから連れ出せたはずがない。"

# game/script/ch11.rpy:325
translate japanese ch11_col_emily_df47ed32:

    # th "No. No careful child walks into a storm at midnight for no one."
    th "違う。用心深い子供が、誰のためでもなく真夜中に嵐の中へ歩いていくはずがない。"

# game/script/ch11.rpy:329
translate japanese ch11_column_done_b5f8f783:

    # "And around every one of them, the frame."
    "そしてそのひとつひとつのまわりに、枠組み。"

# game/script/ch11.rpy:330
translate japanese ch11_column_done_130dc32a:

    # "The confession in Markou's warm office: the preparations, the {i}he doesn't like Emily{/i}, the whole shape of George handed to Samuel by the frightened granddaughter. Hours, it turned out, before Emily died."
    "Markouの暖かい部屋での告白。準備のこと、{i}あの人はEmilyが嫌いなんです{/i}、怯えた孫娘からSamuelに手渡されたGeorgeの姿のすべて。それはEmilyが死ぬ、ほんの数時間前のことだったのだ。"

# game/script/ch11.rpy:332
translate japanese ch11_column_done_6e3ab627:

    # th "I took every word as given. That's what the room was for."
    th "俺はひと言残らず、言われたとおりに受け取った。あの部屋はそのためにあった。"

# game/script/ch11.rpy:334
translate japanese ch11_column_done_b1dee95b:

    # th "Her hands folded tighter on his name. I wrote down fear."
    th "あいつの名前のところで、あの子の手がいっそう固く組まれた。俺は恐怖と書き留めた。"

# game/script/ch11.rpy:335
translate japanese ch11_column_done_981d3deb:

    # "The testimony that put George out on the night. {i}I heard him come home after two.{/i}"
    "あの夜、Georgeを外に出したのはその証言だった。{i}二時過ぎに帰ってくるのが聞こえました。{/i}"

# game/script/ch11.rpy:336
translate japanese ch11_column_done_a2871de0:

    # "Every arrow that had ever pointed at the old man had passed, at some point, through the small calm hands of the child the old man had died to protect."
    "老人を指したすべての矢印は、どこかの時点で、老人が命を捨てて守ろうとした子供の、小さく落ち着いた両手を通り抜けていた。"

# game/script/ch11.rpy:338
translate japanese ch11_column_done_17d95fe1:

    # "Five lines on the page. Two of them in pencil he had not earned. Three of them in ink he could not rub out."
    "ページに五本の行。そのうち二本は、根拠の伴わない鉛筆。三本は、消すことのできないインク。"

# game/script/ch11.rpy:340
translate japanese ch11_column_done_2ac4309c:

    # "Five lines on the page. Three of them in ink he could not rub out."
    "ページに五本の行。そのうち三本は、消すことのできないインク。"

# game/script/ch11.rpy:343
translate japanese ch11_column_done_91f494a2:

    # "At the foot of the column, he wrote one word."
    "列のいちばん下に、彼はひと言書いた。"

# game/script/ch11.rpy:345
translate japanese ch11_column_done_aa9dc00f:

    # note_voice "ALICE"
    note_voice "Alice"

# game/script/ch11.rpy:346
translate japanese ch11_column_done_0c090bed:

    # "The detective in him wrote it all down and saw the pattern close like a trap."
    "彼の中の刑事はそれをすべて書き留め、罠のようにパターンが閉じるのを見た。"

# game/script/ch11.rpy:347
translate japanese ch11_column_done_4d0f6e38:

    # "And the other thing in him, the older thing, the wound worn to the shape of a child, rose up in the same instant and began, in a voice he had trusted his whole life, to talk him out of it."
    "そして彼の中のもうひとつのもの、より古いもの、子供の形にすり減った傷が、同じ瞬間に立ち上がり、生涯信じてきた声で、彼を説き伏せにかかった。"

# game/script/ch11.rpy:348
translate japanese ch11_column_done_26cac1eb:

    # th "She is twelve years old."
    th "あの子は十二歳だ。"

# game/script/ch11.rpy:349
translate japanese ch11_column_done_3a559f35:

    # "That was the first and the last of it, and it was a wall a mile high."
    "それが始まりであり終わりだった。そしてそれは、高さ一マイルの壁だった。"

# game/script/ch11.rpy:350
translate japanese ch11_column_done_a497e3e4:

    # th "Twelve. A child. Children do not do these things. The world is not built to allow it."
    th "十二歳。子供だ。子供はこんなことをしない。世界はそれを許すようにはできていない。"

# game/script/ch11.rpy:351
translate japanese ch11_column_done_40df27ca:

    # th "There's no poison in a schoolbag. No calculation behind a grieving face. No murder in a girl who reads Tom Sawyer and keeps another child's drawings pinned to her wall."
    th "通学鞄に毒なんか入っていない。悲しむ顔の裏に計算なんかない。『トム・ソーヤー』を読み、他の子の絵を壁にピンで留めている女の子に、殺意なんかない。"

# game/script/ch11.rpy:352
translate japanese ch11_column_done_97b03565:

    # th "Listen to yourself, Harris. Listen to what you're building at two in the morning in a cold room with a cracked rib and no sleep."
    th "自分の言っていることを聞け、Harris。午前二時に、寒い部屋で、ひびの入った肋骨を抱えて、一睡もせずに、自分が何を組み立てているのかを聞け。"

# game/script/ch11.rpy:353
translate japanese ch11_column_done_8ba6feb9:

    # th "You put your own child in the ground and never wept. And now, at the far end of the worst week of your life, you look at an orphan you swore over a dead man's body to protect — and see a monster."
    th "お前は自分の子供を土に埋めて、一度も泣かなかった。そして今、人生最悪の一週間の果てに、死んだ男の亡骸にかけて守ると誓った孤児を見て――怪物を見ている。"

# game/script/ch11.rpy:354
translate japanese ch11_column_done_7af3761f:

    # th "Because a monster is easier to look at than a little girl who has lost everyone."
    th "すべてを失った小さな女の子より、怪物のほうが見ていて楽だからだ。"

# game/script/ch11.rpy:355
translate japanese ch11_column_done_0b1b51d0:

    # th "This is not detection. This is grief. This is the crack in you finally running all the way through."
    th "これは捜査じゃない。悲嘆だ。お前の中のひびが、とうとう端から端まで走り抜けたんだ。"

# game/script/ch11.rpy:356
translate japanese ch11_column_done_3ea7a063:

    # th "Doyle would take your badge. Markou would sit you down in the green chair. And they would be right."
    th "Doyleはお前のバッジを取り上げるだろう。Markouはお前を緑の椅子に座らせるだろう。そしてどちらも正しい。"

# game/script/ch11.rpy:357
translate japanese ch11_column_done_4ba4dab5:

    # "He almost stopped there. He wanted to stop there."
    "彼はもう少しでそこで止まるところだった。そこで止まりたかった。"

# game/script/ch11.rpy:358
translate japanese ch11_column_done_709b6bab:

    # "It would have been so easy, and so kind to himself, to close the file and call it a broken man's fever and drive home to Martha in the morning, and let the county take the orphan south, and never know."
    "ファイルを閉じ、壊れた男の熱病だと片づけ、朝になったらMarthaのもとへ車で帰り、郡が孤児を南へ連れていくにまかせ、決して知らずにいる。それはあまりにも簡単で、自分にとってあまりにも優しいことだっただろう。"

# game/script/ch11.rpy:359
translate japanese ch11_column_done_62af3e06:

    # "But Samuel Harris had never once, in thirty years, been able to stop at the easy place. And he did not stop now."
    "だがSamuel Harrisは三十年間、ただの一度も、楽な場所で止まることができなかった。そして今も止まらなかった。"

# game/script/ch11.rpy:360
translate japanese ch11_column_done_c2346bb8:

    # "He picked the pen back up."
    "彼はもう一度ペンを取った。"

# game/script/ch11.rpy:363
translate japanese ch11_column_done_e37c8c1b:

    # "Because there was a second column, and the wound could not touch it, because it was not about the child at all. It was about the old man."
    "なぜなら二つ目の列があり、傷はそれに触れることができなかったからだ。それはあの子のことではまったくなかった。老人のことだった。"

# game/script/ch11.rpy:364
translate japanese ch11_column_done_60d4ad78:

    # note_voice "George Bennett."
    note_voice "George Bennett。"

# game/script/ch11.rpy:365
translate japanese ch11_column_done_7328ca5d:

    # "George Bennett had been innocent. That was not instinct now. That was a receipt, and nineteen seconds of tape."
    "George Bennettは無実だった。それはもう勘ではなかった。一枚のレシートと、十九秒の映像だった。"

# game/script/ch11.rpy:366
translate japanese ch11_column_done_c9ef47fa:

    # "George had been twenty-five miles away buying diesel while Emily Carter died. And he had known — must have known, sitting in that cell — that he had only to say where he had been, and the whole edifice would fall."
    "Emily Carterが死んだとき、Georgeは二十五マイル離れた場所で軽油を買っていた。そして彼は知っていた――あの独房に座りながら、知っていたはずだ――自分がどこにいたかを言いさえすれば、建物全体が崩れ落ちることを。"

# game/script/ch11.rpy:367
translate japanese ch11_column_done_d17cba9f:

    # "And George Bennett had said nothing. Had taken the rope."
    "そしてGeorge Bennettは何も言わなかった。縄を選んだ。"

# game/script/ch11.rpy:368
translate japanese ch11_column_done_9602e36a:

    # "Had sat in a warm room while a detective all but begged him, and had chosen, deliberately, with his eyes open, to be beaten to death in a road rather than speak one saving sentence."
    "刑事がほとんど懇願するようにしているあいだ、暖かい部屋に座り、意図して、目を開けたまま、救いとなるひと言を口にするより、道の上で殴り殺されることを選んだ。"

# game/script/ch11.rpy:369
translate japanese ch11_column_done_16a40f40:

    # "Samuel had known, on the mountain, that this meant George was protecting someone."
    "山の上で、SamuelはそれがGeorgeが誰かを守っているという意味だとわかっていた。"

# game/script/ch11.rpy:370
translate japanese ch11_column_done_5c04d1a0:

    # "He had let himself believe — because the wound needed him to believe it — that the old man was shielding the girl from the past. From the cult. From whatever had made her family vanish. A grandfather's last kindness."
    "彼は信じることを自分に許した――傷がそう信じることを必要としたから――老人は少女を過去からかばっているのだと。教団から。あの子の家族を消し去った何かから。祖父の最後の優しさなのだと。"

# game/script/ch11.rpy:371
translate japanese ch11_column_done_53dce256:

    # "He saw now that he had built that reading for exactly the same reason he had built the reading of the diary: because the true one was unbearable."
    "今、彼にはわかった。自分がその読み方を組み立てたのは、日記の読み方を組み立てたのとまったく同じ理由からだったのだと。本当の読み方が、耐えられないものだったからだ。"

# game/script/ch11.rpy:372
translate japanese ch11_column_done_73968ed1:

    # th "Set it out plain."
    th "平らに並べてみろ。"

# game/script/ch11.rpy:373
translate japanese ch11_column_done_39df679b:

    # th "A man is innocent of a murder. A man can prove it with a word. A man chooses to die instead. Why?"
    th "ある男が殺人について無実だ。その男はひと言でそれを証明できる。その男は代わりに死ぬことを選ぶ。なぜだ？"

# game/script/ch11.rpy:374
translate japanese ch11_column_done_4d3d0baf:

    # "Only one why survives the receipt."
    "レシートを前にして生き残る「なぜ」は、ひとつしかない。"

# game/script/ch11.rpy:375
translate japanese ch11_column_done_ea7f12cc:

    # th "Because the word that clears him is a word that damns someone he loves more than his own life."
    th "自分を潔白にするそのひと言が、自分の命より愛している誰かを破滅させるひと言だからだ。"

# game/script/ch11.rpy:376
translate japanese ch11_column_done_c001235f:

    # "To give himself an alibi, he would have to give the police the real killer. And the real killer was the one person on this earth George Bennett would climb into a grave to keep from being named."
    "自分にアリバイを与えるには、警察に本当の殺人者を差し出さなければならない。そして本当の殺人者とは、名指しされるのを防ぐためならGeorge Bennettが自ら墓に入ることも厭わない、この地上でただひとりの人間だった。"

# game/script/ch11.rpy:377
translate japanese ch11_column_done_1062f78e:

    # "There was only one person alive that George Bennett had loved that much."
    "George Bennettがそれほど愛した人間は、生きている者の中にひとりしかいなかった。"

# game/script/ch11.rpy:378
translate japanese ch11_column_done_d3ea8873:

    # "Samuel had it from the old man's own mouth. The last real warning George ever gave him."
    "Samuelはそれを老人自身の口から聞いていた。Georgeが彼に与えた、最後の本当の警告。"

# game/script/ch11.rpy:381
translate japanese ch11_column_done_7860e777:

    # g grim "Be careful what you decide she is."
    g grim "あの子を何者だと決めるか、気をつけることだ。"

# game/script/ch11.rpy:385
translate japanese ch11_column_done_129c38c3:

    # "He had heard it, in the interrogation room, as a strange man's warning about a strange girl. He heard it now as the truth, offered and refused in the same breath."
    "取調室で、彼はそれを、風変わりな男が風変わりな少女について発した警告として聞いた。今、彼はそれを真実として聞いた。同じひと息のうちに差し出され、そして拒まれた真実として。"

# game/script/ch11.rpy:386
translate japanese ch11_column_done_b9f04323:

    # "By a man who could not save himself without destroying her, and could not destroy her even to save himself."
    "あの子を破滅させずには自分を救えず、自分を救うためであってもあの子を破滅させられなかった男によって。"

# game/script/ch11.rpy:387
translate japanese ch11_column_done_2a076a5b:

    # "{i}Be careful what you decide she is.{/i} Because he knew what she was, and could not say it."
    "{i}あの子を何者だと決めるか、気をつけることだ。{/i}あの男は、あの子が何者かを知っていて、それを言えなかったからだ。"

# game/script/ch11.rpy:389
translate japanese ch11_column_done_8f37c180:

    # th "He looked toward the stair when he said it. Toward her. I watched him do it, and wrote down grief."
    th "あれを言ったとき、あいつは階段のほうを見た。あの子のほうを。俺はそれを見ていて、悲しみと書き留めた。"

# game/script/ch11.rpy:390
translate japanese ch11_column_done_0da3feea:

    # "And was asking the only thing he had left to ask: that when Samuel found out, as George clearly feared he might, he would be gentler with the knowing than George had ever managed to be."
    "そして、残された唯一の頼みを口にしていたのだ。Georgeが明らかに恐れていたとおりにSamuelが真相を知ったとき、その知ったことを、Georgeがついぞできなかったよりも優しく扱ってくれ、と。"

# game/script/ch11.rpy:391
translate japanese ch11_column_done_f56b82ab:

    # th "He didn't die protecting Alice from a killer."
    th "あいつは、Aliceを殺人者から守って死んだんじゃない。"

# game/script/ch11.rpy:392
translate japanese ch11_column_done_c32d7e96:

    # th "He died protecting the world from her. And her from the rope."
    th "世界をあの子から守って死んだんだ。そして、あの子を縄から。"

# game/script/ch11.rpy:393
translate japanese ch11_column_done_380b3bb0:

    # "Both at once. Both true. It was the most terrible arithmetic Samuel had ever done, and it balanced, and it left nothing standing."
    "その両方を同時に。どちらも真実だった。それはSamuelがこれまでにした中で最も恐ろしい計算であり、帳尻は合い、そして何ひとつ立ったままでは残さなかった。"

# game/script/ch11.rpy:395
translate japanese ch11_column_done_ba2c1766:

    # note_voice "George: innocent. Silent. Protecting HER."
    note_voice "George：無実。沈黙。あの子を守っていた。"

# game/script/ch11.rpy:397
translate japanese ch11_column_done_548ed592:

    # "And the last thing fell into place then: the splinter he had carried off the mountain and been unable to draw."
    "そして最後のひとつが、そのとき収まるべき場所に収まった。山から持ち帰り、抜くことのできなかった棘。"

# game/script/ch11.rpy:398
translate japanese ch11_column_done_7ff7aa1b:

    # "That clean and certain conscience he had seen the crowd wear as it killed a man in the road. The look of a court that has weighed a life and found it wanting, and feels only lighter for the ending of it."
    "道の上で男を殺しながら群衆がまとっていた、あの澄んで確信に満ちた良心。ひとつの命を量り、足りないと断じ、その終わりにただ身が軽くなるのを感じる法廷の顔つき。"

# game/script/ch11.rpy:399
translate japanese ch11_column_done_f01a8ed8:

    # "He had told himself he had seen that certainty somewhere close that week and could not place it. He could place it now."
    "あの週、どこか近くでその確信を見たはずなのに、どこだったか思い出せないと、彼は自分に言い聞かせていた。今は思い出せた。"

# game/script/ch11.rpy:400
translate japanese ch11_column_done_88bac17c:

    # "He had seen it in a warm office, and a cold cemetery, and a foster family's kitchen. In a pair of calm gray eyes that did not flinch at a dying priest or a screaming mother or a friend gone into the ground."
    "暖かい部屋で、冷たい墓地で、里親家庭の台所で、それを見ていた。死にゆく司祭にも、叫ぶ母親にも、土の中へ去った友達にもひるまない、一対の落ち着いた灰色の目の中に。"

# game/script/ch11.rpy:401
translate japanese ch11_column_done_1db9b595:

    # "The town had killed George in a fit of the exact thing that had been killing the town."
    "町は、町を殺しつづけてきたのとまさに同じものの発作の中で、Georgeを殺したのだ。"

# game/script/ch11.rpy:402
translate japanese ch11_column_done_6062e8e3:

    # "He had watched the judge's certainty pass into a mob and had not recognized it, because he had first seen it, and refused it, in the face of a child."
    "裁く者の確信が群衆へと移っていくのを見ながら、彼はそれと気づかなかった。最初にそれを見て、そして拒んだのが、ひとりの子供の顔の中だったからだ。"

# game/script/ch11.rpy:410
translate japanese ch11_column_done_c0480151:

    # "Dawn found him still on the edge of the bed, the file spread and cold, the lamp gone yellow and sick in the growing light."
    "夜明けは、まだベッドの縁に座る彼を見つけた。ファイルは広げられて冷え、ランプは増していく光の中で黄色く病んだ色になっていた。"

# game/script/ch11.rpy:411
translate japanese ch11_column_done_c0743aa6:

    # "Samuel Harris was in possession, at last, of the whole truth. And of the second thing that came with it, which was that the truth was worth exactly nothing."
    "Samuel Harrisはついに、真実のすべてを手にしていた。そしてそれとともに来る第二のものも。その真実には、まったく何の価値もないということを。"

# game/script/ch11.rpy:412
translate japanese ch11_column_done_2e703f9c:

    # "He made himself walk it the way a prosecutor would walk it, because that was the only test that mattered, and he already knew how it came out."
    "彼は検察官が辿るようにそれを辿ってみた。それが意味のある唯一の試験であり、結果がどうなるかはもうわかっていた。"

# game/script/ch11.rpy:413
translate japanese ch11_column_done_8c414a9a:

    # th "What do I have?"
    th "俺の手には何がある？"

# game/script/ch11.rpy:414
translate japanese ch11_column_done_dea43fee:

    # "A diary that showed, to any eye but his newly opened one, a lonely girl and a kind young friend. A child who had not cried enough at a funeral. A best friend who had snuck out at night, as teenagers do."
    "新たに開かれた彼の目以外のどんな目にも、孤独な少女と優しい年下の友達しか見せない日記。葬儀で十分に泣かなかった子供。十代の子がよくするように、夜中に家を抜け出した親友。"

# game/script/ch11.rpy:415
translate japanese ch11_column_done_9756488c:

    # "A grandfather who had died without an alibi he could have given. And the alibi, when it surfaced, cleared the grandfather and pointed at no one."
    "与えることのできたアリバイを与えずに死んだ祖父。そしてそのアリバイは、浮かび上がったとき、祖父の潔白を証明し、誰も指さなかった。"

# game/script/ch11.rpy:416
translate japanese ch11_column_done_851ddaf7:

    # "Least of all a twelve-year-old orphan, currently eating toast in a foster kitchen two streets away."
    "とりわけ、いま二本先の通りの里親の台所でトーストを食べている、十二歳の孤児など。"

# game/script/ch11.rpy:417
translate japanese ch11_column_done_fe2b7494:

    # th "A pattern. Patterns aren't evidence. Certainty in a pair of gray eyes isn't a thing you put in an evidence bag and hand to a jury."
    th "パターン。パターンは証拠じゃない。灰色の目に宿る確信は、証拠袋に入れて陪審に手渡せるものじゃない。"

# game/script/ch11.rpy:418
translate japanese ch11_column_done_cf055bc8:

    # "He made himself work the leads, one at a time, the way the county would if he could ever make them look. And one at a time they died in his hands."
    "彼は手がかりを、ひとつずつ当たってみた。郡に目を向けさせることができたなら郡がするであろうやり方で。そしてひとつずつ、それは彼の手の中で死んでいった。"

# game/script/ch11.rpy:419
translate japanese ch11_column_done_11a17840:

    # "The poison was yew, and yew grew wild in every second hedge in the valley. Whoever steeped it had worn gloves and long since burned the making of it."
    "毒はイチイで、イチイは谷の生垣の二つにひとつに自生していた。煎じた者は手袋をはめ、作った痕跡などとうに燃やしてしまっている。"

# game/script/ch11.rpy:420
translate japanese ch11_column_done_a42a34f8:

    # "There would be nothing in that cold house now but a swept floor and a dead grate."
    "あの冷えた家には今、掃かれた床と火の消えた炉床しかないだろう。"

# game/script/ch11.rpy:421
translate japanese ch11_column_done_86e10567:

    # "Emily Carter had walked into the storm with her own phone left charging on her nightstand. Which meant there had been another. A quiet one, a line the two girls had talked on that no parent had known."
    "Emily Carterは自分の電話をナイトテーブルで充電したまま、嵐の中へ出ていった。つまり、もう一台あったということだ。静かな一台。どの親も知らない、二人の少女が話すための回線。"

# game/script/ch11.rpy:422
translate japanese ch11_column_done_7e74eefb:

    # "A phone bought for cash and gone silent the night Emily died: no carrier, no record. A handset lying now at the bottom of some gorge, because a careful person does not keep the one thread that ties her to the dead."
    "現金で買われ、Emilyが死んだ夜に沈黙した電話。通信会社もなく、記録もない。その端末は今ごろどこかの峡谷の底に横たわっている。用心深い人間は、自分と死者を結ぶたった一本の糸を手元に残したりしないからだ。"

# game/script/ch11.rpy:423
translate japanese ch11_column_done_69017896:

    # "There were no prints."
    "指紋はなかった。"

# game/script/ch11.rpy:424
translate japanese ch11_column_done_09eec7b9:

    # "There were no witnesses, because the only witness to each death had been the one who caused it. And the one who caused it was twelve years old and grieving, and had wept, on cue, in every room that mattered."
    "目撃者はいなかった。どの死にも、ただひとりの目撃者はそれを引き起こした者だったからだ。そしてそれを引き起こした者は十二歳で、悲しみの中にあり、肝心な部屋ではどこでも、合図どおりに泣いてみせた。"

# game/script/ch11.rpy:425
translate japanese ch11_column_done_e8550842:

    # "She had killed five people, and an old man had died for it, and a whole town had done the killing."
    "彼女は五人を殺した。そのためにひとりの老人が死に、その殺しを、町がまるごとやってのけた。"

# game/script/ch11.rpy:426
translate japanese ch11_column_done_126fd928:

    # "And there was not one scrap of paper in the world that would make a single living soul believe a word of it."
    "そしてこの世界のどこにも、生きている誰かひとりにでもそのひと言を信じさせる紙切れは、一枚もなかった。"

# game/script/ch11.rpy:428
translate japanese ch11_column_done_7aea17a4:

    # note_voice "Nothing I can prove."
    note_voice "証明できるものは何もない。"

# game/script/ch11.rpy:430
translate japanese ch11_column_done_6dfc803c:

    # "His phone lay on the blanket beside the file. Doyle's number was the second one down."
    "彼の電話がファイルの横の毛布の上にあった。Doyleの番号は上から二番目だった。"

# game/script/ch11.rpy:435
translate japanese ch11_column_done_c5c2a1da:

    # "He picked up the phone. His thumb found the name."
    "彼は電話を手に取った。親指がその名前を見つけた。"

# game/script/ch11.rpy:436
translate japanese ch11_column_done_65988d59:

    # "And before it could press, he heard the call the way he would have heard it from the other end, because he would have taken it himself, from any other man who came to him at dawn with this."
    "そして押す前に、彼はその電話を相手の側から聞くように聞いた。自分が受ける側だったなら、夜明けにこれを持ち込んできたどんな男からでも、そう聞いただろうから。"

# game/script/ch11.rpy:437
translate japanese ch11_column_done_2119c0f4:

    # th "The detective who put his own infant in the ground and never grieved. Who arrested an innocent man and watched him beaten to death."
    th "自分の赤ん坊を土に埋めて、一度も悲しまなかった刑事。罪のない男を逮捕して、そいつが殴り殺されるのを見ていた刑事。"

# game/script/ch11.rpy:438
translate japanese ch11_column_done_0c869344:

    # th "Who hasn't slept in a week, with a cracked rib and a thousand-yard stare, saying in a level voice that the real killer is a grieving twelve-year-old girl."
    th "一週間眠っていない、ひびの入った肋骨と虚ろな目をした男が、落ち着いた声で言うんだ。本当の殺人者は、悲しみに暮れる十二歳の女の子だと。"

# game/script/ch11.rpy:439
translate japanese ch11_column_done_7d93cf05:

    # "Doyle would not hear a case. Doyle would hear a man coming apart at the exact seam everyone had always known was there."
    "Doyleは事件を聞き取りはしないだろう。誰もがずっとそこにあると知っていた、まさにその縫い目からほころびていく男の声を聞くだろう。"

# game/script/ch11.rpy:440
translate japanese ch11_column_done_fd32548b:

    # "They would take his badge, gently, for his own good. And they would take the orphan south to the city on schedule, and be kind to her the whole way."
    "彼らは彼のバッジを取り上げるだろう。優しく、本人のためにと。そして予定どおり孤児を南の都市へと連れていき、道中ずっと彼女に優しくするだろう。"

# game/script/ch11.rpy:441
translate japanese ch11_column_done_1c6f65f7:

    # "They would set her down in a new place among new people. Unwatched. Unsuspected. Unmarked. With a fresh town to weigh."
    "新しい場所の新しい人々の中に、彼女を降ろすだろう。見張られず。疑われず。印もつけられず。量るべき新しい町とともに。"

# game/script/ch11.rpy:442
translate japanese ch11_column_done_fe2c2f59:

    # "He put the phone down on the blanket, face down, very carefully."
    "彼は電話を毛布の上に、画面を下にして、ひどく慎重に置いた。"

# game/script/ch11.rpy:444
translate japanese ch11_column_done_5acd166e:

    # "He did not reach for the phone. He knew precisely what would happen if he said it aloud, to Doyle, to the county, to Markou."
    "彼は電話に手を伸ばさなかった。それを声に出して言ったら何が起きるか、正確にわかっていた。Doyleに、郡に、Markouに。"

# game/script/ch11.rpy:445
translate japanese ch11_column_done_16702a43:

    # "They would not hear a case. They would hear a man coming apart at the exact seam everyone had always known was there."
    "彼らは事件を聞き取りはしないだろう。誰もがずっとそこにあると知っていた、まさにその縫い目からほころびていく男の声を聞くだろう。"

# game/script/ch11.rpy:446
translate japanese ch11_column_done_90f28e65:

    # "They would take his badge, gently, for his own good, and take the orphan south on schedule, and be kind to her the whole way."
    "彼らは彼のバッジを取り上げるだろう。優しく、本人のためにと。そして予定どおり孤児を南へ連れていき、道中ずっと彼女に優しくするだろう。"

# game/script/ch11.rpy:447
translate japanese ch11_column_done_76811258:

    # "And they would set her down in a new place among new people. Unwatched. Unsuspected. Unmarked. With a fresh town to weigh."
    "そして新しい場所の新しい人々の中に、彼女を降ろすだろう。見張られず。疑われず。印もつけられず。量るべき新しい町とともに。"

# game/script/ch11.rpy:449
translate japanese ch11_column_done_b2e75940:

    # "And Samuel understood, sitting in the yellow dawn, that he had become George Bennett."
    "そしてSamuelは、黄色い夜明けの中に座りながら理解した。自分はGeorge Bennettになったのだと。"

# game/script/ch11.rpy:450
translate japanese ch11_column_done_cc50c77b:

    # th "I'm the man who knows, and can't say."
    th "俺は、知っていて、言えない男だ。"

# game/script/ch11.rpy:451
translate japanese ch11_column_done_f0607b2f:

    # "He was holding the same unbearable knowledge the old man had carried down into the road rather than speak. The knowledge of what she was."
    "あの老人が、口にするよりはと道の上まで抱えていったのと同じ、耐えがたい知識を、彼は抱えていた。彼女が何者かという知識を。"

# game/script/ch11.rpy:452
translate japanese ch11_column_done_af008343:

    # "And he was learning, in real time, the thing that had kept George silent for two years: that to say it was to be disbelieved, or to be believed and destroy her."
    "そして彼は、まさに今、Georgeを二年間沈黙させてきたものを学んでいた。それを言えば信じてもらえないか、信じてもらえて彼女を破滅させるかのどちらかなのだと。"

# game/script/ch11.rpy:453
translate japanese ch11_column_done_05d016e5:

    # "Both of those roads ran out into a dark a man could not make himself walk."
    "そのどちらの道も、人が自分を歩かせることのできない闇の中へ続いていた。"

# game/script/ch11.rpy:454
translate japanese ch11_column_done_01032acf:

    # "He had judged George in that cell for his silence. He took the judgment back now, whole, in the cold light."
    "彼はあの独房で、Georgeをその沈黙ゆえに裁いた。今、冷たい光の中で、その裁きをまるごと取り消した。"

# game/script/ch11.rpy:455
translate japanese ch11_column_done_92c7f981:

    # "They were moving her Thursday. Two days. A caseworker and a county car down Route Nine to the city, and the file closed behind her, and the girl gone into the world."
    "彼女は木曜日に移される。二日後だ。ケースワーカーと郡の車がRoute Nineを下って都市へ向かい、背後でファイルが閉じられ、少女は世界の中へと消えていく。"

# game/script/ch11.rpy:456
translate japanese ch11_column_done_d0e064a6:

    # th "I won't let a stranger drive her."
    th "見知らぬやつに、あの子を運転させはしない。"

# game/script/ch11.rpy:457
translate japanese ch11_column_done_a263deba:

    # "He told himself it was to watch her, and that was true."
    "彼女を見張るためだと、彼は自分に言い聞かせた。そしてそれは本当だった。"

# game/script/ch11.rpy:458
translate japanese ch11_column_done_39c83419:

    # "He told himself it was because he could not let her vanish into the state unmarked, with no one alive who knew. And that was true."
    "知っている者がひとりも生きていないまま、印もつけられずに彼女が州の中へ消えていくのを許せないからだと、自分に言い聞かせた。そしてそれも本当だった。"

# game/script/ch11.rpy:459
translate japanese ch11_column_done_3960bc89:

    # "He told himself, too, in the smallest and most dangerous chamber of himself, that there might yet be a child somewhere down inside the thing in that kitchen."
    "そして彼は、自分の中の最も小さく、最も危険な部屋で、こうも言い聞かせた。あの台所にいるものの奥深くのどこかに、まだひとりの子供がいるかもしれないと。"

# game/script/ch11.rpy:460
translate japanese ch11_column_done_670ae625:

    # "The five-year-old George had pulled out of the rain. The girl who read Tom Sawyer."
    "Georgeが雨の中から引き上げた五歳の子。『トム・ソーヤー』を読む女の子。"

# game/script/ch11.rpy:461
translate japanese ch11_column_done_3f2b2dde:

    # "And that if any man alive could reach her, it was the one who had lost a child and might, God help him, still want to save one."
    "そしてもし生きている誰かが彼女に手を届かせられるとしたら、それは子供を失い、神よ許したまえ、それでもなおひとりを救いたいと願っているかもしれない男なのだと。"

# game/script/ch11.rpy:462
translate japanese ch11_column_done_6153c71b:

    # "He did not look too closely at that last chamber. It was the one he trusted least to keep shut in front of her."
    "その最後の部屋を、彼はあまり近くから見ないようにした。彼女の前で閉じたままにしておけると、最も信用できない部屋だったからだ。"

# game/script/ch11.rpy:466
translate japanese ch11_column_done_d6f7d884:

    # "He picked up the phone and called the caseworker, and offered, in the flat easy voice of a man doing a colleague a favor, to drive the Bennett girl down to the city himself."
    "彼は電話を取ってケースワーカーにかけ、同僚に頼まれごとをしてやる男の平板で気楽な声で、Bennettの娘を自分で都市まで送っていこうと申し出た。"

# game/script/ch11.rpy:467
translate japanese ch11_column_done_8b234a1a:

    # s "I'm headed back that way Thursday regardless. And the child knows me. Trusts me. It might go easier on her with a face she knows."
    s "木曜日はどのみちそっちへ戻る予定なんです。それにあの子は私を知っている。信頼している。知っている顔のほうが、あの子にも楽かもしれません。"

# game/script/ch11.rpy:468
translate japanese ch11_column_done_cbcfaecf:

    # woman "Oh — Detective, that would be a real help. Honestly. You've been so good with her."
    woman "まあ――刑事さん、それは本当に助かります。正直なところ。あの子にはずいぶんよくしてくださって。"

# game/script/ch11.rpy:470
translate japanese ch11_column_done_79afb872:

    # "The caseworker was grateful. Of course she was. It was one less long cold drive on a bad road."
    "ケースワーカーは感謝した。もちろんそうだろう。悪路の長く寒い運転が、ひとつ減るのだから。"

# game/script/ch11.rpy:472
translate japanese ch11_column_done_9e5c8c86:

    # note_voice "Thursday. I drive."
    note_voice "木曜日。俺が運転する。"

# game/script/ch11.rpy:474
translate japanese ch11_column_done_7f243b8f:

    # "Samuel set the phone down and sat a while longer as the room filled with gray morning."
    "Samuelは電話を置き、部屋が灰色の朝で満ちていくあいだ、もうしばらく座っていた。"

# game/script/ch11.rpy:475
translate japanese ch11_column_done_1b53f817:

    # "An innocent man newly in the ground, and the guilt of it still on him like a smell no soap could reach. The whole ruinous truth locked up inside him, with nowhere on earth to put it."
    "土に入ったばかりの罪のない男。その罪悪感はまだ、どんな石鹸も届かない匂いのように彼にまとわりついていた。破滅的な真実のすべてが彼の中に閉じ込められ、この地上のどこにも置き場がなかった。"

# game/script/ch11.rpy:476
translate japanese ch11_column_done_04632660:

    # "And two days now between him and a car, and a road, and a girl."
    "そして今、彼と、一台の車と、一本の道と、ひとりの少女とのあいだには、二日しかなかった。"

# game/script/ch11.rpy:479
translate japanese ch11_column_done_c9c27d1b:

    # "And the long white miles down the mountain to the city, and somewhere out along them, small and patient in the dark—"
    "そして山を下って都市へと続く長く白い道のり。そのどこか先に、闇の中で小さく、辛抱強く――"

# game/script/ch11.rpy:480
translate japanese ch11_column_done_6a0aebd5:

    # "A gas station."
    "ガソリンスタンドがひとつ。"

translate japanese strings:

    # game/script/ch11.rpy:39
    old "Her coat."
    new "彼女のコート。"

    # game/script/ch11.rpy:84
    old "Watch her face as she says it."
    new "そう言う彼女の顔を見る。"

    # game/script/ch11.rpy:88
    old "Let it pass."
    new "聞き流す。"

    # game/script/ch11.rpy:100
    old "Her tears."
    new "彼女の涙。"

    # game/script/ch11.rpy:103
    old "The book."
    new "本。"

    # game/script/ch11.rpy:106
    old "\"The right amount.\""
    new "「ちょうどいい量」"

    # game/script/ch11.rpy:117
    old "\"Some people hold it.\""
    new "「抱えていられる人もいる」"

    # game/script/ch11.rpy:120
    old "\"I don't know.\""
    new "「わからない」"

    # game/script/ch11.rpy:214
    old "Who was near it?"
    new "誰が近くにいた？"

    # game/script/ch11.rpy:217
    old "George Bennett."
    new "George Bennett。"

    # game/script/ch11.rpy:220
    old "Steve Collins."
    new "Steve Collins。"

    # game/script/ch11.rpy:231
    old "Kurt Leary."
    new "Kurt Leary。"

    # game/script/ch11.rpy:234
    old "No one I can place."
    new "思い当たる者なし。"

    # game/script/ch11.rpy:433
    old "Call Doyle and tell him."
    new "Doyleに電話して話す。"

