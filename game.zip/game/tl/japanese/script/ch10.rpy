# TODO: Translation updated at 2026-10-11 10:23

# game/script/ch10.rpy:13
translate japanese ch10_b88c5ad2:

    # "The killings stopped, and that was the thing that damned George Bennett more thoroughly in death than any evidence had in life."
    "殺しは止まった。そしてそのことこそが、生前のどんな証拠よりも徹底して、死んだGeorge Bennettを有罪にした。"

# game/script/ch10.rpy:14
translate japanese ch10_48b1b315:

    # "For three days after the road, Greyvale held its breath and nothing happened."
    "あの道の一件から三日のあいだ、Greyvaleは息を詰め、何も起こらなかった。"

# game/script/ch10.rpy:15
translate japanese ch10_9c0f3d4b:

    # "No teacher went off a roof. No shopkeeper folded over his counter. No scrap of torn paper turned up on any threshold."
    "屋上から落ちる教師はいなかった。カウンターに突っ伏す店主もいなかった。どの戸口にも、破られた紙切れは現れなかった。"

# game/script/ch10.rpy:16
translate japanese ch10_51c93d3e:

    # "The snow came and stopped and came again, and the town crept out from behind its doors and found the world unchanged and safe."
    "雪は降り、止み、また降った。町は扉の陰から這い出し、世界が何も変わらず、安全であることを知った。"

# game/script/ch10.rpy:17
translate japanese ch10_c7781e7c:

    # "And it drew from that safety the only conclusion a frightened people ever draws: that the thing which had hunted them was in the ground, and they had put it there, and it had been right to do."
    "そしてその安全から、怯えた人々がいつも引き出す唯一の結論を引き出した。自分たちを狩っていたものは土の下にある。そこへ入れたのは自分たちだ。そしてそれは正しいことだった、と。"

# game/script/ch10.rpy:18
translate japanese ch10_75710548:

    # "By the second day the fires in the square were gone, and the shame had begun its quiet work of turning into a story they could live inside."
    "二日目には広場の焚き火は消え、恥はその静かな仕事を始めていた。自分たちが中で暮らしていける物語へと、姿を変える仕事を。"

# game/script/ch10.rpy:19
translate japanese ch10_141bf9bf:

    # "A hard winter. A terrible strain. A community pushed past bearing."
    "厳しい冬。ひどい重圧。耐えられる限界を超えて追い詰められた共同体。"

# game/script/ch10.rpy:20
translate japanese ch10_07ff1c89:

    # "By the third day a man could buy his bread in the bakery and not lower his voice. It was over. Everyone said so."
    "三日目には、男がパン屋でパンを買うのに声を潜める必要もなくなった。終わったのだ。誰もがそう言った。"

# game/script/ch10.rpy:21
translate japanese ch10_0be48017:

    # "The proof was the silence, and the silence went on and on."
    "証拠は沈黙だった。そして沈黙はどこまでも続いた。"

# game/script/ch10.rpy:24
translate japanese ch10_485f35ee:

    # "On the third morning he walked the square, because he could not sit in the hotel room any longer, and what he saw there was worse than the fires had been."
    "三日目の朝、彼は広場を歩いた。ホテルの部屋にもう座っていられなかったからだ。そこで目にしたものは、焚き火よりもひどかった。"

# game/script/ch10.rpy:25
translate japanese ch10_9abe4559:

    # "The oil drums were gone. The snow had been swept off the church steps."
    "ドラム缶は消えていた。教会の石段の雪は掃かれていた。"

# game/script/ch10.rpy:26
translate japanese ch10_20b746a8:

    # "A man was up a ladder rehanging a shutter the crowd had torn loose the day of the road, whistling, unhurried."
    "梯子の上で、男がひとり鎧戸を掛け直していた。あの道の日に群衆がもぎ取った鎧戸だ。口笛を吹きながら、急ぐ様子もなく。"

# game/script/ch10.rpy:27
translate japanese ch10_82ba3f12:

    # "In the bakery, when Samuel went in for coffee because a man has to be somewhere, the baker served him."
    "パン屋に、Samuelはコーヒーを買いに入った。人はどこかにいなければならないからだ。パン屋は彼に応対した。"

# game/script/ch10.rpy:28
translate japanese ch10_5b210a05:

    # "The same baker whose name Samuel had written down in the red snow three days ago. Whose {i}I never laid a hand, I swear before God{/i} was still logged in Samuel's notebook."
    "三日前、赤い雪の中でSamuelがその名を書き留めた、あのパン屋だった。その{i}誓って、俺は指一本触れてない、神にかけて{/i}は、今もSamuelの手帳に記されていた。"

# game/script/ch10.rpy:30
translate japanese ch10_39f6eced:

    # th "I looked one of them in the face on that road. It makes the forgetting harder to watch."
    th "あの道で、俺はあいつらのひとりの顔をまっすぐ見た。だから、忘れていくのを見るのがよけいにこたえる。"

# game/script/ch10.rpy:32
translate japanese ch10_f0b7834f:

    # th "I kept my eyes on the page that day. I keep them there now."
    th "あの日、俺は目を手帳から上げなかった。今も上げていない。"

# game/script/ch10.rpy:33
translate japanese ch10_8576bae1:

    # "The baker" "There you are, Detective. Coffee, and a roll while they're warm."
    "The baker" "おや、刑事さん。コーヒーと、焼きたてのロールパンをどうぞ。温かいうちに。"

# game/script/ch10.rpy:34
translate japanese ch10_1bd097d7:

    # "The baker" "Heading home soon, I expect? Now the bad business is finished."
    "The baker" "そろそろお帰りでしょう？　嫌な一件も、もう片がついたことだし。"

# game/script/ch10.rpy:35
translate japanese ch10_c59419d3:

    # "Not a flicker in him. Not a shadow."
    "ちらつきひとつない。影ひとつない。"

# game/script/ch10.rpy:36
translate japanese ch10_e23c3121:

    # "The man had helped kill someone in a road and had folded it away already into {i}the bad business{/i}: a thing that had happened to the town, rather than a thing the town had done."
    "この男は道の上で人を殺す手伝いをし、それをもう{i}嫌な一件{/i}へと畳み込んでいた。町がしたことではなく、町に降りかかったことへと。"

# game/script/ch10.rpy:37
translate japanese ch10_1b4b8bf8:

    # "And he had gone back to his ovens with clean hands and a clear morning ahead."
    "そしてきれいな手と晴れた朝を抱えて、窯の前へ戻っていったのだ。"

# game/script/ch10.rpy:38
translate japanese ch10_923fc570:

    # s angry "I expect I'll be off shortly."
    s angry "じきに失礼しますよ。"

# game/script/ch10.rpy:39
translate japanese ch10_14aae4b7:

    # "Samuel paid, and stood in the doorway with the warm cup going cold in his hand, and watched the square be a square."
    "Samuelは金を払い、温かいカップが手の中で冷めていくのにまかせて戸口に立ち、広場が広場であるのを眺めた。"

# game/script/ch10.rpy:40
translate japanese ch10_e1c66815:

    # "Children. A dog. A woman shaking a rug."
    "子供たち。犬が一匹。敷物をはたく女。"

# game/script/ch10.rpy:41
translate japanese ch10_a8fdd2bd:

    # "And he felt, without yet being able to say why, that this, exactly this, the whole ordinary machinery of a town forgetting, was the thing someone had been counting on all along."
    "そして彼は、まだ理由を言葉にできないまま感じていた。これが、まさにこれが、町が忘れていくという当たり前の仕組みそのものが、誰かが最初からずっと当てにしていたものなのだと。"

# game/script/ch10.rpy:42
translate japanese ch10_6fcf03b2:

    # th "Someone was counting on this."
    th "誰かが、これを当てにしていた。"

# game/script/ch10.rpy:51
translate japanese ch10_b3a38738:

    # "Samuel did not believe it, and he could not have told anyone, in those three days, exactly why."
    "Samuelは信じていなかった。そしてその三日間、なぜなのかを誰かにきちんと説明することはできなかっただろう。"

# game/script/ch10.rpy:52
translate japanese ch10_a4b7f119:

    # "He should have been gone. Doyle had all but ordered him home."
    "本来ならもう帰っているはずだった。Doyleはほとんど帰還を命じたも同然だった。"

# game/script/ch10.rpy:53
translate japanese ch10_570ee66d:

    # "{i}You did what could be done and more, Sam. Come back, write it up, let the county close it out.{/i}"
    "{i}やれることはやった、それ以上にな、Sam。戻って報告書を書け。片はつけさせろ、郡に。{/i}"

# game/script/ch10.rpy:54
translate japanese ch10_5407dabe:

    # "And the county wanted nothing so much as a tidy file. Suspect identified, suspect deceased, matter concluded. The awkward business of the road to be handled by a different office and a softer word."
    "そして郡が何より欲しがっていたのは、きれいに整った書類だった。被疑者特定、被疑者死亡、事案終結。あの道の厄介な一件は、別の部署が、もっと柔らかな言葉で処理する。"

# game/script/ch10.rpy:55
translate japanese ch10_e1a172e8:

    # "There was a shape the whole world wanted this to take, and the shape was closed."
    "世界じゅうがこの件に取らせたがっている形があった。そしてその形は、閉じていた。"

# game/script/ch10.rpy:56
translate japanese ch10_0fd7845d:

    # "All Samuel had to do to be free of Greyvale forever was sign his name under the story everyone had already agreed to tell."
    "Greyvaleから永遠に解放されるためにSamuelがすべきことは、誰もがすでに語ると決めた物語の下に、自分の名前を署名することだけだった。"

# game/script/ch10.rpy:57
translate japanese ch10_306cfd27:

    # "He sat in his hotel room with the report half-typed on his phone, his cracked rib taped tight under his shirt, a cigarette burning down unregarded in the ashtray."
    "彼はホテルの部屋に座っていた。電話には半分打ちかけの報告書。シャツの下では、ひびの入った肋骨がテープできつく巻かれている。灰皿では煙草が、顧みられることなく燃え尽きていった。"

# game/script/ch10.rpy:58
translate japanese ch10_f900c40f:

    # "He could not make his thumb move to the last line."
    "親指を最後の行へ動かすことが、どうしてもできなかった。"

# game/script/ch10.rpy:60
translate japanese ch10_331866a0:

    # note_voice "Report unsigned."
    note_voice "報告書、未署名。"

# game/script/ch10.rpy:66
translate japanese ch10_38d4f518:

    # "Because a dead man had thrown a rope back into a flood. That was what would not leave him."
    "死んだ男が、洪水の中で投げられた縄を投げ返したからだ。それが頭を離れなかった。"

# game/script/ch10.rpy:67
translate japanese ch10_da2882aa:

    # "He had turned it over a hundred times in three days and it would not wear smooth."
    "三日のあいだに百回はひっくり返して考えたが、角が取れることはなかった。"

# game/script/ch10.rpy:68
translate japanese ch10_3aa6e64a:

    # "He had given George Bennett every door a man could be given. His freedom, his granddaughter, his life."
    "彼はGeorge Bennettに、人が与えられうるあらゆる扉を与えた。自由を、孫娘を、命を。"

# game/script/ch10.rpy:69
translate japanese ch10_49b1ff6b:

    # "And George had sat in a warm room and looked at each door and chosen the rope."
    "そしてGeorgeは暖かい部屋に座り、扉をひとつずつ見て、縄を選んだ。"

# game/script/ch10.rpy:70
translate japanese ch10_83d49f79:

    # "Samuel had thirty years of watching guilty men to tell him that guilty men do not do that."
    "罪を犯した人間はそんなことをしない。Samuelには、罪人を見つめてきた三十年がそう教えていた。"

# game/script/ch10.rpy:71
translate japanese ch10_9cdb125e:

    # th "Guilty men talk. Guilty men trade. Guilty men, cornered, give you somebody else."
    th "罪人はしゃべる。罪人は取引する。追い詰められた罪人は、誰か別のやつを差し出す。"

# game/script/ch10.rpy:72
translate japanese ch10_6af79819:

    # "Only one kind of man takes the rope over one sentence that would save him. Samuel had said the words aloud on the mountain, with the old man's blood going cold under his knees."
    "自分を救うひと言より縄を選ぶ男は、ひと種類しかいない。Samuelはその言葉を山の上で口に出していた。老人の血が膝の下で冷えていくなかで。"

# game/script/ch10.rpy:73
translate japanese ch10_c6e77961:

    # th "A man protecting somebody."
    th "誰かを守っている男。"

# game/script/ch10.rpy:74
translate japanese ch10_2a6eb09b:

    # "The killings had stopped. Fine. He made himself think it through the way he would have made a junior think it through: cold, from the outside."
    "殺しは止まった。いいだろう。彼は若手に考えさせるときのやり方で、自分に考え抜かせた。冷たく、外側から。"

# game/script/ch10.rpy:75
translate japanese ch10_e9b8f4f7:

    # th "What does a stopped killing prove? It proves a killer stopped. It doesn't prove which killer."
    th "殺しが止まったことで何が証明される？　殺人者が止まったことだ。どの殺人者かは証明されない。"

# game/script/ch10.rpy:76
translate japanese ch10_dec05ce9:

    # "A thing can stop because you have buried it. Or because it has finished what it came to do."
    "ものが止まるのは、それを埋めたからかもしれない。あるいは、それが果たしに来たことを果たし終えたからかもしれない。"

# game/script/ch10.rpy:77
translate japanese ch10_adb6dbdc:

    # "Or because it has learned, from watching a town tear a man apart in a road, exactly how safe it now is."
    "あるいは、町がひとりの男を道の上で引き裂くのを見て、自分がいまどれほど安全かを正確に学んだからかもしれない。"

# game/script/ch10.rpy:78
translate japanese ch10_65dbfef7:

    # "The silence the town was calling proof was the one piece of evidence in the whole affair that pointed nowhere at all."
    "町が証拠と呼んでいる沈黙は、この一件のすべての中で、どこも指していない唯一の証拠だった。"

# game/script/ch10.rpy:79
translate japanese ch10_6c9da697:

    # "He picked up the cigarette, found it dead, lit another."
    "煙草を取り上げ、火が消えているのに気づき、別の一本に火をつけた。"

# game/script/ch10.rpy:80
translate japanese ch10_5a654f4c:

    # "He was not going home. He had known it, he realized, since the road: known it under the grief, under the guilt, in the cold clear third place that had opened in him kneeling by the body."
    "家には帰らない。あの道の時から、それはわかっていたのだと彼は気づいた。悲しみの下で、罪悪感の下で、遺体のそばに膝をついたときに自分の中に開いた、冷たく澄んだ第三の場所で、わかっていた。"

# game/script/ch10.rpy:81
translate japanese ch10_0de8b5ba:

    # "He was going to reopen a closed grave and look, properly this time, at a man he had helped to kill."
    "閉じた墓をもう一度開け、自分が殺す手伝いをした男を、今度こそきちんと見るのだ。"

# game/script/ch10.rpy:82
translate japanese ch10_290eb336:

    # "He was going to find out what George Bennett had died rather than say."
    "George Bennettが、口にするより死を選んだものが何だったのかを突き止めるのだ。"

# game/script/ch10.rpy:83
translate japanese ch10_dcd82183:

    # th "I owe him that. It's the only thing left I can pay."
    th "あの男にはその借りがある。俺に払えるのは、もうそれしか残っていない。"

# game/script/ch10.rpy:90
translate japanese ch10_30a2bb70:

    # "Martha called him the next morning, because Martha always knew, the way she had always known, when the shell was cracking."
    "翌朝、Marthaから電話があった。殻にひびが入りかけているとき、Marthaはいつだってわかった。昔からずっとそうだった。"

# game/script/ch10.rpy:93
translate japanese ch10_c2b19533:

    # ma concerned "You're not back."
    ma concerned "戻ってないじゃないの。"

# game/script/ch10.rpy:94
translate japanese ch10_35cf53ee:

    # "No hello."
    "挨拶もなかった。"

# game/script/ch10.rpy:95
translate japanese ch10_c714b70e:

    # ma concerned "Raymond says you were supposed to be back two days ago. Raymond says there's nothing left up there but paperwork and a town that ought to be ashamed of itself."
    ma concerned "Raymondが言ってたわよ、あなたは二日前に戻ってるはずだったって。Raymondが言うには、あそこにはもう書類仕事と、恥を知るべき町しか残ってないんですって。"

# game/script/ch10.rpy:100
translate japanese ch10_642392a0:

    # s tired "There's a little more than paperwork."
    s tired "書類仕事より、少しだけ多くのことがある。"

# game/script/ch10.rpy:101
translate japanese ch10_add0d776:

    # ma smile "There's always a little more than paperwork with you."
    ma smile "あなたにはいつだって、書類仕事より少しだけ多くのことがあるのよ。"

# game/script/ch10.rpy:103
translate japanese ch10_7fb620df:

    # th "He'd tried the truth on Claire at New Year, and it went back where he kept it. This time it got out."
    th "大晦日に、Claireに本当のことを言いかけた。それは元の場所に引っ込んだ。今度は、外に出た。"

# game/script/ch10.rpy:106
translate japanese ch10_04a2f55a:

    # s tired "It's just paperwork, Martha. A few signatures."
    s tired "ただの書類仕事だよ、Martha。署名がいくつかあるだけだ。"

# game/script/ch10.rpy:107
translate japanese ch10_07170183:

    # "The lie came out practiced and smooth, and fell flat on the line like a dropped plate."
    "嘘は手慣れて滑らかに出てきて、落とした皿のように回線の上で平たく割れた。"

# game/script/ch10.rpy:108
translate japanese ch10_6139c47e:

    # ma concerned "Sam. There's always a little more than paperwork with you. Don't you try that voice on me."
    ma concerned "Sam。あなたにはいつだって、書類仕事より少しだけ多くのことがあるの。その声を私に使おうなんて思わないでちょうだい。"

# game/script/ch10.rpy:110
translate japanese ch10_c2aa2b11:

    # th "The voice he'd used on Claire. It hadn't worked on her either."
    th "Claireに使った声だ。Claireにも通じなかった。"

# game/script/ch10.rpy:112
translate japanese ch10_7b657965:

    # "A pause. He heard her sit down, heard the kitchen chair take her weight, and something in him eased at the sound the way it always did."
    "間があった。彼女が腰を下ろすのが聞こえた。台所の椅子が彼女の重みを受けとめる音がした。その音に、彼の中の何かがいつものようにゆるんだ。"

# game/script/ch10.rpy:113
translate japanese ch10_3d51d086:

    # "The small proof that somewhere a room existed with her in it."
    "どこかに、彼女のいる部屋が存在するという、ささやかな証拠。"

# game/script/ch10.rpy:114
translate japanese ch10_d2ca058a:

    # ma concerned "I heard what happened, Sam. On the road. I heard you went in."
    ma concerned "何があったか聞いたわ、Sam。道でのこと。あなたが飛び込んでいったって。"

# game/script/ch10.rpy:115
translate japanese ch10_41d45759:

    # s hurt "I didn't stop it."
    s hurt "止められなかった。"

# game/script/ch10.rpy:116
translate japanese ch10_4cae4149:

    # ma concerned "That is not what I said."
    ma concerned "私はそんなこと言ってないわ。"

# game/script/ch10.rpy:117
translate japanese ch10_4f3ec10c:

    # "Her voice had gone quiet and hard, the voice she used when she meant to be heard."
    "彼女の声は静かに、硬くなっていた。聞かせるつもりのときに使う声だった。"

# game/script/ch10.rpy:118
translate japanese ch10_6f112a7f:

    # ma concerned "I said you went in. Fifty of them and you the only soul on that mountain who tried."
    ma concerned "飛び込んでいったって言ったの。向こうは五十人、それを止めようとしたのは、あの山であなたひとりだけだった。"

# game/script/ch10.rpy:119
translate japanese ch10_6359b76c:

    # ma concerned "You listen to me, Samuel Harris, because I know how your head works, and I know you're sitting in some cold little room right now stacking this on the pile with all the rest and calling it your fault."
    ma concerned "よく聞きなさい、Samuel Harris。あなたの頭の働き方くらいわかってるんだから。どうせ今もどこかの寒々しい小部屋に座って、これを他のぜんぶと一緒に山に積み上げて、自分のせいだって言ってるんでしょう。"

# game/script/ch10.rpy:120
translate japanese ch10_5f4c8aff:

    # "A breath."
    "ひと息。"

# game/script/ch10.rpy:121
translate japanese ch10_3e1c30cb:

    # ma concerned "A man died who maybe shouldn't have. That's a weight. Carry it honest."
    ma concerned "死ぬべきじゃなかったかもしれない人が死んだ。それは重荷よ。正直に背負いなさい。"

# game/script/ch10.rpy:123
translate japanese ch10_2cdef929:

    # th "He had, once this winter. On the Carters' stair, before the last step."
    th "この冬、一度はそうした。Carter家の階段で、最後の一段の手前で。"

# game/script/ch10.rpy:125
translate japanese ch10_3d20c953:

    # th "He'd let Lara start, on the Carters' stair. He finished it."
    th "Carter家の階段で、Laraに口火を切らせた。終わりまで言ったのは俺だ。"

# game/script/ch10.rpy:126
translate japanese ch10_33fb4e0d:

    # ma concerned "But don't you dare use it to prove the old thing to yourself. Don't you dare."
    ma concerned "でもね、それを使って、あの古いことを自分に証明しようなんて真似は許さない。絶対に許さないわよ。"

# game/script/ch10.rpy:127
translate japanese ch10_685c69e3:

    # "He didn't answer. Outside the window the square lay white and ordinary, a woman crossing it with bread under her arm, a town that had gone back to being a town."
    "彼は答えなかった。窓の外では広場が白く、ありふれた姿で横たわっていた。パンを小脇に抱えた女がそこを横切っていく。町はまた町に戻っていた。"

# game/script/ch10.rpy:128
translate japanese ch10_94fea12f:

    # ma concerned "You still there?"
    ma concerned "まだそこにいる？"

# game/script/ch10.rpy:129
translate japanese ch10_bc6a123c:

    # s soft "I'm here."
    s soft "いるよ。"

# game/script/ch10.rpy:130
translate japanese ch10_509fa011:

    # ma concerned "The old thing. That you couldn't save the one that mattered. That caring's a thing that gets taken from you, so you'd best not do it."
    ma concerned "あの古いこと。いちばん大事なひとりを救えなかったってこと。誰かを想う気持ちは取り上げられるものだから、持たないほうがいいってこと。"

# game/script/ch10.rpy:131
translate japanese ch10_f48a75b9:

    # ma cry "Thirteen years you've believed it, and it's a lie, Sam. It was always a lie. And one of these days it's going to be the thing that gets you killed."
    ma cry "十三年もそれを信じてきて、それは嘘なのよ、Sam。ずっと嘘だった。そしていつか、それがあなたを殺すことになるわ。"

# game/script/ch10.rpy:132
translate japanese ch10_59e878d9:

    # "He heard her swallow."
    "彼女が唾を呑むのが聞こえた。"

# game/script/ch10.rpy:133
translate japanese ch10_fa2bce45:

    # ma smile "Come home when you can. There's food that won't keep and a chair nobody's sitting in."
    ma smile "帰れるときに帰ってきなさい。日持ちしない食べ物と、誰も座ってない椅子があるから。"

# game/script/ch10.rpy:134
translate japanese ch10_b6fc5ccf:

    # ma concerned "And Sam — the thing you're chasing up there. If it's a true thing, chase it. You were always better than all of them at the true things."
    ma concerned "それからSam――あなたがそこで追いかけてるもの。それが本当のことなら、追いかけなさい。本当のことにかけては、あなたはいつだって誰よりも上だった。"

# game/script/ch10.rpy:135
translate japanese ch10_5af55657:

    # ma concerned "Just don't chase it to punish yourself. Chase it because it's true."
    ma concerned "ただ、自分を罰するために追いかけるんじゃないの。本当のことだから追いかけるのよ。"

# game/script/ch10.rpy:138
translate japanese ch10_1d74c138:

    # "When she'd rung off he sat a while with the phone warm in his hand, the shell cracked another quiet inch by the plain unwanted fact of her."
    "電話が切れたあと、彼は温かい電話を手にしたまましばらく座っていた。彼女という、ありふれた、望んでもいない事実によって、殻はまた静かに一インチひび割れていた。"

# game/script/ch10.rpy:139
translate japanese ch10_7f252708:

    # th "You were always better than all of them at the true things."
    th "本当のことにかけては、あなたはいつだって誰よりも上だった。"

# game/script/ch10.rpy:140
translate japanese ch10_700303b5:

    # "He had spent thirteen years certain the caring was the weakness. She had spent them just as certain it was the only thing that had ever made him worth a damn at the work."
    "十三年間、彼は心を寄せることこそが弱さだと確信してきた。彼女はその同じ十三年間、同じくらい強く確信してきた。それこそが、この仕事で彼を多少なりとも価値ある人間にしてきた唯一のものだと。"

# game/script/ch10.rpy:141
translate japanese ch10_0f636f75:

    # "He had never had to choose between them, because the not-choosing was safe, and safety was the whole of what he had built."
    "どちらかを選ばなければならないことはなかった。選ばないことが安全だったからだ。そして安全こそが、彼の築いてきたもののすべてだった。"

# game/script/ch10.rpy:142
translate japanese ch10_a558c23a:

    # "He understood, sitting there, that the case out in the snow was going to choose for him now, one way or the other, and that he was not going to like the cost of the answer."
    "座ったまま、彼は理解した。雪の向こうのこの事件が、これから彼の代わりに、どちらかに選ぶのだと。そしてその答えの代価を、自分は好きになれないだろうと。"

# game/script/ch10.rpy:143
translate japanese ch10_132701e2:

    # "Then he put out the cigarette, and took the tape tighter around his ribs, and went to find out what a dead man had been hiding."
    "それから煙草を消し、肋骨のテープをきつく巻き直し、死んだ男が何を隠していたのかを突き止めに出かけた。"

# game/script/ch10.rpy:152
translate japanese ch10_9c34cca4:

    # "The Bennett house had been searched once already, on the day of the arrest, in the fast and certain way of men who already know what they will find and only want it confirmed."
    "Bennettの家はすでに一度捜索されていた。逮捕の日に、何が見つかるかをもう知っていて、それを確かめたいだけの男たちの、速く確信に満ちたやり方で。"

# game/script/ch10.rpy:153
translate japanese ch10_dab4821c:

    # "Samuel had read that search in the file and known it for what it was. A formality. Boots through rooms, looking for the shape of a killer, and finding — because they were looking for it — the shape of a killer."
    "Samuelはその捜索を書類で読み、それが何であるかを見抜いていた。形式だ。部屋から部屋へ長靴が通り抜け、殺人者の形を探し、そして――探しているのだから――殺人者の形を見つけた。"

# game/script/ch10.rpy:154
translate japanese ch10_ba2c51de:

    # "Nobody had searched it the other way. Nobody had walked those rooms asking what an innocent man would leave behind."
    "逆のやり方で捜索した者はいなかった。罪のない男なら何を残していくか、そう問いながらあの部屋部屋を歩いた者はいなかった。"

# game/script/ch10.rpy:155
translate japanese ch10_9d1f9f57:

    # "That was what Samuel had come to do. He had the sealed-scene key from a county clerk who had handed it over gladly, glad to have the awkwardness of the Bennett house be somebody else's for an afternoon."
    "Samuelはそれをしに来たのだった。封鎖現場の鍵は、郡の事務員から受け取った。事務員は喜んで渡した。Bennettの家の厄介ごとが、午後のあいだだけでも誰か他人のものになるのが嬉しかったのだ。"

# game/script/ch10.rpy:160
translate japanese ch10_d872f6d7:

    # "The house met him with the particular silence of a place whose people are not coming back. The fire was long dead. The cold had got into everything."
    "家は、住人がもう戻らない場所に特有の沈黙で彼を迎えた。火はとうに消えていた。寒さがあらゆるものに染み込んでいた。"

# game/script/ch10.rpy:161
translate japanese ch10_c49f1c80:

    # "It was, even now, even empty, the most orderly house he had ever stood in."
    "今でも、空っぽになった今でも、それは彼がこれまで足を踏み入れたなかで最も整然とした家だった。"

# game/script/ch10.rpy:162
translate japanese ch10_164067fc:

    # "Every tool on its hook, every book squared to the shelf edge, the woodpile stacked to a plumb line under its tarp. A whole life kept in rigid trim against a world the old man had never for one day trusted."
    "道具はすべてそれぞれの鉤に掛かり、本はすべて棚の縁にそろえられ、薪の山は防水布の下で下げ振りの線どおりに積まれていた。老人が一日たりとも信用しなかった世界に抗って、ひとつの人生がまるごと厳格に整えられていた。"

# game/script/ch10.rpy:163
translate japanese ch10_9cdbce92:

    # "Samuel stood in the front room and let it talk to him the way scenes talked to him when he was patient."
    "Samuelは表の部屋に立ち、辛抱強くしているときに現場が語りかけてくるのと同じように、家に語らせた。"

# game/script/ch10.rpy:164
translate japanese ch10_d595aa49:

    # "And what it said, under the story of the killer, was a different and quieter thing."
    "そしてそれが語ったのは、殺人者の物語の下にある、別の、もっと静かなことだった。"

# game/script/ch10.rpy:165
translate japanese ch10_a6c5ac0d:

    # th "A man who was always ready to leave."
    th "いつでも出ていける用意をしていた男。"

# game/script/ch10.rpy:170
translate japanese ch10_1c4a9c33:

    # "He found the girl's room first, and stood in the doorway of it a moment, and did not go in."
    "最初に見つけたのは少女の部屋だった。彼はしばらく戸口に立ち、中には入らなかった。"

# game/script/ch10.rpy:171
translate japanese ch10_5c919659:

    # "It was an ordinary child's room. A narrow bed, made tight. A shelf of schoolbooks and, tucked at the end, softer-spined, a worn copy of {i}The Adventures of Tom Sawyer{/i}."
    "ありふれた子供の部屋だった。きっちり整えられた細いベッド。教科書の並んだ棚と、その端に押し込まれた、背の柔らかくなった、くたびれた{i}『トム・ソーヤーの冒険』{/i}。"

# game/script/ch10.rpy:172
translate japanese ch10_148bf3aa:

    # "Drawings, a few, pinned up. A bird. A long-eared dog. Done by some other child's hand, and kept."
    "絵が何枚か、ピンで留めてあった。鳥。耳の長い犬。どこか別の子供の手で描かれ、取っておかれたもの。"

# game/script/ch10.rpy:173
translate japanese ch10_d8ab98bf:

    # "Nothing out of place. Nothing hidden. Nothing that was not exactly what it appeared to be."
    "乱れているものは何もない。隠されているものも何もない。見えるとおりのものでないものは、何ひとつない。"

# game/script/ch10.rpy:174
translate japanese ch10_6906a2a3:

    # "The room of a twelve-year-old girl who had lost, in the space of a week, her only friend and the last of her family, and who was tonight asleep in a stranger's spare bed with none of it left."
    "一週間のうちに、たったひとりの友達と最後の家族を失った十二歳の少女の部屋。その少女は今夜、見知らぬ他人の客用ベッドで、何ひとつ残されずに眠っている。"

# game/script/ch10.rpy:175
translate japanese ch10_8774eddc:

    # "Samuel felt the old pull come up in him, hard. The thing he had spent thirteen years walling off: the pull toward a child who needed a wall between her and the world."
    "Samuelは、あの古い引力が自分の中に強くこみ上げてくるのを感じた。十三年かけて壁で囲ってきたもの。自分と世界のあいだに壁を必要としている子供へと向かう引力。"

# game/script/ch10.rpy:176
translate japanese ch10_046ac4e6:

    # "And he let it come, this once, because Martha had told him to and because he was too tired to fight it."
    "そして今回だけは、それがこみ上げるにまかせた。Marthaにそう言われたからであり、抗うには疲れすぎていたからだ。"

# game/script/ch10.rpy:177
translate japanese ch10_0bd70c49:

    # th "Whatever else I find in this house, that girl is going to need somebody to stand between her and what happens next."
    th "この家で他に何が見つかろうと、あの子にはこの先起こることとのあいだに立ってやる誰かが必要になる。"

# game/script/ch10.rpy:178
translate japanese ch10_e2c7d854:

    # th "George knew it. That's why he wouldn't talk. He was standing between her and something, right to the end."
    th "Georgeはそれを知っていた。だから口を割らなかった。最後の最後まで、あの子と何かのあいだに立っていたんだ。"

# game/script/ch10.rpy:179
translate japanese ch10_6a4a2160:

    # "He shut the door softly, the way you shut a door on someone sleeping, and went to work on the rest."
    "彼は眠っている人のいる部屋の扉を閉めるように、そっと扉を閉め、残りに取りかかった。"

# game/script/ch10.rpy:186
translate japanese ch10_d3f41350:

    # "He found it in the workshop, behind the trees, where the arrest-day search had logged {i}tools, sundry{/i} and moved on."
    "それは作業小屋で見つかった。木立の奥、逮捕の日の捜索が{i}工具、雑品{/i}とだけ記録して通り過ぎた場所で。"

# game/script/ch10.rpy:187
translate japanese ch10_c815c656:

    # "George Bennett had been good at this, the way he had been good at everything that kept him and the girl alive."
    "George Bennettはこういうことに長けていた。自分と少女を生かしておくためのあらゆることに長けていたのと同じように。"

# game/script/ch10.rpy:188
translate japanese ch10_2d1d02b1:

    # "But Samuel had been finding hidden things for thirty years, and the cold clear place in him was patient now. Methodical. Almost calm."
    "だがSamuelは三十年、隠されたものを見つけてきた。そして彼の中の冷たく澄んだ場所は、いま辛抱強かった。几帳面だった。ほとんど穏やかでさえあった。"

# game/script/ch10.rpy:198
translate japanese ch10_workshop_search_dc6c9db3:

    # "Tins of screws sorted by gauge. Chisels in a rack, edges oiled. He lifted every tin and ran his hand along every board. Nothing behind them but plank and frost."
    "太さ別に分けられたネジの缶。刃に油を引いた鑿が、ラックに並んでいる。缶をひとつ残らず持ち上げ、棚板の一枚一枚に手を這わせた。裏には板と霜のほか何もない。"

# game/script/ch10.rpy:203
translate japanese ch10_workshop_search_8c37efb8:

    # "He unstacked the top courses, one split log at a time, and stacked them back to the old man's plumb line. Wood, and cold, and the smell of resin. A woodpile was the first place anyone would look. George would know that."
    "上の段を、割った薪を一本ずつ崩し、老人の下げ振りの線どおりに積み直した。木と、冷気と、樹脂の匂い。薪の山は誰もが最初に探す場所だ。Georgeはそれを知っていただろう。"

# game/script/ch10.rpy:208
translate japanese ch10_workshop_search_25b6cdac:

    # "He got down on his knees, careful of the rib. The floor beneath the bench was swept clean."
    "肋骨に気をつけながら膝をついた。作業台の下の床はきれいに掃かれていた。"

# game/script/ch10.rpy:209
translate japanese ch10_workshop_search_bdc1fc22:

    # "But the back of the bench sat a little too far forward from the wall. Two inches. A careless man would never notice the depth."
    "だが作業台の背板は、壁からわずかに前へ出すぎていた。二インチ。不注意な男なら、その奥行きには決して気づかない。"

# game/script/ch10.rpy:210
translate japanese ch10_workshop_search_81e9aa2f:

    # th "Two inches is a lot of room, if you build it right."
    th "二インチあれば、うまく作ればかなり入る。"

# game/script/ch10.rpy:215
translate japanese ch10_workshop_search_aaa017cf:

    # "He reached in under the bench and knocked along the back panel, hand's width by hand's width."
    "作業台の下に手を差し入れ、背板を手のひらひとつ分ずつ叩いていった。"

# game/script/ch10.rpy:217
translate japanese ch10_workshop_search_30e885f0:

    # "He went along the walls knocking, hand's width by hand's width, listening, and found nothing until he got down under the workbench and knocked along its back."
    "壁沿いに、手のひらひとつ分ずつ耳を澄ませて叩いていったが、何も見つからなかった。作業台の下に潜り込み、その背を叩いていくまでは。"

# game/script/ch10.rpy:219
translate japanese ch10_workshop_search_6ced1e0c:

    # "The knock came back hollow."
    "返ってきた音は、空洞だった。"

# game/script/ch10.rpy:223
translate japanese ch10_workshop_found_80df26f2:

    # "It took him an hour, all told. Behind a false back he found by knocking: a fitted compartment a careless man would never have built and a hunted one always would."
    "全部で一時間かかった。叩いて見つけた偽の背板の奥に、ぴたりと造り付けた隠し場所があった。不注意な男なら決して造らず、追われる男なら必ず造るもの。"

# game/script/ch10.rpy:224
translate japanese ch10_workshop_found_bb155a3f:

    # "Inside it, a canvas duffel, packed."
    "その中に、荷を詰めた帆布のダッフルバッグ。"

# game/script/ch10.rpy:225
translate japanese ch10_workshop_found_59b15a70:

    # "He drew it out and opened it on the bench and stood over it a long time."
    "彼はそれを引き出して作業台の上で開け、長いあいだその前に立ち尽くした。"

# game/script/ch10.rpy:226
translate japanese ch10_workshop_found_0954f78f:

    # "Clothes for two. A man's and a child's, folded with the same rigid care as everything else, sized for winter."
    "二人分の衣類。男物と子供物。他のすべてと同じ厳格な手つきで畳まれ、冬に合わせた大きさのもの。"

# game/script/ch10.rpy:227
translate japanese ch10_workshop_found_cee3c08c:

    # "An envelope, thick, of cash. Used notes, non-sequential, the patient savings of a cash-only life. More than a handyman banks, and none of it in any bank."
    "分厚い現金の封筒。使い古しの、番号の続いていない紙幣。現金だけで暮らす人生の、辛抱強い蓄え。便利屋が貯めるには多すぎる額で、そのどれひとつ銀行には入っていない。"

# game/script/ch10.rpy:228
translate japanese ch10_workshop_found_28ae1937:

    # "A second envelope of documents he'd need a warrant and a week to make sense of. He did not need either to read the shape of them."
    "二つ目の封筒には書類。意味を読み解くには令状と一週間が要るだろう。だがその形を読むのに、どちらも要らなかった。"

# game/script/ch10.rpy:229
translate japanese ch10_workshop_found_05249443:

    # "The papers a man carries when the name he is using has to be left behind with the house."
    "いま使っている名前を家と一緒に置いていかなければならないときに、男が持ち歩く書類だ。"

# game/script/ch10.rpy:230
translate japanese ch10_workshop_found_f2df71f8:

    # "A folded road atlas. When he opened it the route was there, penciled faint, running south and west and off the edge of anywhere Samuel knew."
    "畳まれた道路地図帳。開くと、そこに道筋があった。鉛筆で薄く引かれ、南へ、西へと延び、Samuelの知るあらゆる場所の端から外へ出ていた。"

# game/script/ch10.rpy:231
translate japanese ch10_workshop_found_9690656f:

    # "It did not go back toward Driftwood. It went away from everything."
    "Driftwoodへ戻る道ではなかった。あらゆるものから遠ざかる道だった。"

# game/script/ch10.rpy:233
translate japanese ch10_workshop_found_77beb0aa:

    # note_voice "Packed bag for two. Cash. Papers. Route away from everything."
    note_voice "二人分の荷造り済みバッグ。現金。書類。すべてから遠ざかる道筋。"

# game/script/ch10.rpy:238
translate japanese ch10_workshop_found_8d2d15a5:

    # "And in the truck, when he checked it after — the impounded truck in the county lot, that no one had thought to look at as anything but a killer's vehicle — the tank was full."
    "そしてあとで確かめたトラックは――郡の保管所に押収されたまま、誰もが殺人者の車としか見ようとしなかったトラックは――燃料タンクが満タンだった。"

# game/script/ch10.rpy:239
translate japanese ch10_workshop_found_9be132e2:

    # "There were two more full cans lashed in the bed under a tarp."
    "荷台には防水布の下に、満杯の携行缶がさらに二つ縛りつけてあった。"

# game/script/ch10.rpy:240
translate japanese ch10_workshop_found_0fe1f736:

    # "The whole thing sat there fueled and ready like a horse saddled in a stall, waiting for a rider who was three days late and now was never coming."
    "すべてが燃料を満たし、用意を整えてそこにあった。厩の中で鞍を置かれた馬のように。三日遅れ、そしてもう決して来ることのない乗り手を待って。"

# game/script/ch10.rpy:242
translate japanese ch10_workshop_found_2df72ca5:

    # note_voice "Truck fueled + two cans."
    note_voice "トラック満タン＋携行缶二つ。"

# game/script/ch10.rpy:243
translate japanese ch10_workshop_found_001d8875:

    # "Samuel stood in the cold with the packed bag in his mind and felt the first plank of the closed case give under his weight."
    "Samuelは寒さの中に立ち、荷造りされたバッグを思い浮かべ、閉じた事件の最初の板が自分の重みでたわむのを感じた。"

# game/script/ch10.rpy:244
translate japanese ch10_workshop_found_24476de9:

    # th "A killer doesn't run."
    th "殺人者は逃げない。"

# game/script/ch10.rpy:245
translate japanese ch10_workshop_found_0a0c83c4:

    # "That was the thing, simple and enormous. Whoever had done these things had done them like a mission. Patient, ritual, righteous."
    "それだった。単純で、途方もないこと。これらをやった者は、使命のようにやっていた。辛抱強く、儀式的に、正義の名のもとに。"

# game/script/ch10.rpy:246
translate japanese ch10_workshop_found_0a8d7281:

    # "A man on a mission does not pack a bag for two and fuel a truck and pencil a road off the edge of the map. A man on a mission stays. He finishes."
    "使命を負った男は、二人分のバッグを詰めたりしない。トラックに燃料を入れたり、地図の端の外へ鉛筆で道を引いたりしない。使命を負った男は留まる。やり遂げる。"

# game/script/ch10.rpy:247
translate japanese ch10_workshop_found_6addb3a6:

    # "Fanatics do not flee mid-sermon. Hunted men flee. Frightened men flee. Men running from something flee."
    "狂信者は説教の途中で逃げ出さない。逃げるのは追われる者だ。怯える者だ。何かから逃げている者だ。"

# game/script/ch10.rpy:248
translate japanese ch10_workshop_found_37d556fe:

    # "George Bennett, in the last week of his life, had not been a man settling in to kill. He had been a man about to run for his life, and the girl's, and had been three days too slow."
    "人生最後の一週間のGeorge Bennettは、腰を据えて殺しにかかる男ではなかった。自分の命と少女の命を抱えて逃げ出そうとしている男であり、そして三日、遅すぎたのだ。"

# game/script/ch10.rpy:249
translate japanese ch10_workshop_found_9c6feefe:

    # th "Running from what?"
    th "何から逃げていた？"

# game/script/ch10.rpy:250
translate japanese ch10_workshop_found_07709a34:

    # "And under the thought, cold, the splinter he could not place turned over once and would not let itself be seen."
    "そしてその考えの下で、冷たく、正体のつかめない棘が一度だけ身をよじり、姿を見せようとはしなかった。"

# game/script/ch10.rpy:253
translate japanese ch10_workshop_found_97e1eda7:

    # "The bag told him George Bennett was a hunted man. It was the truck that told him George Bennett was innocent."
    "バッグは、George Bennettが追われる男だったと告げた。George Bennettが無実だと告げたのは、トラックのほうだった。"

# game/script/ch10.rpy:254
translate japanese ch10_workshop_found_850b0c6b:

    # "It did so in the ordinary handwriting of a fuel pump, because the past leaves its traces whether a man wants it to or not, and the deepest secret in the world cannot stop a machine from printing the time."
    "それは給油ポンプのありふれた筆跡で告げられた。過去は人が望もうと望むまいと痕跡を残すものであり、世界で最も深い秘密も、機械が時刻を印字するのを止めることはできないからだ。"

# game/script/ch10.rpy:255
translate japanese ch10_workshop_found_cee547f5:

    # "Having looked at the fuel, he did the thing thirty years had made a reflex and nobody else had bothered with: he searched the cab the way you search the cab of a man whose movements you actually want to know."
    "燃料を確かめたあと、彼は三十年で反射になり、他の誰も手間をかけなかったことをした。本当に足取りを知りたい男の運転席を探すやり方で、運転席を探したのだ。"

# game/script/ch10.rpy:265
translate japanese ch10_cab_search_99127ccb:

    # "A pencil stub. A folded rag. A tire gauge. In the passenger door, a child's hair tie, dark blue, worn thin. He held it a moment and put it back."
    "ちびた鉛筆。畳んだぼろ布。タイヤゲージ。助手席のドアポケットには、子供の髪留めがあった。濃い青の、すり切れて細くなったもの。彼はしばらくそれを手にして、元に戻した。"

# game/script/ch10.rpy:270
translate japanese ch10_cab_search_1f2bbb0f:

    # "Under the seats, under the mats, in the gap where the seat met the console where small paper things go to die. Grit. A bent nail. Nothing printed, nothing kept."
    "座席の下、マットの下、小さな紙切れが死にに行く、座席とコンソールの隙間。砂粒。曲がった釘。印字されたものは何もない。取っておかれたものは何もない。"

# game/script/ch10.rpy:277
translate japanese ch10_receipt_fbd9e32f:

    # "George Bennett kept his receipts. Of course he did. A man who trusts nothing keeps a record of everything."
    "George Bennettはレシートを取っておいていた。もちろんそうだ。何も信用しない男は、あらゆるものの記録を残す。"

# game/script/ch10.rpy:278
translate japanese ch10_receipt_487a5d90:

    # "And a cash man especially, a man with no card statement to reconstruct his life from, keeps the little printed proofs of where his money went."
    "とりわけ現金で暮らす男、自分の暮らしを再構成できるカードの明細を持たない男は、金の行き先を示す小さな印字の証拠を取っておくものだ。"

# game/script/ch10.rpy:279
translate japanese ch10_receipt_3ff3c677:

    # "There was a rubber-banded roll of them in the glovebox. Months of them. Fuel and hardware and feed."
    "グローブボックスに、輪ゴムで留めたレシートの束があった。何か月分も。燃料、金物、飼料。"

# game/script/ch10.rpy:280
translate japanese ch10_receipt_fbb87402:

    # "Samuel sat in the cold cab with his taped rib aching and went through them one by one in the gray afternoon light."
    "Samuelは冷えきった運転席に座り、テープを巻いた肋骨の痛みを抱えながら、灰色の午後の光のなかでそれを一枚ずつめくっていった。"

# game/script/ch10.rpy:282
translate japanese ch10_receipt_15e4b3a5:

    # "Near the middle of the roll, he stopped."
    "束の真ん中あたりで、彼の手が止まった。"

# game/script/ch10.rpy:286
translate japanese ch10_receipt_ab01421e:

    # "A diesel receipt. Thirty-one liters."
    "軽油のレシート。三十一リットル。"

# game/script/ch10.rpy:287
translate japanese ch10_receipt_d654e2a8:

    # "A station called Vale Cross Services. A lonely pump-and-shop on the far side of the gorge where the mountain road met the county highway."
    "Vale Cross Servicesという給油所。山道が郡道に合流する、峡谷の向こう側にぽつんとある、給油機と売店だけの店。"

# game/script/ch10.rpy:288
translate japanese ch10_receipt_2d853a29:

    # "Better than an hour from Greyvale by the only road that joined them. Twenty-five miles as the crow flew, and the crow could not drive."
    "Greyvaleから、両者を結ぶ唯一の道を通って優に一時間以上。直線距離で二十五マイル。そしてカラスは車を運転できない。"

# game/script/ch10.rpy:289
translate japanese ch10_receipt_7191548a:

    # "And the date on it was the date Emily Carter died."
    "そしてそこにある日付は、Emily Carterが死んだ日だった。"

# game/script/ch10.rpy:291
translate japanese ch10_receipt_d8b78c00:

    # "And the time stamped under the date, in the small honest type of a machine that has never in its life told a lie or protected anyone, was 11:52 p.m."
    "そして日付の下に刻まれた時刻は――生まれてから一度も嘘をついたことも、誰かをかばったこともない機械の、小さく正直な活字で――午後十一時五十二分だった。"

# game/script/ch10.rpy:293
translate japanese ch10_receipt_901d174d:

    # note_voice "Vale Cross Services — 31 L — 11:52 p.m. — night of E.C."
    note_voice "Vale Cross Services ― 31L ― 午後11時52分 ― E.C.の夜"

# game/script/ch10.rpy:295
translate japanese ch10_receipt_003600e0:

    # "Samuel sat very still. He knew the window. He had built the window himself."
    "Samuelはじっと動かずに座っていた。時間の枠はわかっていた。その枠は、彼自身が組み立てたものだった。"

# game/script/ch10.rpy:296
translate japanese ch10_receipt_f7a5f7bc:

    # "Out of the medical examiner's estimate, and the snow on the body, and the cooling, and the girl's own testimony. {i}I heard him leave. I heard him come home after two.{/i}"
    "検死官の推定から、遺体にかかった雪から、体温の低下から、そして少女自身の証言から。{i}出ていくのが聞こえました。二時過ぎに帰ってくるのが聞こえました。{/i}"

# game/script/ch10.rpy:297
translate japanese ch10_receipt_017a48bc:

    # "Emily Carter had been walked to a cemetery and given a poisoned cup and laid out in the snow between eleven and half past midnight. Tightest, the examiner had said, around midnight."
    "Emily Carterは墓地へと歩かされ、毒の入った杯を与えられ、十一時から零時半のあいだに雪の上に横たえられた。最も絞り込めば零時前後、と検死官は言っていた。"

# game/script/ch10.rpy:298
translate japanese ch10_receipt_b7f9148a:

    # "At 11:52 that night, George Bennett's truck had been twenty-five miles away on the wrong side of the gorge, taking on diesel at a lonely pump."
    "その夜の十一時五十二分、George Bennettのトラックは二十五マイル離れた峡谷の向こう側で、寂しい給油機から軽油を入れていた。"

# game/script/ch10.rpy:299
translate japanese ch10_receipt_6ac08aca:

    # "He could not have been in both places. No one could. The road did not allow it. The clock did not allow it."
    "両方の場所にいることはできなかった。誰にもできない。道がそれを許さない。時計がそれを許さない。"

# game/script/ch10.rpy:300
translate japanese ch10_receipt_29c7fe5c:

    # th "George Bennett did not kill Emily Carter. He was buying fuel to run."
    th "George BennettはEmily Carterを殺していない。逃げるための燃料を買っていたんだ。"

# game/script/ch10.rpy:301
translate japanese ch10_receipt_ec3abab2:

    # "Samuel did not put the receipt back in the roll. He took an evidence sleeve from his coat and slid it in and sealed it."
    "Samuelはそのレシートを束に戻さなかった。コートから証拠品袋を取り出し、それを滑り込ませて封をした。"

# game/script/ch10.rpy:302
translate japanese ch10_receipt_eff2837a:

    # "He wrote the date and the place and his own initials across the seal in a hand that had gone very steady, the way it always went steady when the rest of him had begun, somewhere underneath, to shake."
    "封の上に日付と場所と自分のイニシャルを書いた。手はひどく落ち着いていた。自分の残りのどこか奥底が震えはじめたとき、手はいつもそうして落ち着くのだった。"

# game/script/ch10.rpy:303
translate japanese ch10_receipt_94401810:

    # "This did not go back in a glovebox in a county lot, where a tidy office that wanted the case closed could lose it by accident."
    "これは郡の保管所のグローブボックスには戻さない。事件を閉じたがっている几帳面な役所が、うっかり失くしてしまえる場所には。"

# game/script/ch10.rpy:304
translate japanese ch10_receipt_5acb843a:

    # "It went in his breast pocket, over the taped rib, and it stayed there."
    "それは胸ポケットに収まった。テープを巻いた肋骨の上に。そしてそこに留まった。"

# game/script/ch10.rpy:311
translate japanese ch10_receipt_8b61b690:

    # "Samuel drove out to Vale Cross that same afternoon, because a receipt is a piece of paper, and a man who has just watched a town kill an innocent over pieces of paper wants more than paper."
    "Samuelはその日の午後のうちにVale Crossへ車を走らせた。レシートは紙切れにすぎず、町が紙切れのために無実の人間を殺すのを見たばかりの男は、紙以上のものを求めるからだ。"

# game/script/ch10.rpy:312
translate japanese ch10_receipt_63c7491b:

    # "The road took him an hour and ten, the gorge dropping away black beside him the whole way."
    "道のりは一時間十分かかった。そのあいだずっと、峡谷が傍らで黒く落ち込んでいた。"

# game/script/ch10.rpy:319
translate japanese ch10_receipt_9a343c0b:

    # "The station was exactly what the receipt had promised. A single island of light in a great deal of dark. One pump island, one sleepy attendant, one camera bolted under the eave."
    "給油所はレシートが約束したとおりの場所だった。膨大な闇の中の、ひとつきりの光の島。給油機の島がひとつ、眠たげな店員がひとり、軒下にボルトで留めたカメラがひとつ。"

# game/script/ch10.rpy:320
translate japanese ch10_receipt_5fb095da:

    # "The attendant was a boy of maybe nineteen, and he remembered."
    "店員はせいぜい十九の若者で、そして覚えていた。"

# game/script/ch10.rpy:321
translate japanese ch10_receipt_e046d0d2:

    # "You did not forget much out there on the graveyard shift. A face was an event, and a face on a night like that one, with the whole mountain snowed in, was an event you kept."
    "あんな場所の深夜番では、忘れることはあまりない。顔ひとつがひとつの出来事であり、山じゅうが雪に閉ざされたあんな夜の顔は、記憶に留めておく出来事だった。"

# game/script/ch10.rpy:322
translate japanese ch10_receipt_d2904b0f:

    # att "Old fella. Sure."
    att "じいさんだろ。ああ、覚えてる。"

# game/script/ch10.rpy:323
translate japanese ch10_receipt_3d9a415c:

    # att "Big, gray, didn't talk. Paid cash — counted it out exact, which you don't see."
    att "でかくて、白髪で、しゃべらなかった。現金で払ったよ――きっちり数えて出してさ、そういう客はまずいない。"

# game/script/ch10.rpy:324
translate japanese ch10_receipt_2a9f8f30:

    # att "Filled his tank and two cans in the bed, and stood there while it ran. Out by the pump, not in the warm. Just... standing. Watching the road he'd come off of, back toward the pass."
    att "タンクと、荷台の缶二つを満タンにして、入れてるあいだずっと突っ立ってた。暖かい中じゃなくて、給油機のとこに。ただ……立ってた。来た道のほうを、峠のほうを見ながら。"

# game/script/ch10.rpy:325
translate japanese ch10_receipt_a66be595:

    # "He frowned, remembering."
    "思い出しながら、彼は眉を寄せた。"

# game/script/ch10.rpy:326
translate japanese ch10_receipt_d4ea2833:

    # att "Thought at the time he looked like a man waiting for something to catch up to him."
    att "そのとき思ったんだ。何かに追いつかれるのを待ってる男みたいだなって。"

# game/script/ch10.rpy:331
translate japanese ch10_receipt_ea992d28:

    # "Sure. Certain the way witnesses almost never were, with no search upward for the memory. Nobody had told this boy what to remember."
    "確かだ。証人がほとんど決してそうはならない確かさだった。記憶を探して目が上を向くこともない。この若者に、何を覚えておけと吹き込んだ者はいなかった。"

# game/script/ch10.rpy:336
translate japanese ch10_receipt_1eb15f5d:

    # s "You'd have footage."
    s "映像があるだろう。"

# game/script/ch10.rpy:337
translate japanese ch10_receipt_f84f0b60:

    # att "I mean... I'm not really supposed to — the owner, he..."
    att "いや……俺、ほんとはそういうの――オーナーが、その……"

# game/script/ch10.rpy:341
translate japanese ch10_receipt_abc47f76:

    # s tired "I know. I'm asking anyway. A man died because nobody looked. I'd like to look."
    s tired "わかってる。それでも頼んでいる。誰も見なかったせいで人がひとり死んだ。私は見たいんだ。"

# game/script/ch10.rpy:342
translate japanese ch10_receipt_8f8e69fe:

    # "The boy studied him, the taped way he held himself, the tired face. Then he nodded, slowly."
    "若者は彼をじっと見た。テープで固めたような身のこなし、疲れた顔。それから、ゆっくりとうなずいた。"

# game/script/ch10.rpy:343
translate japanese ch10_receipt_3f7da39a:

    # att "...Yeah. Okay. Back here."
    att "……わかった。いいよ。奥だ。"

# game/script/ch10.rpy:345
translate japanese ch10_receipt_64a69fd8:

    # s "It's in the back office, I'd guess. Let's go and have a look."
    s "奥の事務所だろう。見に行こうか。"

# game/script/ch10.rpy:346
translate japanese ch10_receipt_99f47595:

    # "Samuel did not raise his voice. He had learned thirty years ago how to be given the thing he had no paper to demand: a quiet certainty, a way of making the giving feel like the natural course of the world."
    "Samuelは声を荒げなかった。三十年前に覚えたのだ。要求する書類のないものを差し出させる方法を。静かな確信。差し出すことが世の自然な成り行きのように感じさせるやり方を。"

# game/script/ch10.rpy:347
translate japanese ch10_receipt_d11c6d38:

    # "He was already walking. The boy found himself following."
    "彼はもう歩き出していた。若者は気づけばあとをついていっていた。"

# game/script/ch10.rpy:348
translate japanese ch10_receipt_daddf9b5:

    # att "...It's — yeah. Back here."
    att "……あの――うん。奥だよ。"

# game/script/ch10.rpy:350
translate japanese ch10_receipt_ff6a4113:

    # "They stood together in the cramped back office, and the boy scrubbed the file back through its cold hours until a shape came up out of the gray."
    "二人は狭い奥の事務所に並んで立ち、若者は冷たい時間の中を映像ファイルで巻き戻していった。やがて灰色の中から、ひとつの形が浮かび上がった。"

# game/script/ch10.rpy:351
translate japanese ch10_receipt_e28df8d9:

    # "George Bennett. Nineteen seconds of him."
    "George Bennett。十九秒間の彼。"

# game/script/ch10.rpy:352
translate japanese ch10_receipt_4920e076:

    # "Standing at the pump on the wrong side of the mountain at 11:51 at night, the timestamp ticking in the corner. Alive and alone and unhurried."
    "山の反対側の給油機の前に、夜の十一時五十一分に立っている。隅でタイムスタンプが時を刻んでいる。生きて、ひとりで、急ぐ様子もなく。"

# game/script/ch10.rpy:353
translate japanese ch10_receipt_b558d05a:

    # "The diesel running into his tank, while an hour's hard road away, in a cemetery he could not possibly reach, a girl he was going to be hanged for was being laid out in the snow by somebody else's hands."
    "軽油が彼のタンクに流れ込んでいく。そのあいだ、険しい道を一時間行った先の、彼にはどうやっても辿り着けない墓地で、彼がそのために吊るされることになる少女が、誰か別の者の手で雪の上に横たえられていた。"

# game/script/ch10.rpy:355
translate japanese ch10_receipt_d0a24100:

    # note_voice "Footage: G.B. at the pump, 11:51. 25 miles from the cemetery."
    note_voice "映像：G.B.、給油機前、11時51分。墓地から25マイル。"

# game/script/ch10.rpy:356
translate japanese ch10_receipt_30a7866f:

    # "Samuel watched the nineteen seconds four times."
    "Samuelはその十九秒を四回見た。"

# game/script/ch10.rpy:357
translate japanese ch10_receipt_04b12f10:

    # "The boy watched him watch it, and something in the detective's face made him go quiet and stop offering to help."
    "若者は彼が見るのを見ていた。そして刑事の顔にある何かが、若者を黙らせ、手伝いを申し出るのをやめさせた。"

# game/script/ch10.rpy:358
translate japanese ch10_receipt_a1a74ece:

    # s "Copy it. The whole hour, not just the nineteen seconds. Timestamp and all."
    s "コピーしてくれ。十九秒だけじゃない、一時間まるごと。タイムスタンプごと。"

# game/script/ch10.rpy:359
translate japanese ch10_receipt_1c24bd53:

    # "He put a drive from his own pocket on the desk, and watched the boy do it, and took the drive."
    "彼は自分のポケットから出したドライブを机に置き、若者がコピーするのを見届け、ドライブを受け取った。"

# game/script/ch10.rpy:360
translate japanese ch10_receipt_8ac9f8ab:

    # "He wrote the boy's name and the station and the date in his notebook, against the day someone would tell him none of this had ever existed."
    "若者の名前と給油所と日付を手帳に書き留めた。誰かがいつか、こんなものは最初から存在しなかったと言い出す日に備えて。"

# game/script/ch10.rpy:361
translate japanese ch10_receipt_60cd3038:

    # "He was not going to leave the one proof of an innocent man's innocence on a hard disk in a shed on the far side of a gorge, to be wiped in ninety days when the loop came round."
    "罪のない男の無実を示すたったひとつの証拠を、峡谷の向こうの小屋のハードディスクに置き去りにして、九十日後に録画が一巡したとき消されるにまかせるつもりはなかった。"

# game/script/ch10.rpy:362
translate japanese ch10_receipt_acdefad2:

    # s soft "Thank you."
    s soft "ありがとう。"

# game/script/ch10.rpy:363
translate japanese ch10_receipt_e5f44dbc:

    # "Then he got back in his car, and sat in the island of light with the engine off and the cold coming in through the glass, and did not drive anywhere at all for a long while."
    "それから車に戻り、エンジンを切ったまま光の島に座り込んだ。ガラス越しに冷気が忍び込んできた。長いあいだ、彼はどこへも車を出さなかった。"

# game/script/ch10.rpy:370
translate japanese ch10_receipt_fc346410:

    # s hurt "An innocent man is dead."
    s hurt "罪のない男が死んだ。"

# game/script/ch10.rpy:371
translate japanese ch10_receipt_ff90ba4f:

    # "He made himself say it plainly, sitting there in the dark, because the mind will do anything to avoid a sentence like that, and his had already begun to reach for the softenings."
    "闇の中に座ったまま、彼はそれをはっきりと口にさせた。人の心はそういう文をなんとしても避けようとするものであり、彼の心はもう、和らげる言葉に手を伸ばしはじめていたからだ。"

# game/script/ch10.rpy:372
translate japanese ch10_receipt_06a25e75:

    # th "You couldn't have known. The evidence was overwhelming. You tried to stop the road."
    th "知りようがなかった。証拠は圧倒的だった。あの道で止めようとしたじゃないか。"

# game/script/ch10.rpy:373
translate japanese ch10_receipt_7c66dade:

    # "He took each softening as it came and set it aside, because he had never in his life allowed a witness to hide behind a softening, and he would not allow himself."
    "和らげる言葉がやって来るたび、彼はひとつずつ脇へどけた。証人が和らげる言葉の陰に隠れるのを、彼は生涯一度も許したことがなかった。自分にも許すつもりはなかった。"

# game/script/ch10.rpy:374
translate japanese ch10_receipt_b5511e5d:

    # "An innocent man was dead. He had put him in the cell that made him a target."
    "罪のない男が死んだ。彼を標的にした独房に入れたのは、自分だった。"

# game/script/ch10.rpy:375
translate japanese ch10_receipt_174aacfc:

    # "His arrest, his case, his certainty, had handed a frightened town the face it needed, and the town had done the rest."
    "彼の逮捕が、彼の事件が、彼の確信が、怯えた町に必要な顔を差し出し、残りは町がやった。"

# game/script/ch10.rpy:376
translate japanese ch10_receipt_37059c5b:

    # "George Bennett had gone into the ground guilty of nothing but the crime of being unlucky enough to be strange in a place that was afraid."
    "George Bennettは何の罪もなく土に入った。怯えている場所で、運悪く風変わりだったという罪のほかには。"

# game/script/ch10.rpy:377
translate japanese ch10_receipt_4c21e5cd:

    # "That was on Samuel. Not only on him — on Doyle, on the county, on the paper, on fifty pairs of hands in a road — but on him, first and most."
    "それはSamuelの責任だった。彼ひとりのではない――Doyleの、郡の、新聞の、道の上の五十組の手の責任でもある――だが誰より先に、誰より重く、彼の責任だった。"

# game/script/ch10.rpy:378
translate japanese ch10_receipt_aa569d31:

    # "Because he was the one who was supposed to be better than all of them at the true things. And this time, in the one place it mattered, he had not been."
    "本当のことにかけて誰よりも上であるはずなのは、彼だったからだ。そして今回、それが肝心だったただひとつの場所で、彼はそうではなかった。"

# game/script/ch10.rpy:380
translate japanese ch10_receipt_5598cd99:

    # note_voice "George Bennett did not kill Emily Carter."
    note_voice "George BennettはEmily Carterを殺していない。"

# game/script/ch10.rpy:382
translate japanese ch10_receipt_2501b451:

    # "The old grief came up to meet the new one, the way it always did, the way water finds water."
    "古い悲しみが、新しい悲しみを迎えに上がってきた。いつもそうだったように。水が水を見つけるように。"

# game/script/ch10.rpy:387
translate japanese ch10_receipt_9704fc06:

    # "He was thirty-four again, and it was a different winter, and the coffin was so small the man from the funeral home had carried it under one arm."
    "彼は再び三十四歳で、それは別の冬で、棺はあまりに小さく、葬儀社の男は片腕に抱えて運んだ。"

# game/script/ch10.rpy:388
translate japanese ch10_receipt_97c5fa63:

    # "The way you carry a parcel. The way you carry nothing at all."
    "小包を運ぶように。何も運んでいないかのように。"

# game/script/ch10.rpy:389
translate japanese ch10_receipt_6720751c:

    # "Thomas. Eleven weeks old."
    "Thomas。生後十一週。"

# game/script/ch10.rpy:390
translate japanese ch10_receipt_af45c25f:

    # "He had gone down for his morning sleep in a warm room that smelled of milk and had simply, in the ordinary quiet of it, not woken up."
    "ミルクの匂いのする暖かい部屋で朝の昼寝に入り、そのありふれた静けさのなかで、ただ、目を覚まさなかった。"

# game/script/ch10.rpy:391
translate japanese ch10_receipt_eab9a9f4:

    # "There was a word for that. An acronym, four clean letters the doctors said in the gentle careful voice they kept for the thing they could not explain."
    "それには名前があった。頭文字を並べた略語。説明のつかないもののためにとっておく、穏やかで慎重な声で医師たちが口にする、四つのきれいな文字。"

# game/script/ch10.rpy:392
translate japanese ch10_receipt_f54874b7:

    # "As if a word that fit on a form could hold what had happened."
    "書類の欄に収まる言葉が、起きたことを受けとめられるとでもいうように。"

# game/script/ch10.rpy:393
translate japanese ch10_receipt_5aa3d5c6:

    # "Samuel had stood in the hospital corridor and listened to the four letters and understood, with a detective's terrible clarity, that no one had done this."
    "Samuelは病院の廊下に立ってその四文字を聞き、刑事の恐ろしいほどの明晰さで理解した。誰がこれをしたのでもないのだと。"

# game/script/ch10.rpy:394
translate japanese ch10_receipt_3f110702:

    # "That there was no one to find, no door to kick, no hand to put the cuffs on."
    "見つけ出す相手はいない。蹴破る扉もない。手錠をかける手もない。"

# game/script/ch10.rpy:395
translate japanese ch10_receipt_efbe7034:

    # "That the world had simply reached into the one warm room he had and taken the one thing in it, for no reason, and would not be answering questions."
    "世界はただ、彼の持っていたたったひとつの暖かい部屋に手を伸ばし、その中のたったひとつのものを、理由もなく奪い去り、問いに答えるつもりもないのだと。"

# game/script/ch10.rpy:399
translate japanese ch10_receipt_eb75b5ab:

    # "And at the grave, three days later, in the cold, Claire had gone down onto her knees in the wet dirt and howled."
    "そして三日後、寒さの中の墓前で、Claireは濡れた土の上に膝から崩れ落ち、獣のように叫んだ。"

# game/script/ch10.rpy:400
translate japanese ch10_receipt_7c6f101a:

    # "A sound he still heard. A sound with no bottom to it. Her hands in the earth, as though she could dig the box back up."
    "今も聞こえる声。底のない声。土に突っ込まれた彼女の両手。まるであの箱を掘り返せるとでもいうように。"

# game/script/ch10.rpy:401
translate japanese ch10_receipt_d3ec9c1c:

    # "Every other soul at that graveside had wept. Her mother. His own mother. The priest whose voice broke on the words. All of them undone, holding one another, letting it out into the rain."
    "墓のそばにいた他の誰もが泣いた。彼女の母親も。彼自身の母親も。祈りの言葉の途中で声を詰まらせた司祭も。皆が崩れ、互いに抱き合い、雨の中へそれを吐き出していた。"

# game/script/ch10.rpy:402
translate japanese ch10_receipt_818a2d87:

    # "And Samuel had stood a little apart from all of it, dry-eyed, upright, his hands at his sides, and watched the small box go down into the ground, and had not wept."
    "そしてSamuelは、そのすべてから少し離れて立っていた。乾いた目で、背筋を伸ばし、両手を脇に下ろしたまま、小さな箱が土の中へ下りていくのを見つめ、泣かなかった。"

# game/script/ch10.rpy:403
translate japanese ch10_receipt_24799190:

    # "Could not. Had felt the grief come to the door of him, enormous, and had felt something in him meet it there and hold the door shut."
    "泣けなかった。悲しみが巨大な姿で自分の戸口までやって来るのを感じ、自分の中の何かがそこでそれを迎え、扉を押さえて閉ざしておくのを感じた。"

# game/script/ch10.rpy:404
translate japanese ch10_receipt_766d63b7:

    # "He had understood, standing in the rain while his wife screamed his son's name into the mud, that he had made a decision he would never be able to unmake."
    "妻が泥に向かって息子の名を叫ぶあいだ、雨の中に立ちながら、彼は理解した。自分は決して取り消せない決断をしたのだと。"

# game/script/ch10.rpy:405
translate japanese ch10_receipt_a6c82e7a:

    # "That a man who let that door open would die of what came through it. And that he intended to live."
    "あの扉を開けた男は、そこから入ってくるもので死ぬ。そして自分は、生きるつもりなのだと。"

# game/script/ch10.rpy:406
translate japanese ch10_receipt_06a6eab7:

    # "Claire had looked up at him once, from her knees, her face ruined, and seen him standing there with his dry eyes and his straight back."
    "Claireは一度だけ、膝をついたまま、崩れた顔で彼を見上げた。そして乾いた目とまっすぐな背中でそこに立つ彼を見た。"

# game/script/ch10.rpy:407
translate japanese ch10_receipt_37a275e5:

    # "Something had gone out of her face when she looked at him that never came back into it."
    "彼を見たとき、彼女の顔から何かが去り、それは二度と戻らなかった。"

# game/script/ch10.rpy:408
translate japanese ch10_receipt_54cfed57:

    # "The marriage was over from that moment, though it took two more years to admit it, because a woman cannot stay married to a wall, however good the wall's reasons."
    "結婚はその瞬間に終わっていた。それを認めるのにさらに二年かかったとしても。女は壁と結婚したままではいられない。壁の理由がどれほど立派であろうと。"

# game/script/ch10.rpy:409
translate japanese ch10_receipt_7841405d:

    # "That was the day Samuel Harris learned the lesson he had spent thirteen years refusing to unlearn: that to love a thing was to be handed, someday, the unbearable bill for it."
    "それが、Samuel Harrisがひとつの教訓を学んだ日だった。その後十三年かけて、学び直すことを拒んできた教訓を。何かを愛するということは、いつか、そのための耐えがたい請求書を手渡されることなのだと。"

# game/script/ch10.rpy:410
translate japanese ch10_receipt_93aefe85:

    # "And that the only safe man was the man who never signed."
    "そして安全な男とは、決して署名しない男だけなのだと。"

# game/script/ch10.rpy:414
translate japanese ch10_receipt_4a952de9:

    # "He had run his whole life on that arithmetic since. And here was where it had brought him."
    "それ以来、彼は人生のすべてをその計算で動かしてきた。そしてそれが彼を連れてきたのが、ここだった。"

# game/script/ch10.rpy:415
translate japanese ch10_receipt_c774c442:

    # "To an island of light on a mountain road, having failed, again, catastrophically, to protect the very thing he had told himself he was too careful to lose."
    "山道の光の島。またしても、破滅的なまでに、守りそこねたあとで。用心深すぎて失うはずがないと自分に言い聞かせてきた、まさにそのものを。"

# game/script/ch10.rpy:416
translate japanese ch10_receipt_07c27bee:

    # th "Caring is the weakness."
    th "誰かを想うことは、弱さだ。"

# game/script/ch10.rpy:417
translate japanese ch10_receipt_7c82ec3d:

    # "So said thirteen years of him."
    "十三年分の彼が、そう言った。"

# game/script/ch10.rpy:418
translate japanese ch10_receipt_bb846db7:

    # "{i}Caring was the only thing that ever made you good,{/i} said Martha. And said, from further back, a woman kneeling in the dirt he had not been able to kneel in beside."
    "{i}あなたを良くしてきたのは、誰かを想う気持ちだけだったのよ{/i}、とMarthaは言った。そしてもっと遠い昔から、土の上に膝をついた女が言った。彼がその傍らに膝をつくことのできなかった土の上で。"

# game/script/ch10.rpy:419
translate japanese ch10_receipt_269ac907:

    # "He did not know which of them was right. But he knew the case had stopped being about George Bennett."
    "どちらが正しいのか、彼にはわからなかった。だが、事件がもうGeorge Bennettについてのものではなくなったことはわかっていた。"

# game/script/ch10.rpy:423
translate japanese ch10_receipt_8c6c1ca3:

    # "Because if George had not done it — and George had not done it, the clock did not lie — then someone had."
    "Georgeがやったのでないなら――そしてGeorgeはやっていない、時計は嘘をつかない――誰かがやったのだ。"

# game/script/ch10.rpy:424
translate japanese ch10_receipt_978a7148:

    # "Someone was still out there in that white valley. Someone who had walked a teacher onto a roof and folded a shopkeeper over his counter and dropped a priest in front of his church and laid a girl of fourteen in the snow."
    "誰かがまだ、あの白い谷のどこかにいる。教師を屋上へと歩かせ、店主をカウンターに突っ伏させ、司祭を教会の前で倒し、十四歳の少女を雪の上に横たえた誰かが。"

# game/script/ch10.rpy:425
translate japanese ch10_receipt_392623a2:

    # "And who had done one more thing besides, the cleverest and coldest thing of all."
    "そしてその誰かは、さらにもうひとつのことをしていた。何よりも巧妙で、何よりも冷たいことを。"

# game/script/ch10.rpy:426
translate japanese ch10_receipt_26e02647:

    # "Had reached into all of it and arranged every piece so that it pointed, patiently, unmistakably, at George Bennett."
    "そのすべてに手を伸ばし、一つ一つの駒を並べ替え、辛抱強く、紛れもなく、George Bennettを指すようにしたのだ。"

# game/script/ch10.rpy:427
translate japanese ch10_receipt_b3b71d1b:

    # "The notes in the cult tongue George's people spoke. The killings at the sites George's handyman rounds had touched. The preparations, the leaving, the whole shape of a strange secretive man."
    "Georgeの一族が話していた教団の言葉で書かれたメモ。Georgeが便利屋の仕事で回っていた場所での殺し。準備、出立、風変わりで秘密めいた男の、その姿のすべて。"

# game/script/ch10.rpy:428
translate japanese ch10_receipt_5cfbb2a6:

    # "Handed to Samuel not as evidence he had dug up, but as evidence he had been given. A trail laid down for a detective to follow."
    "Samuelが掘り出した証拠としてではなく、与えられた証拠として手渡されたもの。刑事に辿らせるために敷かれた跡。"

# game/script/ch10.rpy:429
translate japanese ch10_receipt_5241ed33:

    # "And he had followed it like a good dog, all the way to a rope."
    "そして彼は利口な犬のようにそれを辿った。縄に至るまで、ずっと。"

# game/script/ch10.rpy:431
translate japanese ch10_receipt_29503112:

    # th "I was steered."
    th "俺は誘導された。"

# game/script/ch10.rpy:433
translate japanese ch10_receipt_23c11377:

    # note_voice "I was steered."
    note_voice "誘導された。"

# game/script/ch10.rpy:434
translate japanese ch10_receipt_c822c2ff:

    # "The knowing of it went through him cold and total."
    "その認識は、冷たく、余すところなく彼を貫いた。"

# game/script/ch10.rpy:435
translate japanese ch10_receipt_e6ee8d9b:

    # "Every arrow that had ever pointed at George had been placed by a hand that knew exactly what a detective's eye would leap to."
    "Georgeを指したすべての矢印は、刑事の目が何に飛びつくかを正確に知っている手によって置かれていた。"

# game/script/ch10.rpy:436
translate japanese ch10_receipt_c30d2b44:

    # "And that hand had known the movements of these victims, and the language of that dead cult, and the private history of the Bennett house."
    "そしてその手は、被害者たちの動きを知っていた。あの滅びた教団の言葉を知っていた。Bennett家の内々の過去を知っていた。"

# game/script/ch10.rpy:437
translate japanese ch10_receipt_231d343b:

    # "It had been close enough to all of it, unseen, to reach into the case itself and lay the trail down clean and patient and pointing one single way —"
    "そのすべてに、人目につかず近づける場所にいた。事件そのものに手を差し入れ、きれいに、辛抱強く、ただひとつの方向を指す跡を敷けるほど近くに――"

# game/script/ch10.rpy:438
translate japanese ch10_receipt_cea2f875:

    # "The thought reached its edge, and there, at the edge, it stopped."
    "思考はその縁まで達し、そこで、縁で、止まった。"

# game/script/ch10.rpy:439
translate japanese ch10_receipt_6d57ff6b:

    # "It stopped the way a man's foot stops at a drop in the dark, some older sense throwing out a hand before the mind has seen the ground fall away."
    "闇の中で人の足が段差の前で止まるように止まった。心が地面の落ち込むのを見るより先に、もっと古い感覚が手を突き出したのだ。"

# game/script/ch10.rpy:440
translate japanese ch10_receipt_79ea9f9b:

    # "There was a shape at the center of it. He could feel the whole apparatus of the frame turning around a single point, the way a wheel turns around a hub."
    "その中心には、ひとつの形があった。枠組みの仕掛け全体が一点を軸に回っているのを、彼は感じることができた。車輪がハブを軸に回るように。"

# game/script/ch10.rpy:441
translate japanese ch10_receipt_c47ac5e2:

    # "And every time his mind moved toward the hub it slid off, baffled, and landed somewhere safe and wrong."
    "そして心がハブへ向かうたびに、それは滑ってそれ、戸惑い、安全で間違った場所へ着地した。"

# game/script/ch10.rpy:446
translate japanese ch10_receipt_2e2514c6:

    # "He made himself turn toward it. For one second the hub almost had a shape: small, and quiet, and sitting very straight in his passenger seat, gray eyes on the dark road —"
    "彼は無理やりそちらへ向き直った。一瞬、ハブはほとんど形をなしかけた。小さく、静かで、彼の車の助手席に背筋をまっすぐ伸ばして座り、灰色の目を暗い道に向けている――"

# game/script/ch10.rpy:447
translate japanese ch10_receipt_72de297a:

    # "And then the shape was gone, slid out from under his looking like a coin under ice."
    "そして形は消えた。氷の下のコインのように、彼の視線の下から滑り抜けていった。"

# game/script/ch10.rpy:449
translate japanese ch10_receipt_0bf80b74:

    # "He let it go. He was too tired to chase a shape he couldn't see."
    "彼はそれを手放した。見えない形を追うには疲れすぎていた。"

# game/script/ch10.rpy:452
translate japanese ch10_receipt_5408dea6:

    # "He was tired. He was hurt. He had watched a man beaten to death and not slept since. He told himself these things."
    "疲れていた。傷を負っていた。男が殴り殺されるのを見て、それ以来眠っていない。彼は自分にそう言い聞かせた。"

# game/script/ch10.rpy:453
translate japanese ch10_receipt_446f09a9:

    # "And under them the truth was simpler and worse: that the hub of the wheel was small, and quiet, and twelve years old, and had wept in his passenger seat."
    "そしてその下にある真実は、もっと単純で、もっと悪かった。車輪のハブは小さく、静かで、十二歳で、彼の助手席で泣いたのだと。"

# game/script/ch10.rpy:454
translate japanese ch10_receipt_9d0a6a02:

    # "And that Samuel Harris had a place in him worn exactly to the shape of a child, that no evidence on earth could make him look straight at."
    "そしてSamuel Harrisの中には、子供の形にぴったりとすり減った場所があり、地上のどんな証拠も、彼にそこをまっすぐ見させることはできないのだと。"

# game/script/ch10.rpy:455
translate japanese ch10_receipt_154d4f9c:

    # "So he did not look at it. He looked, instead, where thirteen years had taught him to look, and what he found there was not suspicion but its terrible opposite."
    "だから彼はそれを見なかった。代わりに十三年が見るよう教えてきた場所を見た。そしてそこで見つけたのは疑いではなく、その恐ろしい反対のものだった。"

# game/script/ch10.rpy:456
translate japanese ch10_receipt_4a865320:

    # "Duty."
    "義務。"

# game/script/ch10.rpy:457
translate japanese ch10_receipt_5502514b:

    # th "George died protecting her."
    th "Georgeはあの子を守って死んだ。"

# game/script/ch10.rpy:458
translate japanese ch10_receipt_6700eaf6:

    # "That was the thing his mind put in the empty place instead of the truth."
    "それが、真実の代わりに彼の心が空いた場所に置いたものだった。"

# game/script/ch10.rpy:459
translate japanese ch10_receipt_28788b6c:

    # "George Bennett had taken the rope over one sentence, and the only thing on this earth a man like that would die to shield was the girl."
    "George Bennettはひと言より縄を選んだ。あんな男が死んでまで守ろうとするものは、この地上であの少女しかいない。"

# game/script/ch10.rpy:460
translate japanese ch10_receipt_783c3084:

    # "George had known something was coming for her — the cult, the past, the thing he'd run from — and had died keeping it off her."
    "Georgeは何かがあの子に迫っていることを知っていた――教団が、過去が、自分が逃げてきたものが――そしてそれをあの子から遠ざけながら死んだのだ。"

# game/script/ch10.rpy:461
translate japanese ch10_receipt_8a2dda2c:

    # "And now George was gone, and the girl was alone in a stranger's house, and there was no one left in the whole valley standing between that child and whatever her grandfather had been so afraid of."
    "そして今、Georgeはいなくなり、少女は見知らぬ他人の家にひとりきりで、谷じゅうを探しても、あの子と、祖父があれほど恐れていた何かとのあいだに立つ者はもう誰ひとり残っていなかった。"

# game/script/ch10.rpy:462
translate japanese ch10_receipt_3269a108:

    # th "Someone has to."
    th "誰かがやらなきゃならない。"

# game/script/ch10.rpy:463
translate japanese ch10_receipt_72500339:

    # "He felt the decision close in him like a hand, warm and certain and thirteen years overdue: the worst decision of his life, wearing the face of the first good one."
    "決断が、手のように自分の中で閉じるのを彼は感じた。温かく、確かで、十三年遅れの決断。生涯最悪の決断が、初めての善い決断の顔をして。"

# game/script/ch10.rpy:464
translate japanese ch10_receipt_15e73e30:

    # th "I couldn't do it. Not for him. But someone has to."
    th "俺にはできなかった。あいつのためには。だが、誰かがやらなきゃならない。"

# game/script/ch10.rpy:471
translate japanese ch10_receipt_e2e20302:

    # "He started the car."
    "彼は車のエンジンをかけた。"

# game/script/ch10.rpy:472
translate japanese ch10_receipt_b37db081:

    # "Far off down the mountain the lights of Greyvale lay scattered and small in the dark, an ordinary town gone back to sleep, believing its nightmare buried."
    "山のはるか下に、Greyvaleの灯が闇の中に小さく散らばっていた。悪夢は埋めたと信じて、また眠りについたありふれた町。"

# game/script/ch10.rpy:473
translate japanese ch10_receipt_d018c7b7:

    # "And somewhere among the lights a kind woman was sitting up late over a sleeping child she thought she was protecting."
    "そしてその灯のどこかで、心優しい女が夜更けまで起きて、自分が守っていると思っている眠る子供を見守っていた。"

# game/script/ch10.rpy:474
translate japanese ch10_receipt_0075cdc8:

    # "Samuel Harris turned the car toward them both, hollow and resolved, and drove down into the valley to look after the one thing in it he should have been most afraid of."
    "Samuel Harrisは虚ろに、そして心を決めて、その二人のほうへ車を向け、谷へと下っていった。谷の中で彼が最も恐れるべきだったただひとつのものの面倒を見るために。"

translate japanese strings:

    # game/script/ch10.rpy:98
    old "Tell her the truth. There's more."
    new "本当のことを言う。まだ続きがある。"

    # game/script/ch10.rpy:104
    old "\"Just paperwork, Martha.\""
    new "「ただの書類仕事だよ、Martha」"

    # game/script/ch10.rpy:193
    old "Where would a careful man hide the thing that mattered?"
    new "用心深い男なら、大事なものをどこに隠す？"

    # game/script/ch10.rpy:196
    old "Search the shelves."
    new "棚を調べる。"

    # game/script/ch10.rpy:201
    old "Search the woodpile."
    new "薪の山を調べる。"

    # game/script/ch10.rpy:206
    old "Look under the workbench."
    new "作業台の下を見る。"

    # game/script/ch10.rpy:213
    old "Knock on the back panel."
    new "背板を叩く。"

    # game/script/ch10.rpy:260
    old "Where does a cash man keep his life?"
    new "現金で暮らす男は、自分の人生をどこにしまう？"

    # game/script/ch10.rpy:263
    old "The door pockets."
    new "ドアポケット。"

    # game/script/ch10.rpy:268
    old "Under the seat."
    new "座席の下。"

    # game/script/ch10.rpy:273
    old "The glovebox."
    new "グローブボックス。"

    # game/script/ch10.rpy:329
    old "How sure he is."
    new "彼がどれほど確信しているか。"

    # game/script/ch10.rpy:334
    old "The owner."
    new "オーナー。"

    # game/script/ch10.rpy:340
    old "Ask him. Plainly."
    new "率直に頼む。"

    # game/script/ch10.rpy:344
    old "Lean on him. Quiet certainty."
    new "押す。静かな確信で。"

    # game/script/ch10.rpy:444
    old "Look at the center of the wheel."
    new "車輪の中心を見る。"

    # game/script/ch10.rpy:448
    old "Look away."
    new "目をそらす。"

