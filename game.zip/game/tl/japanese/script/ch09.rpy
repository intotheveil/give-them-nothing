# TODO: Translation updated at 2026-10-11 10:23

# game/script/ch09.rpy:15
translate japanese ch09_684d2b1e:

    # "They had stopped the van with a log truck."
    "連中は丸太運搬トラックで護送車を止めていた。"

# game/script/ch09.rpy:16
translate japanese ch09_f0913f1f:

    # "Samuel saw it as he came down the last bend too fast, the tail of his car drifting on the packed snow before he caught it."
    "最後のカーブを速すぎる速度で下りてきたとき、Samuelはそれを見た。踏み固められた雪の上で車の尻が流れ、彼はそれを立て直した。"

# game/script/ch09.rpy:17
translate japanese ch09_316e75e7:

    # "A flatbed hauler slewed broadside across Route Nine at the narrowest point, where the road pinched between the cliff wall and the gorge rail."
    "平台のトレーラーが、Route Nineのいちばん狭いところ、崖の岩壁と峡谷のガードレールのあいだで道がくびれる場所に、横向きに滑り込んで道を塞いでいた。"

# game/script/ch09.rpy:18
translate japanese ch09_ff8fff0e:

    # "The little white county van nosed up against it, boxed, going nowhere."
    "小さな白い郡の護送車は、その車体に鼻先をつけ、閉じ込められて、どこへも行けずにいた。"

# game/script/ch09.rpy:19
translate japanese ch09_96931736:

    # "Behind and around the van the town had come to a stop and become, in the space of a mile, the thing Samuel had watched it deciding to be all night."
    "護送車の後ろとまわりで町は停まり、一マイルのうちに、Samuelが一晩じゅうそうなろうと決めていくのを見ていたものになっていた。"

# game/script/ch09.rpy:21
translate japanese ch09_ddc4e6a0:

    # "Fifty of them already out of their trucks in the road, and more spilling down the bends on foot."
    "すでに五十人がトラックを降りて道に出ており、さらに多くが徒歩でカーブを下ってあふれてきていた。"

# game/script/ch09.rpy:22
translate japanese ch09_c6b086fc:

    # "The sound they made when he cut his engine and stepped out was not the sound of a crowd. A crowd argues. This had gone past argument."
    "彼がエンジンを切って外に出たとき、彼らが立てていた音は群衆の音ではなかった。群衆は言い争う。これはもう言い争いを通り越していた。"

# game/script/ch09.rpy:23
translate japanese ch09_74c1e1ff:

    # "This was the low, unanimous, working sound of a thing that has made up its mind and only wants room."
    "心を決め、あとは場所だけを求めているものの、低く、満場一致の、働いている音だった。"

# game/script/ch09.rpy:31
translate japanese ch09_ae592f2f:

    # "For one held second before he moved — the second the mind steals out of any catastrophe to photograph it — the whole of it stood still in front of him like a painting hung in a cold gallery."
    "動き出す前の、息を詰めた一秒――どんな惨事からも心がくすね取って写真に収める一秒――そのすべてが、冷えた画廊に掛けられた一枚の絵のように、彼の前で静止していた。"

# game/script/ch09.rpy:32
translate japanese ch09_a62508ce:

    # "The log truck broadside and black against the snow. The little white van nosed against it, meek as a lamb run up against a wall."
    "横向きの丸太運搬トラックが、雪を背に黒い。小さな白い護送車がそれに鼻先をつけている。壁に突き当たった子羊のように、おとなしく。"

# game/script/ch09.rpy:33
translate japanese ch09_62ba3893:

    # "The gorge falling away on the right into blue nothing and the cliff rising sheer on the left, and strung between them, filling the pinch wall to wall, the town."
    "右手では峡谷が青い虚無へと落ち込み、左手では崖が切り立っている。そしてそのあいだに張りわたされ、くびれを端から端まで埋めて、町がいた。"

# game/script/ch09.rpy:34
translate japanese ch09_17b8858e:

    # "Fifty dark shapes on a white road under a white sky, their breath going up off them all together in a single low cloud, like something the crowd itself was exhaling."
    "白い空の下、白い道の上に五十の黒い影。その吐く息がいっせいに立ちのぼり、ひとつの低い雲になっていた。群衆そのものが吐き出している何かのように。"

# game/script/ch09.rpy:35
translate japanese ch09_019e9ab2:

    # "Trucks slewed at angles down the bends behind them with their doors flung open. A dropped scarf, red, very bright, trodden into the snow near the van's front wheel."
    "後ろのカーブには、ドアを開け放ったトラックがあちこちの角度で止まっている。落ちたスカーフ、赤い、ひどく鮮やかなスカーフが、護送車の前輪のそばで雪に踏みしだかれていた。"

# game/script/ch09.rpy:36
translate japanese ch09_d043dc7f:

    # "And over it all the enormous mountain morning, indifferent, beautiful, the light coming up clean and gray on a thing about to happen that the light did not care about at all."
    "そしてそのすべての上に、広大な山の朝。無関心で、美しく、光は清らかに灰色に昇ってきて、これから起きようとしていることを、まったく気にもかけていなかった。"

# game/script/ch09.rpy:37
translate japanese ch09_0a27dd00:

    # "Samuel would carry the frame of it the rest of his life, composed and terrible and still — the last still second before the road came alive."
    "Samuelはその構図を生涯背負っていくことになる。整い、恐ろしく、静止した構図――道が動き出す前の、最後の静止した一秒を。"

# game/script/ch09.rpy:47
translate japanese ch09_ad4b624d:

    # "He read it in the first three seconds, the way he read everything, and everything he read was bad."
    "最初の三秒で、彼はそれを読んだ。何でもそうやって読むように。そして読んだものはすべて悪かった。"

# game/script/ch09.rpy:48
translate japanese ch09_d54037c6:

    # "Poole and the other county man were still on their feet, but only just — backed against the van's cab, hands up, shouting the words that had turned crowds in easier towns and turned nothing here."
    "Pooleともうひとりの郡の警官はまだ立っていたが、かろうじてだった――護送車の運転台に背を押しつけ、両手を上げ、もっと楽な町なら群衆を引き返させてきた言葉を叫んでいた。ここでは何ひとつ引き返させなかった。"

# game/script/ch09.rpy:49
translate japanese ch09_85d42e78:

    # "The log truck was no accident. Someone had thought of it, moved it, slewed it across the pinch in the dark and waited."
    "丸太運搬トラックは事故ではなかった。誰かが思いつき、動かし、闇のなかでくびれに横向きに滑り込ませ、待っていたのだ。"

# game/script/ch09.rpy:50
translate japanese ch09_f3788253:

    # th "This didn't boil over on the road. It was built in the night. In the same black hours I spent on the phone begging for men, for the dark, for the mine track. No, and no, and no."
    th "これは道の上で煮えこぼれたんじゃない。夜のうちに組まれたんだ。俺が電話にしがみついて、人手を、闇を、鉱山の道をと頼み込んでいた、あの同じ暗い時間に。駄目だ、駄目だ、駄目だ。"

# game/script/ch09.rpy:51
translate japanese ch09_e9abb290:

    # th "I said it out loud. Half this town has a truck."
    th "俺は口に出して言った。この町の半分はトラックを持ってる、と。"

# game/script/ch09.rpy:52
translate japanese ch09_a157da36:

    # "He had seen the shape of this before it had a shape. He had simply not been allowed to stop it."
    "形を持つ前から、彼はこの形を見ていた。ただ、止めることを許されなかっただけだ。"

# game/script/ch09.rpy:53
translate japanese ch09_2029d318:

    # "The cage in the back of the van still held — that was the whole of the good news, and it would not hold long."
    "護送車の後部の檻はまだ持ちこたえていた――良い知らせはそれだけで、それも長くは持たない。"

# game/script/ch09.rpy:54
translate japanese ch09_5314626c:

    # "Four men were already at the rear doors with a tire iron and the honest patience of people who have all the time in the world and God on their side."
    "すでに四人の男が後部扉に取りつき、タイヤレバーを手に、時間はいくらでもあり神も味方についている人間の、誠実な辛抱強さで作業していた。"

# game/script/ch09.rpy:55
translate japanese ch09_88f8c944:

    # "And they were not strangers. That was the thing that went through him coldest as he shoved off the car and into it: he knew these faces."
    "そして彼らは見知らぬ者ではなかった。車から身を離し、その中へ突っ込んでいくとき、彼をいちばん冷たく貫いたのはそれだった。この顔を、知っている。"

# game/script/ch09.rpy:56
translate japanese ch09_74075500:

    # "The baker who'd sold him thin coffee his first morning in town. The hardware man who had told him, unasked, that he wouldn't want George Bennett for a neighbor."
    "町での最初の朝、薄いコーヒーを売ってくれたパン屋。訊かれもしないのに、George Bennettを隣人にしたくはないだろうと言った金物屋の男。"

# game/script/ch09.rpy:57
translate japanese ch09_842dbcca:

    # "The young mother who'd chased two children round the hotel dining room while Samuel ate his chicken pie, who stood now at the edge of the pack with her mittened fists at her sides and her face wide open, her grief finally given somewhere to go."
    "Samuelがチキンパイを食べているあいだ、ホテルの食堂でふたりの子どもを追いかけまわしていた若い母親。彼女はいま群れの端に立ち、ミトンをはめた拳を脇に下ろし、顔をむき出しにしていた。その悲しみに、ようやく行き場が与えられたのだ。"

# game/script/ch09.rpy:58
translate japanese ch09_5d89752c:

    # "Ordinary people. Good people, most of them, on any other morning of their lives."
    "普通の人々。人生のほかのどの朝であっても、ほとんどが善良な人々。"

# game/script/ch09.rpy:59
translate japanese ch09_a858ae38:

    # th "There's no monster on this road to fight. There's only a town."
    th "この道に戦うべき怪物はいない。いるのは町だけだ。"

# game/script/ch09.rpy:60
translate japanese ch09_99a50564:

    # "Samuel did the arithmetic and did not like the sum, and went in anyway, because the sum did not change what he was."
    "Samuelは計算をし、その答えが気に入らなかった。それでも突っ込んでいった。答えがどうであれ、自分が何者であるかは変わらなかったからだ。"

# game/script/ch09.rpy:61
translate japanese ch09_a988f512:

    # s angry "POLICE."
    s angry "警察だ！"

# game/script/ch09.rpy:62
translate japanese ch09_7ffb06c2:

    # "He put the whole of his chest into it, the voice that had emptied the square, and it opened a seam in the crowd three bodies deep and no more. He drove into the seam."
    "彼は胸のすべてを込めた。広場を空にしたあの声だった。それは群衆に三人ぶんの深さの裂け目を開け、それ以上は開かなかった。彼はその裂け目に突っ込んだ。"

# game/script/ch09.rpy:63
translate japanese ch09_3ffc9be6:

    # s "This is a police prisoner in a police vehicle and every hand that touches it hangs. You hear me? Every hand."
    s "これは警察の囚人で、警察の車両だ。手を触れた者は全員、吊られるぞ。聞こえたか？全員だ。"

# game/script/ch09.rpy:64
translate japanese ch09_a829f1aa:

    # s "I have your faces. I have the phones you've been so proud of. Step back."
    s "お前らの顔は覚えた。得意げに構えてたその携帯もな。下がれ。"

# game/script/ch09.rpy:65
translate japanese ch09_57b75a6a:

    # "For a heartbeat it almost worked. Hands hesitated; faces turned to him uncertain, their bodies remembering a whole lifetime of doing what the law told them."
    "一拍のあいだ、それはほとんど効いた。手がためらい、顔が自信なさげに彼のほうを向いた。法に言われたとおりにしてきた一生ぶんを、体が思い出したのだ。"

# game/script/ch09.rpy:66
translate japanese ch09_f2302366:

    # "He got four steps closer to the van on that heartbeat. Close enough to see George Bennett's face through the mesh of the cage window, gray and still and turned toward the noise."
    "その一拍で、彼は護送車に四歩近づいた。檻の窓の金網越しに、George Bennettの顔が見えるほど近くに。灰色で、静かで、騒ぎのほうを向いていた。"

# game/script/ch09.rpy:67
translate japanese ch09_c6923349:

    # "Close enough to see that the old man was not afraid."
    "老人が怯えていないのが見えるほど近くに。"

# game/script/ch09.rpy:69
translate japanese ch09_0e7ad5df:

    # kl angry "He's protecting him! The outsider's protecting the other one!"
    kl angry "あいつを庇ってやがる！よそ者がもうひとりのよそ者を庇ってるぞ！"

# game/script/ch09.rpy:71
translate japanese ch09_75539a65:

    # "And the heartbeat broke."
    "そして一拍が壊れた。"

# game/script/ch09.rpy:72
translate japanese ch09_f1197822:

    # "It did not break like a wave. It broke like ice, all at once and everywhere, and the seam Samuel had opened closed around him."
    "波のようには崩れなかった。氷のように崩れた。一度に、いたるところで。Samuelが開けた裂け目が、彼のまわりで閉じた。"

# game/script/ch09.rpy:73
translate japanese ch09_9ddf4a7a:

    # "The working sound became a roar, and the roar had his name in it now too: the big-city detective who drank coffee while their children died and now stood between honest people and the devil they had cornered."
    "働く音は咆哮になり、その咆哮にはいまや彼の名も混じっていた。子どもたちが死んでいくあいだコーヒーを飲んでいて、いまは正直な人々と、彼らが追い詰めた悪魔とのあいだに立ちはだかる、大都会の刑事。"

# game/script/ch09.rpy:77
translate japanese ch09_e6bdcc99:

    # "A shoulder caught him. Then a fist, high on the cheekbone — not aimed, just the overflow of a body with nowhere to put itself."
    "肩がぶつかった。次に拳が、頬骨の高いところに――狙ったものではない。行き場のない体からあふれ出ただけのものだ。"

# game/script/ch09.rpy:78
translate japanese ch09_4013d5df:

    # "The cold road tilted and he got a hand on the van's wing mirror and held himself up by it and kept shouting, because shouting was the last tool he had left."
    "冷たい道が傾き、彼は護送車のサイドミラーに片手をかけて体を支え、叫び続けた。叫ぶことが、彼に残された最後の道具だったからだ。"

# game/script/ch09.rpy:82
translate japanese ch09_52deae08:

    # "A boot caught him low in the ribs, and something there went from bone to glass — a bright wire of pain up his side with every breath after."
    "ブーツが肋骨の下のほうに入り、そこにある何かが骨からガラスに変わった――それからは息をするたびに、明るい針金のような痛みが脇腹を走った。"

# game/script/ch09.rpy:83
translate japanese ch09_cf0872ff:

    # "He breathed around it and did not stop."
    "彼は痛みをよけて息をし、止まらなかった。"

# game/script/ch09.rpy:84
translate japanese ch09_11ba342d:

    # "He saw Poole go down, dragged sideways off his feet into the mass, gone."
    "Pooleが倒れるのが見えた。横ざまに足をすくわれ、塊のなかへ引きずり込まれて、消えた。"

# game/script/ch09.rpy:86
translate japanese ch09_d2cca4b7:

    # "He saw the tire iron come back and swing, and heard the county van's rear lock give with a sound like a bone."
    "タイヤレバーが引かれて振り下ろされるのが見え、護送車の後部の錠が骨のような音を立てて壊れるのが聞こえた。"

# game/script/ch09.rpy:91
translate japanese ch09_fa6f5231:

    # "He got one hand on the man's collar and hauled him back with the whole strength of an arm that had once been stronger, and for a second the man came, stumbling—"
    "彼は男の襟に片手をかけ、かつてはもっと強かった腕の力のすべてで引き戻した。一瞬、男はよろめきながらついてきた――"

# game/script/ch09.rpy:92
translate japanese ch09_88594915:

    # "—and then two more had Samuel by the coat and the arm and the back of the neck."
    "――そのとき、さらにふたりがSamuelのコートと腕と首の後ろをつかんだ。"

# game/script/ch09.rpy:95
translate japanese ch09_93dcd806:

    # "He threw himself at the rear of the van, shoulder first, to put his own body across the doors. He got a hand flat on the cold white panel—"
    "彼は肩から護送車の後部に体ごとぶつかり、自分の体で扉を塞ごうとした。冷たく白いパネルに手のひらをぴたりとつけた――"

# game/script/ch09.rpy:96
translate japanese ch09_94b5f04c:

    # "—and then two more had him by the coat and the arm and the back of the neck, and peeled him off it like tape."
    "――そのとき、さらにふたりが彼のコートと腕と首の後ろをつかみ、テープのように彼を引き剥がした。"

# game/script/ch09.rpy:100
translate japanese ch09_908d20b9:

    # "The road came up, and he was on his knees in the churned red-brown snow with boots all around him."
    "道がせり上がってきて、彼は踏み荒らされた赤茶色の雪の上にひざをついていた。まわりはブーツばかりだった。"

# game/script/ch09.rpy:101
translate japanese ch09_8906a65e:

    # "The world reduced to shins and the smell of diesel and sweat and the sweet copper thing underneath it that he already knew, on his knees, was coming."
    "世界は脛と、ディーゼルと汗の匂いと、その下にある甘い銅のような何かにまで縮んだ。それが来ることを、ひざをついた彼はもう知っていた。"

# game/script/ch09.rpy:102
translate japanese ch09_1a7cf006:

    # "He got up."
    "彼は立ち上がった。"

# game/script/ch09.rpy:103
translate japanese ch09_38d004a7:

    # "A man half his age would have stayed down and been forgiven for it. Samuel Harris, forty-seven and smoke-lunged and grieving and now cracked along one side, got his boots under him and stood back up."
    "彼の半分の年の男なら、倒れたままでいて、それを許されただろう。Samuel Harris、四十七歳、煙草に肺を侵され、悲しみを引きずり、いまや片側にひびの入った男は、ブーツを体の下に入れて、もう一度立ち上がった。"

# game/script/ch09.rpy:104
translate japanese ch09_6c5547fa:

    # th "He's in that cage because I put him there. I will not kneel in the snow and let them finish it."
    th "奴があの檻にいるのは、俺が入れたからだ。雪のなかにひざまずいて、連中に片をつけさせたりはしない。"

# game/script/ch09.rpy:105
translate japanese ch09_3da68389:

    # "He was three men from the rear doors when they got them open."
    "後部扉まであと三人というところで、連中は扉をこじ開けた。"

# game/script/ch09.rpy:106
translate japanese ch09_96eb58d4:

    # "They took George Bennett out of the cage the way the sea takes a thing off a deck — not one pair of hands but twenty, a single hunger with too many arms."
    "彼らはGeorge Bennettを檻から引き出した。海が甲板から物をさらっていくように――ひと組の手ではなく二十組の手で。腕の多すぎるひとつの飢えだった。"

# game/script/ch09.rpy:107
translate japanese ch09_e7801eff:

    # "The old man came out into the gray morning and the cold and the noise and did not fight it, and did not beg, and did not make a sound."
    "老人は灰色の朝へ、寒さと騒音のなかへ出てきた。抗わず、命乞いもせず、音ひとつ立てなかった。"

# game/script/ch09.rpy:108
translate japanese ch09_e8b7ab9e:

    # "Samuel saw it in pieces, over shoulders, between heads, the way you see the worst things."
    "Samuelはそれを切れ切れに見た。肩越しに、頭と頭のあいだから。最悪のものはいつもそうやって見える。"

# game/script/ch09.rpy:109
translate japanese ch09_0b62fc79:

    # "George on his feet a moment, upright even now, even here, his cuffed hands still before him, his gray head above the crowd for one second like a man standing in a river."
    "Georgeは一瞬、立っていた。いまでも、ここでも、背筋を伸ばし、手錠をかけられた両手をまだ前に置いて。一秒のあいだ、その白髪頭が群衆の上に出ていた。川のなかに立つ男のように。"

# game/script/ch09.rpy:112
translate japanese ch09_e8cdd60b:

    # "He saw the first blow take him from the side. He saw the head snap and the old man go down out of sight into the mass."
    "最初の一撃が横から彼を捉えるのが見えた。頭が跳ね、老人が塊のなかへ沈んで見えなくなるのが見えた。"

# game/script/ch09.rpy:113
translate japanese ch09_b76293bc:

    # "And the mass folded inward over the place where he had been — boots and arms and the long animal note of a hundred people doing at last the thing they had come up the mountain to do."
    "そして塊は、彼のいた場所の上へ内側に折り重なった――ブーツと腕と、山を上ってきた目的をついに果たす百人の、長く尾を引く獣の声。"

# game/script/ch09.rpy:116
translate japanese ch09_af5c3011:

    # "Samuel, fighting toward it, screaming words that had lost their shape, understood the thing under the horror."
    "Samuelはそこへ向かって戦いながら、形をなくした言葉を叫びながら、恐怖の下にあるものを理解した。"

# game/script/ch09.rpy:117
translate japanese ch09_746132c5:

    # "They believed they were doing justice. Not a riot. A court. They had weighed the outsider and found him wanting, and were passing the sentence with the clean conscience of the certain."
    "彼らは正義を行っていると信じていた。暴動ではない。法廷だ。よそ者を量り、足りぬと見て、確信する者の澄んだ良心で判決を下しているのだ。"

# game/script/ch09.rpy:118
translate japanese ch09_e3c5e5d5:

    # th "I've seen that certainty somewhere close. This week. Where—"
    th "あの確信は、どこか近くで見た。今週だ。どこで――"

# game/script/ch09.rpy:119
translate japanese ch09_e7399bf2:

    # "He could not place it, and the not-placing sat in him like a splinter driven deep."
    "思い出せなかった。思い出せないことが、深く打ち込まれた棘のように彼のなかに残った。"

# game/script/ch09.rpy:120
translate japanese ch09_730d6e41:

    # "Then he stopped thinking anything at all, and only fought."
    "それから彼は何も考えるのをやめ、ただ戦った。"

# game/script/ch09.rpy:121
translate japanese ch09_7cfd0b13:

    # "He shoved and hauled and clawed his way into the mass toward the place the old man had gone down, and got one hand on a gray sleeve — one hand, for half a second—"
    "押しのけ、引き寄せ、爪を立てて塊のなかへ進み、老人が沈んだ場所を目指した。灰色の袖に片手が届いた――片手が、半秒だけ――"

# game/script/ch09.rpy:124
translate japanese ch09_75e4a577:

    # "—before it closed, and three of them took him by the arms and the coat and the broken side of him and flung him back out of it the way a body spits a splinter."
    "――塊が閉じた。三人が彼の腕とコートと折れた脇腹をつかみ、体が棘を吐き出すように、彼をその外へ放り出した。"

# game/script/ch09.rpy:125
translate japanese ch09_ae16c924:

    # "He went down hard on the road on the cracked rib, and the white sky wheeled over him."
    "彼はひびの入った肋骨から道に激しく叩きつけられ、白い空が頭上でぐるりと回った。"

# game/script/ch09.rpy:134
translate japanese ch09_a8ae8cc6:

    # "They had him on the ground now."
    "連中はもう、彼を地面に倒していた。"

# game/script/ch09.rpy:135
translate japanese ch09_47148ae9:

    # "George Bennett, who had spent forty years teaching himself and everyone he loved that the world was a machine for grinding the weak to nothing, discovered at the very end that he had been right all along."
    "George Bennettは、四十年をかけて、自分自身と愛する者すべてに、世界とは弱い者をすり潰して無にする機械だと教え込んできた。その彼が最後の最後に、自分がずっと正しかったことを知った。"

# game/script/ch09.rpy:136
translate japanese ch09_7c4b3fab:

    # "And that being right was no comfort at all."
    "そして、正しかったことが何の慰めにもならないことを。"

# game/script/ch09.rpy:138
translate japanese ch09_17210f12:

    # "The first boots came in, and his body did the thing he had trained it across a whole hard life to do."
    "最初のブーツが入ってきて、彼の体は、厳しい生涯をかけて鍛え込んできたことをした。"

# game/script/ch09.rpy:139
translate japanese ch09_a0bab197:

    # "It made no sound."
    "音を立てなかった。"

# game/script/ch09.rpy:140
translate japanese ch09_c2d8fa49:

    # "That was the deepest lesson the cold house had ever put in him, older than the doctrine, under the words and holding them up."
    "それが、冷たい家が彼に植えつけたいちばん深い教えだった。教義よりも古く、言葉の下にあって、言葉を支えていた。"

# game/script/ch09.rpy:141
translate japanese ch09_29833112:

    # gth "You do not give them your pain. Pain shown is pain doubled. A man who cries out has handed the world the one thing it ever wanted from him."
    gth "痛みを奴らに与えるな。見せた痛みは倍になる。叫ぶ男は、世界が自分に求めていたたったひとつのものを手渡してしまう。"

# game/script/ch09.rpy:142
translate japanese ch09_ae4ce353:

    # "He had knelt on bare boards and learned it from a father who had learned it from his. He had put it into his own son with a cold and patient hand he had genuinely believed was love."
    "むき出しの床板にひざまずき、それを父親から学んだ。その父親もまた自分の父親から学んだのだ。彼はそれを、冷たく辛抱強い手で、自分の息子に注ぎ込んだ。それが愛だと本気で信じていた手で。"

# game/script/ch09.rpy:143
translate japanese ch09_8bc6bc7e:

    # "Now the town of Greyvale, which knew nothing of Driftwood or the sea or the catechism, stood over him in a mountain road and tried to beat that same thing out of him one blow at a time."
    "いま、Driftwoodのことも、海のことも、教理問答のことも何ひとつ知らないGreyvaleの町が、山道で彼の上に立ち、その同じものを一撃ずつ叩き出そうとしていた。"

# game/script/ch09.rpy:144
translate japanese ch09_459adb5a:

    # "And found, exactly as the boy on the boards had found, that there was nothing under the hardness left to break."
    "そして、床板の上の少年がそうだったのとまったく同じように、硬さの下にはもう壊すべきものが何も残っていないことを知った。"

# game/script/ch09.rpy:145
translate japanese ch09_5cfbaeaa:

    # "He curled, and covered, and took it, and gave them nothing. Some far cold part of him, even now, with his own blood in his mouth, was almost proud."
    "彼は体を丸め、身を庇い、受け止め、何も与えなかった。口のなかに自分の血の味がするいまでさえ、遠く冷たい彼のどこかは、ほとんど誇らしかった。"

# game/script/ch09.rpy:146
translate japanese ch09_08147ed2:

    # gth "The machine came for me. I always knew it would. A man who feeds a machine does not get to walk out of it clean."
    gth "機械が俺を迎えに来た。来るとずっとわかっていた。機械に餌をやる者は、無傷でそこから出られはしない。"

# game/script/ch09.rpy:147
translate japanese ch09_a14fbbbb:

    # "He had fed it his whole life. He had fed it the boy."
    "彼は生涯それに餌をやってきた。あの少年を食わせた。"

# game/script/ch09.rpy:148
translate japanese ch09_019c773c:

    # "He had stood at a rain-streaked window and watched it begin to take a five-year-old, and had reached in, once, the single time in all his years, and dragged something back into the light."
    "雨の筋がついた窓辺に立ち、それが五歳の子を捕らえはじめるのを見て、一度だけ、生涯でただ一度だけ手を差し入れ、何かを光のなかへ引き戻した。"

# game/script/ch09.rpy:149
translate japanese ch09_cca21666:

    # "And even that, the one mercy he had ever managed, he had done too late and too small, and the machine had only smiled and gone on turning, and taken her the long way round instead."
    "だがそれさえ、彼がどうにか果たしたただひとつの慈悲さえ、遅すぎて、小さすぎた。機械はただ微笑んで回り続け、遠回りをして彼女を連れていっただけだった。"

# game/script/ch09.rpy:151
translate japanese ch09_c089c53d:

    # "So it was fair, said some old accountant deep in him, unbothered, as a heel came down on his hand and broke it against the road."
    "だからこれは公平だ、と彼の奥深くにいる年老いた帳簿係が、平然と言った。踵が彼の手に振り下ろされ、道に押しつけて砕いた。"

# game/script/ch09.rpy:152
translate japanese ch09_1e34e389:

    # gth "Only the sum coming right. Only the past, catching up the way the past always does, on its own patient legs."
    gth "帳尻が合うだけだ。過去が追いついてくるだけだ。過去がいつもそうするように、自分の辛抱強い脚で。"

# game/script/ch09.rpy:153
translate japanese ch09_8f8fa49b:

    # "A boot found his ribs and something deep inside gave way, and the pain of it was very large and very far off at the same time — a catastrophe in a house he had already moved out of."
    "ブーツが肋骨を捉え、体の奥深くで何かが崩れた。その痛みはひどく大きく、同時にひどく遠かった――もう引っ越したあとの家で起きた大惨事のように。"

# game/script/ch09.rpy:155
translate japanese ch09_3d9dd3e9:

    # "And then there came a moment, near the end, when he stopped feeling the blows entirely."
    "そして終わり近く、打撃をまったく感じなくなる瞬間が来た。"

# game/script/ch09.rpy:156
translate japanese ch09_ceffad66:

    # "It was not peace. He had never believed in peace; it was one of the soft lies the weak told themselves to get through the night."
    "安らぎではなかった。彼は安らぎなど信じたことはなかった。それは弱い者が夜をやり過ごすために自分につく、柔らかな嘘のひとつだった。"

# game/script/ch09.rpy:157
translate japanese ch09_6d6d32c7:

    # "It was only distance — the body carrying on somewhere down below while the part of him that had done all the watching floated up and off and looked down at it, unhurried."
    "ただの距離だった――体はどこか下のほうで続いていて、ずっと見ることをしてきた彼の一部が、浮かび上がって離れ、急ぐでもなくそれを見下ろしていた。"

# game/script/ch09.rpy:158
translate japanese ch09_4a2efd1d:

    # gth "The town is weather. You don't hate weather. You only, sometimes, fail to live through it."
    gth "町は天気だ。天気を憎む者はいない。ただときどき、生き延びられないだけだ。"

# game/script/ch09.rpy:162
translate japanese ch09_d1ea2ce4:

    # "He thought instead, with the strange wide calm of the almost-gone, of the boy on the bare boards, the thin careful voice going through the catechism while the tears ran and the mouth kept on."
    "代わりに彼は、消えかけた者の奇妙に広い静けさのなかで、むき出しの床板の上の少年のことを考えた。涙が流れても口は動き続け、教理問答を唱えていた、細く慎重な声。"

# game/script/ch09.rpy:165
translate japanese ch09_a6206648:

    # "He thought of the girl in the yard in the rain, and his own shirt drying her hair, and the forbidden whispered thing that he had believed, that one night, would be enough to save her."
    "雨の庭にいた少女のことを考えた。彼女の髪を拭いた自分のシャツのことを。あの一夜、それで彼女を救うのに足りると信じた、禁じられたささやきのことを。"

# game/script/ch09.rpy:166
translate japanese ch09_f3e11dbb:

    # g neutral "{i}You do not have to be what they make you.{/i}"
    g neutral "{i}奴らが作ろうとするものに、お前がなる必要はない。{/i}"

# game/script/ch09.rpy:168
translate japanese ch09_91e9e649:

    # "He thought of a truck on a coast road in the dark and a small silent shape beside him with rain-wet hair, watching the black go by."
    "闇のなかの海沿いの道を走るトラックと、隣にいた、雨に濡れた髪の小さく無言の影のことを考えた。過ぎていく闇を見つめていた影を。"

# game/script/ch09.rpy:169
translate japanese ch09_8688dd4b:

    # "He had told himself the whole way that he was carrying her out of danger. He had only, in truth, been carrying her — and the thing that was already in her — further down the same road that had made them both."
    "道中ずっと、彼女を危険から連れ出しているのだと自分に言い聞かせていた。本当は、ただ彼女を――そしてすでに彼女のなかにあったものを――ふたりを作ったのと同じ道の、さらに先へと運んでいただけだった。"

# game/script/ch09.rpy:172
translate japanese ch09_dc569a5d:

    # "And then he thought, because there was no longer any reason under heaven not to, the thought he had refused for two years to think all the way to its end."
    "それから彼は考えた。もはや天の下にそうしない理由が何ひとつなかったから。二年間、最後まで考えることを拒んできた考えを。"

# game/script/ch09.rpy:173
translate japanese ch09_da802808:

    # "He let it arrive whole, because a dying man owes the truth nothing and can afford it at last."
    "彼はそれをまるごと到来させた。死にゆく男は真実に何の借りもなく、ようやくそれを抱える余裕があるからだ。"

# game/script/ch09.rpy:177
translate japanese ch09_aacfb118:

    # gth "It was her."
    gth "あの子だった。"

# game/script/ch09.rpy:178
translate japanese ch09_137a6ba2:

    # gth "The teacher. The shopkeeper. The priest. The little friend laid out in the snow. My girl."
    gth "教師。店主。神父。雪の上に横たえられた、小さな友だち。俺の、あの子が。"

# game/script/ch09.rpy:179
translate japanese ch09_d918fb9d:

    # "The soft thing he had smuggled out of the rain had grown up wearing his own doctrine like a second skin."
    "雨のなかからこっそり連れ出したあの柔らかなものは、彼自身の教義を第二の皮膚のようにまとって育っていた。"

# game/script/ch09.rpy:180
translate japanese ch09_4482b05f:

    # "He had felt it since the first grave and refused to feel it. He had built the whole vast architecture of his denial across two years for this single reason:"
    "最初の墓のときからそれを感じ、感じることを拒んできた。二年かけて否認の巨大な構造をまるごと築き上げてきたのは、ただひとつの理由のためだった。"

# game/script/ch09.rpy:181
translate japanese ch09_59cc2692:

    # "To finish the thought was to know that he had won. That the cold house had won. That everything he fled had ridden out of Driftwood in the seat beside him, small and patient and quiet and his."
    "その考えを最後まで考えれば、自分が勝ったと知ることになる。冷たい家が勝ったと。自分が逃げてきたすべてが、隣の座席に乗ってDriftwoodを出てきたのだと。小さく、辛抱強く、静かで、自分のものとして。"

# game/script/ch09.rpy:182
translate japanese ch09_c783a7b0:

    # "And having thought it, whole, at the very last, he did the one thing he had left in the world to do with it."
    "そして最後の最後に、それをまるごと考えてしまうと、彼はこの世で残されたただひとつのことを、それに対して行った。"

# game/script/ch09.rpy:183
translate japanese ch09_d2023243:

    # "He kept it."
    "胸にしまった。"

# game/script/ch09.rpy:187
translate japanese ch09_935a90b7:

    # gth "Give them nothing."
    gth "何も与えるな。"

# game/script/ch09.rpy:188
translate japanese ch09_0c71723a:

    # "His own words, forty years old, the only inheritance he had ever succeeded in passing down — and the only one that had ever, at the very end, come out of him as something like a mercy."
    "四十年前の、彼自身の言葉。彼が受け継がせることに成功した唯一の遺産――そして最後の最後に、慈悲に似たものとして彼から出てきた唯一のもの。"

# game/script/ch09.rpy:189
translate japanese ch09_e18d3ccc:

    # "He would not say her name. Not to the detective who had all but gone on his knees for it, not to the county, not to the God the priest had died still believing in, not to the fists."
    "彼女の名前は言わない。それを求めてひざまずかんばかりだった刑事にも、郡にも、神父が死ぬまで信じていた神にも、拳にも。"

# game/script/ch09.rpy:190
translate japanese ch09_814ec7a1:

    # "He would carry the whole of it down into the dark: the name, the knowing, the two years, the entire ruined truth of what he had made and what he had failed to unmake."
    "そのすべてを闇の底まで持っていく。名前も、知っていたことも、二年間も、自分が造ったものと、解体しそこねたものの、すっかり壊れた真実のすべてを。"

# game/script/ch09.rpy:191
translate japanese ch09_9827160b:

    # "And she would go on being an ordinary girl who had lost her grandfather. The only thing he had ever given her that the cold house had not first gotten to and spoiled: his silence, entire, unbroken, forever."
    "そして彼女は、祖父を亡くした普通の少女であり続ける。冷たい家が先に手をつけて駄目にしていない、彼が彼女に与えた唯一のもの。彼の沈黙。完全で、破られることのない、永遠の沈黙。"

# game/script/ch09.rpy:192
translate japanese ch09_42ae3fe2:

    # "He told them, all of them at once — the boy on the boards, the girl in the rain, the two sisters on the far coast, the whole ruined line of them running back and back into the salt dark—"
    "彼は彼ら全員に、一度に告げた――床板の上の少年に、雨のなかの少女に、遠い海岸のふたりの姉妹に、潮の闇の奥へ奥へと遡っていく、壊れた血筋のすべてに――"

# game/script/ch09.rpy:193
translate japanese ch09_d1ea65d5:

    # gth "I'm sorry."
    gth "すまない。"

# game/script/ch09.rpy:194
translate japanese ch09_7d8ea5b2:

    # gth "I'm sorry. I gave you nothing."
    gth "すまない。お前たちに何も与えなかった。"

# game/script/ch09.rpy:195
translate japanese ch09_290f5c9c:

    # gth "I never did have anything else to give."
    gth "ほかに与えるものなど、もともと何も持っていなかった。"

# game/script/ch09.rpy:196
translate japanese ch09_88cb6bc5:

    # "Then the distance became the dark."
    "それから、距離は闇になった。"

# game/script/ch09.rpy:197
translate japanese ch09_4247b0c0:

    # "And George Bennett, who had judged and been judged, who had built a machine with his own hands and been ground to nothing inside it, went down into that dark having said, aloud, to the very end, not one single word."
    "そしてGeorge Bennett、裁き、裁かれた男、自分の手で機械を造り、その中ですり潰されて無になった男は、最後の最後まで、声に出してただのひと言も言わないまま、その闇へと沈んでいった。"

# game/script/ch09.rpy:209
translate japanese ch09_7e1bdeee:

    # "They were already breaking apart when Samuel reached him."
    "Samuelがたどり着いたとき、彼らはもう散りはじめていた。"

# game/script/ch09.rpy:210
translate japanese ch09_72f0e3ce:

    # "He had read enough of these to know: the thing that comes over a crowd the instant the deed is done, the tide going out as fast as it came in."
    "こういうものは十分に読んできたから知っていた。事が終わった瞬間に群衆を襲うもの。来たときと同じ速さで引いていく潮。"

# game/script/ch09.rpy:211
translate japanese ch09_4431ee93:

    # "It left them blinking and separate and human again on the cold road. No longer a court. Only forty or fifty men and women standing too close to a thing they had made together and could not now believe."
    "潮が引いたあと、彼らは冷たい道の上で目をしばたたき、ばらばらの人間に戻っていた。もう法廷ではない。一緒に作り上げ、いまでは信じられずにいるものの、近くに立ちすぎている四、五十人の男女にすぎなかった。"

# game/script/ch09.rpy:212
translate japanese ch09_020636d3:

    # "The working roar had emptied out into a silence broken only by someone, somewhere back in the pack, beginning to weep."
    "働く咆哮は抜け落ちて沈黙になり、その沈黙を破るのは、群れの後ろのどこかで誰かが泣きはじめた声だけだった。"

# game/script/ch09.rpy:213
translate japanese ch09_d16830cb:

    # "Samuel went through them, and this time they let him, parting, stepping back, their faces already rearranging themselves toward the story they would tell tonight and for the rest of their lives."
    "Samuelは彼らのあいだを進んだ。今度は彼らも通した。道を開け、後ずさり、その顔はすでに、今夜と残りの生涯で語ることになる話のほうへと組み替えられつつあった。"

# game/script/ch09.rpy:214
translate japanese ch09_21d38538:

    # "He went down on his knees in the red snow beside what they had left."
    "彼らが残していったもののそばで、彼は赤い雪にひざをついた。"

# game/script/ch09.rpy:216
translate japanese ch09_340dbfbc:

    # "There was no help to give. He had known there would be none since the bend, but his hands did the things anyway — the checking, two fingers at the ruined throat."
    "できる手当てはなかった。カーブの時点からないとわかっていた。それでも手はするべきことをした――確認を。壊れた喉に二本の指を。"

# game/script/ch09.rpy:217
translate japanese ch09_3036ef64:

    # "To not do them was to accept it one second sooner than the body forced him to."
    "それをしないのは、体に強いられるより一秒早くそれを受け入れることだった。"

# game/script/ch09.rpy:218
translate japanese ch09_64bfc3db:

    # "George Bennett was gone. He had gone, Samuel thought, some while before his heart had. There was a stillness in the wrecked face that had arrived ahead of death — the look of a man who had finished a thing."
    "George Bennettは逝っていた。心臓が止まるよりしばらく前に逝っていたのだ、とSamuelは思った。壊れた顔には、死よりも先に訪れた静けさがあった――ひとつのことをやり終えた男の顔だった。"

# game/script/ch09.rpy:219
translate japanese ch09_bba0b6f9:

    # "Samuel knelt there with his own blood running warm down his cheek and the old man's blood going cold under his knees, and for a while he did not do anything at all."
    "Samuelはそこにひざまずいていた。自分の血が温かく頬を伝い、老人の血がひざの下で冷えていった。しばらくのあいだ、彼は何ひとつしなかった。"

# game/script/ch09.rpy:226
translate japanese ch09_7985d0f4:

    # "Then he stood up, because he was the only law on that road, and the law does not get to grieve until the scene is closed."
    "それから立ち上がった。その道にいる法は彼だけで、法は現場を閉じるまで嘆くことを許されないからだ。"

# game/script/ch09.rpy:227
translate japanese ch09_5c9c2982:

    # "He found Poole alive against the gorge rail, sitting in the snow with his nose broken sideways and one hand pressed to his ribs, the other county man beside him worse but breathing."
    "Pooleは峡谷のガードレールにもたれて生きていた。雪の上に座り、鼻は横に折れ曲がり、片手を肋骨に押し当てていた。そばにいるもうひとりの郡の警官はもっとひどかったが、息はしていた。"

# game/script/ch09.rpy:229
translate japanese ch09_d6762d87:

    # "He got on his radio with a hand that had started, now, at last, to shake, and he called it in."
    "ようやくいまになって震えはじめた手で無線を取り、彼は報告を入れた。"

# game/script/ch09.rpy:230
translate japanese ch09_9ba28f78:

    # s hurt "Officers down. Death in custody, Route Nine. The transport is lost."
    s hurt "警官負傷。Route Nineで被拘束者死亡。移送は失敗。"

# game/script/ch09.rpy:231
translate japanese ch09_a07d7e67:

    # "The flat clipped grammar of the job, because the grammar of the job was the only thing holding him upright, and he knew it, and he clung to it."
    "仕事の平板で切り詰めた文法。仕事の文法だけが彼をまっすぐ立たせていて、彼はそれを知っていて、それにしがみついた。"

# game/script/ch09.rpy:232
translate japanese ch09_2cfadfc2:

    # "Sirens somewhere below, climbing. Mercer's voice breaking on the radio. The mountain going about its enormous indifferent morning while a town crept back to its trucks and would not meet his eyes."
    "下のどこかでサイレンが上ってくる。無線で割れるMercerの声。山は広大で無関心な朝をいつもどおりに過ごし、町はこそこそとトラックへ戻り、彼の目を見ようとしなかった。"

# game/script/ch09.rpy:233
translate japanese ch09_dfe4a580:

    # "He did the work. He held the scene. He would not let them move the body, though a dozen hands offered, suddenly gentle, suddenly ashamed."
    "彼は仕事をした。現場を保持した。遺体は動かさせなかった。急に優しくなり、急に恥じ入った手が十何本も申し出たが。"

# game/script/ch09.rpy:234
translate japanese ch09_f6582042:

    # "He photographed what had to be photographed with his own phone, the county's camera lost somewhere under the log truck. Where his hands shook he braced them against his knees and did it anyway."
    "撮らねばならないものを自分の携帯で撮った。郡のカメラは丸太運搬トラックの下のどこかに消えていた。手が震えるところでは、ひざに押し当てて支え、それでも撮った。"

# game/script/ch09.rpy:236
translate japanese ch09_36b4b0d6:

    # note_voice "George Bennett — dead in custody, Route Nine. 50+ present."
    note_voice "George Bennett――Route Nineにて拘束中に死亡。現場に五十人以上。"

# game/script/ch09.rpy:237
translate japanese ch09_6ae3b16d:

    # "Then he took the names."
    "それから、名前を取った。"

# game/script/ch09.rpy:238
translate japanese ch09_45569961:

    # "He walked the line of them where they stood scattered along the road, and he looked into each face until it looked away and gave up its name."
    "道沿いに散らばって立つ彼らの列を歩き、ひとりひとりの顔を、相手が目を逸らして名前を明け渡すまで見つめた。"

# game/script/ch09.rpy:239
translate japanese ch09_2ccbe254:

    # "The baker gave his, and could not stop the apology that came with it."
    "パン屋は名前を言い、それに続く謝罪を止められなかった。"

# game/script/ch09.rpy:240
translate japanese ch09_d2ed33ee:

    # vo "I only came to watch, Detective. I swear before God I never laid a hand—"
    vo "見に来ただけなんです、刑事さん。神に誓って、指一本――"

# game/script/ch09.rpy:241
translate japanese ch09_02726d8d:

    # "Maybe it was even true. It did not matter. Samuel wrote him down."
    "本当なのかもしれない。どうでもよかった。Samuelは彼の名を書き留めた。"

# game/script/ch09.rpy:242
translate japanese ch09_d07f6e77:

    # "The hardware man gave his name to the snow at his own boots and would not lift his eyes."
    "金物屋の男は自分のブーツのそばの雪に向かって名前を言い、目を上げようとしなかった。"

# game/script/ch09.rpy:243
translate japanese ch09_242cefcc:

    # "And the young mother from the hotel dining room, when Samuel reached her, was weeping too hard to stand straight."
    "そしてホテルの食堂の若い母親は、Samuelがたどり着いたとき、泣きすぎてまっすぐ立っていられなかった。"

# game/script/ch09.rpy:248
translate japanese ch09_a93db371:

    # "He made himself hold her face. It was the face from the dining room, the one that had shushed two children over breakfast, and it would be in his notebook now beside the others."
    "彼は彼女の顔から目を離すまいとした。食堂で見たあの顔、朝食の席でふたりの子どもを静かにさせていた顔。それがいま、ほかの顔と並んで彼の手帳に載ることになる。"

# game/script/ch09.rpy:249
translate japanese ch09_414f33e7:

    # "She turned it up to him, ruined and open."
    "彼女はその顔を彼に向けた。壊れて、むき出しの顔を。"

# game/script/ch09.rpy:252
translate japanese ch09_f3c77ccb:

    # "He kept his eyes on the page. He did not trust what his face would do."
    "彼はページから目を上げなかった。自分の顔がどうなるか信用できなかった。"

# game/script/ch09.rpy:253
translate japanese ch09_7f57bbf4:

    # "She turned her ruined open face up to him anyway, and he heard it in her voice."
    "それでも彼女は壊れたむき出しの顔を彼に向け、彼はそれを彼女の声に聞いた。"

# game/script/ch09.rpy:255
translate japanese ch09_1214035f:

    # woman "I don't— I don't know what happened."
    woman "わからない――何が起きたのか、わからないの。"

# game/script/ch09.rpy:256
translate japanese ch09_18c14d9c:

    # woman "I don't know what happened to us."
    woman "私たちに何が起きたのか、わからない。"

# game/script/ch09.rpy:257
translate japanese ch09_82975ddc:

    # "Samuel, who an hour ago had wanted to hate every soul on this road and found that now he mostly could not, said only, quietly—"
    "一時間前にはこの道のすべての者を憎みたかったのに、いまではほとんど憎めないと気づいたSamuelは、ただ静かにこう言った――"

# game/script/ch09.rpy:258
translate japanese ch09_1ab7b3c1:

    # s hurt "Your name."
    s hurt "名前を。"

# game/script/ch09.rpy:259
translate japanese ch09_a1b319bf:

    # "And she gave it, and he wrote it down."
    "彼女は名前を言い、彼はそれを書き留めた。"

# game/script/ch09.rpy:261
translate japanese ch09_af866550:

    # "Even Leary gave his — small now, the drink gone out of him, a middle-aged man on a cold road who had helped to kill a person and was just beginning to understand it."
    "Learyでさえ名前を言った――いまは小さくなり、酒も抜けて、人ひとりを殺す手助けをしたことをようやく理解しはじめた、冷たい道の上の中年男だった。"

# game/script/ch09.rpy:263
translate japanese ch09_59006818:

    # "Samuel wrote them all down, every one, in his cramped hand."
    "Samuelは全員の名前を、ひとり残らず、窮屈な字で書き留めた。"

# game/script/ch09.rpy:264
translate japanese ch09_7e139731:

    # "It was mostly theater and he knew it. No county in the world hangs a whole town, and the story by nightfall would be a tragic loss of control, a community pushed past its bearing."
    "ほとんど芝居だと、彼にはわかっていた。町ひとつを丸ごと吊るす郡など世界のどこにもない。日暮れまでには、話は悲劇的な統制の喪失、限界を超えて追い詰められた共同体の話になっているだろう。"

# game/script/ch09.rpy:265
translate japanese ch09_a8edfe08:

    # "But he wrote them down anyway, because it was the last thing left he could do for George Bennett — and because the alternative was to kneel back down in the snow and not get up."
    "それでも彼は書き留めた。それがGeorge Bennettのために彼にできる最後のことだったから――そして、そうしなければ、雪のなかにまたひざまずいて二度と立ち上がらないことになるからだ。"

# game/script/ch09.rpy:267
translate japanese ch09_55f6df92:

    # note_voice "Names: the baker (sorry, sorry). Hardware man. The young mother. Leary. Forty-odd more."
    note_voice "名前――パン屋（すみません、すみません）。金物屋。若い母親。Leary。ほか四十人あまり。"

# game/script/ch09.rpy:270
translate japanese ch09_c5d943b5:

    # "Doyle reached him on the phone as the ambulance crested the bend."
    "救急車がカーブの頂を越えてきたとき、Doyleから電話が入った。"

# game/script/ch09.rpy:272
translate japanese ch09_782a9326:

    # d worried "Sam."
    d worried "Sam。"

# game/script/ch09.rpy:273
translate japanese ch09_0393f837:

    # "Just his name, at first. Doyle had heard. Doyle had heard everything."
    "最初はただ名前だけだった。Doyleは聞いていた。Doyleは何もかも聞いていた。"

# game/script/ch09.rpy:274
translate japanese ch09_af82a224:

    # d "Sam, are you—"
    d "Sam、お前――"

# game/script/ch09.rpy:275
translate japanese ch09_227c7c4a:

    # s shocked "He's dead, Ray."
    s shocked "死んだよ、Ray。"

# game/script/ch09.rpy:276
translate japanese ch09_51318728:

    # "His own voice sounded very far away and very calm."
    "自分の声がひどく遠く、ひどく落ち着いて聞こえた。"

# game/script/ch09.rpy:277
translate japanese ch09_e0d5de57:

    # s "They took him off the van on Route Nine and beat him to death in the road, and I was ten feet from him, and there were fifty of them, and I could not stop it."
    s "Route Nineで護送車から引きずり出されて、道の上で殴り殺された。俺は十フィートのところにいた。向こうは五十人だった。止められなかった。"

# game/script/ch09.rpy:278
translate japanese ch09_d7a839e6:

    # "A long silence on the line. When Doyle spoke again his voice had gone thick."
    "回線の向こうで長い沈黙。ふたたび口を開いたとき、Doyleの声はくぐもっていた。"

# game/script/ch09.rpy:279
translate japanese ch09_46fd802e:

    # d "Poole's already on to the county saying you went in alone against the whole road. Sam — nobody is going to lay this on you—"
    d "Pooleがもう郡に言ってる。お前が道じゅうを相手にひとりで突っ込んでいったってな。Sam――誰もお前のせいにはしない――"

# game/script/ch09.rpy:280
translate japanese ch09_0928f0fc:

    # s "I don't care what they lay on me."
    s "俺のせいにされようがかまわない。"

# game/script/ch09.rpy:281
translate japanese ch09_3e4f2405:

    # "And he found, saying it, that it was true. Under the grief and the guilt and the blood drying on his face there was a third thing rising, cold and clear and level, that he did not yet have a name for."
    "口にしてみて、それが本当だとわかった。悲しみと罪悪感と、顔で乾いていく血の下で、三つめの何かが立ち上がってきていた。冷たく、澄んで、水平な何か。まだ名前のないものが。"

# game/script/ch09.rpy:282
translate japanese ch09_609a01cd:

    # s hurt "Ray. Listen to me. Something's wrong."
    s hurt "Ray。聞いてくれ。何かがおかしい。"

# game/script/ch09.rpy:283
translate japanese ch09_3da53243:

    # d "Sam—"
    d "Sam――"

# game/script/ch09.rpy:284
translate japanese ch09_0e491746:

    # s "I mean it."
    s "本気だ。"

# game/script/ch09.rpy:285
translate japanese ch09_11113032:

    # "He was looking down at George Bennett as he said it, at the ruined, finished face, at the cuffed hands that even now had never come apart."
    "そう言いながら、彼はGeorge Bennettを見下ろしていた。壊れて、やり終えた顔を。いまでさえ一度も離れなかった、手錠をかけられた両手を。"

# game/script/ch09.rpy:286
translate japanese ch09_b27056c3:

    # s hurt "He never said a word. All night. I gave him every door, Ray. I gave him the girl, I gave him his own life, and he sat there and took the rope over one sentence that would've saved him."
    s hurt "ひと言も言わなかった。一晩じゅうだ。俺はあらゆる扉を開けてやったんだ、Ray。あの子のことも、あいつ自身の命のことも持ち出した。なのにあいつはそこに座って、自分を救ったはずのたったひとつの文の代わりに、縄を受け取った。"

# game/script/ch09.rpy:287
translate japanese ch09_ffc760b9:

    # s "And I have been telling myself all night that's a guilty man protecting himself."
    s "で、俺は一晩じゅう、あれは自分を守っている有罪の男だと自分に言い聞かせてきた。"

# game/script/ch09.rpy:288
translate japanese ch09_aaf2f034:

    # "He wiped the blood out of his eye with the back of his wrist."
    "彼は手首の裏で目に入った血を拭った。"

# game/script/ch09.rpy:289
translate japanese ch09_d66bed03:

    # s hurt "Guilty men don't do that. I've been doing this thirty years. Guilty men talk. Guilty men deal. Guilty men give you the other fella."
    s hurt "有罪の男はああいうことはしない。三十年やってきたんだ。有罪の男はしゃべる。取引する。別の奴を差し出す。"

# game/script/ch09.rpy:290
translate japanese ch09_6853b4bd:

    # s "This man had a way out and looked at it and chose to die instead, and there is only one kind of man I've ever known do that."
    s "あの男には逃げ道があった。それを見て、代わりに死ぬことを選んだ。そんなことをする男を、俺はひと種類しか知らない。"

# game/script/ch09.rpy:291
translate japanese ch09_3f05e48c:

    # d "...And what kind is that."
    d "……どんな種類だ。"

# game/script/ch09.rpy:292
translate japanese ch09_7dc0714e:

    # "Samuel was quiet a moment, on his knees again now, though he did not remember kneeling, beside the body in the reddened snow. The certainty settled into him the way cold settles, from the outside in."
    "Samuelはしばらく黙っていた。赤く染まった雪の上、遺体のそばで、またひざをついていた。ひざまずいた覚えはなかった。確信が、寒さが沁みるように、外側から内側へと彼のなかに沈んでいった。"

# game/script/ch09.rpy:297
translate japanese ch09_37e092d2:

    # s hurt "A man protecting somebody."
    s hurt "誰かを守っている男だ。"

# game/script/ch09.rpy:299
translate japanese ch09_90b02c16:

    # th "I told Ray 'not yet' in that car. He heard 'soon'. So did I."
    th "あの車で、俺はRayに「まだだ」と言った。Rayは「もうすぐ」と聞いた。俺もそう聞いた。"

# game/script/ch09.rpy:301
translate japanese ch09_c218c8b0:

    # th "'You're right,' I told him in that car. The truest wrong thing I said all winter."
    th "「あんたの言うとおりだ」と、あの車で俺はRayに言った。この冬に俺が口にした、いちばん正直な間違いだ。"

# game/script/ch09.rpy:304
translate japanese ch09_392d9e8a:

    # note_voice "He never said a word. Guilty men talk."
    note_voice "ひと言も言わず。有罪の男はしゃべる。"

# game/script/ch09.rpy:306
translate japanese ch09_b374e722:

    # note_voice "A man protecting somebody."
    note_voice "誰かを守っている男。"

# game/script/ch09.rpy:313
translate japanese ch09_712b0f8a:

    # "Far below them the town was going home. Above them the pines held their snow."
    "はるか下で、町は家路についていた。頭上では、松が雪を抱えていた。"

# game/script/ch09.rpy:314
translate japanese ch09_2ab5e595:

    # "And somewhere down in the white valley a twelve-year-old girl was being minded by a kind woman who believed she was comforting an orphan."
    "そして白い谷の底のどこかで、十二歳の少女が、孤児を慰めていると信じている親切な女に見守られていた。"

# game/script/ch09.rpy:315
translate japanese ch09_f29c95c7:

    # "While up on the road Samuel Harris knelt bleeding beside the innocent man he had helped to kill, and felt the first thin crack open in the floor he had stood on all week."
    "そのあいだ、上の道ではSamuel Harrisが、自分が殺す手助けをした無実の男のそばで血を流しながらひざまずき、一週間ずっと立ってきた床に、最初の細いひびが入るのを感じていた。"

# game/script/ch09.rpy:316
translate japanese ch09_d14681f8:

    # "And through it, where his certainty had been, nothing but cold air, and a long way down."
    "そしてそのひびの向こうには、確信があった場所に、冷たい空気と、はるかな落差だけがあった。"

translate japanese strings:

    # game/script/ch09.rpy:89
    old "Go for the man with the tire iron."
    new "タイヤレバーの男に向かう。"

    # game/script/ch09.rpy:93
    old "Go for the van doors."
    new "護送車の扉に向かう。"

    # game/script/ch09.rpy:246
    old "Look her in the eye."
    new "彼女の目を見る。"

    # game/script/ch09.rpy:250
    old "Look at the notebook."
    new "手帳を見る。"

