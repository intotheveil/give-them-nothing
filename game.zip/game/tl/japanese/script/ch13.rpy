# TODO: Translation updated at 2026-10-11 10:23

# game/script/ch13.rpy:14
translate japanese ch13_b3f553bf:

    # "The station was nearly empty, the way such places are at that hour."
    "スタンドはほとんど無人だった。そういう場所が、その時刻にはそうであるように。"

# game/script/ch13.rpy:15
translate japanese ch13_26cd7871:

    # "One bored attendant behind the glass of the shop with a phone held close to his face. The forecourt bright and vacant under its cold canopy. No other car for as far as the dark went in either direction."
    "売店のガラスの向こうに退屈そうな店員が一人、携帯電話を顔に近づけて持っていた。給油場は冷たいキャノピーの下で明るく、がらんとしていた。闇の続くかぎり、どちらの方向にも、ほかの車は一台もなかった。"

# game/script/ch13.rpy:16
translate japanese ch13_92a72221:

    # "Samuel pulled up at the outermost pump, farthest from the light, out of an old habit he did not examine, and cut the engine."
    "Samuelは光からいちばん遠い、いちばん外側の給油機に車を寄せた。自分でも顧みることのない古い習慣からだった。そしてエンジンを切った。"

# game/script/ch13.rpy:18
translate japanese ch13_5c1fb6be:

    # "For a moment the two of them sat in the sudden silence, with the tick of the cooling engine between them and the hard white light coming in the windows."
    "一瞬、二人は突然の静寂の中に座っていた。冷えていくエンジンのカチカチという音を挟んで、硬く白い光が窓から差し込んでいた。"

# game/script/ch13.rpy:19
translate japanese ch13_45f5cb6d:

    # s tired "I need the fuel. And then it's an hour, and you're there, and this is over."
    s tired "給油しないといけない。そうしたらあと一時間で着く。それで終わりだ。"

# game/script/ch13.rpy:21
translate japanese ch13_c5e8d9b7:

    # a "Can I use the toilet?"
    a "トイレに行ってもいいですか？"

# game/script/ch13.rpy:22
translate japanese ch13_f3b7731c:

    # "Alice had her hand on the door already, her small bag on her shoulder. A child's voice, ordinary, a little embarrassed the way children are about their bodies."
    "Aliceはもうドアに手をかけていた。小さな鞄を肩に掛けて。子どもの声だった。ありふれた、子どもが自分の体のことで見せる、少しばかりの恥ずかしさを帯びた声。"

# game/script/ch13.rpy:23
translate japanese ch13_2877deef:

    # a "Before we go the last part. I won't be long."
    a "最後の道のりに出る前に。すぐ戻ります。"

# game/script/ch13.rpy:31
translate japanese ch13_8a76453b:

    # "The bag. For a toilet. Everything she owned, and the coin, and whatever else."
    "鞄。トイレに。持ち物のすべてと、コインと、ほかに何であれ。"

# game/script/ch13.rpy:32
translate japanese ch13_9ba99d56:

    # th "A child alone takes all of it with her. Every time."
    th "一人きりの子どもは全部持っていく。いつだって。"

# game/script/ch13.rpy:36
translate japanese ch13_51778a3d:

    # "There it was: the ordinary human request that a man cannot refuse a twelve-year-old at a gas station in the dark without becoming, in that instant, a monster himself."
    "そこにあった。暗闇のガソリンスタンドで十二歳の子どもに頼まれて、断れば、その瞬間に自分が怪物になってしまう、ありふれた人間の頼み。"

# game/script/ch13.rpy:37
translate japanese ch13_5872e942:

    # "He knew everything and could prove nothing. He had spent four hours feeling his certainty drown, and had dragged it, gasping, back up onto dry land in the last cold mile."
    "彼はすべてを知っていて、何ひとつ証明できなかった。四時間、確信が溺れていくのを感じ、最後の冷たい一マイルで、喘ぐそれを乾いた陸へと引きずり上げたのだった。"

# game/script/ch13.rpy:38
translate japanese ch13_3cbd9bb8:

    # "And he felt the whole impossible shape of his situation close over him like water."
    "そして自分の置かれた状況の、ありえない全体の形が、水のように頭上で閉じるのを感じた。"

# game/script/ch13.rpy:43
translate japanese ch13_b2e073f3:

    # "He could not stop her. On what grounds."
    "彼女を止めることはできなかった。何を根拠に。"

# game/script/ch13.rpy:44
translate japanese ch13_b5304b03:

    # "He could not say {i}I know what you are, so you'll hold it.{/i} He could not cuff a grieving orphan to the door handle of his car, on a suspicion no soul on earth would credit."
    "{i}君が何者か知っている、だから我慢しなさい{/i}とは言えなかった。地上の誰ひとり信じないような疑いで、悲嘆に暮れる孤児を車のドアハンドルに手錠でつなぐことはできなかった。"

# game/script/ch13.rpy:47
translate japanese ch13_56cfcae1:

    # "His eyes went to the canvas holdall on her shoulder. He had not searched her, not once in four hours. Not the bag that held everything the world had left her, nor the small body it hung from."
    "彼の目は彼女の肩に掛かった帆布のボストンバッグへ向かった。四時間のあいだ、一度も彼女を調べていなかった。世界が彼女に残したものすべてを入れた鞄も、それが掛かっている小さな体も。"

# game/script/ch13.rpy:48
translate japanese ch13_8a9d38cf:

    # "His hand began to move, and stopped."
    "手が動きかけ、止まった。"

# game/script/ch13.rpy:49
translate japanese ch13_53d8024d:

    # "To run his hands over a grieving child like a suspect was a thing he could no more make himself do than strike her. The very wanting-to was its own kind of filth."
    "悲嘆に暮れる子どもの体を容疑者のように手で探るなど、彼女を殴るのと同じくらい、自分にさせることのできないことだった。そうしたいと思うことそのものが、一種の汚れだった。"

# game/script/ch13.rpy:52
translate japanese ch13_5c18c623:

    # "The words were there. {i}You'll hold it.{/i} Three words."
    "言葉はそこにあった。{i}我慢しなさい{/i}。ほんのひと言。"

# game/script/ch13.rpy:53
translate japanese ch13_66c32af9:

    # "And behind them, the rest of the sentence he would have to say if she asked why. {i}Because I know what you are.{/i}"
    "そしてその背後に、なぜと訊かれたら言わなければならない文の残り。{i}君が何者か知っているからだ{/i}。"

# game/script/ch13.rpy:54
translate japanese ch13_43382219:

    # "He could not say it. A grieving orphan, a child in his protective care, on a suspicion no soul on earth would credit."
    "それは言えなかった。悲嘆に暮れる孤児に。彼の保護下にある子どもに。地上の誰ひとり信じないような疑いで。"

# game/script/ch13.rpy:56
translate japanese ch13_0905b74a:

    # "He could not draw the weapon under his coat on a twelve-year-old walking to a toilet, and know himself a man afterward."
    "トイレへ歩いていく十二歳にコートの下の銃を抜いて、その後も自分を人間だと思えるはずがなかった。"

# game/script/ch13.rpy:57
translate japanese ch13_3c5b0880:

    # "Every door his training reached for had a child standing in it, and his hand stopped at every one."
    "訓練が手を伸ばすどの扉にも子どもが立っていて、彼の手はそのひとつひとつで止まった。"

# game/script/ch13.rpy:58
translate japanese ch13_d3f3272c:

    # "That was the trap, and it had never been a trap of her building. It was the trap of his own decency, the last unspoiled thing in him."
    "それが罠だった。そしてそれは、決して彼女が仕掛けた罠ではなかった。それは彼自身のまっとうさという罠、彼のなかに残った最後の損なわれていないものだった。"

# game/script/ch13.rpy:59
translate japanese ch13_1a0cd7e4:

    # "She had read it in him weeks ago across a notebook, and had counted, all the way down the mountain, on its holding."
    "彼女は何週間も前に手帳越しにそれを彼のなかに読み取り、山を下るあいだずっと、それが持ちこたえることを当てにしていた。"

# game/script/ch13.rpy:60
translate japanese ch13_4b3de87c:

    # s tired "Go on. I'll be right here. Don't be long."
    s tired "行っておいで。ここにいるから。早く戻るんだよ。"

# game/script/ch13.rpy:62
translate japanese ch13_7c94a916:

    # "She got out. He watched her cross the forecourt in the white light, small in her too-big coat, the bag on her shoulder, unhurried."
    "彼女は車を降りた。白い光の中、給油場を横切っていくのを彼は見つめた。大きすぎるコートの中で小さく、鞄を肩に掛け、急ぐでもなく。"

# game/script/ch13.rpy:63
translate japanese ch13_39693921:

    # "She disappeared around the side of the shop toward the squat row of toilets."
    "彼女は売店の角を曲がり、ずんぐりと並んだトイレのほうへ消えた。"

# game/script/ch13.rpy:65
translate japanese ch13_98d5bf54:

    # "He sat one moment more with both hands flat on his thighs and his heart going like a fist on a door."
    "彼はもう一瞬だけ座っていた。両手を腿の上に平らに置き、心臓は扉を叩く拳のように打っていた。"

# game/script/ch13.rpy:66
translate japanese ch13_35d4780c:

    # "Then he made himself move, because a man who sat frozen in a car was no use to anyone, least of all himself."
    "それから自分を動かした。車の中で凍りついて座っている男など誰の役にも立たない。自分自身にとってはなおさらだ。"

# game/script/ch13.rpy:71
translate japanese ch13_6c2856b4:

    # "He got out into the cold. The night was enormous and clean and bitter, the stars very hard overhead."
    "彼は寒さの中へ降り立った。夜は巨大で、澄んでいて、身を切るようで、頭上の星はひどく硬かった。"

# game/script/ch13.rpy:72
translate japanese ch13_07292dfe:

    # "The gorge was a deeper black past the broken run of barrier rail at the lot's edge. The only sound was the hum of the canopy lights and, faint, the wind coming up out of the drop."
    "敷地の端の、途切れ途切れのガードレールの向こうで、峡谷はいっそう深い黒だった。聞こえるのはキャノピーの照明の唸りと、かすかに、落ち込みから吹き上がってくる風だけだった。"

# game/script/ch13.rpy:73
translate japanese ch13_7311d640:

    # "He unhooked the nozzle and set it in the tank and started the pump, and stood there in the light with the fuel running, his back to the shop and the toilets."
    "彼はノズルを外して給油口に差し込み、ポンプを動かした。そして燃料が流れるあいだ、売店とトイレに背を向けて光の中に立っていた。"

# game/script/ch13.rpy:74
translate japanese ch13_a8608f30:

    # "And made himself think, fast and cold, the way he had not let himself think in four hours."
    "そして自分に考えさせた。速く、冷たく。この四時間、自分に許さなかったやり方で。"

# game/script/ch13.rpy:75
translate japanese ch13_e7556369:

    # "Because this was the place. He had never seen this station in his life, but he knew the shape of it. The wrongness."
    "なぜならここがその場所だったからだ。このスタンドは生まれて一度も見たことがなかったが、その形は知っていた。その歪みを。"

# game/script/ch13.rpy:76
translate japanese ch13_c83da34f:

    # "The whole day had been running downhill toward exactly this: a lit and lonely nowhere, a cliff, a child gone quiet, and himself alone in the open."
    "一日じゅう、すべてはまさにここへ向かって坂を下ってきていた。明かりの灯った寂しい、どこでもない場所。崖。黙り込んだ子ども。そして開けた場所に一人きりの自分。"

# game/script/ch13.rpy:77
translate japanese ch13_e7788f53:

    # "He had watched her, on the road, close a file on him."
    "道中、彼女が彼についてのファイルを閉じるのを、彼は見ていた。"

# game/script/ch13.rpy:78
translate japanese ch13_ad3d7b0f:

    # th "She didn't ask to use the toilet because she needed the toilet."
    th "トイレに行きたかったから、トイレに行かせてくれと言ったんじゃない。"

# game/script/ch13.rpy:79
translate japanese ch13_0fdb2577:

    # "The animal in him knew it, standing at the pump with the diesel running."
    "ディーゼルを流しながら給油機の前に立つ彼のなかの獣は、それを知っていた。"

# game/script/ch13.rpy:84
translate japanese ch13_d01db5f5:

    # "His hand moved toward the weapon under his coat. It got as far as the lapel."
    "手がコートの下の銃へと動いた。襟元まで行った。"

# game/script/ch13.rpy:85
translate japanese ch13_b960d93b:

    # "And stopped there, because it was a child."
    "そしてそこで止まった。相手が子どもだったから。"

# game/script/ch13.rpy:88
translate japanese ch13_d0d10dc9:

    # "He kept his hands where they were. And still his hand drifted, without his deciding it, toward the weapon under his coat."
    "彼は両手をそのままにしていた。それでも手は、彼が決めたわけでもないのに、コートの下の銃へと漂っていった。"

# game/script/ch13.rpy:89
translate japanese ch13_d5eeea92:

    # "And stopped, because it was a child."
    "そして止まった。相手が子どもだったから。"

# game/script/ch13.rpy:91
translate japanese ch13_b6a0c510:

    # "It hung there, useless, in the six inches between decency and survival where Samuel Harris had lived his whole ruined life."
    "手はそこに、役立たずのまま宙に浮いていた。まっとうさと生存のあいだの六インチ、Samuel Harrisがその壊れた人生のすべてを生きてきた場所に。"

# game/script/ch13.rpy:92
translate japanese ch13_f06e9426:

    # "That was where he was standing, and that was where his hand was, when he heard it over the hum of the light and the run of the fuel."
    "彼が立っていたのはそこで、彼の手があったのもそこだった。照明の唸りと燃料の流れる音の向こうに、それが聞こえたとき。"

# game/script/ch13.rpy:93
translate japanese ch13_837eaac1:

    # "The small clean sound of her feet coming back across the concrete behind him. Quicker than a child who needed nothing would walk."
    "背後のコンクリートを戻ってくる、彼女の足の小さく澄んだ音。何も必要としていない子どもが歩くよりも速かった。"

# game/script/ch13.rpy:97
translate japanese ch13_0244b6ea:

    # "He turned."
    "彼は振り向いた。"

# game/script/ch13.rpy:99
translate japanese ch13_0ddbb32a:

    # "And the child was gone."
    "そして、子どもはいなくなっていた。"

# game/script/ch13.rpy:100
translate japanese ch13_2195d915:

    # "That was the thing he would carry out of that forecourt, if he carried anything out of it at all. Not a monster. Not a face contorted into anything. Nothing so easy to bear."
    "それが、彼があの給油場から持ち帰ることになるものだった。何かを持ち帰れたとしての話だが。怪物ではない。何かの形に歪んだ顔でもない。そんな耐えやすいものではない。"

# game/script/ch13.rpy:101
translate japanese ch13_e7a54aff:

    # "Just an absence. The warmth switched off at the wall. The grief, the softness, the frightened orphan, all of it set down somewhere back in the dark like a coat she no longer needed."
    "ただの不在。壁のスイッチで切られた温もり。悲しみも、やわらかさも、怯えた孤児も、そのすべてが、もう要らなくなったコートのように後ろの闇のどこかに置かれていた。"

# game/script/ch13.rpy:102
translate japanese ch13_796b20ce:

    # "What stood in front of him in the cold white light, six feet away and closing, was the thing he had first glimpsed weeks ago across a notebook and had spent every day since refusing to look at."
    "冷たく白い光の中、六フィート先に立ち、距離を詰めてくるもの。それは何週間も前に手帳越しに初めて垣間見て、それ以来毎日、見ることを拒んできたものだった。"

# game/script/ch13.rpy:103
translate japanese ch13_1f83a82a:

    # "A calm, patient, unhurried attention, very old and entirely without mercy, looking out of a twelve-year-old's gray eyes at a man it had weighed and found wanting."
    "穏やかで、辛抱強く、急がない注意。とても古く、慈悲をまったく持たないそれが、十二歳の灰色の目から、量り終えて不足と断じた男を見つめていた。"

# game/script/ch13.rpy:104
translate japanese ch13_52f2110f:

    # "She had a knife. A kitchen knife, plain, the kind that lives in any drawer in any house."
    "彼女はナイフを持っていた。包丁だ。飾り気のない、どこの家のどの引き出しにもあるような。"

# game/script/ch13.rpy:105
translate japanese ch13_998978d7:

    # "She had carried it out of the foster kitchen the way she carried everything: quietly, in advance, in case. Whatever she had decided about him on the road, she had come down the mountain ready to decide it."
    "彼女はそれを、何でもそうしてきたように里親の台所から持ち出していた。静かに、前もって、念のために。道中で彼について何を決めたにせよ、彼女はそれを決める用意をして山を下りてきたのだ。"

# game/script/ch13.rpy:106
translate japanese ch13_596cebf3:

    # a cold "You knew."
    a cold "知ってたのね。"

# game/script/ch13.rpy:107
translate japanese ch13_cec11e37:

    # "Not a question. Her voice had nothing in it. No fear, no heat. Only a kind of mild, terrible interest."
    "問いではなかった。その声には何もなかった。恐れも、熱も。ただ、穏やかで恐ろしい一種の興味だけがあった。"

# game/script/ch13.rpy:108
translate japanese ch13_a7b7d89f:

    # a cold "For a while now. I watched you know it."
    a cold "しばらく前から。あなたが知っていくのを見てた。"

# game/script/ch13.rpy:109
translate japanese ch13_8872b9fd:

    # "Her head tilted: the small precise movement he had seen her make over a dying priest, over a mug of cocoa. Weighing."
    "彼女の頭が傾いだ。死にゆく神父の上で、ココアのマグの上で、彼女がするのを見たことのある、小さく正確な動き。量っていた。"

# game/script/ch13.rpy:110
translate japanese ch13_db72635e:

    # a cold "I hoped I was wrong about you. At the start you were the only strong one. I thought— here, finally, is one who carries it and doesn't break."
    a cold "あなたについては間違っていたらいいと思ってた。最初、あなただけが強き者だった。思ったの――ここにやっと、背負っても壊れない人がいるって。"

# game/script/ch13.rpy:111
translate japanese ch13_94ffc2f0:

    # "Something almost like sorrow crossed the calm, and it was the most frightening thing yet, because it was real."
    "悲しみにも似た何かが落ち着きを横切った。それがこれまででいちばん恐ろしかった。本物だったからだ。"

# game/script/ch13.rpy:112
translate japanese ch13_7b0c0f3c:

    # a cold "But you're soft all the way down, Detective. You had it and you couldn't say it."
    a cold "でも、あなたは底の底までやわらかいのね、刑事さん。わかっていたのに、言えなかった。"

# game/script/ch13.rpy:113
translate japanese ch13_d2ff91f4:

    # a cold "You knew what I was and you drove me anyway, and you tried to {i}save{/i} me."
    a cold "私が何者か知っていて、それでも私を乗せて走って、私を{i}救おう{/i}とした。"

# game/script/ch13.rpy:114
translate japanese ch13_f13e39b6:

    # "The word came out with the only contempt she had ever let him see."
    "その言葉は、彼女がこれまで彼に見せた唯一の軽蔑とともに吐き出された。"

# game/script/ch13.rpy:115
translate japanese ch13_8a3a5c06:

    # a cold "You were almost worthy. You were the closest I ever found."
    a cold "あなたは、もう少しで値するところだった。私が見つけたなかで、いちばん近かった。"

# game/script/ch13.rpy:116
translate japanese ch13_3e91318a:

    # s shocked "Alice—"
    s shocked "Alice――"

# game/script/ch13.rpy:117
translate japanese ch13_d9583d0e:

    # a cold "It's alright."
    a cold "いいの。"

# game/script/ch13.rpy:118
translate japanese ch13_ab012202:

    # "She said it gently, the way you'd gentle a horse. And stepped in."
    "馬をなだめるように、彼女は優しくそう言った。そして踏み込んだ。"

# game/script/ch13.rpy:123
translate japanese ch13_1303be01:

    # "And put the knife into him."
    "そしてナイフを彼に突き入れた。"

# game/script/ch13.rpy:127
translate japanese ch13_09cd71ab:

    # "Low in his side, under the ribs. A small hot certainty, no drama to it at all. A child's whole weight behind a domestic blade."
    "脇腹の低いところ、肋骨の下。小さく熱い確かさ。芝居がかったところはまるでない。家庭用の刃の背後に、子どもの全体重がかかっていた。"

# game/script/ch13.rpy:128
translate japanese ch13_b4618622:

    # "The pain came a beat late and enormous, and the world tilted white."
    "痛みは一拍遅れて、途方もなく大きくやってきた。世界が白く傾いた。"

# game/script/ch13.rpy:129
translate japanese ch13_2c51801f:

    # "He heard himself make a sound he had never made. His knees went."
    "自分が一度も出したことのない声を出すのが聞こえた。膝が崩れた。"

# game/script/ch13.rpy:130
translate japanese ch13_eafdd717:

    # "The diesel nozzle tore out of the tank and clattered on the concrete, and lay there hissing a slick of fuel out across the cold forecourt."
    "ディーゼルのノズルが給油口から引きちぎれるように外れ、コンクリートに音を立てて落ち、冷たい給油場に燃料をシュウシュウと吐き広げながらそこに転がった。"

# game/script/ch13.rpy:132
translate japanese ch13_56e29896:

    # "She stepped back from him, out of the reach of a falling man. Patient. Watching him fold. Waiting for the strong one to finish being strong."
    "彼女は倒れていく男の手の届かないところへ下がった。辛抱強く。彼が崩れていくのを見つめて。強き者が強くあることを終えるのを待って。"

# game/script/ch13.rpy:138
translate japanese ch13_71420d21:

    # "But he did not finish."
    "だが彼は終わらなかった。"

# game/script/ch13.rpy:139
translate japanese ch13_99bef342:

    # "That was the thing she had never seen, in all her careful study of the weak."
    "それが、弱き者を注意深く研究してきた彼女が、一度も見たことのないものだった。"

# game/script/ch13.rpy:140
translate japanese ch13_fda2cca4:

    # "There is a floor under a man. Below the reason. Below the decency. Below the grief."
    "男の下には床がある。理性の下に。まっとうさの下に。悲しみの下に。"

# game/script/ch13.rpy:141
translate japanese ch13_fb5fd62d:

    # "A blind red room with no thought in it at all."
    "思考のまったくない、盲目の赤い部屋。"

# game/script/ch13.rpy:142
translate japanese ch13_256eda5c:

    # "When the knife goes in, it is not the detective who answers. Not the father. Not the good man who could not draw on a child."
    "ナイフが入ったとき、応えるのは刑事ではない。父親でもない。子どもに銃を抜けなかった善良な男でもない。"

# game/script/ch13.rpy:143
translate japanese ch13_80c5fe15:

    # "It is the animal."
    "獣だ。"

# game/script/ch13.rpy:144
translate japanese ch13_576b68dd:

    # "And the animal does not care that she is twelve. The animal does not care about anything but the next breath."
    "そして獣は、彼女が十二歳であることなど気にかけない。獣が気にかけるのは、次のひと息だけだ。"

# game/script/ch13.rpy:145
translate japanese ch13_64b183d4:

    # "It came up out of the floor of him as his knees hit the concrete and his own blood ran hot over his hand. And it took the wheel."
    "膝がコンクリートを打ち、自分の血が熱く手を伝ったとき、それは彼の床から這い上がってきた。そしてハンドルを握った。"

# game/script/ch13.rpy:146
translate japanese ch13_2ed08a55:

    # "She stepped in to finish it. One more, into the neck, clean, the way you'd end anything."
    "彼女はとどめを刺そうと踏み込んだ。もう一突き、首へ。きれいに。何かを終わらせるときのように。"

# game/script/ch13.rpy:149
translate japanese ch13_3d0cc47f:

    # "The wounded thing on the ground caught her wrist."
    "地面の傷ついたものが、彼女の手首をつかんだ。"

# game/script/ch13.rpy:150
translate japanese ch13_281dd59a:

    # "It caught her wrist and it did not let go."
    "手首をつかみ、放さなかった。"

# game/script/ch13.rpy:151
translate japanese ch13_516111fc:

    # "She pulled, and it held. A big man's ruined hand closed to the bone around a child's thin arm."
    "彼女は引いた。それは離さなかった。大男の壊れた手が、子どもの細い腕に骨まで食い込んで閉じていた。"

# game/script/ch13.rpy:152
translate japanese ch13_cc5e5089:

    # "For the first time in the whole cold history of her, something went wrong in the calm gray eyes. Some small astonishment."
    "彼女の冷たい来歴のすべてで初めて、穏やかな灰色の目の中で何かが狂った。小さな驚き。"

# game/script/ch13.rpy:153
translate japanese ch13_f740fcd3:

    # "The sum was not coming out. The strong one was supposed to be finished, and was not finished, and was rising."
    "計算が合わなかった。強き者は終わっているはずだった。なのに終わっておらず、立ち上がろうとしていた。"

# game/script/ch13.rpy:154
translate japanese ch13_a329812e:

    # "Dragging himself up her arm hand over hand like a drowning man up a rope. Enormous, bleeding, beyond stopping."
    "溺れる男がロープをたぐるように、彼女の腕を手から手へとたぐって自分を引き上げてくる。巨大で、血を流し、止めようもなく。"

# game/script/ch13.rpy:155
translate japanese ch13_f396ca3e:

    # "The knife came loose and skittered away into the dark, and neither of them looked at it."
    "ナイフが外れて闇の中へ滑っていき、二人ともそれを見なかった。"

# game/script/ch13.rpy:156
translate japanese ch13_721176ce:

    # th "Get up."
    th "立て。"

# game/script/ch13.rpy:157
translate japanese ch13_d6f792e2:

    # "He got up. Folded around the fire in his side, he got up the way he had gotten up in the road with George, because it was the one thing left in him that was still his."
    "彼は立った。脇腹の炎を抱え込むように身を折り、Georgeのいたあの道で立ち上がったように立ち上がった。それが彼のなかに残った、まだ彼自身のものである唯一のものだったから。"

# game/script/ch13.rpy:158
translate japanese ch13_b3eb4989:

    # "And he got his hands on her."
    "そして彼女に手をかけた。"

# game/script/ch13.rpy:160
translate japanese ch13_217f74c2:

    # "He would never be able to lay the seconds out in their order. Only pieces. Only pieces, for the rest of his life."
    "その数秒を順序立てて並べることは、彼には決してできないだろう。断片だけ。残りの人生ずっと、断片だけ。"

# game/script/ch13.rpy:161
translate japanese ch13_64b5d8ab:

    # "The small body twisting. Ferociously strong for its size."
    "身をよじる小さな体。その大きさに似合わず、猛々しく強い。"

# game/script/ch13.rpy:162
translate japanese ch13_c4c33196:

    # "And silent. No scream. No plea. Giving him nothing to the very end, the way the old man had taught her, in a colder house, long ago."
    "そして無言だった。悲鳴もない。懇願もない。最後の最後まで彼に何も与えない。ずっと昔、もっと冷たい家で、あの老人が教えたとおりに。"

# game/script/ch13.rpy:163
translate japanese ch13_b39c93dc:

    # "His own voice, saying something. A word. A name. He never knew what."
    "何かを言っている自分の声。ひとつの言葉。ひとつの名前。何だったのか、彼には最後までわからなかった。"

# game/script/ch13.rpy:164
translate japanese ch13_e77a51b6:

    # "There was a gun under his coat and he never reached for it."
    "コートの下には銃があり、彼は一度もそれに手を伸ばさなかった。"

# game/script/ch13.rpy:165
translate japanese ch13_3ba6760d:

    # "The animal did not think of steel. Or the man inside the animal would not, even blind, even dying, put a bullet in a child."
    "獣は鋼のことなど考えなかった。あるいは、獣の内側の人間が、盲目になっても、死にかけていても、子どもに弾を撃ち込もうとはしなかったのだ。"

# game/script/ch13.rpy:166
translate japanese ch13_a654cccc:

    # "So it was his hands. Only ever his hands."
    "だから、それは彼の手だった。ただ彼の手だけだった。"

# game/script/ch13.rpy:167
translate japanese ch13_9ee69a03:

    # "The hands that had held a report and a cigarette and a dead man's ruined face. And once, a thing no heavier than a loaf of bread, that had been warm and then was not."
    "報告書を持ち、煙草を持ち、死んだ男の壊れた顔を抱えた手。そしてかつて、一斤のパンほどの重さもないものを抱き、それが温かく、それから温かくなくなった手。"

# game/script/ch13.rpy:168
translate japanese ch13_bd8f42b3:

    # "Those hands found the child's throat in the dark, and closed."
    "その手が、闇の中で子どもの喉を見つけ、閉じた。"

# game/script/ch13.rpy:169
translate japanese ch13_ca367d6d:

    # "Not the detective deciding it. Not the father. Only the animal in the blind red room, and the body taking her breath to keep its own."
    "刑事が決めたのではない。父親でもない。ただ盲目の赤い部屋の獣と、自分の息を保つために彼女の息を奪う体だけだった。"

# game/script/ch13.rpy:173
translate japanese ch13_dbea35d8:

    # "It did not take long. She was very small."
    "長くはかからなかった。彼女はとても小さかった。"

# game/script/ch13.rpy:174
translate japanese ch13_a24eb20f:

    # "That was the thing he would not be able to stop knowing. That at the last she did not fight it the way she had fought the wrist."
    "それが、彼が知っていることをやめられなくなるものだった。最後に彼女が、手首のときのようには抗わなかったこと。"

# game/script/ch13.rpy:175
translate japanese ch13_79ddda75:

    # "Somewhere in it the ferocity went out of her, and she let it come."
    "そのどこかで猛々しさが彼女から抜け、彼女はそれが来るのに任せた。"

# game/script/ch13.rpy:176
translate japanese ch13_95411fe4:

    # "He could never decide, in all the years he had to decide it, whether that had been the body giving up, or the judge, at the very end, closing one last file."
    "それを決めるために与えられたすべての歳月をかけても、彼には決められなかった。あれは体が諦めたのか、それとも、裁く者が、最後の最後に、最後のファイルを閉じたのか。"

# game/script/ch13.rpy:177
translate japanese ch13_84af5640:

    # "Weighing the strong one's hands around her throat, and finding, at last, exactly the verdict she had come down the mountain to prove."
    "喉にかかった強き者の手を量り、ついに、山を下りてまで証明しにきたまさにその評決を見出したのか。"

# game/script/ch13.rpy:178
translate japanese ch13_0b58553f:

    # th "You were almost worthy. You were the closest I ever found."
    th "あなたは、もう少しで値するところだった。私が見つけたなかで、いちばん近かった。"

# game/script/ch13.rpy:179
translate japanese ch13_7ac03dce:

    # "She had come all this way, worked four hours down a mountain, to take the one strong man she had ever met and make him weak. Make him break."
    "彼女ははるばるここまで来たのだ。四時間かけて山を下りながら働きかけ、出会ったなかでただ一人の強い男を、弱くするために。壊すために。"

# game/script/ch13.rpy:180
translate japanese ch13_f6b08a35:

    # "Make him kill with his bare hands, in a red rage, the child he had sworn to protect."
    "赤い怒りのなかで、守ると誓った子どもを、素手で殺させるために。"

# game/script/ch13.rpy:181
translate japanese ch13_53ade6a6:

    # "And she had done it. In the only country that had ever mattered to her, the cold country of her judgment, Alice Bennett had won, and knew it as she went."
    "そして彼女はそれを成し遂げた。彼女にとって唯一意味のあった国、彼女の裁きという冷たい国において、Alice Bennettは勝ち、そのことを知りながら逝った。"

# game/script/ch13.rpy:182
translate japanese ch13_28c56104:

    # "Samuel knelt in the spreading fuel with her gone still under his hands, and knew it too."
    "Samuelは広がる燃料の中に膝をつき、両手の下で彼女が動かなくなるなかで、彼もまたそれを知った。"

# game/script/ch13.rpy:183
translate japanese ch13_657f8dd3:

    # "The winning was hers. The losing was only his. And it would be his forever."
    "勝ちは彼女のものだった。負けは彼だけのものだった。そしてそれは永遠に彼のものであり続けるだろう。"

# game/script/ch13.rpy:187
translate japanese ch13_d89654c5:

    # "Then his hands opened."
    "それから彼の手が開いた。"

# game/script/ch13.rpy:188
translate japanese ch13_7ee389bd:

    # "And there was nothing under them but a child."
    "そしてその下には、子どものほかに何もなかった。"

# game/script/ch13.rpy:198
translate japanese ch13_53234fa2:

    # "He knelt over her for a long time in the spreading fuel and the cold, and did not weep."
    "彼は広がる燃料と寒さの中で、長いあいだ彼女の上に膝をついていた。そして泣かなかった。"

# game/script/ch13.rpy:199
translate japanese ch13_27007acd:

    # "The weeping place was already full. It had been full for thirteen years, and there was no room in it for this."
    "泣く場所はすでにいっぱいだった。十三年前からいっぱいで、これの入る余地はなかった。"

# game/script/ch13.rpy:200
translate japanese ch13_75d1b67a:

    # "He knelt the way he had knelt over George. The way he had once stood over a coffin no heavier than a loaf of bread. Dry-eyed, upright, watching from a little way outside himself while his life fell into itself."
    "彼はGeorgeの上に膝をついたように膝をついていた。かつて、一斤のパンほどの重さもない棺の前に立ったように。涙もなく、背筋を伸ばし、少し離れた自分の外から、自分の人生が崩れ落ちていくのを見つめていた。"

# game/script/ch13.rpy:201
translate japanese ch13_9db67297:

    # "Somewhere behind the glass the attendant had finally looked up from his phone, and seen, and was shouting into it now."
    "ガラスの向こうのどこかで、店員がようやく携帯電話から顔を上げ、目にし、いまそれに向かって叫んでいた。"

# game/script/ch13.rpy:202
translate japanese ch13_4bf9dadf:

    # "The sound came to Samuel thin and far away, from another country. The country of people to whom things had not happened yet."
    "その声は細く遠く、別の国からSamuelに届いた。まだ何も起きていない人々の国から。"

# game/script/ch13.rpy:203
translate japanese ch13_cc96ce68:

    # "He should have been dead. The blade had gone in low and wide and found nothing in him that would kill a man."
    "彼は死んでいるはずだった。刃は低く、外側に入り、人を殺すようなものを彼のなかに何ひとつ見つけなかった。"

# game/script/ch13.rpy:204
translate japanese ch13_0ddfe7af:

    # "Not because he had been quick. He had been slow, a half-second too slow, slowed to the last by the decency in him that could not, even with a knife coming, believe a child would."
    "彼がすばやかったからではない。彼は遅かった。半秒遅かった。ナイフが迫っていてさえ、子どもがそうするとは信じられない彼のなかのまっとうさに、最後まで足を引っ張られて。"

# game/script/ch13.rpy:205
translate japanese ch13_5ece6818:

    # "But because she was twelve, and strong for it, and very good, and had not yet lived the years it takes to know exactly where in a body a life is kept."
    "そうではなく、彼女が十二歳で、その歳にしては強く、とても優秀で、体のどこに命がしまわれているのかを正確に知るほどの年月をまだ生きていなかったからだ。"

# game/script/ch13.rpy:206
translate japanese ch13_9d2b2bf9:

    # "It was the one mercy in the whole of it, and it was an accident, and it was the cruelest of them all. Because it meant he lived."
    "それがこの出来事全体の中の唯一の慈悲だった。そしてそれは偶然であり、すべての中で最も残酷なものだった。なぜならそれは、彼が生きることを意味したからだ。"

# game/script/ch13.rpy:207
translate japanese ch13_b6af9c1f:

    # "He got the coat off, one-handed, and wadded it against his side, and lay down on the cold concrete beside her, out of the reach of the fuel."
    "彼は片手でコートを脱ぎ、丸めて脇腹に押し当て、燃料の届かないところで、冷たいコンクリートの上、彼女の隣に横たわった。"

# game/script/ch13.rpy:212
translate japanese ch13_f707883e:

    # "He looked up at the hard stars, and waited for the far country to arrive with its lights and its hands."
    "硬い星を見上げ、遠い国がその光とその手を携えてやってくるのを待った。"

# game/script/ch13.rpy:213
translate japanese ch13_084c264f:

    # "And while he waited he did the last of the arithmetic, because he was, to the marrow, past all saving, a detective."
    "そして待つあいだに、最後の計算をした。彼は骨の髄まで、救いようもなく、刑事だったからだ。"

# game/script/ch13.rpy:214
translate japanese ch13_52671b36:

    # "They would believe him now."
    "これで、彼らは彼の言うことを信じるだろう。"

# game/script/ch13.rpy:215
translate japanese ch13_99bc164f:

    # "That was the terrible sum, coming out at last, clean and balanced and unbearable."
    "それが恐ろしい答えだった。ようやく出てきた答え。きれいで、釣り合いが取れていて、耐えがたい。"

# game/script/ch13.rpy:216
translate japanese ch13_d0ea97ae:

    # "A twelve-year-old who walks calm out of a toilet with a kitchen knife from a foster kitchen and puts it into a detective in the dark is not a grieving orphan."
    "里親の台所から持ち出した包丁を手に、落ち着き払ってトイレから歩み出て、闇の中で刑事にそれを突き立てる十二歳は、悲嘆に暮れる孤児ではない。"

# game/script/ch13.rpy:217
translate japanese ch13_a226e9bf:

    # "And a detective bleeding out beside her, with the receipt in his hotel room that put George Bennett twenty-five miles from a dying girl, is not a broken man seeing monsters anymore."
    "そして彼女の隣で血を流している刑事は――George Bennettを死にゆく少女から二十五マイル離れた場所に置くレシートをホテルの部屋に持つ刑事は――もはや怪物を見る壊れた男ではない。"

# game/script/ch13.rpy:218
translate japanese ch13_743d1ecb:

    # "He had come down the mountain with a truth no soul on earth would credit, and she had, in the last thing she ever did, made them credit it."
    "彼は地上の誰ひとり信じないような真実を抱えて山を下りてきた。そして彼女は、生涯最後の行いで、彼らにそれを信じさせたのだ。"

# game/script/ch13.rpy:219
translate japanese ch13_2c9a5217:

    # "George Bennett would come up out of the mud. The name would be cleared, the record set right. The one thing Samuel had sworn over his body to return to him."
    "George Bennettは泥の中から引き上げられるだろう。名は晴らされ、記録は正される。それこそ、Samuelがあの遺体の前で、彼に返すと誓った唯一のものだった。"

# game/script/ch13.rpy:220
translate japanese ch13_afe06fa6:

    # "It had cost him a child's throat in his two hands."
    "その代償は、彼の両手の中の子どもの喉だった。"

# game/script/ch13.rpy:221
translate japanese ch13_5223d7a3:

    # "Every good thing this case had ever given him, it had charged for in the one currency he had left. And now the account was empty, and George was clean, and the truth was safe."
    "この事件が彼に与えたあらゆる良きものに対し、事件は彼に残された唯一の通貨で代価を取り立ててきた。そしていま口座は空になり、Georgeは潔白となり、真実は守られた。"

# game/script/ch13.rpy:222
translate japanese ch13_a4b3f91b:

    # "He lay on his back at a gas station at the bottom of the world with the blood of a little girl going cold on his shirt, and understood that he had solved it."
    "彼は世界の底のガソリンスタンドで仰向けに横たわっていた。小さな女の子の血がシャツの上で冷えていくなか、自分がこの事件を解き明かしたのだと理解した。"

# game/script/ch13.rpy:223
translate japanese ch13_1035d043:

    # "Every piece of it. Start to finish, the whole cold machine laid bare and proven. The best work of thirty years."
    "そのすべての断片を。始めから終わりまで、冷たい機械の全体が暴かれ、証明された。三十年の中で最高の仕事。"

# game/script/ch13.rpy:224
translate japanese ch13_25a07b2a:

    # "And that it had solved him too, the way she had promised him on the road it would."
    "そして、事件のほうもまた彼を解き明かしたのだと。道中で彼女が約束したとおりに。"

# game/script/ch13.rpy:225
translate japanese ch13_5dac34c5:

    # th "You're just as sad and soft as everybody. You only hid it better and longer."
    th "ほかのみんなと同じくらい悲しくて、やわらかい。ただ、うまく、長く隠していただけ。"

# game/script/ch13.rpy:226
translate japanese ch13_3168f343:

    # "She had been right. Thirteen years he had believed the caring was the weakness, and thirteen years Martha had sworn it was the only thing that ever made him good."
    "彼女は正しかった。十三年間、彼は思いやりこそが弱さだと信じてきた。そして十三年間、Marthaは、それこそが彼を善い人間にしてきた唯一のものだと言い張ってきた。"

# game/script/ch13.rpy:227
translate japanese ch13_e25a1ddb:

    # "Here at the bottom of the world he finally had the answer, and it was worthless, because they had both been right."
    "世界の底のここで、彼はついに答えを手にした。そしてそれは無価値だった。二人とも正しかったのだから。"

# game/script/ch13.rpy:228
translate japanese ch13_e032673c:

    # "The caring was the best of him and the ruin of him. The same thing. Indivisible."
    "思いやりは彼の最良の部分であり、彼の破滅だった。同じひとつのもの。分かちがたい。"

# game/script/ch13.rpy:229
translate japanese ch13_525537b1:

    # "He had spent his whole life keeping the one door shut, and at the very end he had opened it, and reached in, and it had cost him a child."
    "彼は人生のすべてを、ひとつの扉を閉じておくことに費やしてきた。そして最後の最後にそれを開け、手を伸ばし、その代償は一人の子どもだった。"

# game/script/ch13.rpy:230
translate japanese ch13_5455b864:

    # "The far country came at last, red and blue against the hard dark, sirens climbing the empty road."
    "遠い国がついにやってきた。硬い闇に赤と青をにじませ、サイレンが無人の道を登ってきた。"

# game/script/ch13.rpy:231
translate japanese ch13_4bd55146:

    # "Hands lifted him. A voice asked his name, and he gave it."
    "手が彼を持ち上げた。声が彼の名前を尋ね、彼は答えた。"

# game/script/ch13.rpy:232
translate japanese ch13_8d995f9d:

    # "They worked over the child a while, because they did not yet know. And then they stopped, and drew the sheet."
    "彼らはしばらく子どもの処置をした。まだ知らなかったからだ。それから手を止め、シーツを引き上げた。"

# game/script/ch13.rpy:233
translate japanese ch13_ed5bf201:

    # "The small covered shape under the canopy light was the last thing he saw before they closed the ambulance doors."
    "キャノピーの明かりの下の、覆われた小さな形。それが、救急車の扉が閉まる前に彼が見た最後のものだった。"

# game/script/ch13.rpy:239
translate japanese ch13_a712aca5:

    # "Martha came the second day, when they had him stitched and drained and propped up in a bed with a machine counting his heart for him."
    "Marthaが来たのは二日目だった。彼は縫合され、ドレーンを入れられ、ベッドに体を起こされて、機械が彼の代わりに心臓を数えていた。"

# game/script/ch13.rpy:240
translate japanese ch13_e8bf937b:

    # "He heard her before he saw her: the particular quick step of her down the corridor, faster at the end."
    "姿より先に足音が聞こえた。廊下を来る彼女独特の小走りの足音。最後のほうでさらに速くなった。"

# game/script/ch13.rpy:242
translate japanese ch13_20cabfe6:

    # "Then she was in the door, and stopped, and looked at him. He watched her take in the whole of it in one sweep: the taped side, the gray face, the thing behind his eyes the surgeons had not been able to reach."
    "それから彼女は戸口に現れ、立ち止まり、彼を見た。彼女がひと目ですべてを見て取るのを、彼は見つめた。テープで覆われた脇腹、灰色の顔、外科医たちにも届かなかった目の奥のもの。"

# game/script/ch13.rpy:243
translate japanese ch13_9885cebd:

    # "She did not fuss. She had never once fussed."
    "彼女は騒ぎ立てなかった。一度だって騒ぎ立てたことはなかった。"

# game/script/ch13.rpy:244
translate japanese ch13_8711fc0d:

    # "She came and sat in the hard chair by the bed and took his nearer hand in both of hers and held it, and for a long time neither of them said anything."
    "彼女はベッド脇の硬い椅子に来て座り、近いほうの彼の手を両手で包んで握った。長いあいだ、どちらも何も言わなかった。"

# game/script/ch13.rpy:246
translate japanese ch13_3a7cfa61:

    # "The machine counted. Outside the window the flat gray city went about its business."
    "機械が数えていた。窓の外では、平坦な灰色の街がいつもの営みを続けていた。"

# game/script/ch13.rpy:247
translate japanese ch13_6fa0c3fb:

    # ma cry "I heard what she was. Raymond told me. What she'd done. What she made you do."
    ma cry "あの子が何だったのか聞いたわ。Raymondが話してくれた。あの子が何をしたのか。あなたに何をさせたのか。"

# game/script/ch13.rpy:248
translate japanese ch13_7f298661:

    # "Her thumb moved over his knuckles."
    "彼女の親指が彼の指の関節をなぞった。"

# game/script/ch13.rpy:249
translate japanese ch13_c62590e9:

    # ma concerned "You listen to me, Sam. That was not you."
    ma concerned "よく聞いて、Sam。あれはあなたじゃない。"

# game/script/ch13.rpy:250
translate japanese ch13_a9c02c76:

    # ma concerned "A thing came at you with a knife in the dark and your body did what a body does. That was not the man doing it. That was the meat keeping itself alive."
    ma concerned "暗闇でナイフを持ったものが向かってきて、あなたの体は体のすることをしたの。あれは人間がしたことじゃない。肉が自分を生かそうとしただけよ。"

# game/script/ch13.rpy:251
translate japanese ch13_c4e6d088:

    # s hurt "I know."
    s hurt "わかってる。"

# game/script/ch13.rpy:252
translate japanese ch13_3ab08e27:

    # "And he did know it, and it did not help at all. He could see in her face that she knew that too."
    "そして彼はわかっていた。それは何の助けにもならなかった。彼女もそれをわかっていることが、その顔から見て取れた。"

# game/script/ch13.rpy:253
translate japanese ch13_30536b93:

    # "Of all the things she had ever said to him across all the years, this was the one that would not go in. Because it was true, and it did not matter that it was true."
    "長い年月のあいだに彼女が言ってくれたあらゆることのなかで、これだけは染み込まなかった。本当のことだったから。そしてそれが本当であることは、どうでもよかったから。"

# game/script/ch13.rpy:254
translate japanese ch13_75dfbe98:

    # "She had told him the caring was the only good thing in him. She had been right. And he had reached in for a child, and it had turned to a knife in his hands."
    "思いやりこそが彼のなかの唯一の良いものだと、彼女は言っていた。彼女は正しかった。そして彼は一人の子どものために手を伸ばし、それは彼の手の中でナイフに変わったのだ。"

# game/script/ch13.rpy:255
translate japanese ch13_989c55dd:

    # "There was no sentence in the language, hers or anyone's, that could make that a thing a man carried lightly."
    "彼女の言葉にも、ほかの誰の言葉にも、それを人が軽々と背負えるものにする文はなかった。"

# game/script/ch13.rpy:256
translate japanese ch13_9819b02c:

    # "She stayed the day. She did not try again."
    "彼女はその日一日そばにいた。二度と同じことは言わなかった。"

# game/script/ch13.rpy:257
translate japanese ch13_2704dd16:

    # "She only held his hand, which was, in the end, the only argument she had ever really been making."
    "ただ彼の手を握っていた。それが結局、彼女がずっと本当に唱えてきた、唯一の主張だった。"

# game/script/ch13.rpy:269
translate japanese ending_4301298a:

    # "There was an inquiry after, because there is always an inquiry when a policeman's hands stop a life. It did not last long."
    "その後、審問があった。警官の手が命を止めたときには、いつも審問がある。長くはかからなかった。"

# game/script/ch13.rpy:270
translate japanese ending_aae7ae36:

    # "There was the knife with her prints on it, and the wound low in his side, and the blood he had left across half a forecourt."
    "彼女の指紋のついたナイフがあった。彼の脇腹の低い位置の傷があった。給油場の半分にわたって彼が残した血があった。"

# game/script/ch13.rpy:272
translate japanese ending_37395a27:

    # "It took no great wisdom to call the thing what it plainly was: a man attacked in the dark by a child he had been trying to help. And to let him go."
    "それをありのままの名で呼ぶのに、大した知恵は要らなかった。助けようとしていた子どもに、闇の中で襲われた男。そして彼を放免すること。"

# game/script/ch13.rpy:273
translate japanese ending_9efe8502:

    # "No one at the inquiry said serial killer about a twelve-year-old, and no one afterward quite could."
    "審問では誰も十二歳について連続殺人犯とは言わなかった。そしてその後も、誰ひとりとして、そうとは言い切れなかった。"

# game/script/ch13.rpy:274
translate japanese ending_3788ba6b:

    # "But the receipt came up out of his hotel room and did its quiet work. The file on George Bennett was opened again and closed again, differently, and the dead man was given back his name."
    "だがレシートが彼のホテルの部屋から出てきて、静かに役目を果たした。George Bennettのファイルは再び開かれ、再び閉じられた。今度は違う形で。そして死んだ男には名前が返された。"

# game/script/ch13.rpy:276
translate japanese ending_cce62818:

    # th "Once, at dawn, I had his number under my thumb. I put the phone face down."
    th "一度、明け方、あいつの番号に親指をかけたことがある。俺は電話を伏せて置いた。"

# game/script/ch13.rpy:278
translate japanese ending_e3ad67af:

    # note_voice "George Bennett: name cleared."
    note_voice "George Bennett：名誉回復。"

# game/script/ch13.rpy:279
translate japanese ending_79be3d00:

    # "It was the last case Samuel Harris ever cleared, and the only one he ever wished he had not."
    "それはSamuel Harrisが解決した最後の事件であり、解決しなければよかったと願った唯一の事件だった。"

# game/script/ch13.rpy:288
translate japanese ending_0587adb0:

    # "They tell it, in the town, still."
    "町では、いまもそれが語られる。"

# game/script/ch13.rpy:289
translate japanese ending_748fb7f9:

    # "How the strange man from Driftwood killed all those people and got what was coming to him on the road."
    "Driftwoodから来た奇妙な男が、あの人たちを皆殺しにし、道の上で当然の報いを受けた話。"

# game/script/ch13.rpy:290
translate japanese ending_86dcc5e3:

    # "And how it turned out, in the end, in some way nobody quite has the shape of, that they'd had it wrong. That the old man hadn't done it after all."
    "そして結局は、誰にもうまく形のつかめない何らかの成り行きで、町の者たちは間違っていたとわかった話。あの老人は結局やっていなかったのだと。"

# game/script/ch13.rpy:291
translate japanese ending_581cc6fb:

    # woman "That it was— the little girl. His granddaughter. All along."
    woman "それがね――あの小さな女の子だったって。孫娘よ。最初からずっと。"

# game/script/ch13.rpy:292
translate japanese ending_c65ab73d:

    # "Here the tellers always lower their voices, because it is not a thing the mouth wants to say."
    "ここで語り手たちは決まって声を落とす。口が言いたがるようなことではないからだ。"

# game/script/ch13.rpy:293
translate japanese ending_250f7770:

    # "They tell it by the fire on winter nights, and they shiver, and they do not, in their hearts, believe it. Not really. Because it cannot be believed. Because the world is not built to allow it."
    "冬の夜、炉辺で彼らはそれを語り、身を震わせる。そして心の底では、信じていない。本当には。信じられるはずがないからだ。世界はそれを許すようにはできていないからだ。"

# game/script/ch13.rpy:294
translate japanese ending_e28e49d1:

    # "And they never mention the detective at all, the tall gray one who was there for the worst of it and left when it was done."
    "そして彼らは刑事のことはまったく口にしない。最悪のときにそこにいて、事が済むと去っていった、背の高い、灰色の男のことは。"

# game/script/ch13.rpy:295
translate japanese ending_b1671238:

    # "There is nothing to tell about him."
    "彼について語ることは何もない。"

# game/script/ch13.rpy:296
translate japanese ending_379c6080:

    # "He solved it. He went home."
    "彼は事件を解決した。彼は家に帰った。"

# game/script/ch13.rpy:301
translate japanese ending_c63ef919:

    # "He went home to an apartment where a woman had left food that would not keep and sat, sometimes, in a chair that nobody else sat in."
    "彼は、一人の女性が日持ちのしない食べ物を置いていき、ときどき、ほかの誰も座らない椅子に座っていく部屋へと帰った。"

# game/script/ch13.rpy:302
translate japanese ending_dadc4c53:

    # "He healed, in the body, the way bodies do."
    "体のほうは、体がそうであるように癒えた。"

# game/script/ch13.rpy:303
translate japanese ending_57f5259e:

    # "On the far side of it he was, to anyone who did not know him, exactly the man he had always been. Quiet, courteous, worn, a little grayer."
    "それを越えた先で、彼を知らない者の目には、彼はかつてとまったく同じ男だった。物静かで、礼儀正しく、くたびれていて、少しばかり白髪が増えた。"

# game/script/ch13.rpy:304
translate japanese ending_1213b6e7:

    # "Back at his desk with his cigarettes and his paperwork, keeping the chaos at bay with ink and routine."
    "煙草と書類仕事とともにデスクに戻り、インクと日課で混沌を寄せつけずにいた。"

# game/script/ch13.rpy:305
translate japanese ending_c48636a0:

    # "Only Martha, who loved him, saw that the last light in him had gone out on a mountain road at a gas station in the dark."
    "彼を愛していたMarthaだけが、彼のなかの最後の明かりが、山道の、闇の中のガソリンスタンドで消えてしまったことに気づいていた。"

# game/script/ch13.rpy:306
translate japanese ending_04b7503e:

    # "That the thing that came back down and sat at the desk and answered to his name was a man who had found the one thing he had spent his whole life certain was safest to keep locked away."
    "山を下りて戻ってきて、デスクに座り、彼の名で呼ばれれば応えるそれは、生涯かけて、鍵を掛けてしまっておくのがいちばん安全だと確信してきたひとつのものを、見つけてしまった男なのだと。"

# game/script/ch13.rpy:307
translate japanese ending_cfb12f75:

    # "And had opened the door on it, and reached for it, and had it turn, in his hands, in the cold white light, into a knife."
    "そしてその扉を開け、それに手を伸ばし、それが彼の手の中で、冷たく白い光の中で、ナイフに変わってしまった男なのだと。"

# game/script/ch13.rpy:314
translate japanese ending_8070d679:

    # "He kept the coin."
    "彼はコインを手放さなかった。"

# game/script/ch13.rpy:315
translate japanese ending_81944ab3:

    # "It was in the county property room, weeks after, that he took it."
    "彼がそれを持ち出したのは、数週間後、郡の証拠品保管室でのことだった。"

# game/script/ch13.rpy:316
translate japanese ending_dc6ce035:

    # "They had let him sit with the girl's effects one last time before the file closed for good. A courtesy to the detective who had cleared it: an hour alone at a steel table with the canvas holdall."
    "ファイルが永久に閉じられる前に、彼は最後にもう一度、少女の遺品とともに座ることを許された。事件を解決した刑事への配慮だった。鋼のテーブルで、帆布のボストンバッグと一時間、二人きり。"

# game/script/ch13.rpy:317
translate japanese ending_a4ad3772:

    # "He went through it slowly, the way he went through everything. The folded child's clothes. The worn copy of {i}Tom Sawyer{/i}. The toothbrush. The small dead ordinary weight of a life."
    "彼はゆっくりとそれを調べた。何でもそうするように。畳まれた子どもの服。くたびれた{i}『トム・ソーヤーの冒険』{/i}。歯ブラシ。ひとつの人生の、小さく、死んだ、ありふれた重さ。"

# game/script/ch13.rpy:318
translate japanese ending_7bf39dc2:

    # "And at the bottom, in a fold of the lining, his fingers found the coin."
    "そして底の、裏地の折り目の中で、彼の指がコインを見つけた。"

# game/script/ch13.rpy:319
translate japanese ending_ce173505:

    # "He knew it by touch before he saw it."
    "見るより先に、触れただけでそれとわかった。"

# game/script/ch13.rpy:324
translate japanese ending_495be35d:

    # "Smooth as a river stone, warm from nothing, no bigger than the pad of his thumb. The face worn clean off it by more hands than either of them would ever count."
    "川の石のように滑らかで、何もないのに温かく、親指の腹ほどの大きさしかない。二人のどちらにも数えきれないほど多くの手によって、顔はすっかり擦り消えていた。"

# game/script/ch13.rpy:325
translate japanese ending_0f62b12e:

    # "He turned it over once in the fluorescent light of that cold room. This blind bronze blank a dead girl had given, out of a toffee tin, to the friend who would kneel in the snow and kill her."
    "あの冷たい部屋の蛍光灯の下で、彼はそれを一度裏返した。この盲いた青銅の無地を、死んだ少女はトフィーの缶から取り出し、雪の中に膝をついて彼女を殺すことになる友に与えたのだ。"

# game/script/ch13.rpy:326
translate japanese ending_4d93a395:

    # "The best one, she'd said. The one you only give to someone you love."
    "いちばんいいやつ、と彼女は言った。愛している人にしかあげないもの。"

# game/script/ch13.rpy:327
translate japanese ending_37b45b48:

    # "Then, without any decision he could afterward point to, he closed his hand around it and put it in his coat pocket."
    "それから、後になって指し示せるような決断もないまま、彼はそれを手の中に握り込み、コートのポケットに入れた。"

# game/script/ch13.rpy:328
translate japanese ending_13dd7256:

    # "He signed the inventory sheet that did not, now, list it, and stood up, and walked out with it."
    "いまやそれの記載されていない目録に署名し、立ち上がり、それを持って出ていった。"

# game/script/ch13.rpy:329
translate japanese ending_b36fe8a8:

    # "It was the one crime he ever committed, and the only thing he ever stole."
    "それが彼の犯した唯一の罪であり、彼が盗んだ唯一のものだった。"

# game/script/ch13.rpy:336
translate japanese ending_a8e140de:

    # "He carried it in his coat pocket for the rest of his life, and turned it over in his fingers on the bad nights. The smooth blind face of it."
    "彼はそれを生涯コートのポケットに入れて持ち歩き、悪い夜には指先で裏返した。その滑らかな、盲いた顔を。"

# game/script/ch13.rpy:337
translate japanese ending_c81786ba:

    # "The trace of a girl who had loved a friend and killed her."
    "友を愛し、そして殺した少女の痕跡。"

# game/script/ch13.rpy:338
translate japanese ending_782505a7:

    # "The trace of the past that does not stay in the past. That rides down out of the mountains in the seat beside you, small and patient and quiet."
    "過去に留まらない過去の痕跡。山から下りてくる車の、あなたの隣の席に乗ってくる。小さく、辛抱強く、静かに。"

# game/script/ch13.rpy:339
translate japanese ending_bf1de87a:

    # "And waits, in the cold, at the bottom of every road, for you to pull in."
    "そして、寒さの中、あらゆる道を下りきったところで、あなたが車を寄せるのを待っている。"

# game/script/ch13.rpy:356
translate japanese ending_57e7b1d5:

    # "One night, late, he opened the notebook to a clean page and wrote, for once, about himself."
    "ある夜遅く、彼は手帳の白いページを開き、珍しく、自分自身のことを書いた。"

# game/script/ch13.rpy:365
translate japanese ending_bb87133a:

    # note_voice "Every time, there was a choice, and every time I chose not to look. That's not a failure of the eye. I had the eye. That's a decision."
    note_voice "毎回、選択があった。毎回、見ないことを選んだ。目の失敗ではない。目はあった。それは決断だ。"

# game/script/ch13.rpy:366
translate japanese ending_852c76f1:

    # note_voice "The old man gave them nothing, to keep her. She gave them nothing, to the end. And I had it in front of me from the first week, and I put it where I put Thomas."
    note_voice "老人は、あの子を守るために何も与えなかった。あの子は、最後まで何も与えなかった。そして俺は最初の週からそれを目の前にしていながら、Thomasをしまった場所にしまい込んだ。"

# game/script/ch13.rpy:368
translate japanese ending_f7cc38db:

    # note_voice "I didn't search the bag."
    note_voice "鞄を調べなかった。"

# game/script/ch13.rpy:370
translate japanese ending_d81916d7:

    # note_voice "I didn't tell her to hold it."
    note_voice "我慢しろと言わなかった。"

# game/script/ch13.rpy:372
translate japanese ending_5a50263b:

    # note_voice "Every door I reached for, I stopped at the handle."
    note_voice "手を伸ばしたどの扉でも、取っ手のところで止まった。"

# game/script/ch13.rpy:373
translate japanese ending_6fbdebf2:

    # note_voice "Give them nothing. I gave myself nothing."
    note_voice "何も与えるな。俺は、自分に何も与えなかった。"

# game/script/ch13.rpy:376
translate japanese ending_83d57d5b:

    # "One night, late, he opened the notebook to a clean page, and sat a long time before he wrote."
    "ある夜遅く、彼は手帳の白いページを開き、長いあいだ座ってから書いた。"

# game/script/ch13.rpy:383
translate japanese ending_05b81011:

    # note_voice "Some nights I'm sure I did. Some nights I think I put it there after, the way you do, to make it bearable that I didn't."
    note_voice "見えていたと確信する夜もある。後からそこに置いたのだと思う夜もある。人はそうするものだ。見えていなかったことに耐えられるように。"

# game/script/ch13.rpy:385
translate japanese ending_f7cc38db_1:

    # note_voice "I didn't search the bag."
    note_voice "鞄を調べなかった。"

# game/script/ch13.rpy:387
translate japanese ending_d81916d7_1:

    # note_voice "I didn't tell her to hold it."
    note_voice "我慢しろと言わなかった。"

# game/script/ch13.rpy:389
translate japanese ending_5a50263b_1:

    # note_voice "Every door I reached for, I stopped at the handle."
    note_voice "手を伸ばしたどの扉でも、取っ手のところで止まった。"

# game/script/ch13.rpy:390
translate japanese ending_8ff3f5b4:

    # note_voice "Either way, I wrote down everything but her."
    note_voice "どちらにせよ、あの子以外のすべてを書き留めた。"

# game/script/ch13.rpy:393
translate japanese ending_1a70e291:

    # "One night, late, he opened the notebook to a clean page, and wrote one line, and closed it."
    "ある夜遅く、彼は手帳の白いページを開き、一行だけ書いて、閉じた。"

# game/script/ch13.rpy:394
translate japanese ending_274fe0c9:

    # note_voice "I solved it. I went home."
    note_voice "解決した。家に帰った。"

# game/script/ch13.rpy:407
translate japanese ending_65241178:

    # centered "Adapted from the novel by A. Damon"
    centered "A. Damonの小説より"

# game/script/ch13.rpy:408
translate japanese ending_61570088:

    # centered "Art generated for this adaptation"
    centered "アート：本作のために生成"

# game/script/ch13.rpy:409
translate japanese ending_39c98c1e:

    # centered "Original score composed for this adaptation"
    centered "音楽：本作のために作曲されたオリジナルスコア"

# game/script/ch13.rpy:412
translate japanese ending_b8de85c4:

    # centered "{i}Give them nothing.{/i}"
    centered "{i}何も与えるな。{/i}"

translate japanese strings:

    # game/script/ch13.rpy:29
    old "The bag."
    new "鞄。"

    # game/script/ch13.rpy:41
    old "Let her go."
    new "行かせる。"

    # game/script/ch13.rpy:45
    old "Search her bag first."
    new "先に鞄を調べる。"

    # game/script/ch13.rpy:50
    old "Tell her to hold it."
    new "我慢しろと言う。"

    # game/script/ch13.rpy:82
    old "Reach for the weapon."
    new "銃に手を伸ばす。"

    # game/script/ch13.rpy:86
    old "Don't."
    new "やめておく。"

# TODO: Translation updated at 2026-10-11 10:28

translate japanese strings:

    # game/script/ch13.rpy:379
    old "Did I see it?"
    new "見えていたのか？"

    # game/script/ch13.rpy:381
    old "Did I see it? The bike racks. The head tilt. The way she looked at the road."
    new "見えていたのか？自転車置き場。首の傾げ方。道を見る、あの目つき。"

