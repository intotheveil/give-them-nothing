# TODO: Translation updated at 2026-10-11 10:23

# game/script/ch07.rpy:9
translate japanese ch07_scene_note_f5893857:

    # "The note next. It lay on the folded hands, set square, meant to be found."
    "次はメモだった。組まれた両手の上に、きちんとまっすぐ置かれていた。見つけられるために。"

# game/script/ch07.rpy:11
translate japanese ch07_scene_note_aa61438c:

    # "A scrap of paper torn, not cut, its edges ragged, the stock thick and pulpy. The same as the slip in Hensley's till. The same as the scrap trodden into the churchyard grass the morning the priest fell."
    "切られたのではなく、破られた紙片。縁はぎざぎざで、紙は厚く、パルプのように粗い。Hensleyのレジにあった紙片と同じだった。司祭が倒れた朝、教会墓地の草に踏みつけられていた切れ端とも同じだった。"

# game/script/ch07.rpy:12
translate japanese ch07_scene_note_c5cbafe1:

    # "Samuel crouched and read it without lifting it, his breath clouding over the words."
    "Samuelはしゃがみこみ、それを持ち上げずに読んだ。彼の息が文字の上で白く曇った。"

# game/script/ch07.rpy:13
translate japanese ch07_scene_note_29e4aad6:

    # note_voice "Sacrifice is the highest purity."
    note_voice "犠牲こそが至高の清らかさ。"

# game/script/ch07.rpy:14
translate japanese ch07_scene_note_734e2e80:

    # "He held very still for a moment."
    "彼は一瞬、身じろぎもせずにいた。"

# game/script/ch07.rpy:15
translate japanese ch07_scene_note_542af77c:

    # "Then he lifted it with the tweezers, bagged it, labeled it, logged the exact position. Centered. Folded hands."
    "それからピンセットでつまみ上げ、袋に入れ、ラベルを貼り、正確な位置を記録した。中央。組まれた両手。"

# game/script/ch07.rpy:16
translate japanese ch07_scene_note_023bfd59:

    # "He did not let his hand shake. A man's hands did not shake at a scene. They shook afterward, in a car, in the dark, where no one filed a report on them."
    "手を震わせはしなかった。現場で男の手は震えない。震えるのはあとだ。車の中で、暗闇の中で、誰もそれについて報告書を書かない場所で。"

# game/script/ch07.rpy:21
translate japanese ch07_scene_button_17196b10:

    # "It was set into the snow three plots along, at the head of the raw grave. The new one. Clara's, still without a stone of her own."
    "それは三区画先、掘ったばかりの墓の頭の雪に埋め込まれていた。新しい墓。Claraの墓だ。まだ自分の墓石もない。"

# game/script/ch07.rpy:22
translate japanese ch07_scene_button_d28261c0:

    # "A button. Deep green, small, a little worn anchor stamped in its face, pressed deliberately into the white."
    "ボタンだった。深い緑色の小さなボタンで、表には少しすり減った錨の模様が刻印されている。白い雪に、わざと押し込まれていた。"

# game/script/ch07.rpy:23
translate japanese ch07_scene_button_4c2a231c:

    # "And beside it, folded once, gone soft and translucent with damp, a scrap of paper that was not the killer's stock."
    "そしてその横に、一度だけ折られ、湿気で柔らかく半透明になった紙片があった。犯人の紙ではなかった。"

# game/script/ch07.rpy:24
translate japanese ch07_scene_button_da001f9c:

    # "He crouched over it without touching. A drawing. A child's drawing, in pencil, of a girl's face."
    "彼は触れずに、その上にかがみこんだ。絵だった。子どもの絵。鉛筆で描かれた、少女の顔。"

# game/script/ch07.rpy:25
translate japanese ch07_scene_button_a3da12b8:

    # "Clumsy, unfinished, the nose gone over and over and never right. Done by someone who had not looked long enough at the living face to get it, and was trying, too late, to remember."
    "不器用で、描きかけで、鼻は何度も何度もなぞられたのに、いつまでも正しくならない。生きている顔を十分に長く見つめなかった誰かが描いたものだった。そしていまになって、遅すぎるのに、思い出そうとしていた。"

# game/script/ch07.rpy:26
translate japanese ch07_scene_button_d86dc06c:

    # "Samuel looked at the button, and the drawing, and the two graves three plots apart, and something in him that was not the detective ached and could not say why."
    "Samuelはボタンを見た。絵を見た。三区画離れた二つの墓を見た。すると彼の中の、刑事ではない何かが疼いた。なぜなのかは言えなかった。"

# game/script/ch07.rpy:27
translate japanese ch07_scene_button_c65aa2e9:

    # th "It makes no sense in the frame. A cult doesn't leave a child's drawing. A ritual doesn't bring a present to a grave."
    th "この構図では説明がつかない。カルトは子どもの絵など残さない。儀式が墓に贈り物を持ってくるはずがない。"

# game/script/ch07.rpy:29
translate japanese ch07_scene_button_fd28a7af:

    # note_voice "Button + drawing, Ward grave — unexplained."
    note_voice "ボタン+絵、Wardの墓――説明つかず。"

# game/script/ch07.rpy:30
translate japanese ch07_scene_button_688bcc20:

    # "He underlined it once, and did not understand it, and moved on. A scene did not let you stop at the thing that hurt."
    "彼はそれに一本だけ下線を引き、理解できないまま、先へ進んだ。現場は、痛むものの前で立ち止まることを許さない。"

# game/script/ch07.rpy:45
translate japanese ch07_8a8910d2:

    # "Alice caught her before she fell."
    "倒れる前に、Aliceは彼女を受け止めた。"

# game/script/ch07.rpy:46
translate japanese ch07_bd088b70:

    # "She took the whole small weight down into the snow the way you lower a thing you don't want to break, and she held her."
    "その小さな重みを丸ごと抱えて、雪の上に下ろした。壊したくないものを下ろすときのように。そして、抱きしめた。"

# game/script/ch07.rpy:47
translate japanese ch07_b82ee0b8:

    # "She had prepared for a great many parts of this. Not, it turned out, for the warmth."
    "このことの多くについて、彼女は備えてきた。だが結局、温かさにだけは備えていなかった。"

# game/script/ch07.rpy:52
translate japanese ch07_07d92546:

    # "She had thought it would be cold. That was the shape the ending had always taken in her mind, across the eleven days she had carried it. A clean cold. A stillness. A candle pinched out."
    "冷たいものだと思っていた。それを抱えてきた十一日のあいだ、心の中で結末はいつもその形をしていた。清らかな冷たさ。静止。指でつまんで消される蝋燭の火。"

# game/script/ch07.rpy:53
translate japanese ch07_d940a70d:

    # "Everything she had done had been in service of that cold. The extract steeped behind the flour. The seeds crushed in a folded rag. The gloves, the scrubbed and aching hands."
    "彼女のしてきたことはすべて、その冷たさのためだった。小麦粉の陰で浸け出したエキス。折りたたんだ布の中で砕いた種。手袋。こすり洗って痛む両手。"

# game/script/ch07.rpy:54
translate japanese ch07_fac29eea:

    # "The after, rehearsed motion by motion, so that nothing would have to be felt in the during. She had built the whole night to be cold."
    "その「後」を、一つ一つの動作まで予行しておいた。その「最中」に何も感じずにすむように。彼女はこの夜全体を、冷たくなるように組み立てたのだ。"

# game/script/ch07.rpy:59
translate japanese ch07_401d75cb:

    # "It was not cold. That was the thing no book had told her."
    "冷たくはなかった。それが、どんな本も教えてくれなかったことだった。"

# game/script/ch07.rpy:60
translate japanese ch07_6d27a6f5:

    # "Emily fought. The body always fought; it did not believe in causes."
    "Emilyはもがいた。体はいつももがく。体は大義など信じない。"

# game/script/ch07.rpy:61
translate japanese ch07_a0975794:

    # "Alice held her through it. The small drumming heels, the arching back, the fingers that clutched at her sleeve with a strength that would leave marks."
    "Aliceはそのあいだずっと彼女を抱いていた。小さく打ちつけるかかと、反り返る背中、痕が残るほどの力で袖をつかむ指。"

# game/script/ch07.rpy:62
translate japanese ch07_33a0f86b:

    # "All of it was warm. Terribly warm. The warmth of a body still full of the animal work of living."
    "そのすべてが温かかった。恐ろしいほど温かかった。生きるという獣の営みにまだ満ちている体の温かさだった。"

# game/script/ch07.rpy:63
translate japanese ch07_22415a83:

    # "Alice knelt in the snow and was the only witness, and did not look away, because looking away would have been for herself."
    "Aliceは雪の上にひざまずき、ただ一人の目撃者となり、目をそらさなかった。目をそらせば、それは自分のためになってしまうからだ。"

# game/script/ch07.rpy:64
translate japanese ch07_ee6ccd5c:

    # a "You're not alone."
    a "一人じゃないよ。"

# game/script/ch07.rpy:65
translate japanese ch07_9b0f0075:

    # "Low. Even. The one true thing she had left to give."
    "低く。平らに。彼女に残された、与えられるただ一つの本当のもの。"

# game/script/ch07.rpy:66
translate japanese ch07_8b43f9c2:

    # a "You're not alone. I'm here."
    a "一人じゃないよ。私がいる。"

# game/script/ch07.rpy:67
translate japanese ch07_7387a3d3:

    # "The fighting slowed. The grip on her sleeve loosened, finger by finger, and the hand slid down and lay open in the snow, palm up."
    "もがきが鈍くなった。袖をつかむ力が指一本ずつほどけ、手は滑り落ちて、雪の上に開いたまま、掌を上にして横たわった。"

# game/script/ch07.rpy:68
translate japanese ch07_69b78243:

    # "The breath, which had been ragged, went shallow. And then long. And then—Alice counted, because she had made herself learn to count—"
    "荒かった息が浅くなった。それから長くなった。それから――Aliceは数えた。数えられるよう、自分に覚えさせてきたのだ――"

# game/script/ch07.rpy:72
translate japanese ch07_25a78098:

    # "—stopped."
    "――止まった。"

# game/script/ch07.rpy:73
translate japanese ch07_35d37368:

    # "And still the warmth stayed."
    "それでも、温かさは残った。"

# game/script/ch07.rpy:78
translate japanese ch07_f4e64bfa:

    # "That was the thing that opened something in her she had believed sealed."
    "それが、封じたと信じていた彼女の中の何かを開いた。"

# game/script/ch07.rpy:79
translate japanese ch07_6db7169b:

    # "Emily was gone. She had felt her go, felt the exact moment the thing that was Emily left the body it had lived in."
    "Emilyは逝った。Aliceはその去り際を感じた。Emilyだったものが、それまで住んでいた体を離れる、まさにその瞬間を感じた。"

# game/script/ch07.rpy:80
translate japanese ch07_2b6090fb:

    # "And yet the body stayed warm in her arms. Soft, heavy, warm as sleep. Warm as a friend fallen asleep against your shoulder on a long drive."
    "それなのに、腕の中の体は温かいままだった。柔らかく、重く、眠りのように温かい。長いドライブの途中で、肩にもたれて眠ってしまった友だちのように温かかった。"

# game/script/ch07.rpy:81
translate japanese ch07_d0e060b6:

    # "It went on being warm, obscenely, patiently, in no hurry at all to become the cold thing Alice had prepared for."
    "それは温かくあり続けた。おぞましいほどに、辛抱強く。Aliceが備えてきた冷たいものになることを、少しも急がずに。"

# game/script/ch07.rpy:82
translate japanese ch07_4da7dfd5:

    # "She held her friend and felt the warmth not leave. It only, over the long minutes, very slowly, began to."
    "彼女は友を抱き、温かさが去らないのを感じていた。ただ、長い数分をかけて、ごくゆっくりと、去りはじめた。"

# game/script/ch07.rpy:86
translate japanese ch07_95aac3de:

    # "She stayed there longer than the plan allowed."
    "計画が許すよりも長く、彼女はそこにとどまった。"

# game/script/ch07.rpy:87
translate japanese ch07_3b887552:

    # "The tears came, and she let them come. She had earned them."
    "涙が来た。彼女は来るままにさせた。その資格はあった。"

# game/script/ch07.rpy:88
translate japanese ch07_65873bd9:

    # "She did not sob. Sobbing was the sound grief made when it wanted a witness, and there was no witness here, and she wanted none."
    "声をあげて泣きはしなかった。嗚咽とは、悲しみが目撃者を求めるときに立てる音だ。ここに目撃者はいない。彼女も求めていなかった。"

# game/script/ch07.rpy:89
translate japanese ch07_c732cf2f:

    # "She had loved Emily. She made herself hold the whole size of it, there in the snow, the warm weight cooling by degrees against her."
    "彼女はEmilyを愛していた。その大きさのすべてを、自分に抱えさせた。雪の中で、温かな重みが少しずつ冷えていくのを体に受けながら。"

# game/script/ch07.rpy:90
translate japanese ch07_3586bf68:

    # "She had loved this one truly, more than anyone since the coast. And she had weighed that love against the cause, and chosen."
    "この子のことは本当に愛していた。海辺を離れてから、誰よりも。そして彼女はその愛を大義と天秤にかけ、選んだのだ。"

# game/script/ch07.rpy:91
translate japanese ch07_4d040287:

    # "Not because the love was small. Because she would not be a judge with a door in her. A room she would not enter. A person who could be ruled through the thing she loved."
    "愛が小さかったからではない。自分の中に扉を持つ裁き手になるつもりはなかったからだ。足を踏み入れられない部屋。愛するものを通して支配されうる人間。"

# game/script/ch07.rpy:92
translate japanese ch07_e71bce95:

    # "She had watched a door like that make a coward of George."
    "そういう扉がGeorgeを臆病者にするのを、彼女は見てきた。"

# game/script/ch07.rpy:93
translate japanese ch07_7db151fc:

    # "She had closed hers herself, tonight, with her own hands. And now she knew the price of it, which was this: the warmth, and how long it took to go."
    "今夜、彼女は自分の扉を自分の手で閉ざした。そしていま、その代償を知った。それはこれだった。温かさと、それが去るまでにかかる時間の長さ。"

# game/script/ch07.rpy:94
translate japanese ch07_97d2ba1b:

    # ath "The priestess does not bend to love."
    ath "巫女は愛に屈しない。"

# game/script/ch07.rpy:95
translate japanese ch07_dea6ad6a:

    # "She had not bent. She had chosen."
    "彼女は屈しなかった。選んだのだ。"

# game/script/ch07.rpy:96
translate japanese ch07_2c4aab94:

    # "It felt like dying. She understood, kneeling there, that this was the last of her own childhood leaving—quietly, the way Emily's breath had left, without any fuss at all."
    "死ぬような感じがした。ひざまずいたまま、彼女は理解した。これは自分自身の子ども時代の最後のかけらが去っていくのだと――静かに、Emilyの息が去ったように、何の騒ぎもなく。"

# game/script/ch07.rpy:100
translate japanese ch07_298257f1:

    # "Then she wiped her face on the back of her wrist, and stood, and went to work."
    "それから彼女は手首の裏で顔を拭い、立ち上がり、仕事にかかった。"

# game/script/ch07.rpy:103
translate japanese ch07_171d8fb0:

    # "The cold helped, the way it always did. She was steady again."
    "寒さが助けになった。いつもそうだった。彼女はまた落ち着いていた。"

# game/script/ch07.rpy:104
translate japanese ch07_dc96a821:

    # "She moved in order, no motion wasted, the way George moved."
    "彼女は順序よく動いた。無駄な動きは一つもない。Georgeの動き方だった。"

# game/script/ch07.rpy:105
translate japanese ch07_16d65758:

    # "The thermos and the mug into the bag. Nothing warm, nothing shared, no sign that two girls had ever crouched here over cocoa."
    "魔法瓶とマグカップを袋に。温かいものは何も残さない。分かち合ったものも何も。二人の少女がここでココアを前にしゃがみこんでいた痕跡は、何一つ。"

# game/script/ch07.rpy:106
translate japanese ch07_bbd509f6:

    # "Fresh snow scuffed across the dark spill until it was only snow. The gloves stayed on."
    "黒くこぼれた跡に新しい雪を蹴りかけ、ただの雪にしか見えなくなるまで続けた。手袋ははめたままだった。"

# game/script/ch07.rpy:107
translate japanese ch07_a2a9bc58:

    # "And the phone. The cheap one from Emily's coat pocket, the one that held every message between them."
    "それから、電話。Emilyのコートのポケットから出した安物の携帯。二人のあいだのメッセージがすべて残っているもの。"

# game/script/ch07.rpy:108
translate japanese ch07_eac6ac73:

    # "The single thread in all of this that led anywhere but where she needed it to lead."
    "このすべての中で、彼女が導きたい場所以外のどこかへつながる、たった一本の糸。"

# game/script/ch07.rpy:109
translate japanese ch07_905a035d:

    # "That went into her own bag too, to be broken small and scattered off the gorge bridge on the way down."
    "それも自分の袋に入れた。帰り道、峡谷の橋の上で細かく砕いて撒くために。"

# game/script/ch07.rpy:110
translate japanese ch07_400503c7:

    # "The drawing she let be. A child's drawing of a dead girl led nowhere, and it belonged where Emily had meant it to go."
    "絵はそのままにした。死んだ少女を描いた子どもの絵は、どこへもつながらない。それに、Emilyが届けるつもりだった場所にあるべきものだった。"

# game/script/ch07.rpy:111
translate japanese ch07_1eb06bc2:

    # "Then the staging. It had to shout one thing to a starved and frightened town so loudly that no one would ever think to listen underneath it."
    "それから、演出。飢えておびえた町に向かって、一つのことを叫ばせなければならない。あまりの大声で、その下に耳を澄まそうなどと誰も思いつかないほどに。"

# game/script/ch07.rpy:112
translate japanese ch07_d170ada5:

    # "She laid Emily on her back and folded the warm hands on the still chest. Composed. Deliberate. Placed, the way the others had been placed."
    "彼女はEmilyを仰向けに寝かせ、温かい両手を動かない胸の上で組ませた。整えられた姿。意図された姿。ほかの者たちが置かれたように、置かれた姿。"

# game/script/ch07.rpy:113
translate japanese ch07_ef408aae:

    # "Whoever found her would feel the wrongness before they understood it."
    "彼女を見つけた者は、理解するより先に、異様さを感じるだろう。"

# game/script/ch07.rpy:114
translate japanese ch07_1b8448e6:

    # "From her pocket she took the scrap she had torn that morning from the thick pulpy stock, the same as all the others, and set it on the folded hands."
    "ポケットから、その朝あの厚くパルプのような紙から破り取っておいた紙片を取り出した。ほかのすべてと同じものだ。それを組まれた両手の上に置いた。"

# game/script/ch07.rpy:126
translate japanese ch07_58c9dd9c:

    # "True on both readings, like all of them."
    "どちらに読んでも真実だった。ほかのすべてと同じように。"

# game/script/ch07.rpy:127
translate japanese ch07_3a95d584:

    # "Let the town read a cult. A ritual. An old handyman's inherited madness, pointing back to a village that didn't talk."
    "町にはカルトを読ませればいい。儀式を。変わり者の老いた便利屋が受け継いだ狂気を。口を閉ざす村を指し示すものを。"

# game/script/ch07.rpy:128
translate japanese ch07_6e1ebe9f:

    # "She read the other thing. That she had made a sacrifice tonight, the highest she would ever be asked for, and had not flinched."
    "彼女はもう一方を読んだ。今夜自分は犠牲を捧げたのだと。これから求められるうちで最も高い犠牲を。そしてひるまなかったのだと。"

# game/script/ch07.rpy:129
translate japanese ch07_44a9ec2a:

    # "And that its purity was the purity of a blade with nothing left on it."
    "そしてその清らかさは、何も残っていない刃の清らかさなのだと。"

# game/script/ch07.rpy:130
translate japanese ch07_ab84a0ca:

    # "The markings last. Chalked quick and sure on the flat face of the nearest stone—the shapes she had carried out of Driftwood in her head, where no search of any house could ever find them."
    "最後に、印。いちばん近い墓石の平らな面に、素早く確かにチョークで描いた――Driftwoodから頭の中に入れて持ち出した形。どんな家宅捜索でも決して見つけられない場所に。"

# game/script/ch07.rpy:131
translate japanese ch07_c6def386:

    # ath "Cult-tongued. Inherited. He carries it everywhere, and so must I."
    ath "カルトの言葉。受け継いだもの。彼はそれをどこへでも持ち歩く。だから私もそうしなければ。"

# game/script/ch07.rpy:132
translate japanese ch07_3d9f4e2c:

    # "The words she had handed the detective a few hours ago, in a warm room. Doing their slow clouding work in him even now."
    "数時間前、暖かい部屋で刑事に手渡した言葉。それはいまも彼の中で、ゆっくりと曇らせる仕事を続けている。"

# game/script/ch07.rpy:133
translate japanese ch07_34179576:

    # "So that when he stood over this in the grey morning, some part of him would already have been taught what to see."
    "灰色の朝に彼がこれを見下ろすとき、彼の一部はすでに、何を見るべきか教えこまれているように。"

# game/script/ch07.rpy:134
translate japanese ch07_4ae4550f:

    # "She did not take the button back."
    "ボタンは持ち帰らなかった。"

# game/script/ch07.rpy:135
translate japanese ch07_b41d98cd:

    # "She left it where Emily had pressed it, at the head of Clara's raw grave, and set the little folded drawing beside it, in the snow, where the goodbye had been meant to go."
    "Emilyが押し込んだその場所、Claraの新しい墓の頭に残し、小さく折られた絵をその横の雪の上に置いた。別れが届けられるはずだった場所に。"

# game/script/ch07.rpy:136
translate japanese ch07_1c8b82dd:

    # "It changed nothing in the frame. It was the one thing she did that night that was not for the cause."
    "それは構図を何一つ変えなかった。その夜彼女がしたことのうち、大義のためではないただ一つのことだった。"

# game/script/ch07.rpy:137
translate japanese ch07_2e8a7026:

    # "She let herself have it, once, exactly, the way she had let herself have the tears."
    "彼女は自分にそれを許した。一度だけ、きっちりと。涙を自分に許したのと同じように。"

# game/script/ch07.rpy:138
translate japanese ch07_49e9a0f0:

    # "Then she turned her back on both graves and did not look at either again."
    "それから二つの墓に背を向け、もうどちらも振り返らなかった。"

# game/script/ch07.rpy:145
translate japanese ch07_577752f9:

    # "The walk down was long, and downhill, and easier than the climb."
    "下り道は長く、下り坂で、登りより楽だった。"

# game/script/ch07.rpy:147
translate japanese ch07_3896b258:

    # "Piece by piece, as she went, she rebuilt the girl the town believed in."
    "歩きながら、彼女は一つずつ、町が信じている少女を組み立て直した。"

# game/script/ch07.rpy:148
translate japanese ch07_181ff454:

    # "Straightened the back. Smoothed the face."
    "背筋を伸ばす。顔をならす。"

# game/script/ch07.rpy:150
translate japanese ch07_5bb37127:

    # "Set into it the hollow, frightened look of a child who had been somewhere warm and safe while a terrible thing happened out in the dark to the one friend she had."
    "そこに、うつろでおびえた表情をはめこむ。たった一人の友だちが暗闇の中で恐ろしい目にあっていたあいだ、どこか暖かく安全な場所にいた子どもの顔を。"

# game/script/ch07.rpy:157
translate japanese ch07_001ba460:

    # "The house was still dark. The truck still gone."
    "家はまだ暗かった。トラックはまだ戻っていなかった。"

# game/script/ch07.rpy:158
translate japanese ch07_19213eab:

    # "She let herself in the side, and hung her wet coat, and washed the thermos and the mug and set them exactly where they lived."
    "彼女は横の戸口から入り、濡れたコートを掛け、魔法瓶とマグカップを洗って、いつもの場所に寸分たがわず戻した。"

# game/script/ch07.rpy:159
translate japanese ch07_f6828aa4:

    # "She pushed one more rag deep into the dead ash of the hearth."
    "もう一枚の布を、暖炉の冷えた灰の奥深くに押し込んだ。"

# game/script/ch07.rpy:160
translate japanese ch07_cdb9747c:

    # "Then she went up and lay down on top of the covers in her clothes, and folded her hands on her chest the way she had folded Emily's, and stared at the ceiling, and waited."
    "それから二階に上がり、服のまま掛け布団の上に横たわり、Emilyの手を組んだように自分の手を胸の上で組んで、天井を見つめ、待った。"

# game/script/ch07.rpy:165
translate japanese ch07_e9db4c41:

    # "The engine came a little after two."
    "エンジンの音がしたのは、二時を少し過ぎたころだった。"

# game/script/ch07.rpy:166
translate japanese ch07_f7950f91:

    # "The tires on the snow. The door."
    "雪を踏むタイヤ。ドア。"

# game/script/ch07.rpy:168
translate japanese ch07_967ec368:

    # "The heavy tread on the stair that paused, out of habit, outside her room. And moved on."
    "階段を上る重い足音が、習慣のように、彼女の部屋の前で止まった。そして通り過ぎた。"

# game/script/ch07.rpy:172
translate japanese ch07_deac2f91:

    # ath "I heard my grandfather leave."
    ath "祖父が出ていくのを聞いた。"

# game/script/ch07.rpy:173
translate japanese ch07_b8a4bc31:

    # "She would say it, when they came."
    "彼らが来たら、そう言うつもりだった。"

# game/script/ch07.rpy:174
translate japanese ch07_928aab72:

    # ath "And later, I heard him come home."
    ath "それからあとで、祖父が帰ってくるのを聞いた。"

# game/script/ch07.rpy:175
translate japanese ch07_6e0450fe:

    # "Both true."
    "どちらも真実だ。"

# game/script/ch07.rpy:176
translate japanese ch07_922e80cf:

    # "She closed her eyes. Outside, the snow had started again, and was already, patiently, beginning to cover everything she had left on the hill."
    "彼女は目を閉じた。外ではまた雪が降りはじめていて、丘の上に彼女が残してきたすべてを、もう、辛抱強く覆いはじめていた。"

# game/script/ch07.rpy:189
translate japanese ch07_c78dfe73:

    # "The phone woke him at 6:52, and he knew before he answered."
    "電話が彼を起こしたのは六時五十二分だった。出る前から、彼にはわかっていた。"

# game/script/ch07.rpy:190
translate japanese ch07_24555005:

    # "There is a particular way a phone rings before dawn in a town where people have started to die. Samuel had learned it that week, the way a soldier learns the difference between weather and gunfire."
    "人が死にはじめた町では、夜明け前の電話には特有の鳴り方がある。Samuelはその週にそれを覚えた。兵士が天気と銃声の違いを覚えるように。"

# game/script/ch07.rpy:191
translate japanese ch07_33b436df:

    # "The cold of the room on his bare arm. The radiator ticking in the dark. MERCER on the screen."
    "素肌の腕に触れる部屋の冷気。暗闇でカチカチと鳴るラジエーター。画面には「Mercer」。"

# game/script/ch07.rpy:192
translate japanese ch07_8ddefda7:

    # "He sat up and put his feet on the floor and was a detective again before he had said a word."
    "彼は起き上がり、床に足をつけ、一言も発しないうちにまた刑事に戻っていた。"

# game/script/ch07.rpy:195
translate japanese ch07_28cb586f:

    # s "Harris."
    s "Harrisだ。"

# game/script/ch07.rpy:196
translate japanese ch07_37e521fe:

    # m shaken "Detective."
    m shaken "刑事。"

# game/script/ch07.rpy:197
translate japanese ch07_e532dfb3:

    # "Mercer's voice had no colour in it at all. That was how Samuel knew it was bad in a new way. Worse than a shopkeeper. Worse than a priest."
    "Mercerの声には色がまったくなかった。それで、Samuelにはそれが新しい意味でひどいことなのだとわかった。店主よりひどい。司祭よりひどい。"

# game/script/ch07.rpy:198
translate japanese ch07_bfcbc82f:

    # "Mercer had found a voice for those. He hadn't found one for this."
    "そういうことのための声を、Mercerは見つけていた。これのための声は、まだ見つけていなかった。"

# game/script/ch07.rpy:199
translate japanese ch07_87485135:

    # m shaken "You need to come up to the cemetery. Same one. Up by the Ward plot."
    m shaken "墓地まで来てください。同じところです。Ward家の区画のそばです。"

# game/script/ch07.rpy:200
translate japanese ch07_be0b7829:

    # s "Talk to me."
    s "話せ。"

# game/script/ch07.rpy:201
translate japanese ch07_22af9b56:

    # m shaken "It's a child."
    m shaken "子どもです。"

# game/script/ch07.rpy:202
translate japanese ch07_fbc72068:

    # "A breath came down the line, unsteady."
    "回線の向こうから、震える息が伝わってきた。"

# game/script/ch07.rpy:203
translate japanese ch07_5d6afa99:

    # m shaken "A girl. Kaftanis found her when he came up to clear the paths, maybe an hour ago. She's—"
    m shaken "女の子です。Kaftanisが小道の雪かきに上がってきて見つけました。一時間くらい前に。その子は――"

# game/script/ch07.rpy:204
translate japanese ch07_77f6a30a:

    # "The word didn't come. Mercer tried again."
    "言葉が出てこなかった。Mercerはもう一度言おうとした。"

# game/script/ch07.rpy:205
translate japanese ch07_ca5f7bc1:

    # m shaken "She's laid out, Detective. Like the others. There's a note."
    m shaken "寝かされてるんです、刑事。ほかと同じように。メモがあります。"

# game/script/ch07.rpy:206
translate japanese ch07_29e72752:

    # s "Don't touch anything. Don't let anyone touch anything. Keep Kaftanis there and keep everybody else at the gate."
    s "何にも触るな。誰にも何も触らせるな。Kaftanisはそこに引き止めて、ほかの連中は全員門で止めておけ。"

# game/script/ch07.rpy:207
translate japanese ch07_d206aea8:

    # "He had the phone jammed against his shoulder, buttoning his shirt with cold fingers. Some part of him had already gone up the hill ahead of his body."
    "彼は電話を肩に挟み、冷えた指でシャツのボタンを留めていた。彼のどこかは、体より先にもう丘を上っていた。"

# game/script/ch07.rpy:208
translate japanese ch07_585dc416:

    # s "Have you got a name?"
    s "名前はわかってるのか？"

# game/script/ch07.rpy:209
translate japanese ch07_36afc5c8:

    # "The silence on the line lasted a beat too long."
    "回線の沈黙が、一拍長すぎた。"

# game/script/ch07.rpy:210
translate japanese ch07_5429fa9c:

    # s "Mercer. The girl. Do we have a name."
    s "Mercer。その子だ。名前はわかってるのか。"

# game/script/ch07.rpy:211
translate japanese ch07_dc286169:

    # m shaken "We think so. There's a school bag near the wall."
    m shaken "たぶん。塀のそばに学校の鞄があります。"

# game/script/ch07.rpy:212
translate japanese ch07_6fd6ed29:

    # m shaken "Carter. Emily Carter."
    m shaken "Carter。Emily Carterです。"

# game/script/ch07.rpy:214
translate japanese ch07_da44fed1:

    # "Samuel stopped with one button undone."
    "Samuelは、ボタンを一つ外したまま手を止めた。"

# game/script/ch07.rpy:215
translate japanese ch07_47b2a309:

    # "For a moment the room was very loud—the radiator, the wind at the glass, the blood in his own ears—and then it was very quiet."
    "一瞬、部屋がひどくうるさくなった――ラジエーター、窓を打つ風、自分の耳の中の血――それから、ひどく静かになった。"

# game/script/ch07.rpy:216
translate japanese ch07_34c6ad7b:

    # "And into the quiet came a small warm voice from the passenger seat of his own car, hours ago, close enough that he could have reached out and touched the girl who had said it."
    "その静けさの中に、小さく温かな声が入ってきた。数時間前、彼自身の車の助手席からの声。手を伸ばせば、それを言った少女に触れられるほど近かった。"

# game/script/ch07.rpy:217
translate japanese ch07_8dd847c7:

    # "{i}She's my best friend. I don't want to lose her.{/i}"
    "{i}あの子は私の一番の友だちなんです。失いたくないんです。{/i}"

# game/script/ch07.rpy:218
translate japanese ch07_edf7afa3:

    # m shaken "Detective? You there?"
    m shaken "刑事？聞こえてますか？"

# game/script/ch07.rpy:219
translate japanese ch07_ae4b9311:

    # s shocked "I'm here."
    s shocked "聞いてる。"

# game/script/ch07.rpy:220
translate japanese ch07_00054a98:

    # "His own voice sounded far away. Flat. Professional. The voice that had walked into a hundred rooms after the worst thing had already happened."
    "自分の声が遠くに聞こえた。平板で。職業的で。最悪のことがすでに起きたあとの部屋に、百回は踏み込んできた声。"

# game/script/ch07.rpy:221
translate japanese ch07_d21bd4ff:

    # s neutral "I'm coming. Fifteen minutes. Mercer—"
    s neutral "行く。十五分だ。Mercer――"

# game/script/ch07.rpy:222
translate japanese ch07_7c376b5e:

    # "He made himself say it."
    "彼は自分にそれを言わせた。"

# game/script/ch07.rpy:223
translate japanese ch07_03c8d525:

    # s "Has anyone told the parents?"
    s "両親には誰か知らせたか？"

# game/script/ch07.rpy:224
translate japanese ch07_4bea0be7:

    # m "Not yet."
    m "まだです。"

# game/script/ch07.rpy:225
translate japanese ch07_be080a02:

    # s "Then nobody does until I'm there. Not one word."
    s "なら、俺が着くまで誰も知らせるな。一言もだ。"

# game/script/ch07.rpy:227
translate japanese ch07_7d5172d4:

    # "He stood a moment in the dark with the phone in his hand. Then he finished the button, and put on his coat, and went."
    "彼は電話を手にしたまま、暗闇の中でしばらく立っていた。それからボタンを留め終え、コートを着て、出ていった。"

# game/script/ch07.rpy:234
translate japanese ch07_660f86bb:

    # "The sky was going from black to the colour of ash as he drove up out of the town. The mountains stood out of it hard and white and indifferent."
    "町から車で上っていくあいだに、空は黒から灰の色へと変わっていった。山々はその空から、硬く、白く、無関心に突き出ていた。"

# game/script/ch07.rpy:235
translate japanese ch07_8274f1b0:

    # "He smoked one cigarette down to the filter and lit another off it and did not taste either."
    "煙草を一本フィルターまで吸い、その火で次の一本に火をつけた。どちらも味がしなかった。"

# game/script/ch07.rpy:236
translate japanese ch07_c4c87bcd:

    # "He knew this road now. He had driven it once already, days ago, following a coffin."
    "この道はもう知っていた。数日前、一度走ったことがある。棺のあとを追って。"

# game/script/ch07.rpy:237
translate japanese ch07_c2a850bf:

    # "He had stood in that cemetery and felt the old wound tear its stitches, and a priest had died at his feet, and he had thought the place had shown him the worst it had."
    "彼はあの墓地に立ち、古い傷が縫い目を裂くのを感じた。司祭が彼の足元で死んだ。そして、この場所は持っている最悪のものをもう見せたのだと思っていた。"

# game/script/ch07.rpy:238
translate japanese ch07_8e938f5a:

    # th "The place had been saving something."
    th "この場所は、まだ何かを取っておいた。"

# game/script/ch07.rpy:239
translate japanese ch07_0f9ba624:

    # "He made himself go cold. It was a door he knew how to pull, and he pulled it now the way he had pulled it for thirteen years."
    "彼は自分を冷たくした。それは引き方を知っている扉で、十三年間引いてきたのと同じように、彼はいまそれを引いた。"

# game/script/ch07.rpy:240
translate japanese ch07_536d0c85:

    # "Not because he did not feel it. Because feeling it was a luxury the dead could not afford."
    "感じていないからではない。感じることは、死者には払えない贅沢だからだ。"

# game/script/ch07.rpy:241
translate japanese ch07_3e1a6331:

    # th "Work first. The child needs a detective, not a mourner. Feel it later, on your own time, the way you feel everything."
    th "仕事が先だ。あの子に要るのは刑事で、弔う者じゃない。感じるのはあとだ。自分の時間に。何もかもそうしてきたように。"

# game/script/ch07.rpy:242
translate japanese ch07_157cf6c9:

    # "By the time the cemetery gate rose out of the pale morning he was, on the outside, exactly the man the scene required."
    "青白い朝の中に墓地の門が立ち上がってくるころには、彼は外から見る限り、まさに現場が必要とする男になっていた。"

# game/script/ch07.rpy:251
translate japanese ch07_4664a05e:

    # "Two patrol cars stood at odd angles below the gate, their lights turning slow and useless in the growing light."
    "門の下に、二台のパトカーがちぐはぐな角度で停まっていた。明るくなっていく光の中で、回転灯がゆっくりと、役にも立たずに回っていた。"

# game/script/ch07.rpy:252
translate japanese ch07_5184835e:

    # "A knot of people had already gathered on the road, despite the hour, despite the cold. A town could smell this now. A single uniform held them back with his arms spread and his face grey."
    "こんな時刻にも、この寒さにもかかわらず、道にはもう人の塊ができていた。町はいまや、この匂いを嗅ぎつけられるのだ。制服警官が一人、両腕を広げ、灰色の顔で彼らを押しとどめていた。"

# game/script/ch07.rpy:253
translate japanese ch07_687af2d5:

    # "Above, past the black iron, the graves climbed the slope in their white rows. Among them, small figures moved. And one figure did not."
    "その上、黒い鉄柵の向こうで、墓が白い列をなして斜面を上っていた。そのあいだを小さな人影が動いている。そして一つの人影は動かなかった。"

# game/script/ch07.rpy:256
translate japanese ch07_4b9f8680:

    # "Mercer came down through the stones to meet him. He looked ten years older than he had the night before. His eyes were red-rimmed, and not from sleep this time."
    "Mercerが墓石のあいだを下りてきて彼を迎えた。前の晩より十歳は老けて見えた。目のふちが赤い。今度は寝不足のせいではなかった。"

# game/script/ch07.rpy:257
translate japanese ch07_8dcb47e5:

    # m shaken "Detective. She's up by the Ward plot."
    m shaken "刑事。Ward家の区画のそばです。"

# game/script/ch07.rpy:258
translate japanese ch07_fb2dc55f:

    # m shaken "Kaftanis is over by the shed. I sat him down, gave him a cigarette, he's not good. He covered her with his coat before he understood. Didn't know what else to do. I've bagged the coat."
    m shaken "Kaftanisは物置のほうにいます。座らせて煙草をやりましたが、よくないです。何なのかわかる前に、自分のコートであの子を覆ってしまって。ほかにどうしていいかわからなかったんでしょう。コートは袋に入れました。"

# game/script/ch07.rpy:259
translate japanese ch07_b4bad1a9:

    # s "Good man."
    s "よくやった。"

# game/script/ch07.rpy:260
translate japanese ch07_0759e53c:

    # "Samuel put a hand on his shoulder once, brief, hard. The only comfort he had time for."
    "Samuelは彼の肩に一度、短く強く手を置いた。それが、時間の許すただ一つの慰めだった。"

# game/script/ch07.rpy:261
translate japanese ch07_9bd42480:

    # s "Walk me up. Tell me what you've touched."
    s "案内してくれ。何に触ったか話せ。"

# game/script/ch07.rpy:262
translate japanese ch07_3aea1170:

    # m shaken "Nothing. Nobody. I made them stand where they are."
    m shaken "何も。誰も。みんな、いまいる場所に立たせてあります。"

# game/script/ch07.rpy:263
translate japanese ch07_13bf68c2:

    # m shaken "It snowed on her, Detective. After. She's got snow on her. She's been up here—"
    m shaken "あの子の上に雪が降ったんです、刑事。そのあとで。雪をかぶってるんです。あの子はここに――"

# game/script/ch07.rpy:264
translate japanese ch07_a1830283:

    # "He stopped."
    "彼は言葉を切った。"

# game/script/ch07.rpy:265
translate japanese ch07_04582705:

    # m shaken "She's been up here since the night."
    m shaken "夜からずっと、ここにいたんです。"

# game/script/ch07.rpy:268
translate japanese ch07_90bae90d:

    # "The valley opened below them as they climbed, the whole town laid out small and blue, lights just going on in kitchen windows. Ordinary people waking to an ordinary day they did not yet know was over."
    "登るにつれて、眼下に谷が開けていった。町全体が小さく青く広がり、台所の窓に明かりがともりはじめていた。もう終わってしまったことをまだ知らない、普通の一日に目覚めていく普通の人々。"

# game/script/ch07.rpy:269
translate japanese ch07_1f057fcc:

    # "They came over the shoulder of the slope, among the older headstones a few plots above the raw unstoned mound that was all Clara Ward yet had."
    "二人は斜面の肩を越え、古い墓石のあいだに出た。Clara Wardがいまのところ持っているすべてである、墓石のない新しい盛り土の数区画上だった。"

# game/script/ch07.rpy:270
translate japanese ch07_05b9c9f5:

    # "Samuel saw her, and stopped."
    "Samuelは彼女を見て、立ち止まった。"

# game/script/ch07.rpy:276
translate japanese ch07_d3b53622:

    # "She lay on her back in the snow with her hands folded on her chest."
    "彼女は雪の上に仰向けに横たわり、両手を胸の上で組んでいた。"

# game/script/ch07.rpy:277
translate japanese ch07_d993ca69:

    # "That was the first thing. The wrong thing. She was not fallen but arranged. Composed. Laid out with a care that no accident and no despair had ever managed."
    "それが最初のことだった。間違ったこと。彼女は倒れたのではなく、整えられていた。姿勢を正され。どんな事故も、どんな絶望も成し遂げたことのない丁寧さで、寝かされていた。"

# game/script/ch07.rpy:278
translate japanese ch07_89e843b9:

    # "Her hands folded one over the other exactly at the centre of her. Her hair drawn back from her face. Her coat straightened."
    "両手は体のちょうど中心で重ねて組まれている。髪は顔からかき上げられ、コートはまっすぐに直されていた。"

# game/script/ch07.rpy:279
translate japanese ch07_6d0df507:

    # th "Someone made her neat. Someone knelt in this snow and made a murdered child neat."
    th "誰かがこの子をきれいに整えた。誰かがこの雪の中にひざまずいて、殺された子どもをきれいに整えたんだ。"

# game/script/ch07.rpy:280
translate japanese ch07_43d5e94a:

    # "The wrongness of it went into Samuel like cold water into a cracked tooth."
    "その異様さは、ひびの入った歯に冷水がしみるように、Samuelの中へしみこんだ。"

# game/script/ch07.rpy:281
translate japanese ch07_918091bd:

    # "Snow had fallen on her through the night, a fine white veil that softened her and made her, for one merciful second, look only asleep."
    "夜のうちに彼女の上に雪が降り積もっていた。細かな白いヴェールが彼女を柔らかく包み、慈悲深い一瞬のあいだ、ただ眠っているように見せた。"

# game/script/ch07.rpy:282
translate japanese ch07_e3e676eb:

    # "Then he was standing over her, and it was Emily. Of course it was Emily."
    "それから彼は彼女のそばに立っていて、それはEmilyだった。もちろんEmilyだった。"

# game/script/ch07.rpy:283
translate japanese ch07_410d5e71:

    # "The girl from the counsellor's office who had asked him not to think badly of Clara. The girl at the funeral who had turned her face into her friend's shoulder so she wouldn't have to see."
    "カウンセラー室で、Claraのことを悪く思わないでほしいと彼に頼んだ少女。葬儀で、見なくてすむように友の肩に顔を埋めた少女。"

# game/script/ch07.rpy:284
translate japanese ch07_2f5427ef:

    # "The girl whose name he had spoken in his own warm car not twelve hours ago, fishing, working an angle, while she was alive somewhere in this town with hours left."
    "十二時間も経たない前、彼自身の暖かい車の中で、彼がその名を口にした少女。探りを入れ、角度を狙いながら。そのあいだ彼女はこの町のどこかで生きていて、残りはあと数時間だった。"

# game/script/ch07.rpy:285
translate japanese ch07_dfbfe8f5:

    # th "She's a good one, from the look of her."
    th "見たところ、いい子みたいだな。"

# game/script/ch07.rpy:286
translate japanese ch07_d95c9726:

    # "She had been. She was fourteen and she had been a good one, and now she was laid out in the snow with a stranger's care."
    "そうだった。十四歳で、いい子だった。そしていま、見知らぬ者の丁寧さで、雪の中に寝かされていた。"

# game/script/ch07.rpy:287
translate japanese ch07_2b35dcf6:

    # "Behind the cold visor of his face, Samuel felt the old welded door shudder in its frame."
    "顔という冷たい面頬の奥で、Samuelは、溶接された古い扉が枠の中で震えるのを感じた。"

# game/script/ch07.rpy:288
translate japanese ch07_6c45abf2:

    # "He did not open it. He could not, not here. But he felt it, and he knew he would pay for feeling it later, the way he paid for everything."
    "彼はそれを開けなかった。開けられなかった、ここでは。だが彼はそれを感じ、感じたことの代償をあとで払うことになるとわかっていた。何もかもそうして払ってきたように。"

# game/script/ch07.rpy:289
translate japanese ch07_b65bc05f:

    # m "Detective?"
    m "刑事？"

# game/script/ch07.rpy:290
translate japanese ch07_e883c8c9:

    # s "Give me a minute."
    s "少し時間をくれ。"

# game/script/ch07.rpy:291
translate japanese ch07_732479c5:

    # "He took out his notebook, and clicked his pen, and made himself begin."
    "彼は手帳を取り出し、ペンをカチリと鳴らし、自分に始めさせた。"

# game/script/ch07.rpy:297
translate japanese ch07_ab38d80d:

    # "He worked the way he always worked, from the outside in, and let the cold visor do the seeing so the man behind it could stay standing."
    "彼はいつもどおり、外側から内側へと仕事を進めた。見ることは冷たい面頬にまかせ、その奥の男が立っていられるようにした。"

# game/script/ch07.rpy:298
translate japanese ch07_de372e3c:

    # "The coroner and a scene unit from the city were two hours out on the mountain road, if the passes were clear. Until they climbed it, the hill and the girl were his alone."
    "検視官と市の鑑識班は、峠が開いていれば、山道を二時間のところにいた。彼らが登ってくるまで、丘と少女は彼一人のものだった。"

# game/script/ch07.rpy:299
translate japanese ch07_e9ce44ad:

    # "The body first, without touching. The pallor he had learned to read that week. At the lips, a faint blue-purple bloom; the same shadow under the nails of the folded hands."
    "まず遺体を、触れずに。その週に読むことを覚えた蒼白さ。唇にかすかな青紫の色が浮かび、組まれた手の爪の下にも同じ影があった。"

# game/script/ch07.rpy:300
translate japanese ch07_acb55b92:

    # "Cyanosis. The quiet signature of a heart that had been made to stop. No wound. No blood. Only the terrible neatness and the colour of the mouth."
    "チアノーゼ。止めさせられた心臓の、静かな署名。傷はない。血もない。あるのは恐ろしいほどの整然さと、口の色だけだった。"

# game/script/ch07.rpy:301
translate japanese ch07_75b6a726:

    # th "Yew. Same as Hensley. Same as Karalis. I won't say it until the lab does."
    th "イチイだ。Hensleyと同じ。Karalisと同じ。ラボが言うまでは口にしない。"

# game/script/ch07.rpy:302
translate japanese ch07_da54b0e5:

    # "A girl of fourteen did not sit in a cemetery at midnight in a coat and drink a poison by choice. She had been brought here. She had been given it. She had been arranged."
    "十四歳の少女が、真夜中に墓地でコートを着て座り、自分から毒を飲んだりはしない。ここへ連れてこられたのだ。それを与えられたのだ。整えられたのだ。"

# game/script/ch07.rpy:310
translate japanese ch07_750951ea:

    # "Three plots along, at the head of the raw grave, something small and dark broke the white. He went to it before he let himself look at her hands again."
    "三区画先、新しい墓の頭で、何か小さく黒いものが白を破っていた。彼女の手をもう一度見る前に、彼はそこへ行った。"

# game/script/ch07.rpy:312
translate japanese ch07_d9f6c9ff:

    # "Then he came back to the girl."
    "それから少女のもとへ戻った。"

# game/script/ch07.rpy:315
translate japanese ch07_ff09c567:

    # "The stone beside her carried the rest."
    "彼女のそばの墓石が、残りを語っていた。"

# game/script/ch07.rpy:316
translate japanese ch07_1ad12db5:

    # "On the flat face of the nearest headstone, chalked quick and sure, were the marks. Angular, deliberate. A language that was not a language."
    "いちばん近い墓石の平らな面に、素早く確かにチョークで、印が描かれていた。角ばって、意図的で。言語ではない言語。"

# game/script/ch07.rpy:317
translate japanese ch07_701c7d43:

    # "The same cult-tongue that had trailed this killer through four deaths and pointed, every time, back toward a strange old man from a village that answered its phone in silence."
    "四つの死を通してこの犯人につきまとい、そのたびに、電話に沈黙で答える村から来た変わり者の老人を指し示してきたのと同じ、カルトの言葉。"

# game/script/ch07.rpy:318
translate japanese ch07_02a8f226:

    # "Samuel photographed them. He had Mercer photograph them again. He wrote them into his notebook stroke by stroke, though he could not read them, because someone, somewhere, might."
    "Samuelはそれを写真に撮った。Mercerにももう一度撮らせた。読めはしないが、一画ずつ手帳に書き写した。どこかの誰かが、読めるかもしれないからだ。"

# game/script/ch07.rpy:319
translate japanese ch07_949f939d:

    # "Then the things that were missing, which were always the things that mattered most."
    "それから、欠けているもの。いつも最も重要なのは、欠けているものだった。"

# game/script/ch07.rpy:320
translate japanese ch07_cb94d9fa:

    # "No cup. No bottle, no flask, no vessel of any kind. The poison had gone into her through something. Whoever had done this had taken it away."
    "カップがない。瓶も、水筒も、どんな容器もない。毒は何かを通して彼女の体に入ったはずだ。これをした者が、それを持ち去ったのだ。"

# game/script/ch07.rpy:321
translate japanese ch07_2da2f4c8:

    # "No phone. The bag by the wall held schoolbooks, a pencil case, a half-eaten roll of sweets. He had never in his life met a fourteen-year-old without a phone within arm's reach."
    "電話がない。塀のそばの鞄には教科書と筆箱、食べかけの飴の筒が入っていた。手の届くところに電話を置いていない十四歳には、生まれてこのかた会ったことがなかった。"

# game/script/ch07.rpy:322
translate japanese ch07_0560c290:

    # "He circled the grave twice, slow, reading the churned and re-frozen snow. The night's snowfall had smoothed the world to a blank sheet. Whatever tracks had been here were filled and sealed."
    "彼は墓のまわりをゆっくりと二度回り、踏み乱されて再び凍った雪を読んだ。夜の雪が世界をなめらかな白紙に変えていた。ここにどんな足跡があったにせよ、埋められ、封じられていた。"

# game/script/ch07.rpy:324
translate japanese ch07_7b909a6a:

    # note_voice "No cup. No phone. Tracks gone under snow."
    note_voice "カップなし。電話なし。足跡は雪の下。"

# game/script/ch07.rpy:327
translate japanese ch07_e0441fcb:

    # "He was straightening from the stone when he saw the button."
    "墓石から身を起こしかけたとき、彼はボタンに気づいた。"

# game/script/ch07.rpy:330
translate japanese ch07_02caace3:

    # "He looked once more toward Clara's grave, at the small green thing in the snow. It still made no sense. He let it not make sense."
    "彼はもう一度Claraの墓のほうを、雪の中の小さな緑のものを見やった。やはり意味をなさなかった。彼は意味をなさないままにしておいた。"

# game/script/ch07.rpy:333
translate japanese ch07_0c6ae873:

    # "It was while he was logging the bag by the wall, kneeling in the snow with the girl's schoolbooks in his gloved hands, that the car came back to him."
    "塀のそばの鞄を記録していたとき――雪の中にひざまずき、手袋をした手に少女の教科書を持っていたとき――あの車のことがよみがえった。"

# game/script/ch07.rpy:338
translate japanese ch07_ab659aab:

    # "Not as a memory. As a room he suddenly found himself standing in, whole, lit, the heater roaring, the wipers counting, the snow coming out of the black."
    "記憶としてではなかった。突然そこに立っている部屋として、まるごと、明かりのついたまま。ヒーターがうなり、ワイパーが拍子をとり、黒い闇から雪が降ってくる。"

# game/script/ch07.rpy:339
translate japanese ch07_7ee7caf7:

    # "And the small voice beside him, calm, sad, feeding him a sentence at a time."
    "そして隣の小さな声。落ち着いて、悲しげに、一度に一文ずつ彼に差し出していた。"

# game/script/ch07.rpy:340
translate japanese ch07_f78197cd:

    # "{i}He doesn't like me having her. He says she makes me weak. He says we won't be able to keep people, where we're going. I don't want to lose her.{/i}"
    "{i}私があの子といるのが嫌なんです。あの子のせいで私が弱くなるって言うんです。行った先では人をそばに置いておけないって。あの子を失いたくないんです。{/i}"

# game/script/ch07.rpy:341
translate japanese ch07_7f909944:

    # "{i}This work of your grandfather's. He tell you where?{/i} — {i}No. He never says where.{/i}"
    "{i}おじいさんの、その仕事だけど。どこでやるか言ってたかい？{/i}――{i}いいえ。どこかは絶対に言わないんです。{/i}"

# game/script/ch07.rpy:342
translate japanese ch07_bcc5b8d0:

    # "{i}And tonight? He out on one now?{/i} — {i}He said he'd be late. He said he had preparations.{/i}"
    "{i}今夜は？いまも出かけてるのかい？{/i}――{i}遅くなるって言ってました。準備があるって。{/i}"

# game/script/ch07.rpy:348
translate japanese ch07_d50f56be:

    # "Samuel knelt very still in the snow."
    "Samuelは雪の中で、じっとひざまずいていた。"

# game/script/ch07.rpy:349
translate japanese ch07_5f834012:

    # "He had sat in that warm car and filed every word of it against George Bennett, brick by brick. Then he had driven the child home and watched her light come on and driven away pleased with himself."
    "あの暖かい車に座って、彼はその言葉の一つ一つを、George Bennettに不利なものとして、煉瓦を積むように記録していったのだ。それから子どもを家まで送り、彼女の部屋の明かりがつくのを見届け、自分に満足して走り去った。"

# game/script/ch07.rpy:350
translate japanese ch07_ec73684e:

    # "And while he did it, the man he was building it against had been—"
    "そしてそうしているあいだ、彼が煉瓦を積み上げていた相手の男は――"

# game/script/ch07.rpy:351
translate japanese ch07_91046911:

    # th "No. Stop. That's the grief talking, not the work. The leap that feels like insight and is only guilt looking for somewhere to stand."
    th "違う。やめろ。それは悲しみがしゃべってるんであって、仕事じゃない。洞察のように感じる飛躍は、立つ場所を探している罪悪感にすぎない。"

# game/script/ch07.rpy:352
translate japanese ch07_43d08562:

    # "He did not know George Bennett had done this."
    "George Bennettがこれをやったと、彼は知っていたわけではない。"

# game/script/ch07.rpy:353
translate japanese ch07_ce35a0b1:

    # "He knew a girl had told him, hours before her death, that her grandfather resented her one friendship. That he spoke of leaving. That he was out that very night on unnamed preparations."
    "彼が知っていたのは、一人の少女が死の数時間前に、祖父は自分のたった一つの友情を疎んでいると話したことだった。祖父が町を出る話をしていたこと。まさにその夜、名前のない準備のために出かけていたこと。"

# game/script/ch07.rpy:354
translate japanese ch07_7d4fdf16:

    # "And now the friend was dead, laid out in the killer's own hand, days before whatever leaving George had planned."
    "そしていま、その友は死に、犯人自身の手で寝かされている。Georgeが計画していた出発が何であれ、その数日前に。"

# game/script/ch07.rpy:355
translate japanese ch07_0b512acf:

    # "He knew what a jury would call that. He knew what he would have called it, in any other town, about any other man."
    "陪審がそれを何と呼ぶか、彼は知っていた。ほかのどの町で、ほかのどの男についてでも、自分ならそれを何と呼んだかも知っていた。"

# game/script/ch07.rpy:356
translate japanese ch07_e16809c8:

    # "He had been told. That was the thing that would not let him breathe."
    "彼は聞かされていたのだ。それが、彼に息をさせないものだった。"

# game/script/ch07.rpy:357
translate japanese ch07_7a3b30c6:

    # "A frightened child had all but drawn him the map in his own car, and he had folded it up and put it in his pocket, and driven her home to an empty house and a grandfather due back after two, and gone to bed."
    "おびえた子どもが、彼自身の車の中で、地図を描いてくれたも同然だった。それなのに彼はそれをたたんでポケットにしまい、彼女を空っぽの家へ、二時過ぎに帰ってくる祖父のもとへ送り届け、そして眠りについたのだ。"

# game/script/ch07.rpy:358
translate japanese ch07_501f973d:

    # "And Emily Carter had climbed a hill in the dark and drunk something warm and sweet and been laid out in the snow while Samuel Harris slept off a good day's work."
    "そしてEmily Carterは暗闇の中で丘を登り、温かく甘い何かを飲み、雪の中に寝かされた。Samuel Harrisが、よく働いた一日の疲れを眠りで癒しているあいだに。"

# game/script/ch07.rpy:359
translate japanese ch07_3b005ca8:

    # "The welded door shuddered again. Behind it, very far down, a smaller coffin than this one waited in a smaller grave, and a woman screamed, and Samuel had stood dry-eyed and useless then too."
    "溶接された扉がまた震えた。その奥、ずっと深いところで、これよりも小さな棺が、もっと小さな墓の中で待っていた。一人の女が叫んでいた。そしてSamuelは、あのときもまた、涙も流さず、役立たずのまま立っていたのだ。"

# game/script/ch07.rpy:360
translate japanese ch07_9a969fa1:

    # s "Later."
    s "あとだ。"

# game/script/ch07.rpy:361
translate japanese ch07_245de468:

    # "Under his breath, to no one."
    "誰に向けるでもなく、小声で。"

# game/script/ch07.rpy:362
translate japanese ch07_9a969fa1_1:

    # s "Later."
    s "あとだ。"

# game/script/ch07.rpy:363
translate japanese ch07_e29d41e1:

    # "He finished logging the bag. His hands did not shake. That would come later, with the rest of it, on his own time, in the dark, where it always came."
    "彼は鞄の記録を終えた。手は震えなかった。それはあとで来る。ほかのすべてと一緒に、自分の時間に、暗闇の中で。いつも来る場所で。"

# game/script/ch07.rpy:375
translate japanese ch07_c1e67f81:

    # "The Carters already knew, in the way that people know, before he ever reached their door."
    "彼が玄関にたどり着くより前に、Carter夫妻はもう知っていた。人が知るときの、あのやり方で。"

# game/script/ch07.rpy:376
translate japanese ch07_9ac21f21:

    # "They had woken to an empty bed. Found her boots gone and the front door unbolted. They had been calling her name through the house and then through the streets since first light."
    "目を覚ますと、娘のベッドは空だった。ブーツがなくなり、玄関のかんぬきが外れていた。夜が明けてからずっと、二人は家じゅうで、それから通りで、娘の名前を呼びつづけていた。"

# game/script/ch07.rpy:379
translate japanese ch07_f7931fb8:

    # "Samuel came up their stair with Lara Whitfield a step behind him and his hat in his hand."
    "Samuelは、一歩後ろにLara Whitfieldを従え、帽子を手に、彼らの家の階段を上った。"

# game/script/ch07.rpy:384
translate japanese ch07_1ac1d400:

    # "He did not let the stair finish. He looked up at the mother, and she read the whole of it off his face before he had climbed the last step."
    "彼は階段を上りきるのを待たなかった。母親を見上げると、最後の一段を上る前に、彼女は彼の顔からすべてを読み取った。"

# game/script/ch07.rpy:387
translate japanese ch07_23805bea:

    # l concerned "Mrs. Carter—"
    l concerned "Carterさん――"

# game/script/ch07.rpy:388
translate japanese ch07_bb4cc8a3:

    # "Lara's voice was gentle and it was not enough. Nothing would have been. Emily's mother looked past her, at Samuel, and read the whole of it off his face."
    "Laraの声は優しかったが、それでは足りなかった。何であっても足りなかっただろう。Emilyの母親は彼女の向こうのSamuelを見て、彼の顔からすべてを読み取った。"

# game/script/ch07.rpy:389
translate japanese ch07_d6750ee3:

    # "He would not leave it to anyone else. He stepped up beside Lara."
    "ほかの誰かにまかせるつもりはなかった。彼はLaraの隣に上がった。"

# game/script/ch07.rpy:391
translate japanese ch07_f77d1abc:

    # mrsc "No— no, no—"
    mrsc "いや――いや、いや――"

# game/script/ch07.rpy:392
translate japanese ch07_496442bc:

    # "The sound she made after that was not a word."
    "そのあとに彼女が上げた声は、言葉ではなかった。"

# game/script/ch07.rpy:393
translate japanese ch07_dcc6c5da:

    # "Samuel had done this more times than he could count. He had a way of standing, a way of speaking, low and level and without flinching, that gave grief something solid to break against."
    "Samuelはこれを数えきれないほどやってきた。立ち方があり、話し方があった。低く、平らに、ひるまずに。悲しみがぶつかって砕けられる、何か硬いものを与える話し方が。"

# game/script/ch07.rpy:394
translate japanese ch07_6a20a24c:

    # "He told them the truth, plainly, because people deserved the truth, and because the lies they told themselves in its place were always worse."
    "彼は二人に真実を、ありのままに伝えた。人は真実を受けるに値するからだ。そして、その代わりに人が自分につく嘘のほうが、いつだってひどいからだ。"

# game/script/ch07.rpy:395
translate japanese ch07_e911720e:

    # "He did not say ritual. He did not say poison."
    "儀式とは言わなかった。毒とも言わなかった。"

# game/script/ch07.rpy:396
translate japanese ch07_fa0aa4e0:

    # s "Your daughter is gone. I'm so sorry."
    s "お嬢さんは亡くなりました。本当に、お気の毒です。"

# game/script/ch07.rpy:398
translate japanese ch07_250e8278:

    # "The mother had already gone down. Lara had her, on the stair, folding around the sound she was making."
    "母親はすでに崩れ落ちていた。Laraが階段の上で彼女を支え、彼女の上げる声を包みこむように身を寄せていた。"

# game/script/ch07.rpy:399
translate japanese ch07_bfaed74d:

    # "It was the father Samuel watched, because the father was the one who had not moved."
    "Samuelが見ていたのは父親だった。動かなかったのは父親のほうだったからだ。"

# game/script/ch07.rpy:400
translate japanese ch07_731220ae:

    # "A big soft-handed man in a vest and unlaced boots, who mended roofs for a living. He heard the words and did not fall and did not weep."
    "大柄で手の柔らかい男だった。ベストを着て、紐を結んでいないブーツを履いている。屋根の修理で生計を立てていた。その言葉を聞いても、倒れもせず、泣きもしなかった。"

# game/script/ch07.rpy:401
translate japanese ch07_6b3e364f:

    # "He only looked at Samuel with a slow, terrible reasonableness."
    "ただ、ゆっくりとした、恐ろしいほどの物分かりのよさで、Samuelを見た。"

# game/script/ch07.rpy:402
translate japanese ch07_aa22cfa1:

    # carter "No. She's with Alice. She goes off with Alice sometimes."
    carter "いいえ。Aliceと一緒にいるんです。あの子はときどきAliceと出かけるんです。"

# game/script/ch07.rpy:403
translate japanese ch07_8264a90c:

    # "As though it were a scheduling error. As though, if he were patient and clear, the detective would check his notes and find he had come to the wrong house."
    "まるで予定の行き違いであるかのように。辛抱強く、はっきり話せば、刑事が手帳を確かめて、家を間違えたと気づくだろうとでもいうように。"

# game/script/ch07.rpy:404
translate japanese ch07_4d2636cd:

    # s "Mr. Carter."
    s "Carterさん。"

# game/script/ch07.rpy:405
translate japanese ch07_fd877b9b:

    # "Samuel held his eyes and did not let him have the door out of it."
    "Samuelは彼の目をとらえたまま、そこから逃げる扉を与えなかった。"

# game/script/ch07.rpy:406
translate japanese ch07_cbaac774:

    # s "She's not with Alice. I'm sorry. I saw her myself, an hour ago. It's her."
    s "Aliceと一緒ではありません。お気の毒です。一時間前に、私がこの目で見ました。お嬢さんです。"

# game/script/ch07.rpy:407
translate japanese ch07_4062f5ac:

    # "He watched the reasonableness go. The exact moment it left the man, the way a lamp goes out, and the thing underneath came up into the face all at once, unhoused."
    "物分かりのよさが去っていくのを、彼は見ていた。それが男から離れるまさにその瞬間を。ランプが消えるように。そしてその下にあったものが、一度に、住み処を失って、顔に浮かび上がってきた。"

# game/script/ch07.rpy:408
translate japanese ch07_b4492df6:

    # "Carter's big useless hands rose a few inches from his sides and hung there, holding nothing. A sound came up out of him that had no shape to it."
    "Carterの大きな、役に立たない両手が、脇から数インチ持ち上がり、何もつかまずにそこで止まった。形のない声が、彼の中から上がってきた。"

# game/script/ch07.rpy:409
translate japanese ch07_2c6eb780:

    # "He took one step toward Samuel, as if the detective were the thing that had done it or the thing that could undo it, and Samuel did not step back."
    "彼はSamuelのほうへ一歩踏み出した。まるで刑事が、それをやったものであるか、それを元に戻せるものであるかのように。Samuelは後ずさりしなかった。"

# game/script/ch07.rpy:410
translate japanese ch07_338947d8:

    # "He took the man's weight when it came, the whole grieving bulk of him folding forward, and held him up in the doorway of his own house, because there was no one else to do it."
    "その重みが来たとき、彼は受け止めた。嘆く巨体がまるごと前へ崩れてくるのを。そして彼自身の家の戸口で、彼を支えて立たせた。ほかにそれをする者がいなかったからだ。"

# game/script/ch07.rpy:411
translate japanese ch07_d23e3a9a:

    # s "She didn't suffer long. I'm going to find who did this."
    s "長く苦しまれたわけではありません。誰がやったのか、必ず見つけます。"

# game/script/ch07.rpy:412
translate japanese ch07_fa37b9dc:

    # "Not because Carter could hear it now. Because someday, surfacing, he would need to have been told."
    "Carterにいまそれが聞こえるからではない。いつか、水面に浮かび上がったとき、そう告げられていたことが必要になるからだ。"

# game/script/ch07.rpy:415
translate japanese ch07_5f3e1f5d:

    # "He learned what there was to learn, gently, in the wreckage."
    "残骸の中で、彼はそっと、知るべきことを聞き出した。"

# game/script/ch07.rpy:416
translate japanese ch07_99fb9f20:

    # "Emily had gone to bed at her usual hour. No, they had heard nothing. No, she had not said she was meeting anyone."
    "Emilyはいつもの時間にベッドに入った。いいえ、何も聞いていない。いいえ、誰かと会うとは言っていなかった。"

# game/script/ch07.rpy:417
translate japanese ch07_cb22ca1f:

    # mrsc "Her phone— it's here. It was on her nightstand. Charging. Where she always leaves it."
    mrsc "あの子の電話――ここにあります。ナイトテーブルの上に。充電していて。いつも置いている場所に。"

# game/script/ch07.rpy:418
translate japanese ch07_db097a43:

    # "Her mother pressed it into his hands. The screen was a smiling photograph of the two girls, Emily and Alice, cheek to cheek."
    "母親はそれを彼の手に押しつけた。画面には、頬を寄せて微笑む二人の少女の写真があった。EmilyとAlice。"

# game/script/ch07.rpy:419
translate japanese ch07_42afb772:

    # "She had gone out into the night without it. To a place a mile away, in a storm, at fourteen."
    "彼女はそれを持たずに夜の中へ出ていったのだ。一マイル先の場所へ、嵐の中、十四歳で。"

# game/script/ch07.rpy:420
translate japanese ch07_2f2253c1:

    # th "Only one thing takes a careful, frightened, sensible girl out into the dark without so much as her phone. Love."
    th "慎重で、怖がりで、分別のある子を、電話さえ持たせずに闇の中へ連れ出すものは一つしかない。愛だ。"

# game/script/ch07.rpy:421
translate japanese ch07_b970fe42:

    # th "Someone she trusted asked her to come. Someone she wouldn't refuse."
    th "信頼する誰かに、来てくれと頼まれたんだ。断れない誰かに。"

# game/script/ch07.rpy:423
translate japanese ch07_c4bb2638:

    # note_voice "Someone she trusted asked her to come."
    note_voice "信頼する誰かが呼び出した。"

# game/script/ch07.rpy:425
translate japanese ch07_d3d3630f:

    # "He held that thought very carefully, the way you hold something with an edge."
    "彼はその考えを、刃のあるものを持つように、ひどく慎重に持った。"

# game/script/ch07.rpy:426
translate japanese ch07_81159b03:

    # "He left them to Lara and the family that had begun to gather. The aunts, the neighbours, the terrible machinery of a town's mourning cranking into motion."
    "彼は二人を、Laraと、集まりはじめた親族にまかせた。叔母たち、隣人たち、町の弔いという恐ろしい機械が、軋みながら動きだしていた。"

# game/script/ch07.rpy:433
translate japanese ch07_e6834509:

    # "He sat in the car a moment with the smiling phone in an evidence bag on the seat beside him. Two girls, cheek to cheek. Then he started the engine."
    "彼は車の中にしばらく座っていた。隣の座席には、微笑む電話が証拠品袋に入って置いてあった。頬を寄せる二人の少女。それから、エンジンをかけた。"

# game/script/ch07.rpy:437
translate japanese ch07_7f0f9162:

    # "Doyle called before he reached the square."
    "広場に着く前に、Doyleから電話があった。"

# game/script/ch07.rpy:438
translate japanese ch07_1a6edc57:

    # d angry "Tell me it isn't what they're saying."
    d angry "みんなが言ってるようなことじゃないと言え。"

# game/script/ch07.rpy:439
translate japanese ch07_9aa3f7c7:

    # "No greeting. The captain's voice had gone past fury into something flatter and more frightened."
    "挨拶もなかった。警部の声は怒りを通り越して、もっと平板で、もっとおびえた何かになっていた。"

# game/script/ch07.rpy:440
translate japanese ch07_b4849801:

    # d worried "Tell me I don't have a fourth— Sam, tell me it is not a child."
    d worried "四人目だなんて言うな――Sam、子どもじゃないと言ってくれ。"

# game/script/ch07.rpy:441
translate japanese ch07_d2a991d9:

    # s "It's a child. Fourteen. Same method as the priest, same signatures, laid out ritual up at the cemetery, a few plots off the Ward girl's grave. Her name was Emily Carter."
    s "子どもだ。十四歳。司祭と同じ手口、同じ署名。墓地で儀式みたいに寝かされてる。Wardの娘の墓から数区画のところだ。名前はEmily Carter。"

# game/script/ch07.rpy:442
translate japanese ch07_38b50a40:

    # s "She was the Bennett girl's best friend."
    s "Bennettのところの子の親友だった。"

# game/script/ch07.rpy:443
translate japanese ch07_dd5d2acb:

    # "The line was silent for a long moment."
    "回線は長いこと黙っていた。"

# game/script/ch07.rpy:444
translate japanese ch07_a8fbf09a:

    # d neutral "The grandfather. The one you've been circling."
    d neutral "祖父か。お前がずっと目をつけてきた男だな。"

# game/script/ch07.rpy:445
translate japanese ch07_0a9e0a44:

    # s "His granddaughter told me, last night, that he resented the friendship. That he was leaving town soon and was out that night on— her word— preparations."
    s "孫娘が、昨夜、俺に言ったんだ。祖父はその友情を嫌ってる、と。もうすぐ町を出るつもりで、昨夜は出かけていた――あの子の言葉で言えば――準備に。"

# game/script/ch07.rpy:446
translate japanese ch07_737f4c4e:

    # "Samuel heard how it sounded, said aloud, and did not soften it."
    "口に出すとそれがどう聞こえるか、Samuelにはわかった。それでも和らげはしなかった。"

# game/script/ch07.rpy:447
translate japanese ch07_d8c3be5e:

    # s "I filed it as a controlling old man isolating a kid. Ray, it reads different this morning."
    s "俺は、子どもを孤立させる支配的な爺さん、として片付けた。Ray、今朝は読み方が違ってくる。"

# game/script/ch07.rpy:448
translate japanese ch07_b77d8479:

    # d angry "It reads like probable cause is what it reads like."
    d angry "相当な理由がある、としか読めんだろうが。"

# game/script/ch07.rpy:449
translate japanese ch07_150b655e:

    # d angry "A man with cult ties from a village full of missing girls, no alibi, near half these scenes on his handyman rounds, whose own blood sat in your car and told you he was dangerous and about to run—"
    d angry "カルトとつながりがあって、娘が何人も消えた村から来て、アリバイはなく、便利屋の仕事で現場の半分近くをうろついてる男だ。そいつの孫がお前の車に座って、あいつは危険で、もうすぐ逃げると言ったんだぞ――"

# game/script/ch07.rpy:450
translate japanese ch07_fbb41556:

    # d angry "—and now the one person she said he wanted gone is dead in ground he could've dug. What are you waiting for? Christmas?"
    d angry "――で、そいつが消えてほしがってると孫が言ったたった一人の人間が、そいつが掘れたはずの地面で死んでる。何を待ってる？クリスマスか？"

# game/script/ch07.rpy:452
translate japanese ch07_c038e0ea:

    # "He had let Ray put it on him once already this week. Ray had come back with more."
    "今週、彼はすでに一度、Rayの言い分を呑んでいた。Rayはさらに上乗せしてきた。"

# game/script/ch07.rpy:454
translate japanese ch07_1e0939f6:

    # "He had pushed back once already this week. Ray had been saving the rest."
    "今週、彼はすでに一度押し返していた。Rayは残りを取っておいたのだ。"

# game/script/ch07.rpy:459
translate japanese ch07_153990a4:

    # s "Not yet. I'm waiting to not be wrong."
    s "まだだ。間違っていない、と言えるまで待つ。"

# game/script/ch07.rpy:460
translate japanese ch07_de35e4fd:

    # "Samuel pulled the car to the curb and stopped, and sat, the engine idling."
    "Samuelは車を縁石に寄せて止め、エンジンをかけたまま座っていた。"

# game/script/ch07.rpy:461
translate japanese ch07_182afc5d:

    # s "Because if I take George Bennett and I'm wrong, the real one walks, and there's a fifth."
    s "George Bennettを引っぱって、それが間違いだったら、本物は野放しになって、五人目が出る。"

# game/script/ch07.rpy:464
translate japanese ch07_cd96cc0d:

    # s "You're right. It reads like cause."
    s "あんたの言うとおりだ。相当な理由に読める。"

# game/script/ch07.rpy:465
translate japanese ch07_28997a6d:

    # "Samuel pulled the car to the curb and stopped, and sat, the engine idling, and heard himself go on anyway."
    "Samuelは車を縁石に寄せて止め、エンジンをかけたまま座った。そして、それでも自分が続けるのを聞いた。"

# game/script/ch07.rpy:466
translate japanese ch07_01c0b5d0:

    # s "But if I take George Bennett and I'm wrong, Ray, the real one walks. And there's a fifth."
    s "だが、George Bennettを引っぱって間違いだったら、Ray、本物は野放しだ。そして五人目が出る。"

# game/script/ch07.rpy:468
translate japanese ch07_bd052405:

    # d angry "You think I don't know that?"
    d angry "俺がそれを知らないとでも思ってるのか？"

# game/script/ch07.rpy:469
translate japanese ch07_6faf0a10:

    # "Something broke loose under the fury then, the frightened thing beneath it."
    "そのとき、怒りの下で何かがほどけた。その下にある、おびえたものが。"

# game/script/ch07.rpy:470
translate japanese ch07_3c54cf72:

    # d worried "The mayor's called me four times before nine, and I can live with the mayor. What I can't live with is the stringer from the city paper who already has the word cult and is maybe three hours from filing."
    d worried "町長からは九時前に四回電話が来た。町長ならまだいい。我慢できないのは市の新聞の通信員だ。もう「カルト」って言葉をつかんでて、記事を送るまであと三時間ってところだ。"

# game/script/ch07.rpy:471
translate japanese ch07_46e61ab7:

    # d angry "You know what happens the day that runs? It stops being a town, Sam. It becomes a story. A satanic child-killer loose in the mountains while the police sit in the hotel."
    d angry "それが載った日に何が起きるかわかるか？町じゃなくなるんだよ、Sam。物語になる。悪魔崇拝の子ども殺しが山をうろついてるのに、警察はホテルで座ってる、ってな。"

# game/script/ch07.rpy:472
translate japanese ch07_03aa11f6:

    # d angry "That is the kind of story that ends careers. Mine first and then yours, and neither of us young enough to outrun it."
    d angry "そういう物語は経歴を終わらせる。まず俺の、それからお前のだ。どっちも、逃げ切れるほど若くはない。"

# game/script/ch07.rpy:473
translate japanese ch07_b6fb3766:

    # "Samuel said nothing. Through the windshield, the square was filling."
    "Samuelは何も言わなかった。フロントガラスの向こうで、広場が人で埋まりつつあった。"

# game/script/ch07.rpy:474
translate japanese ch07_c1ae1f5a:

    # d neutral "So here's where we are."
    d neutral "いいか、状況はこうだ。"

# game/script/ch07.rpy:475
translate japanese ch07_019103db:

    # "Doyle's voice dropped, and the drop was worse than the shouting."
    "Doyleの声が低くなった。その低さは、怒鳴り声よりたちが悪かった。"

# game/script/ch07.rpy:476
translate japanese ch07_71350812:

    # d neutral "You give me a name today, or the day after tomorrow this stops being yours. They send people. A task force. Feds, if the cult angle holds. Strangers tearing that town apart."
    d neutral "今日中に名前を出せ。さもなきゃ明後日には、これはお前の事件じゃなくなる。人が送られてくる。特別捜査班だ。カルトの線が残れば連邦だ。よそ者があの町をばらばらにする。"

# game/script/ch07.rpy:477
translate japanese ch07_4c6b1a73:

    # d neutral "And you and me in a room explaining why we sat on a suspect the whole valley could name."
    d neutral "そして俺とお前は部屋に呼ばれて説明する羽目になる。谷じゅうの誰もが名前を言える容疑者を、なぜ放っておいたのかをな。"

# game/script/ch07.rpy:478
translate japanese ch07_5f95efbe:

    # d angry "You've got probable cause a first-year could stand up in front of a judge. You've got a man the town already convicted. Take him. Hold him. Build it right from inside a cell."
    d angry "新米でも判事の前で通せる相当な理由がある。町がもう有罪にした男がいる。引っぱれ。拘束しろ。房の中から、正しく固めていけ。"

# game/script/ch07.rpy:479
translate japanese ch07_4fb9818e:

    # d neutral "You don't have to charge him today. But you get him off that street."
    d neutral "今日起訴しなくてもいい。だが、あいつを通りから引き上げろ。"

# game/script/ch07.rpy:480
translate japanese ch07_6c214ab0:

    # s "And if I don't."
    s "で、やらなかったら。"

# game/script/ch07.rpy:481
translate japanese ch07_57a45255:

    # d neutral "If you don't, that street takes him off it for you."
    d neutral "やらなかったら、通りのほうがお前の代わりにあいつを引き上げる。"

# game/script/ch07.rpy:482
translate japanese ch07_09d486be:

    # "Flat now. Certain. A man who had watched it happen before."
    "いまは平板だった。確信していた。前にもそれが起きるのを見てきた男の声だった。"

# game/script/ch07.rpy:483
translate japanese ch07_74ad1119:

    # d neutral "They are already saying his name in the square, Sam. I can hear it in the calls, that particular note. A child is dead. They are terrified and they are furious and at last they have a face."
    d neutral "広場じゃもうあいつの名前が出てるぞ、Sam。電話でわかるんだ、あの独特の調子でな。子どもが死んだ。連中はおびえて、怒り狂って、ようやく顔を手に入れたんだ。"

# game/script/ch07.rpy:484
translate japanese ch07_88c3c0cf:

    # d neutral "The only thing standing between George Bennett and a rope is you putting him somewhere they can't reach."
    d neutral "George Bennettと縄のあいだに立ってるのは、お前があいつを連中の手の届かないところに置くこと、それだけだ。"

# game/script/ch07.rpy:485
translate japanese ch07_4b71aa9c:

    # d angry "I would rather he sat in your cell cursing your name for a year than swung off their lamppost tonight. Bring him in, Sam."
    d angry "あいつが今夜、連中の街灯からぶら下がるくらいなら、お前の房で一年お前の名前を呪ってるほうがましだ。連れてこい、Sam。"

# game/script/ch07.rpy:486
translate japanese ch07_05b0013f:

    # "Samuel looked out through the fogging windshield at the shuttered shops, the church on the far side, the little knots of people gathering in doorways, heads bent together."
    "Samuelは曇っていくフロントガラス越しに外を見た。シャッターの下りた店。向こう側の教会。戸口に寄り集まって額を寄せ合う、小さな人の塊。"

# game/script/ch07.rpy:487
translate japanese ch07_9a321b81:

    # "The low current of a town's fear, finding at last a name to run toward."
    "町の恐怖の低い流れが、ようやく、向かって走るべき名前を見つけていた。"

# game/script/ch07.rpy:488
translate japanese ch07_a06cbf85:

    # s "I'll talk to the girl first. Then I'll bring him in."
    s "まず、あの子と話す。それから引っぱる。"

# game/script/ch07.rpy:501
translate japanese ch07_f8efcebe:

    # "He should have gone the back way. But the square lay between him and the road out to Markou's, and the square was where the town had come."
    "裏道を通るべきだった。だが彼とMarkouの家へ向かう道とのあいだには広場があり、町が集まってきたのはその広場だった。"

# game/script/ch07.rpy:502
translate japanese ch07_83c652ad:

    # "Forty of them, fifty, more coming down the side lanes with their breath rising white. The church doors standing open behind them, and the word {i}child{/i} passing mouth to mouth like a coal too hot to hold."
    "四十人、五十人。さらに脇道から、白い息を上げながら下りてくる。彼らの後ろで教会の扉が開け放たれ、{i}子ども{/i}という言葉が、熱すぎて持っていられない炭のように、口から口へ渡っていった。"

# game/script/ch07.rpy:503
translate japanese ch07_9676f14a:

    # "Samuel brought the car to a crawl through them. They turned to look at it, and the thing he had felt building under this town all week finally came up into their faces and showed itself."
    "Samuelは彼らのあいだを這うような速さで車を進めた。人々が振り向いて車を見た。この一週間、町の下で育ちつつあると彼が感じていたものが、ついに彼らの顔に浮かび上がり、正体を現した。"

# game/script/ch07.rpy:504
translate japanese ch07_7449a5c3:

    # "At the funeral it had been a whisper. {i}Outsider. Why is he here.{/i} It was not a whisper now."
    "葬儀ではそれはささやきだった。{i}よそ者。なぜここにいる。{/i}いまはもう、ささやきではなかった。"

# game/script/ch07.rpy:506
translate japanese ch07_57f9e5e2:

    # "A palm came down flat on the hood. Not hard, but deliberate, the way you lay a hand on a man's chest to stop him."
    "掌がボンネットに平たく振り下ろされた。強くはない。だが意図的だった。男の胸に手を当てて止めるときのように。"

# game/script/ch07.rpy:507
translate japanese ch07_a28d42b6:

    # "Samuel braked, because to drive on was to drag someone. And rolled the window down, because a coward rolled it up."
    "Samuelはブレーキを踏んだ。そのまま進めば誰かを引きずることになるからだ。そして窓を下ろした。臆病者なら閉めるからだ。"

# game/script/ch07.rpy:510
translate japanese ch07_2faff9e6:

    # "Kurt Leary, naturally. His face blotched red with cold and with something hotter, and drink on him already at ten in the morning. Men gathered at his shoulder as he bent to the window."
    "案の定、Kurt Learyだった。顔は寒さと、もっと熱い何かで赤くまだらになり、朝の十時だというのにもう酒が入っていた。彼が窓に身をかがめると、男たちがその肩のまわりに集まった。"

# game/script/ch07.rpy:511
translate japanese ch07_23473f22:

    # kl angry "Four. Four now. And a little girl this time, a baby."
    kl angry "四人だ。もう四人だぞ。今度は小さな女の子だ、まだ赤ん坊じゃねえか。"

# game/script/ch07.rpy:512
translate japanese ch07_8fea8557:

    # "His voice shook."
    "声が震えていた。"

# game/script/ch07.rpy:513
translate japanese ch07_e1818d54:

    # kl angry "A week and more you've been here, mister big-city detective, walking round with your notebook and your cigarettes, and there's four of ours in the ground and not one hand laid on him."
    kl angry "一週間以上もここにいやがって、都会の大刑事さんよ、手帳と煙草持ってうろうろして、こっちは四人も土の下だってのに、あいつに指一本触れてねえ。"

# game/script/ch07.rpy:514
translate japanese ch07_998751e6:

    # kl angry "So which is it? You can't catch him? Or you're too busy sleeping in that hotel to try?"
    kl angry "で、どっちだ？捕まえられねえのか？それともあのホテルで寝るのに忙しくて、やる気もねえのか？"

# game/script/ch07.rpy:515
translate japanese ch07_0f01df15:

    # "A sound went through the crowd behind him. Low. Agreeing. Ugly."
    "彼の後ろの群衆に、ある音が広がった。低く。同意する音。醜い音。"

# game/script/ch07.rpy:524
translate japanese ch07_8c834c84:

    # "It had shaken. Under the drink and the finger, terror, come out as a fist because a fist was the only shape it knew."
    "声は震えていた。酒と突きつける指の下にあるのは恐怖だった。拳の形で出てきたのは、それが恐怖の知っている唯一の形だったからだ。"

# game/script/ch07.rpy:525
translate japanese ch07_9d88eb89:

    # "Samuel held the man's eyes. A crowd like this fed on flinch; the only thing to feed it instead was stillness."
    "Samuelは男の目をとらえた。こういう群衆はひるみを餌にする。代わりに与えられる唯一のものは、静けさだった。"

# game/script/ch07.rpy:526
translate japanese ch07_b5df03f5:

    # s "I'm going to catch who did this. Today, if the day gives me room."
    s "これをやった奴は必ず捕まえる。今日だ、今日が余地をくれるならな。"

# game/script/ch07.rpy:527
translate japanese ch07_991b8e89:

    # s "And it'll be because it was done right and it holds. Not because I handed you a face so you could sleep tonight."
    s "そしてそれは、正しくやって、揺るがないからだ。あんたらが今夜眠れるように、顔を一つ差し出したからじゃない。"

# game/script/ch07.rpy:528
translate japanese ch07_fed11fa6:

    # s "You want the wrong man in the ground beside that child? Fast and wrong is how you get a second grave and the real one still out here."
    s "あの子の隣に、間違った男を埋めたいのか？速くて間違ってりゃ、墓がもう一つ増えて、本物はまだここをうろついてる。"

# game/script/ch07.rpy:529
translate japanese ch07_b7d9d228:

    # woman "We know who it is. Everyone knows. That devil up in the trees and his cold little girl, come here from nowhere—"
    woman "誰だかわかってるよ。みんな知ってる。森の上のあの悪魔と、あの冷たい孫娘だよ。どこからともなくやって来て――"

# game/script/ch07.rpy:530
translate japanese ch07_bcb94d43:

    # crowd "—and the dying started—"
    crowd "――それから人が死にはじめた――"

# game/script/ch07.rpy:531
translate japanese ch07_5d8d9edb:

    # crowd "—while you drink coffee and he picks us off one at a time—"
    crowd "――あんたがコーヒー飲んでるあいだに、あいつは一人ずつ俺たちを片付けてる――"

# game/script/ch07.rpy:533
translate japanese ch07_c7010200:

    # "The voices climbed over one another. The ring of bodies pressed a half-step in."
    "声が互いに重なり合って高まった。体の輪が半歩、詰め寄った。"

# game/script/ch07.rpy:534
translate japanese ch07_e1c91416:

    # "Samuel felt the thing in the crowd change temperature. Felt it stop being fear and start wanting somewhere to go. A door to put its shoulder to."
    "Samuelは群衆の中のものが温度を変えるのを感じた。恐怖であることをやめ、どこかへ向かいたがりはじめるのを感じた。肩を押し当てる扉を。"

# game/script/ch07.rpy:535
translate japanese ch07_2c27ceb7:

    # "He had stood in the middle of this before. He knew exactly how thin the wall was, and how fast it went."
    "前にもこういうものの真ん中に立ったことがあった。その壁がどれほど薄く、どれほど速く崩れるか、彼は正確に知っていた。"

# game/script/ch07.rpy:536
translate japanese ch07_ef4567a4:

    # s "Go home."
    s "帰れ。"

# game/script/ch07.rpy:537
translate japanese ch07_da25823c:

    # "He put the edge in it now, the flat cold authority that had turned rooms before."
    "今度はそこに刃を込めた。かつて幾つもの部屋の空気を変えた、平板で冷たい権威を。"

# game/script/ch07.rpy:538
translate japanese ch07_8077cf68:

    # s angry "All of you. It is ten in the morning and there is a family two streets from here that lost their daughter in the night, and you are out here making theatre of your fear where they can hear every word."
    s angry "全員だ。朝の十時だぞ。ここから二本先の通りに、夜のうちに娘を亡くした家族がいる。なのにあんたらはここで、その家族に一言残らず聞こえるところで、自分たちの恐怖を芝居にしてる。"

# game/script/ch07.rpy:539
translate japanese ch07_2cc80609:

    # s "Go home. Let me work. You'll have your answer before dark."
    s "帰れ。仕事をさせろ。暗くなる前に答えは出す。"

# game/script/ch07.rpy:540
translate japanese ch07_d9c4e8ea:

    # "It was the family that did it. The shame of it. The reminder that the grief was real and near and belonged to someone, while they performed their own out in the cold."
    "効いたのは家族だった。その恥ずかしさだった。悲しみは本物で、すぐ近くにあって、誰かのものなのだと思い出させられたことだった。そのあいだ自分たちは、寒空の下で自分の悲しみを演じていたのだと。"

# game/script/ch07.rpy:542
translate japanese ch07_f4296267:

    # "Leary straightened. The ring gave."
    "Learyは身を起こした。輪がゆるんだ。"

# game/script/ch07.rpy:545
translate japanese ch07_b62c8c50:

    # "They did not scatter so much as loosen, sullen, still muttering. Their faces slid by the glass one after another, and the Bennett name was in every one of them, whether the mouth said it or not."
    "彼らは散ったというより、ほどけた。不機嫌に、まだぶつぶつ言いながら。彼らの顔が一つ、また一つとガラスの外を過ぎていった。どの顔にも、口が言うか言わないかにかかわらず、Bennettの名があった。"

# game/script/ch07.rpy:546
translate japanese ch07_302f20ae:

    # th "Before dark. I promised a frightened town an answer before dark, the way you promise a screaming child anything to make the screaming stop."
    th "暗くなる前に、か。おびえた町に、暗くなる前に答えを約束した。泣き叫ぶ子どもに、叫ぶのをやめさせるためなら何でも約束するみたいに。"

# game/script/ch07.rpy:547
translate japanese ch07_06602e6b:

    # "And there was exactly one name in the whole white valley to give them."
    "そして、この白い谷全体に、彼らに与えられる名前はちょうど一つしかなかった。"

# game/script/ch07.rpy:548
translate japanese ch07_8654c503:

    # "Doyle had been right, and that was the worst of it. This town would have George Bennett before the day was out, one way or the other."
    "Doyleは正しかった。それが最悪のところだった。この町は今日が終わる前に、どうにかしてGeorge Bennettを手に入れるだろう。"

# game/script/ch07.rpy:549
translate japanese ch07_0bcfab97:

    # "The only choice still left to Samuel was whether it happened behind a locked door or at the end of a rope."
    "Samuelにまだ残された選択は、それが鍵のかかった扉の向こうで起きるか、縄の先で起きるか、それだけだった。"

# game/script/ch07.rpy:559
translate japanese ch07_960e654b:

    # "Helena Markou was waiting for him at her door, and she had Alice."
    "Helena Markouは戸口で彼を待っていた。Aliceを連れて。"

# game/script/ch07.rpy:560
translate japanese ch07_e1f8a8a6:

    # "She had gone and got her herself, Samuel understood. Had heard, the way the town heard, and driven out to the house at the edge of the trees and taken the child before anyone else could."
    "自分で迎えに行ったのだ、とSamuelは理解した。町が聞いたのと同じように聞きつけ、森のはずれの家まで車を走らせ、ほかの誰かより先に子どもを連れてきたのだ。"

# game/script/ch07.rpy:561
translate japanese ch07_00ecc986:

    # "It was what she had refused to do for him with a file, and did without hesitation for a girl: put herself between the child and the world."
    "ファイルについては彼に拒んだことを、一人の少女のためにはためらいなくやってのけた。子どもと世界のあいだに、自分の身を置くこと。"

# game/script/ch07.rpy:563
translate japanese ch07_2d1ca89b:

    # "She met his eyes with a look that was half warning and half plea."
    "彼女は彼の目を見た。その目は半分が警告で、半分が懇願だった。"

# game/script/ch07.rpy:564
translate japanese ch07_0b73c2a3:

    # th "Gently. She is twelve, and her friend is dead. Gently, or not at all."
    th "そっとだ。あの子は十二歳で、友だちが死んだ。そっとやるか、やらないかだ。"

# game/script/ch07.rpy:567
translate japanese ch07_df7d4b0c:

    # "Alice sat in the same armchair by the same fire, wrapped in the same blanket. And she was not composed."
    "Aliceは同じ暖炉のそばの、同じ肘掛け椅子に座り、同じ毛布にくるまっていた。そして、落ち着いてはいなかった。"

# game/script/ch07.rpy:568
translate japanese ch07_63a63faf:

    # "That was the thing that stopped Samuel in the doorway. Every time he had seen this child she had been still, contained, older than her years. A calm that never broke."
    "Samuelを戸口で立ち止まらせたのは、それだった。この子を見るたび、彼女は静かで、抑制されていて、年よりも大人びていた。決して崩れない平静さ。"

# game/script/ch07.rpy:569
translate japanese ch07_e9fe6ae2:

    # "It had broken now. She sat small and folded in on herself, knees drawn up, her face blotched and swollen."
    "それがいま崩れていた。彼女は小さく、自分の中に折りたたまれるように座り、膝を抱え、顔はまだらに腫れていた。"

# game/script/ch07.rpy:570
translate japanese ch07_15e03980:

    # "When she saw him her mouth worked and no sound came, and then the sound came. A raw high hitching thing. The sound of a child who has lost the one warm thing she had."
    "彼を見ると、口が動いたが声は出ず、それから声が出た。生々しい、甲高い、しゃくりあげる声。持っていたたった一つの温かいものを失った子どもの声。"

# game/script/ch07.rpy:571
translate japanese ch07_aaa3f154:

    # "Tears ran down her face and she did not wipe them. Her hands shook. She looked, for the first time since he had met her, exactly like what she was."
    "涙が顔を流れ、彼女はそれを拭わなかった。手が震えていた。出会ってから初めて、彼女はまさにありのままの彼女に見えた。"

# game/script/ch07.rpy:572
translate japanese ch07_46c1fa49:

    # "A little girl whose best friend was dead."
    "親友を亡くした、小さな女の子に。"

# game/script/ch07.rpy:573
translate japanese ch07_dabf545e:

    # "Something in Samuel's chest, already cracked, gave a little further."
    "すでにひびの入っていたSamuelの胸の中の何かが、もう少し崩れた。"

# game/script/ch07.rpy:574
translate japanese ch07_0f1de2a4:

    # s soft "Alice."
    s soft "Alice。"

# game/script/ch07.rpy:575
translate japanese ch07_609bf6a5:

    # "He crossed to her, and crouched to her level the way he had learned to, his voice gone low and careful."
    "彼は彼女のそばへ行き、覚えてきたやり方で目の高さまでしゃがんだ。声は低く、慎重になっていた。"

# game/script/ch07.rpy:576
translate japanese ch07_b7486790:

    # s "I'm so sorry. I am so sorry."
    s "気の毒に。本当に、気の毒に。"

# game/script/ch07.rpy:577
translate japanese ch07_3b24a619:

    # a cry "They said— Mrs. Markou said someone— that Emily—"
    a cry "みんなが――Markou先生が、誰かが――Emilyが――"

# game/script/ch07.rpy:578
translate japanese ch07_065224c3:

    # "Her face crumpled."
    "彼女の顔がくしゃくしゃに歪んだ。"

# game/script/ch07.rpy:579
translate japanese ch07_84d3855a:

    # a cry "It's not true. Tell me it's not true."
    a cry "本当じゃないですよね。本当じゃないって言ってください。"

# game/script/ch07.rpy:580
translate japanese ch07_1901707c:

    # "He did not lie to children."
    "彼は子どもに嘘をつかなかった。"

# game/script/ch07.rpy:581
translate japanese ch07_b1b6057e:

    # s "It's true. I'm sorry, Alice. She's gone."
    s "本当だ。気の毒に、Alice。あの子は亡くなった。"

# game/script/ch07.rpy:583
translate japanese ch07_f2438efc:

    # "The sound she made then, he would hear for a long time."
    "そのとき彼女が上げた声を、彼は長いあいだ聞きつづけることになる。"

# game/script/ch07.rpy:584
translate japanese ch07_bca5c9e7:

    # "Helena moved to her and gathered her in. The girl turned her face into the woman's shoulder—exactly the way, Samuel remembered with a lurch, Emily had turned her face into Alice's at the funeral."
    "Helenaが彼女に近寄り、抱き寄せた。少女は女の肩に顔を埋めた――葬儀でEmilyがAliceの肩に顔を埋めたのとまったく同じように、とSamuelは思い出し、胃が揺らいだ。"

# game/script/ch07.rpy:585
translate japanese ch07_62b7fbd8:

    # "She cried until the crying wore itself down to shudders. Samuel knelt there and waited, and hated the job, and did it anyway, because there was a killer and there was a clock."
    "彼女は、泣き声がすり切れて震えだけになるまで泣いた。Samuelはそこにひざまずいて待ち、この仕事を憎み、それでもやった。殺人者がいて、時計が動いていたからだ。"

# game/script/ch07.rpy:587
translate japanese ch07_f455c924:

    # s "Alice."
    s "Alice。"

# game/script/ch07.rpy:588
translate japanese ch07_631ba305:

    # "He waited until her eyes came back to him, red and streaming."
    "彼女の目が、赤く濡れたまま、彼に戻ってくるまで待った。"

# game/script/ch07.rpy:589
translate japanese ch07_0187ad73:

    # s "I have to ask you some things. Hard things. And then I'll leave you be, I promise. Can you do that? For Emily?"
    s "いくつか聞かなきゃならないことがある。つらいことだ。それが済んだら、そっとしておく。約束する。できるかい？Emilyのために。"

# game/script/ch07.rpy:590
translate japanese ch07_668ccd6c:

    # "The name steadied her the way nothing else could have. She nodded, a small fierce nod, and pressed her lips together."
    "その名前は、ほかの何にもできないやり方で彼女を落ち着かせた。彼女はうなずいた。小さく、激しく。そして唇を固く結んだ。"

# game/script/ch07.rpy:591
translate japanese ch07_2116dc79:

    # "Samuel saw her gather herself by force, and mistook it for courage."
    "彼女が力ずくで自分をかき集めるのを見て、Samuelはそれを勇気と取り違えた。"

# game/script/ch07.rpy:592
translate japanese ch07_df34283c:

    # s "Your grandfather. Last night. When I brought you home, his truck was gone— you remember? He was already out."
    s "おじいさんのことだ。昨夜、私が君を送っていったとき、トラックがなかった――覚えてるかい？もう出かけていた。"

# game/script/ch07.rpy:593
translate japanese ch07_7ba2653d:

    # a cry "He went after dinner. Before I walked to Mrs. Markou's. He said he had work. He said he'd be late."
    a cry "夕食のあとに出ていきました。私がMarkou先生のところへ歩いていく前です。仕事があるって。遅くなるって言ってました。"

# game/script/ch07.rpy:594
translate japanese ch07_5f4c8aff:

    # "A breath."
    "一つ、息。"

# game/script/ch07.rpy:595
translate japanese ch07_79307084:

    # a cry "I heard him leave. The truck, on the gravel. I always hear the truck."
    a cry "出ていくのが聞こえました。砂利の上の、トラックの音。トラックの音は、いつも聞こえるんです。"

# game/script/ch07.rpy:596
translate japanese ch07_f46ebb42:

    # "Samuel kept his own voice level, kept the pen still."
    "Samuelは自分の声を平らに保ち、ペンを動かさずにいた。"

# game/script/ch07.rpy:597
translate japanese ch07_c46e9620:

    # s "And did you hear him come back?"
    s "帰ってくる音は聞こえたかい？"

# game/script/ch07.rpy:598
translate japanese ch07_dcfc5c88:

    # "She was quiet a moment. Her eyes moved to the fire, and the flames turned in them."
    "彼女はしばらく黙っていた。目が暖炉に移り、炎がその中で揺れた。"

# game/script/ch07.rpy:602
translate japanese ch07_0aea8ba2:

    # "He laid a hand, lightly, on the arm of the chair. Not on her. Just near. Something solid."
    "彼は軽く、椅子の肘掛けに手を置いた。彼女にではなく。ただ、近くに。何か確かなものとして。"

# game/script/ch07.rpy:603
translate japanese ch07_e154f6df:

    # s "Take your time. There's no wrong answer."
    s "ゆっくりでいい。間違った答えなんてないから。"

# game/script/ch07.rpy:604
translate japanese ch07_239ea366:

    # a cry "Late. Really late. After two— I looked at the clock, because I couldn't sleep."
    a cry "遅くです。すごく遅く。二時過ぎ――時計を見たんです。眠れなかったから。"

# game/script/ch07.rpy:608
translate japanese ch07_aae21959:

    # "He watched her eyes, the firelight moving in them. The tears were real; he had seen enough false ones to know. They ran and she let them."
    "彼は彼女の目を、その中で動く炎の光を見ていた。涙は本物だった。偽物の涙は十分見てきたから、わかる。涙は流れ、彼女はそれを流れるにまかせた。"

# game/script/ch07.rpy:609
translate japanese ch07_239ea366_1:

    # a cry "Late. Really late. After two— I looked at the clock, because I couldn't sleep."
    a cry "遅くです。すごく遅く。二時過ぎ――時計を見たんです。眠れなかったから。"

# game/script/ch07.rpy:610
translate japanese ch07_7b701867:

    # "And when she said {i}after two{/i}, her eyes did not waver. Not a flicker. Not the small search upward that people made for a number they half remembered."
    "そして彼女が{i}二時過ぎ{/i}と言ったとき、その目は揺らがなかった。ちらりとも。うろ覚えの数字を探すときに人がする、あの小さく上を見る動きもなかった。"

# game/script/ch07.rpy:611
translate japanese ch07_b28da902:

    # th "She looked at the clock. She's sure. Grief makes some things very sharp."
    th "時計を見たんだ。確かなんだろう。悲しみは、ものによってはひどく鋭くする。"

# game/script/ch07.rpy:612
translate japanese ch07_9f6e64f2:

    # "He heard it as certainty, and let it go."
    "彼はそれを確信として聞き、流した。"

# game/script/ch07.rpy:614
translate japanese ch07_9efe8949:

    # "She lifted her wet eyes back to Samuel's, and they did not waver."
    "彼女は濡れた目をSamuelの目に戻した。その目は揺らがなかった。"

# game/script/ch07.rpy:615
translate japanese ch07_e71c0893:

    # a cry "Why? Why are you asking me about George?"
    a cry "どうして？どうしてGeorgeのことを聞くんですか？"

# game/script/ch07.rpy:616
translate japanese ch07_bf575319:

    # "And there it was."
    "そして、それが来た。"

# game/script/ch07.rpy:618
translate japanese ch07_1f5155a8:

    # "Samuel felt it settle over him, cold and total."
    "Samuelは、それが冷たく、完全に、自分の上に降りてくるのを感じた。"

# game/script/ch07.rpy:619
translate japanese ch07_5c638efa:

    # "A man gone from his house the whole of the murder night—he had seen the empty drive with his own eyes. Home after two. Days from a leaving he had told no one about."
    "殺人の夜、一晩じゅう家を空けていた男――空っぽの車寄せを、彼は自分の目で見ていた。二時過ぎに帰宅。誰にも話していない出発まで、あと数日。"

# game/script/ch07.rpy:620
translate japanese ch07_b7cd68d1:

    # "Whose own granddaughter had wept in Samuel's passenger seat that he wanted her one friend gone."
    "その実の孫娘が、Samuelの車の助手席で泣きながら、祖父はたった一人の友だちがいなくなればいいと思っていると言ったのだ。"

# game/script/ch07.rpy:622
translate japanese ch07_9dc12410:

    # note_voice "George out all night. Home after two (per Alice)."
    note_voice "George、一晩外出。帰宅二時過ぎ（Alice談）。"

# game/script/ch07.rpy:623
translate japanese ch07_6988e41f:

    # "He would want it corroborated. He would put men on the truck, on the roads out, on the resin a poisoner carried under his nails, and build it the right way, brick by proven brick."
    "裏づけは欲しい。トラックに、町から出る道に、毒を盛る者が爪の下に持ち歩く樹脂に、人を張りつけて、正しいやり方で固めていく。証明された煉瓦を一つずつ。"

# game/script/ch07.rpy:624
translate japanese ch07_80ec4b6a:

    # "But he already knew where every road of it ran, and they all ran to the same door."
    "だが、そのどの道がどこへ通じているか、彼にはもうわかっていた。どの道も同じ扉へ通じていた。"

# game/script/ch07.rpy:625
translate japanese ch07_8900fa9c:

    # "Somewhere under the certainty a smaller thing tried to be heard."
    "確信の下のどこかで、もっと小さなものが聞いてもらおうとしていた。"

# game/script/ch07.rpy:626
translate japanese ch07_e466f1dd:

    # th "A careful girl doesn't climb out into a storm at midnight for a grandfather she's afraid of. She goes for someone she loves. Someone she'd open a window for—"
    th "慎重な子は、怖がっている祖父のために真夜中に嵐の中へ抜け出したりはしない。愛している誰かのためなら行く。窓を開けてやるような誰かのために――"

# game/script/ch07.rpy:627
translate japanese ch07_fbe2deb5:

    # "Samuel felt it move in him, and reached for it, and it was gone before it had a name. Sunk without trace, the way the wrong-turning instinct in the dark car had sunk."
    "Samuelはそれが自分の中で動くのを感じ、手を伸ばした。だがそれは名前を持つ前に消えていた。跡形もなく沈んだ。暗い車の中で、道を誤ったあの直感が沈んだように。"

# game/script/ch07.rpy:628
translate japanese ch07_1d8ec842:

    # "He looked at the shaking, streaming, broken child in front of him, and let it go. Grief was loud in the room, and the work was quiet, and the work said George."
    "彼は目の前の、震え、涙を流し、打ちひしがれた子どもを見て、それを手放した。部屋では悲しみが騒がしく、仕事は静かで、そして仕事はGeorgeと言っていた。"

# game/script/ch07.rpy:629
translate japanese ch07_a93237bb:

    # s "You did the right thing telling me. You've been so brave."
    s "話してくれたのは正しいことだった。君は本当によく頑張った。"

# game/script/ch07.rpy:630
translate japanese ch07_c955eaf0:

    # s "This isn't your fault, Alice. None of it is your fault. Do you understand me?"
    s "これは君のせいじゃない、Alice。何一つ、君のせいじゃない。わかるね？"

# game/script/ch07.rpy:631
translate japanese ch07_f9bc20de:

    # a cry "I want George to come home."
    a cry "Georgeに帰ってきてほしいです。"

# game/script/ch07.rpy:632
translate japanese ch07_965c5f0e:

    # "A whisper. She put her face back in Helena's shoulder."
    "ささやきだった。彼女はまたHelenaの肩に顔を埋めた。"

# game/script/ch07.rpy:633
translate japanese ch07_1b24e981:

    # a cry "I just want to go home."
    a cry "ただ、家に帰りたいんです。"

# game/script/ch07.rpy:634
translate japanese ch07_b5ff4d36:

    # "Over the child's bowed head, Helena Markou looked at Samuel. There was a question in her face, and a dread, because she had seen where his own face had gone."
    "子どものうつむいた頭越しに、Helena MarkouがSamuelを見た。その顔には問いがあり、恐れがあった。彼自身の顔がどこへ向かったのか、見てとっていたからだ。"

# game/script/ch07.rpy:635
translate japanese ch07_c1855018:

    # h concerned "Detective. What are you going to do?"
    h concerned "刑事さん。どうなさるおつもりですか？"

# game/script/ch07.rpy:636
translate japanese ch07_097292f7:

    # "Samuel stood. His knees ached. Outside the tall windows the light had come up full and grey over the snow, and the town waited under it, afraid."
    "Samuelは立ち上がった。膝が痛んだ。背の高い窓の外では、光がすっかり昇り、雪の上に灰色に広がっていた。町はその下で、おびえながら待っていた。"

# game/script/ch07.rpy:637
translate japanese ch07_3dbded53:

    # "Somewhere in it an old man was cutting wood or fixing a gutter, with no idea that a detective and a frightened town had, in the last hour, quietly agreed on his name."
    "そのどこかで、一人の老人が薪を割るか雨樋を直すかしていた。一人の刑事とおびえた町が、この一時間のうちに、静かに彼の名前で合意したことなど知りもせずに。"

# game/script/ch07.rpy:638
translate japanese ch07_a405d20b:

    # s "My job."
    s "私の仕事です。"

# game/script/ch07.rpy:643
translate japanese ch07_06de6cd8:

    # "He let himself out into the cold, and got into his car, and picked up the radio, and called it in."
    "彼は自分で戸を開けて寒さの中へ出ると、車に乗り、無線を取り、連絡を入れた。"

# game/script/ch07.rpy:656
translate japanese ch07_63c5eec4:

    # "They took George Bennett a little before noon, and the town came up the mountain to watch."
    "正午少し前、彼らはGeorge Bennettを連行した。町は山を登って見物にやって来た。"

# game/script/ch07.rpy:657
translate japanese ch07_d02e225a:

    # "Samuel went himself, with Mercer and Lara and two more uniforms behind him in a second car, up the winding road to the tree line where the house sat behind its squared fence."
    "Samuelは自ら出向いた。MercerとLara、それにもう二人の制服警官が、後ろの二台目の車に乗っていた。曲がりくねった道を、四角い柵の向こうに家が建つ森の境まで登った。"

# game/script/ch07.rpy:658
translate japanese ch07_16929737:

    # "Word of a police convoy climbing the hill had done what four bodies could not quite do. It had given the fear a place to go."
    "丘を登っていく警察の車列の噂は、四つの死体でさえ成し遂げきれなかったことをやってのけた。恐怖に、行き場を与えたのだ。"

# game/script/ch07.rpy:659
translate japanese ch07_0b8bcab7:

    # "They came labouring up the road in trucks and on foot. Thirty already strung along the fence when Samuel stepped out, more arriving every minute."
    "彼らはトラックで、徒歩で、道を苦労して登ってきた。Samuelが車を降りたとき、すでに三十人が柵沿いに連なり、刻一刻と増えていた。"

# game/script/ch07.rpy:660
translate japanese ch07_c3f15eb1:

    # "The low sound coming off them was not yet words. But it was well on its way to being words."
    "彼らから立ち上る低い音は、まだ言葉ではなかった。だが、言葉になる道のりをもうずいぶん進んでいた。"

# game/script/ch07.rpy:663
translate japanese ch07_109f87d6:

    # "Helena Markou's car stood in the drive. She had brought the girl home an hour past, because the child had asked and asked."
    "Helena Markouの車が車寄せに停まっていた。一時間前、彼女は少女を家に連れて帰ったのだ。子どもが何度も何度もそう頼んだから。"

# game/script/ch07.rpy:664
translate japanese ch07_7d7eada6:

    # "And because whatever Samuel's face had told her in that office was a look and not a warrant, and Helena Markou did not tear a grieving child from the last of her family on the strength of a detective's look."
    "そして、あの部屋でSamuelの顔が彼女に告げたものは、表情であって令状ではなかったからだ。Helena Markouは、刑事の表情一つを根拠に、悲しむ子どもを最後の家族から引き離したりはしなかった。"

# game/script/ch07.rpy:665
translate japanese ch07_d76dc2ea:

    # "She came out onto the step now with her coat half on and her face white, understanding all at once, too late, what that principle had delivered the child home into."
    "いま彼女は、コートを半分はおり、真っ白な顔で戸口の段に出てきた。その原則が子どもをどんな場所へ送り届けてしまったのかを、一度に、遅すぎるほどに理解して。"

# game/script/ch07.rpy:668
translate japanese ch07_9e8489bd:

    # "George Bennett opened his door before Samuel reached it, the way he had the last time, as though he had been standing behind it all along."
    "George Bennettは、Samuelがたどり着く前に戸を開けた。前のときと同じように。まるでずっとその後ろに立っていたかのように。"

# game/script/ch07.rpy:669
translate japanese ch07_0c9af3bb:

    # "He filled the frame, tall and grey and still, his face set in the hard lines this town had long since decided were a killer's lines."
    "彼は戸口いっぱいに立っていた。背が高く、灰色で、静かだった。顔は硬い線に固まっていた。この町がとうの昔に、殺人者の線だと決めつけた線に。"

# game/script/ch07.rpy:670
translate japanese ch07_851fcbc6:

    # "He looked past Samuel at the officers, and past them at the crowd bleeding up his road. The thing that moved behind his eyes was not surprise."
    "彼はSamuelの向こうの警官たちを見た。さらにその向こう、自分の道に滲み出すように上ってくる群衆を。目の奥で動いたものは、驚きではなかった。"

# game/script/ch07.rpy:671
translate japanese ch07_3b6a37c0:

    # "It was nearer to recognition. As if something he had been braced against for a very long time had finally, almost restfully, arrived."
    "それは見覚えに近いものだった。ひどく長いあいだ身構えてきた何かが、ついに、ほとんど安らかなほどに、やって来たとでもいうように。"

# game/script/ch07.rpy:672
translate japanese ch07_ec374e9b:

    # s "Mr. Bennett. I need you to come with me."
    s "Bennettさん。一緒に来てもらいます。"

# game/script/ch07.rpy:673
translate japanese ch07_ce2056e3:

    # g grim "On what."
    g grim "何の件だ。"

# game/script/ch07.rpy:674
translate japanese ch07_8e1016cd:

    # s "We'll talk about it at the station."
    s "署で話しましょう。"

# game/script/ch07.rpy:675
translate japanese ch07_8462a0d3:

    # "George's gaze went over Samuel's shoulder to the crowd. The raised phones, the red faces. The men at the front who had already, without deciding to, bent and taken up what the frozen ground offered a hand."
    "Georgeの視線がSamuelの肩越しに群衆へと向かった。掲げられた電話。赤い顔。先頭の男たちは、決めたわけでもないのに、すでに身をかがめて、凍った地面が手に差し出すものを拾い上げていた。"

# game/script/ch07.rpy:676
translate japanese ch07_ca3bff56:

    # "Samuel watched a grim arithmetic finish itself behind the old man's face. The arithmetic of a man who had spent a lifetime expecting the worst, and been schooled by it."
    "Samuelは、老人の顔の奥で冷厳な計算が答えを出すのを見ていた。一生最悪を予期して生き、それに鍛えられてきた男の計算。"

# game/script/ch07.rpy:677
translate japanese ch07_a935eccd:

    # g neutral "You'll want to be quick about it, then. For your sake more than mine."
    g neutral "なら、急いだほうがいい。俺のためというより、あんたのためにな。"

# game/script/ch07.rpy:683
translate japanese ch07_58476519:

    # "And he brought his own hands up and held them out before him, wrists together, waiting for the cuffs, before Samuel had said the word."
    "そして彼は自分から両手を上げ、手首をそろえて前に差し出し、手錠を待った。Samuelがその言葉を口にする前に。"

# game/script/ch07.rpy:684
translate japanese ch07_68611f7b:

    # "At the fence a phone was already up and filming. The town would have that image by nightfall—the old man offering his hands to the law like he knew the shape of the thing."
    "柵のところでは、もう電話が掲げられ、撮影していた。日暮れまでに町はその映像を手に入れるだろう――このことの形を知っているかのように、法に両手を差し出す老人の姿を。"

# game/script/ch07.rpy:685
translate japanese ch07_6356a197:

    # "It would be all the proof they ever wanted."
    "それで、彼らが求める証拠はすべてそろうことになる。"

# game/script/ch07.rpy:692
translate japanese ch07_37cedf1c:

    # a sad "Grandpa?"
    a sad "おじいちゃん？"

# game/script/ch07.rpy:693
translate japanese ch07_fe9b6c9b:

    # "The voice came small from the dim of the hall behind him. Alice stood at the foot of the stairs."
    "その声は、彼の背後の薄暗い廊下から小さく聞こえた。Aliceが階段の下に立っていた。"

# game/script/ch07.rpy:694
translate japanese ch07_e54f6ad4:

    # "Samuel's stomach turned over at the sight of her. A child about to watch this thing happen to the last of her family."
    "その姿を見て、Samuelの胃がひっくり返った。最後の家族にこれが起きるのを、いまから見届けようとしている子ども。"

# game/script/ch07.rpy:695
translate japanese ch07_2ffe34c2:

    # "George went still. He turned his head, and for one long moment the old man looked at the girl."
    "Georgeは動きを止めた。首を巡らせ、長い一瞬、老人は少女を見つめた。"

# game/script/ch07.rpy:696
translate japanese ch07_e8068708:

    # "And Samuel—reading faces was his life, his one true skill—could not read what was in it."
    "そしてSamuelは――顔を読むことが彼の人生であり、ただ一つの本物の技だったのに――そこにあるものを読めなかった。"

# game/script/ch07.rpy:697
translate japanese ch07_9a37c297:

    # "Not the fury of the framed. Not the plea of the innocent. Something heavier and more private than either."
    "罠にはめられた者の怒りではない。無実の者の懇願でもない。そのどちらよりも重く、もっと私的な何か。"

# game/script/ch07.rpy:698
translate japanese ch07_21e43679:

    # "Something that looked, impossibly, like a question he had carried a long way and was afraid to reach the end of."
    "ありえないことに、長い道のりを抱えてきて、その終わりにたどり着くのを恐れている問いのように見える何か。"

# game/script/ch07.rpy:703
translate japanese ch07_c858433b:

    # "Nothing. For the first time in thirty years, a face he could not read."
    "何も。三十年で初めて、読めない顔だった。"

# game/script/ch07.rpy:706
translate japanese ch07_c858433b_1:

    # "Nothing. For the first time in thirty years, a face he could not read."
    "何も。三十年で初めて、読めない顔だった。"

# game/script/ch07.rpy:709
translate japanese ch07_c858433b_2:

    # "Nothing. For the first time in thirty years, a face he could not read."
    "何も。三十年で初めて、読めない顔だった。"

# game/script/ch07.rpy:710
translate japanese ch07_86bc5b3b:

    # "Then he shut it, the way he shut everything, behind the grey door of his face."
    "それから彼はそれを閉ざした。あらゆるものを閉ざすのと同じように、顔という灰色の扉の奥に。"

# game/script/ch07.rpy:711
translate japanese ch07_3fc7e752:

    # g grim "Go inside."
    g grim "中に入れ。"

# game/script/ch07.rpy:712
translate japanese ch07_38dfbbe6:

    # "Rough. Not unkind."
    "ぶっきらぼうに。だが、つれなくはなく。"

# game/script/ch07.rpy:713
translate japanese ch07_fcb1520e:

    # g soft "Go to Mrs. Markou. Don't watch this."
    g soft "Markou先生のところへ行け。これは見るな。"

# game/script/ch07.rpy:715
translate japanese ch07_8f674f68:

    # "He turned his back on the child and stepped out into the cold and the rising noise, and did not look at her again."
    "彼は子どもに背を向け、寒さと高まっていく騒ぎの中へ踏み出し、二度と彼女を見なかった。"

# game/script/ch07.rpy:720
translate japanese ch07_05b7041f:

    # "They walked him to the car through a gauntlet of it. The crowd surged and the uniforms held, barely."
    "彼らはその騒ぎの列のあいだを抜けて、彼を車まで歩かせた。群衆が押し寄せ、制服警官たちがかろうじて食い止めた。"

# game/script/ch07.rpy:721
translate japanese ch07_33ee9c3d:

    # m shaken "Back! Get back— all of you, get back!"
    m shaken "下がれ！下がれ――全員、下がれ！"

# game/script/ch07.rpy:722
translate japanese ch07_bd7877bd:

    # l stern "Off the road! Off the road, now!"
    l stern "道から出て！道から出なさい、今すぐ！"

# game/script/ch07.rpy:723
translate japanese ch07_55032356:

    # "Mercer with his arms spread and his voice gone hoarse. Lara shouting them back a foot at a time."
    "両腕を広げ、声をからしたMercer。一フィートずつ彼らを押し戻して叫ぶLara。"

# game/script/ch07.rpy:726
translate japanese ch07_eca5f983:

    # "A stone came out of the pack from somewhere and starred the rear window white."
    "人の群れのどこからか石が飛んできて、後部の窓に白い星形のひびを入れた。"

# game/script/ch07.rpy:728
translate japanese ch07_eafe5615:

    # woman "Emily! Clara! God sees you— God sees what you are—"
    woman "Emily！Clara！神は見てるよ――お前が何者か、神は見てるんだ――"

# game/script/ch07.rpy:729
translate japanese ch07_b2df8a5e:

    # "George Bennett walked through all of it with his cuffed hands before him and his eyes on nothing. Upright. Silent."
    "George Bennettは、そのすべての中を歩いていった。手錠をかけられた両手を前に、目は何も見ずに。背筋を伸ばし。黙って。"

# game/script/ch07.rpy:730
translate japanese ch07_719e6866:

    # "Giving them the stillness Samuel himself had given the square. And looking for all the world exactly like the monster they had made of him."
    "Samuel自身が広場に与えたのと同じ静けさを、彼らに与えながら。そしてどこからどう見ても、彼らが彼に仕立て上げた怪物そのものに見えながら。"

# game/script/ch07.rpy:732
translate japanese ch07_4af2c83a:

    # "Lara got the car turned and moving, nosing down through the parting, jeering, howling town."
    "Laraが車の向きを変えて走らせた。割れて、嘲り、吠える町のあいだを、鼻先で押し分けるように下っていった。"

# game/script/ch07.rpy:740
translate japanese ch07_2c71203b:

    # "Samuel stood a moment alone in the churned snow of George Bennett's tidy garden."
    "Samuelはしばらく一人で、George Bennettのきちんとした庭の、踏み荒らされた雪の中に立っていた。"

# game/script/ch07.rpy:741
translate japanese ch07_30a76488:

    # "The trimmed hedges. The cleared path. The order the old man had kept against a world he'd always known was coming for him."
    "刈り込まれた生け垣。雪かきされた小道。いつか自分を捕まえに来るとずっとわかっていた世界に対して、老人が保ってきた秩序。"

# game/script/ch07.rpy:742
translate japanese ch07_2a4330ba:

    # "He felt no triumph in it at all."
    "勝利の気分はまったくなかった。"

# game/script/ch07.rpy:743
translate japanese ch07_d4b4122b:

    # "Only a certainty, cold and total and correct, that he had done everything exactly right."
    "あるのはただ確信だけだった。冷たく、完全で、正しい確信。自分はすべてを寸分たがわず正しくやった、という。"

# game/script/ch07.rpy:744
translate japanese ch07_3bd5da9d:

    # "And under it, quiet and immovable, the sense that something in it was wrong in a way he could not yet find."
    "そしてその下に、静かに、動かしがたく、その中の何かがまだ見つけられないかたちで間違っているという感覚があった。"

# game/script/ch07.rpy:749
translate japanese ch07_7b0987c0:

    # "Behind an upstairs window, a curtain moved."
    "二階の窓の向こうで、カーテンが動いた。"

# game/script/ch07.rpy:750
translate japanese ch07_b6d7117e:

    # "And was still."
    "そして、静かになった。"

translate japanese strings:

    # game/script/ch07.rpy:306
    old "Read the note on her hands."
    new "彼女の手の上のメモを読む。"

    # game/script/ch07.rpy:308
    old "Something at Clara's grave. Look there first."
    new "Claraの墓に何かある。先にそちらを見る。"

    # game/script/ch07.rpy:382
    old "Tell them plainly. Now."
    new "ありのままに伝える。いますぐ。"

    # game/script/ch07.rpy:385
    old "Let Lara speak first."
    new "Laraに先に話させる。"

    # game/script/ch07.rpy:457
    old "\"Not yet.\""
    new "「まだだ」"

    # game/script/ch07.rpy:462
    old "\"Bring him in.\""
    new "「連行する」"

    # game/script/ch07.rpy:518
    old "The men at his shoulder."
    new "彼の肩のまわりの男たち。"

    # game/script/ch07.rpy:520
    old "The church doors."
    new "教会の扉。"

    # game/script/ch07.rpy:522
    old "His voice."
    new "彼の声。"

    # game/script/ch07.rpy:601
    old "Comfort her. Let her take her time."
    new "慰める。ゆっくり話させる。"

    # game/script/ch07.rpy:606
    old "Watch her eyes on the fire."
    new "暖炉を見る彼女の目を見る。"

    # game/script/ch07.rpy:704
    old "His mouth."
    new "彼の口元。"

