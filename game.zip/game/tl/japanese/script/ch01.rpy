# TODO: Translation updated at 2026-10-11 10:23

# game/script/ch01.rpy:12
translate japanese ch01_aae35c2d:

    # "Alice sat at her desk with her chin in her palms."
    "Aliceは机に向かい、両の手のひらに顎をのせていた。"

# game/script/ch01.rpy:13
translate japanese ch01_7e1a6b17:

    # "The wood under her elbows was old and scarred — years of ink, and knife-marks worked into the grain by hands that were not hers."
    "肘の下の木は古く、傷だらけだった。長年のインクの染みと、彼女のものではない手が木目に刻んだナイフの跡。"

# game/script/ch01.rpy:14
translate japanese ch01_0ffc93d3:

    # "It had been her father's desk once, and his father's before that, in a house that had belonged to Bennetts for the better part of a century."
    "かつては父の机で、その前は父の父の机だった。一世紀近くBennett家のものであり続けた家の、机だった。"

# game/script/ch01.rpy:15
translate japanese ch01_b7f1d31a:

    # "Everything in the room had come down to her the same way. She was ten years old, and almost nothing she owned had begun with her."
    "部屋にあるものはどれも、同じようにして彼女のもとへ降りてきた。彼女は十歳で、持ち物のうち彼女から始まったものはほとんどなかった。"

# game/script/ch01.rpy:16
translate japanese ch01_de02c7c4:

    # "A candle burned at her elbow. She tilted her head and watched the draft lean the flame, and the shadows it threw climb the wall and draw back, climb and draw back."
    "肘のそばで蝋燭が燃えていた。彼女は首をかしげ、すきま風が炎を傾けるのを見つめた。炎の投げる影が壁を這いのぼり、退き、また這いのぼり、退いた。"

# game/script/ch01.rpy:17
translate japanese ch01_c26e0e38:

    # "She watched them the way another child might watch television."
    "ほかの子どもがテレビを見るように、彼女はそれを見ていた。"

# game/script/ch01.rpy:19
translate japanese ch01_d3db1293:

    # "From above came hurried footsteps, quick and uneven, and the rise of a woman's voice. Her mother."
    "上の階から、せわしない足音が聞こえた。速く、不揃いな足音。そして高まっていく女の声。母だ。"

# game/script/ch01.rpy:20
translate japanese ch01_5925b3a2:

    # "The words blurred, muffled by the ceiling boards, but Alice caught enough to know what they circled around."
    "言葉は天井板にくぐもってぼやけていたが、何をめぐる話なのか、Aliceにわかる程度には聞き取れた。"

# game/script/ch01.rpy:21
translate japanese ch01_556bec74:

    # "The gathering. Tonight. The day they had been preparing for, whispered about, shaped toward, for years."
    "集い。今夜。何年もかけて備え、ささやき合い、そこへ向けて形づくってきた日。"

# game/script/ch01.rpy:28
translate japanese ch01_627d386c:

    # "Her door cracked open without a knock. Her father entered in three strides, sure and swift, the air shifting with him."
    "ノックもなく扉が細く開いた。父が三歩で入ってきた。確かな、すばやい足取りで。空気が彼とともに動いた。"

# game/script/ch01.rpy:30
translate japanese ch01_7974c5cd:

    # "He knelt by her chair and took her small hands in his rough ones. His eyes searched hers."
    "父は椅子のそばに膝をつき、彼女の小さな手を自分の荒れた手に包んだ。その目が彼女の目を探った。"

# game/script/ch01.rpy:31
translate japanese ch01_5776576c:

    # fa "Are you nervous?"
    fa "緊張しているか？"

# game/script/ch01.rpy:32
translate japanese ch01_8f0547e9:

    # "Alice shook her head, and a small smile crossed her lips — quick, certain, unafraid."
    "Aliceは首を横に振った。唇に小さな笑みがよぎった。すばやく、確かで、恐れのない笑み。"

# game/script/ch01.rpy:33
translate japanese ch01_1611467a:

    # fa "Of course you're not."
    fa "もちろん、していないな。"

# game/script/ch01.rpy:34
translate japanese ch01_a9a3b471:

    # "He patted her hair with the gentle pride of a craftsman inspecting finished work."
    "父は彼女の髪を撫でた。仕上がった品をあらためる職人の、穏やかな誇りをこめて。"

# game/script/ch01.rpy:35
translate japanese ch01_c0ed95cd:

    # fa "You'll do great."
    fa "お前ならうまくやれる。"

# game/script/ch01.rpy:37
translate japanese ch01_471b1215:

    # "The scent of him lingered as he rose: burnt wood, ash, and the faint musk of sweat. He must have set the fireplace alight only minutes ago."
    "父が立ち上がっても、その匂いは残った。焦げた木、灰、かすかな汗のにおい。ほんの数分前に暖炉に火を入れたのだろう。"

# game/script/ch01.rpy:38
translate japanese ch01_2733a66a:

    # "The night was already cold enough to bite, and the sky outside promised rain. When the door closed again, silence folded over her."
    "夜はすでに肌を刺すほど冷え、外の空は雨を約束していた。扉がふたたび閉じると、静けさが彼女を包みこんだ。"

# game/script/ch01.rpy:40
translate japanese ch01_e301e769:

    # "She crossed to the bookcase — her only piece of furniture not steeped in history. New wood, sharp-edged, bought just for her."
    "彼女は本棚へ向かった。彼女の家具のなかで唯一、歴史に浸かっていないもの。新しい木で、角が鋭く、彼女のためだけに買われたもの。"

# game/script/ch01.rpy:41
translate japanese ch01_d3a0eeb7:

    # "World history volumes, comparative studies of religion, calligraphy textbooks, a Bible, math and science manuals — all far ahead of what most children her age would touch."
    "世界史の全集、宗教の比較研究、書道の教本、聖書、数学と理科の手引き。どれも、同じ年頃の子どもがふつう手に取るものよりはるかに先を行っていた。"

# game/script/ch01.rpy:42
translate japanese ch01_46561ab7:

    # "Education was not encouraged in that house so much as enforced."
    "あの家では、教育は奨励されるというより、強制されるものだった。"

# game/script/ch01.rpy:43
translate japanese ch01_29f35d49:

    # "On the lower shelf, softer bindings: {i}Moby-Dick{/i}, {i}Anna Karenina{/i}, {i}Pride and Prejudice{/i}. That last one had been a particular torment."
    "下の段には、もっと柔らかな装丁の本があった。{i}『白鯨』{/i}、{i}『アンナ・カレーニナ』{/i}、{i}『高慢と偏見』{/i}。最後の一冊はとりわけ苦痛だった。"

# game/script/ch01.rpy:44
translate japanese ch01_9700ba94:

    # "She would lose herself within a few pages, the story dissolving into fog. In her private, unflinching judgment, she hated it."
    "数ページで迷子になり、物語は霧のように溶けていった。誰にも明かさない、容赦のない彼女自身の判定では、彼女はその本を憎んでいた。"

# game/script/ch01.rpy:45
translate japanese ch01_1e2398f8:

    # "From the back of the shelf she drew out the worn spine of her favorite: {i}The Adventures of Tom Sawyer{/i}. Of all those bindings, this one truly belonged to her."
    "棚の奥から、彼女はいちばん好きな本のすり切れた背を引き出した。{i}『トム・ソーヤーの冒険』{/i}。並んだ本のうち、これだけが本当に彼女のものだった。"

# game/script/ch01.rpy:46
translate japanese ch01_17d6e089:

    # "She carried it to the bed, curled against the quilt, and let herself sink into its pages."
    "彼女はそれをベッドへ運び、キルトに身を丸めて、ページの中へ沈んでいった。"

# game/script/ch01.rpy:49
translate japanese ch01_dc98324e:

    # "She had barely read a handful before the hinges creaked again. Her mother stepped inside, a smile stretched wide — kind, yet tight with nerves."
    "ほんの数ページ読んだところで、また蝶番がきしんだ。母が入ってきた。大きく引き伸ばした笑み。優しく、けれど緊張に張りつめていた。"

# game/script/ch01.rpy:50
translate japanese ch01_869aa938:

    # mo "Darling, I brought you your clothes for tonight. Best to get dressed soon."
    mo "あなた、今夜の服を持ってきたわ。早めに着替えておきなさい。"

# game/script/ch01.rpy:51
translate japanese ch01_68411465:

    # mo "Your grandpa will take you to the church, so behave, okay?"
    mo "おじいさまが教会へ連れていってくださるから、お行儀よくなさい。いいわね？"

# game/script/ch01.rpy:52
translate japanese ch01_a085cd0c:

    # "Alice nodded without question. Her parents always had things to attend to, but tonight was different."
    "Aliceは何も問わずにうなずいた。両親にはいつも何かしら用事があった。けれど今夜は違った。"

# game/script/ch01.rpy:53
translate japanese ch01_96a839cb:

    # "This was the night of her initiation. Ten years old, and at last ready. A blessing for her family. Only good things could follow."
    "今夜は彼女の入信の夜だった。十歳になり、ついに準備が整った。家族にとっての祝福。あとには良いことしか続かないはずだった。"

# game/script/ch01.rpy:54
translate japanese ch01_656c0730:

    # "She lingered with Tom Sawyer a little longer, letting the words soften the weight pressing at the edges of her thoughts. Then she rose and began to dress."
    "彼女はもう少しだけトム・ソーヤーのそばにとどまり、思考の縁を押してくる重みを言葉にやわらげてもらった。それから立ち上がり、着替えはじめた。"

# game/script/ch01.rpy:56
translate japanese ch01_d210e326:

    # "A girl her age might need her mother's hands to brush her hair, straighten the seams. But Alice was not like other girls."
    "この年頃の女の子なら、髪を梳かし、縫い目を整えてくれる母の手が要るかもしれない。けれどAliceはほかの女の子とは違った。"

# game/script/ch01.rpy:57
translate japanese ch01_224ed5c6:

    # "Each button closed with precision. Each ribbon tied to perfection."
    "ボタンはひとつずつ正確に留められた。リボンはひとつずつ完璧に結ばれた。"

# game/script/ch01.rpy:58
translate japanese ch01_72889d4f:

    # "Halfway through, she heard her parents' voices below — brief farewells at the threshold. The front door shut, their steps fading into the cold night."
    "半分ほど済んだところで、階下から両親の声が聞こえた。戸口での短い別れの言葉。玄関の扉が閉まり、二人の足音は冷たい夜へ遠ざかっていった。"

# game/script/ch01.rpy:63
translate japanese ch01_79af5ff5:

    # "The living room was dim, lit mostly by the restless blaze in the fireplace. Her grandfather stood near the flames, a cigarette between his fingers."
    "居間は薄暗く、明かりはほとんど暖炉の落ち着きのない炎だけだった。祖父は炎のそばに立ち、指に煙草を挟んでいた。"

# game/script/ch01.rpy:64
translate japanese ch01_529bc9df:

    # "Both he and her father smoked indoors. So many of the books she'd been made to read called such a thing shameful. The irony struck her again, and she grinned."
    "祖父も父も、家の中で煙草を吸った。読まされてきた本の多くは、そういうことを恥ずべき行いだとしていた。その皮肉にまた気づいて、彼女はにやりとした。"

# game/script/ch01.rpy:66
translate japanese ch01_ac041bb7:

    # "He was tall, broad-shouldered, the strength of his frame still evident despite his years. He split his own wood, still hunted when he could."
    "背が高く、肩幅が広く、歳を重ねてもなおその体格の力強さははっきりしていた。薪は自分で割り、機会があればいまも狩りに出た。"

# game/script/ch01.rpy:67
translate japanese ch01_267d449a:

    # "A gray stubble roughened his jaw, and the crown of his head shone faintly where time had thinned the hair away."
    "灰色の無精ひげが顎を粗くし、時が髪を薄くした頭頂がかすかに光っていた。"

# game/script/ch01.rpy:69
translate japanese ch01_10f5658e:

    # ay "I'm ready."
    ay "準備できたよ。"

# game/script/ch01.rpy:70
translate japanese ch01_7db0f2b4:

    # "Her grandfather drew one last, deep breath and flicked the cigarette into the fire. He turned to her with a kind smile, eyes soft."
    "祖父は最後に深く一服し、煙草を火の中へはじき入れた。それから優しい笑みを浮かべて彼女に向き直った。目が和らいでいた。"

# game/script/ch01.rpy:71
translate japanese ch01_0adf1d5b:

    # g soft "You look wonderful."
    g soft "きれいだな。"

# game/script/ch01.rpy:72
translate japanese ch01_c28bb31b:

    # ay "I want to be perfect for tonight."
    ay "今夜は、完璧でいたいの。"

# game/script/ch01.rpy:73
translate japanese ch01_73ce5e3c:

    # g "You are perfect. Don't worry."
    g "お前は完璧だ。心配するな。"

# game/script/ch01.rpy:74
translate japanese ch01_8c58c488:

    # "She tilted her head, glancing toward the window."
    "彼女は首をかしげ、窓のほうへ目をやった。"

# game/script/ch01.rpy:75
translate japanese ch01_c8d3edc9:

    # ay "So... is it time already?"
    ay "じゃあ……もう時間？"

# game/script/ch01.rpy:76
translate japanese ch01_e12ef2c7:

    # g "Not quite. We'll take a walk first. It'll take the edge off."
    g "まだだ。先に少し歩こう。気が楽になる。"

# game/script/ch01.rpy:77
translate japanese ch01_397ceda0:

    # "Alice nodded. He was right. A walk might help. The knot in her chest eased, just a little."
    "Aliceはうなずいた。そのとおりだ。歩けば楽になるかもしれない。胸の結び目が、ほんの少しほどけた。"

# game/script/ch01.rpy:82
translate japanese ch01_0f3a1023:

    # "Outside, the evening was sharp and wet, the kind of coastal chill that sank quickly into the bones. After only a few steps George slowed."
    "外の夕暮れは鋭く湿っていた。すぐに骨まで染みこむ、海辺の冷え。数歩進んだだけで、Georgeは足をゆるめた。"

# game/script/ch01.rpy:84
translate japanese ch01_7e8f926d:

    # g "This weather isn't for walking. Come on — we'll take the truck instead."
    g "歩く天気じゃないな。来い。トラックで行こう。"

# game/script/ch01.rpy:91
translate japanese ch01_988dc12e:

    # "The family owned only one car, George's old pickup. The Bennetts rarely left Driftwood Bay."
    "一家の車は一台きり、Georgeの古いピックアップだけだった。Bennett家の者がDriftwood Bayを出ることはめったになかった。"

# game/script/ch01.rpy:92
translate japanese ch01_06b97c30:

    # "Its leather seats were polished, kept clean to the point of reverence. She remembered him scolding her father for treating it carelessly, and smirked as she climbed in."
    "革のシートは磨かれ、崇めるほどに清潔に保たれていた。父の扱いが雑だと祖父が叱っていたのを思い出し、彼女は乗りこみながら薄く笑った。"

# game/script/ch01.rpy:93
translate japanese ch01_e7fa8311:

    # "Errands, berry-picking in the forested hills — that was the extent of her world. But tonight they weren't heading toward the coast, nor the village square."
    "使い走りと、森の丘での木いちご摘み。それが彼女の世界のすべてだった。けれど今夜、二人は海岸へも、村の広場へも向かっていなかった。"

# game/script/ch01.rpy:94
translate japanese ch01_898c29aa:

    # "George steered them past the edges of town, into the pale stretches beyond."
    "Georgeは町の外れを過ぎ、その先の白っぽく広がる土地へと車を進めた。"

# game/script/ch01.rpy:96
translate japanese ch01_c25b81d8:

    # ay "Grandpa?"
    ay "おじいちゃん？"

# game/script/ch01.rpy:97
translate japanese ch01_60d8437f:

    # "He didn't answer. His smile, so steady moments ago, faltered."
    "祖父は答えなかった。さっきまであれほど揺るがなかった笑みが、崩れた。"

# game/script/ch01.rpy:98
translate japanese ch01_e16a9a2e:

    # ay "Where are we going? What about tonight — the ceremony?"
    ay "どこへ行くの？　今夜は……儀式は？"

# game/script/ch01.rpy:99
translate japanese ch01_9f6adfbf:

    # "Still silence. Only the engine and the wheels on wet gravel."
    "なおも沈黙。聞こえるのはエンジンと、濡れた砂利を踏む車輪の音だけ。"

# game/script/ch01.rpy:103
translate japanese ch01_0072d856:

    # ay "Grandpa. The gathering is {i}tonight{/i}."
    ay "おじいちゃん。集いは{i}今夜{/i}だよ。"

# game/script/ch01.rpy:104
translate japanese ch01_439f112c:

    # "His hands tightened on the wheel. That was all the answer she got."
    "ハンドルを握る手に力がこもった。返ってきた答えはそれだけだった。"

# game/script/ch01.rpy:106
translate japanese ch01_7b526095:

    # "She folded her hands in her lap the way she had been taught, and said nothing, and watched."
    "彼女は教えられたとおりに膝の上で手を組み、何も言わず、見ていた。"

# game/script/ch01.rpy:108
translate japanese ch01_05097200:

    # "She lifted her eyes to the rearview mirror. For a heartbeat their gazes locked."
    "彼女はバックミラーへ目を上げた。一瞬、二人の視線が絡んだ。"

# game/script/ch01.rpy:109
translate japanese ch01_aac964a1:

    # "His looked heavy, uncertain, shadowed with something she had never seen before."
    "祖父の目は重く、迷い、彼女が一度も見たことのない何かに翳っていた。"

# game/script/ch01.rpy:113
translate japanese ch01_c0755fe2:

    # "A few miles down the road the truck gave a sharp rattle, then sputtered." with vpunch
    "数マイル走ったところで、トラックが鋭くがたつき、咳きこんだ。" with vpunch

# game/script/ch01.rpy:114
translate japanese ch01_07c6dc68:

    # g "Damn it."
    g "くそっ。"

# game/script/ch01.rpy:115
translate japanese ch01_937931d8:

    # "He eased onto the shoulder and sat a moment with both hands on the wheel, looking at the dark ahead. Then he made himself smile."
    "祖父は路肩に車を寄せ、両手をハンドルに置いたまま、しばらく前方の暗がりを見ていた。それから無理に笑ってみせた。"

# game/script/ch01.rpy:116
translate japanese ch01_72a0287e:

    # g "Nothing to worry about. We've run dry, that's all. Station's not far — we'll walk it."
    g "心配いらん。ガス欠だ、それだけだ。スタンドは遠くない。歩いていこう。"

# game/script/ch01.rpy:124
translate japanese ch01_b3e276b5:

    # g "Don't worry. The station isn't far."
    g "心配するな。スタンドは遠くない。"

# game/script/ch01.rpy:125
translate japanese ch01_05c2add6:

    # "The walk, though unexpected, had its charms. Waves crashed far below the cliff line, gulls wheeled wide arcs across the horizon."
    "思いがけない散歩だったが、それなりの魅力があった。崖の連なりのはるか下で波が砕け、カモメが水平線をよぎって大きな弧を描いていた。"

# game/script/ch01.rpy:126
translate japanese ch01_5589096b:

    # "The last of the sun spilled gold and violet through the thickening clouds."
    "沈みかけた日の名残が、厚みを増していく雲のあいだから金と紫をこぼしていた。"

# game/script/ch01.rpy:130
translate japanese ch01_71caa83d:

    # "After several minutes the low neon glow of a gas station came into view. Quiet, almost deserted."
    "数分歩くと、ガソリンスタンドのネオンのほの暗い光が見えてきた。静かで、ほとんど人気がなかった。"

# game/script/ch01.rpy:131
translate japanese ch01_5c00f659:

    # g "Go on, have a stroll. I'll fetch us some fuel."
    g "そのへんを歩いてこい。燃料を取ってくる。"

# game/script/ch01.rpy:133
translate japanese ch01_44f57ecb:

    # "She drifted across the cracked pavement. Six pumps, a narrow shop front, a squat row of toilets to the side."
    "彼女はひび割れた舗装の上をぶらぶらと横切った。給油機が六台、細い店構え、脇にはずんぐりと並んだトイレ。"

# game/script/ch01.rpy:134
translate japanese ch01_727f196c:

    # "Further back, at the edge of the lot, the remains of an old barrier — iron bars long rusted, some bent, others snapped off and jutting from the earth."
    "さらに奥、敷地の端には古い柵の残骸があった。とうに錆びた鉄の棒。曲がったものもあれば、折れて地面から突き出しているものもあった。"

# game/script/ch01.rpy:135
translate japanese ch01_beb19c03:

    # "They had been set there once to keep people back from the cliff. Broken now, they kept no one from anything."
    "かつては人を崖から遠ざけるために立てられたものだった。いまは壊れ、誰を何から遠ざけることもなかった。"

# game/script/ch01.rpy:144
translate japanese ch01_b4e72171:

    # "Alice went to the gap in the rail and looked over."
    "Aliceは柵の切れ目まで行き、下をのぞきこんだ。"

# game/script/ch01.rpy:145
translate japanese ch01_f1495826:

    # "The drop fell a long way to the water, and the wind came up it cold against her face."
    "崖は水面まで長く落ちこみ、そこを吹き上がってくる風が冷たく顔に当たった。"

# game/script/ch01.rpy:149
translate japanese ch01_dfce63f5:

    # "She took one small step back. Not from fear. Only because it seemed the proper thing to do."
    "彼女は小さく一歩、後ろへ下がった。怖かったからではない。そうするのがふさわしいように思えたからにすぎない。"

# game/script/ch01.rpy:150
translate japanese ch01_cff62777:

    # "The rocks stayed where they were, far below, patient."
    "岩ははるか下の、もとの場所にあった。辛抱強く。"

# game/script/ch01.rpy:152
translate japanese ch01_a633b0bd:

    # "She leaned the smallest bit further, the toes of her Mary Janes at the very lip of the earth."
    "彼女はほんのわずか、さらに身を乗り出した。メリー・ジェーンのつま先が、大地のまさに縁にかかった。"

# game/script/ch01.rpy:153
translate japanese ch01_79aac4e0:

    # "The sea broke white on the rocks and drew back, broke and drew back, and she watched it the way she had watched the candle."
    "海は岩に白く砕けては退き、砕けては退いた。彼女はそれを、蝋燭を見ていたのと同じように見ていた。"

# game/script/ch01.rpy:158
translate japanese ch01_9f6cb163:

    # "She stood a while at the broken edge, looking down at the rocks, until George called her name."
    "彼女はしばらく壊れた縁に立ち、下の岩を見下ろしていた。Georgeが名前を呼ぶまで。"

# game/script/ch01.rpy:159
translate japanese ch01_3ece28f8:

    # g "Alice, we're ready — let's go."
    g "Alice、済んだぞ。行こう。"

# game/script/ch01.rpy:160
translate japanese ch01_d38c458b:

    # "She turned and went back."
    "彼女は振り返り、戻っていった。"

# game/script/ch01.rpy:167
translate japanese ch01_5c76d3c4:

    # "The way back proved more tiring. After only a few minutes Alice winced, muttering that her feet hurt."
    "帰り道のほうがこたえた。ほんの数分でAliceは顔をしかめ、足が痛いとつぶやいた。"

# game/script/ch01.rpy:168
translate japanese ch01_e767b915:

    # "Shiny black Mary Janes with stiff straps and small bows — made for appearances, not distance. Every step turned into a small torment."
    "硬いストラップと小さなリボンのついた、つやのある黒いメリー・ジェーン。見栄えのための靴で、長い道のりのためのものではなかった。一歩ごとに、小さな責め苦になった。"

# game/script/ch01.rpy:169
translate japanese ch01_0fb68bcf:

    # g "Alright. We'll take a quick break."
    g "わかった。少し休もう。"

# game/script/ch01.rpy:170
translate japanese ch01_f03b3286:

    # "They stood in silence until headlights appeared down the road."
    "道の先にヘッドライトが現れるまで、二人は黙って立っていた。"

# game/script/ch01.rpy:172
translate japanese ch01_b261fea0:

    # "Alice spotted the car first, then saw the hesitation flicker across George's face before he masked it with another smile. He raised his hand."
    "先に車に気づいたのはAliceだった。それから、Georgeの顔にためらいがよぎり、また別の笑みでそれを覆い隠すのを見た。祖父は手を挙げた。"

# game/script/ch01.rpy:173
translate japanese ch01_4bbc50ca:

    # "She pressed close against him, clutching his free hand. She had scarcely seen anyone from outside Driftwood Bay in her life."
    "彼女は祖父にぴったりと身を寄せ、空いているほうの手を握りしめた。Driftwood Bayの外の人間を、彼女は生まれてこのかたほとんど見たことがなかった。"

# game/script/ch01.rpy:174
translate japanese ch01_b9448a88:

    # "Behind the glass, a woman at the wheel. She seemed anxious too, her hands gripping the wheel a little too tightly."
    "ガラスの向こう、ハンドルを握っているのは女だった。その女も不安げに見えた。ハンドルを握る手に、少し力が入りすぎていた。"

# game/script/ch01.rpy:175
translate japanese ch01_ec917290:

    # ath "Maybe she's going to the ceremony."
    ath "あの人も、儀式に行くのかもしれない。"

# game/script/ch01.rpy:176
translate japanese ch01_b7ef39a4:

    # "Then she dismissed it. Why would she?"
    "それから、その考えを打ち消した。どうして行くはずがある？"

# game/script/ch01.rpy:178
translate japanese ch01_1874f6d1:

    # "George did the talking, his tone courteous, practiced. After a pause, the woman nodded, and they climbed inside."
    "話をしたのはGeorgeだった。礼儀正しく、慣れた口調で。少し間があって、女はうなずき、二人は乗りこんだ。"

# game/script/ch01.rpy:186
translate japanese ch01_ec187b22:

    # "The ride was quiet, heavy with unease. George kept smiling, polite, steady. Alice said nothing."
    "車内は静かで、落ち着かない空気が重く垂れこめていた。Georgeは笑みを絶やさなかった。礼儀正しく、揺るがずに。Aliceは何も言わなかった。"

# game/script/ch01.rpy:187
translate japanese ch01_9784f2b0:

    # "She watched the woman instead — the set of her jaw, the tension in her shoulders, the cut of her clothes."
    "かわりに彼女は女を観察した。顎の構え、肩の強張り、服の仕立て。"

# game/script/ch01.rpy:188
translate japanese ch01_a89b01cc:

    # ath "She must be from the big town. She looks... different."
    ath "大きな町の人なんだ。なんだか……違って見える。"

# game/script/ch01.rpy:189
translate japanese ch01_bd14cf41:

    # g "That's us."
    g "ここだ。"

# game/script/ch01.rpy:190
translate japanese ch01_67c7b5aa:

    # "The car slowed. George leaned briefly toward the windshield with a few words of thanks, and the woman drove away, taillights fading into the night."
    "車が速度を落とした。Georgeはフロントガラスのほうへわずかに身を乗り出して短く礼を言い、女は走り去った。テールライトが夜の中へ薄れていった。"

# game/script/ch01.rpy:197
translate japanese ch01_951ded00:

    # "The truck coughed, then roared back to life, and they continued on."
    "トラックは咳きこみ、それから唸りをあげて息を吹き返し、二人はまた走り出した。"

# game/script/ch01.rpy:198
translate japanese ch01_216d86a8:

    # "Night fell quickly. George never stopped driving, at least not while Alice remained awake."
    "夜はすぐに落ちた。Georgeは一度も車を止めなかった。少なくとも、Aliceが起きているあいだは。"

# game/script/ch01.rpy:199
translate japanese ch01_3592099f:

    # "She pressed her forehead to the cool glass, lulled by the hum of the engine and the endless dark unfurling outside."
    "彼女は冷たいガラスに額を押しつけ、エンジンの唸りと、外に果てしなく広がっていく闇にあやされていた。"

# game/script/ch01.rpy:200
translate japanese ch01_2a4af23f:

    # "Hunger gnawed at her, the kind that dulled thought and made her limbs heavy."
    "空腹が彼女を蝕んだ。考えを鈍らせ、手足を重くする種類の空腹だった。"

# game/script/ch01.rpy:201
translate japanese ch01_c1545503:

    # "The ceremony, the gathering — those ideas blurred at the edges, slipping further away as exhaustion pressed down."
    "儀式、集い。そうした考えは縁からぼやけ、疲れがのしかかるにつれて、さらに遠くへ滑り落ちていった。"

# game/script/ch01.rpy:206
translate japanese ch01_e5c9f0ca:

    # "When at last morning light spilled across her face, Alice stirred."
    "ようやく朝の光が顔に差したとき、Aliceは身じろぎした。"

# game/script/ch01.rpy:207
translate japanese ch01_91c265cc:

    # "The road clung to the side of a mountain, the drop at its edge dizzying, endless. She recoiled, crawling to the other side of the cab." with hpunch
    "道は山の斜面にしがみつき、その縁の落差は目がくらむほど、果てしなかった。彼女はたじろぎ、運転席の反対側へ這って移った。" with hpunch

# game/script/ch01.rpy:208
translate japanese ch01_f483ee13:

    # "George laughed softly."
    "Georgeが小さく笑った。"

# game/script/ch01.rpy:209
translate japanese ch01_c428053b:

    # g soft "It's alright. Everything's fine. Soon we'll be at our new home."
    g soft "大丈夫だ。何も心配ない。もうすぐ新しい家に着く。"

# game/script/ch01.rpy:210
translate japanese ch01_ac95c4c8:

    # "And so it was. By the time the sun climbed higher, they were winding into a small mountain town."
    "そのとおりになった。日が高くのぼるころには、二人は小さな山あいの町へと曲がりくねった道を下りていた。"

# game/script/ch01.rpy:213
translate japanese ch01_f02780fd:

    # "The days that followed blurred together. Alice asked questions, of course — about the ceremony, about her parents, about why they had come here instead."
    "それからの日々は、混ざり合ってぼやけた。Aliceはもちろん問いかけた。儀式のこと、両親のこと、なぜかわりにここへ来たのか。"

# game/script/ch01.rpy:214
translate japanese ch01_ca39749a:

    # "George's answers were vague but always warm. Enough to quiet her doubts, if not erase them."
    "Georgeの答えは曖昧だったが、いつも温かかった。疑いを消し去りはしなくとも、黙らせるには足りた。"

# game/script/ch01.rpy:215
translate japanese ch01_6ab2b2f7:

    # "Weeks passed. Alice enrolled in a new school. She found friends, pieced together routines. George's busy hands turned to repairs and small jobs around town."
    "数週間が過ぎた。Aliceは新しい学校に入った。友だちができ、日々の決まりごとを少しずつ組み立てた。Georgeの忙しい手は、町のあちこちの修理や小さな仕事に向かった。"

# game/script/ch01.rpy:216
translate japanese ch01_7bea18ab:

    # "As the months drifted by, the questions she once carried began to fade. Rare now, softer, less urgent."
    "月日が流れるにつれ、かつて抱えていた問いは薄れていった。いまではまれに、柔らかく、急ぐこともなく浮かぶだけになった。"

# game/script/ch01.rpy:219
translate japanese ch01_556f3328:

    # "Life seemed to settle with them."
    "暮らしは、二人とともに落ち着いていくように見えた。"

# game/script/ch01.rpy:220
translate japanese ch01_96995eb1:

    # "But some nights, when Alice woke in the dark, she still wondered if her parents were waiting for her, somewhere..."
    "けれどときおり、暗闇で目を覚ました夜には、Aliceはいまも考えた。両親はどこかで、自分を待っているのではないか……"

# game/script/ch01.rpy:221
translate japanese ch01_b579e466:

    # extend " to finish what they had begun."
    extend "始めたことを、終わらせるために。"

translate japanese strings:

    # game/script/ch01.rpy:102
    old "Ask him again."
    new "もう一度たずねる。"

    # game/script/ch01.rpy:105
    old "Stay quiet and watch him."
    new "黙って、祖父を見ている。"

    # game/script/ch01.rpy:148
    old "Step back from the edge."
    new "縁から一歩下がる。"

    # game/script/ch01.rpy:151
    old "Look a little longer."
    new "もう少しだけ見ている。"

