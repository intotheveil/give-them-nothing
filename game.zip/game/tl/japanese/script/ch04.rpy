# TODO: Translation updated at 2026-10-11 10:23

# game/script/ch04.rpy:13
translate japanese ch04_d48f941a:

    # "Three days later, just after one, Samuel pushed open the door to his hotel room with a stack of folders under his arm."
    "三日後、一時を少し回った頃、Samuelはフォルダーの束を脇に抱えてホテルの部屋のドアを押し開けた。"

# game/script/ch04.rpy:14
translate japanese ch04_a6dc144e:

    # "The reports felt heavier than their weight: autopsy sheets, lab results, witness statements that said nothing. He let them drop onto the desk, black ink on white fanning across the wood."
    "報告書は目方以上に重く感じられた。検死記録、鑑識の結果、何も語らない目撃証言。彼はそれを机に落とした。白地に黒のインクが木の天板に扇のように広がった。"

# game/script/ch04.rpy:15
translate japanese ch04_3cb51bd3:

    # "He shrugged out of his coat and stood a moment, rubbing the bridge of his nose. His eyes were red-ringed from long hours and too little sleep."
    "彼はコートを脱ぎ、しばらく立ったまま鼻梁を揉んだ。長時間の仕事と足りない睡眠で、目の縁が赤くなっていた。"

# game/script/ch04.rpy:16
translate japanese ch04_952718df:

    # "The cigarette box on the table was already half-empty, a silent tally of his nerves."
    "テーブルの煙草の箱はもう半分空だった。神経のすり減りを黙って数える目盛りだった。"

# game/script/ch04.rpy:17
translate japanese ch04_8a568198:

    # "The toxicology report lay on top. Patrick Hensley. Cause of death: ingestion of {i}Taxus baccata{/i}. Yew alkaloids. No doubt."
    "一番上に毒物検査の報告書があった。Patrick Hensley。死因、{i}Taxus baccata{/i}の摂取。イチイのアルカロイド。疑いの余地はない。"

# game/script/ch04.rpy:18
translate japanese ch04_b70bdbb3:

    # "Poison strong enough to stop a heart within minutes. And the manner of ingestion? Coffee, almost certainly. He'd swallowed death with his morning ritual."
    "数分で心臓を止めるほどの毒。摂取の経路は？　コーヒー、ほぼ間違いない。彼は毎朝の習慣と一緒に死を飲み下したのだ。"

# game/script/ch04.rpy:21
translate japanese ch04_e087e2fd:

    # note_voice "Hensley — yew alkaloids (Taxus baccata). In the coffee."
    note_voice "Hensley――イチイのアルカロイド（Taxus baccata）。コーヒーに混入。"

# game/script/ch04.rpy:23
translate japanese ch04_acfb69b5:

    # "Beside it, Maria's file. No poison, no substance. Just the fall, the fractures, the cranial trauma. {i}Suicide{/i}, the medical examiner had typed."
    "その隣にMariaのファイル。毒物なし、薬物なし。転落、骨折、頭蓋の外傷だけ。{i}自殺{/i}と検死官はタイプしていた。"

# game/script/ch04.rpy:24
translate japanese ch04_37e01535:

    # "But with the USB message Samuel now carried in evidence, he knew better. She hadn't jumped from despair. She'd been driven."
    "だが、いま証拠として手元にあるUSBのメッセージがある以上、Samuelには分かっていた。彼女は絶望から飛び降りたのではない。追い込まれたのだ。"

# game/script/ch04.rpy:25
translate japanese ch04_4281cf77:

    # "The phone analysis came back clean. No hidden files, no deleted texts, no photographs. Family chatter, the tutoring group, that six-second call from Steve Collins."
    "携帯電話の解析結果は何も出なかった。隠しファイルも、削除されたメッセージも、写真もない。家族とのやりとり、補習のグループ、Steve Collinsからのあの六秒の通話。"

# game/script/ch04.rpy:26
translate japanese ch04_abfdbd70:

    # "No CCTV at the shop, either. The cameras had been out for weeks, no money to fix them."
    "店の防犯カメラもなかった。カメラは何週間も前から壊れていて、直す金がなかった。"

# game/script/ch04.rpy:27
translate japanese ch04_c30596c5:

    # "Witness reports? Worthless. A few locals had seen Hensley last, buying cigarettes or grumbling over bread deliveries. Everyone agreed: nothing unusual. Normal."
    "目撃証言は？　役に立たない。町の者が何人か、最後にHensleyを見ていた。煙草を買っていたとか、パンの配達に文句を言っていたとか。誰もが同じことを言った。変わったことはなかった。普通だった。"

# game/script/ch04.rpy:28
translate japanese ch04_96fbc406:

    # th "Normal."
    th "普通、か。"

# game/script/ch04.rpy:29
translate japanese ch04_ec24a959:

    # "Two bodies in two days. Both carrying a mark of judgment: Maria cornered with words, Patrick left with a single word by his corpse."
    "二日で死体が二つ。どちらにも裁きの印があった。Mariaは言葉で追い詰められ、Patrickは死体の傍らに一語だけを残された。"

# game/script/ch04.rpy:30
translate japanese ch04_15cc8254:

    # "He leaned forward, elbows on his knees, rubbing his dry, raw hands together. His breath came steady, but tight, as if each inhale fought against the room itself."
    "彼は膝に肘をついて前屈みになり、乾いて荒れた両手をこすり合わせた。呼吸は一定だったが、窮屈だった。吸うたびに部屋そのものと争っているかのようだった。"

# game/script/ch04.rpy:36
translate japanese ch04_1caf6144:

    # "He was at the desk, a second cup of coffee cooling beside him, when the phone buzzed. Mercer's name lit the screen."
    "二杯目のコーヒーを傍らで冷ましながら机に向かっていたとき、電話が震えた。画面にMercerの名前が灯った。"

# game/script/ch04.rpy:39
translate japanese ch04_28cb586f:

    # s "Harris."
    s "Harrisだ。"

# game/script/ch04.rpy:40
translate japanese ch04_21635c42:

    # m shaken "Detective... We've got another body. A student this time."
    m shaken "刑事……また死体です。今度は生徒です。"

# game/script/ch04.rpy:41
translate japanese ch04_2b8c222d:

    # "Behind Mercer's voice: muffled chatter, the occasional sharp command. Samuel's shoulders stiffened."
    "Mercerの声の向こうに、くぐもったざわめきと、ときおり鋭い指示の声。Samuelの肩がこわばった。"

# game/script/ch04.rpy:42
translate japanese ch04_ad6f3432:

    # s shocked "Go on."
    s shocked "続けろ。"

# game/script/ch04.rpy:43
translate japanese ch04_96e2a1a3:

    # m shaken "Gym class had just finished. Four girls went to the locker room to change. They found her there. Wrists slit, still in uniform."
    m shaken "体育の授業が終わったところでした。女子が四人、着替えに更衣室へ行った。そこで見つけたんです。手首を切って、体操着のままで。"

# game/script/ch04.rpy:44
translate japanese ch04_cdd1202b:

    # m shaken "They screamed. The rest of the class rushed in, the teacher too. Whole wing was in chaos before we arrived."
    m shaken "四人が悲鳴を上げて、クラスの残りが駆け込んできた。教師もです。俺たちが着いたときには、棟全体が大混乱でした。"

# game/script/ch04.rpy:45
translate japanese ch04_e07e3b8e:

    # "Samuel set his cup down. The porcelain clinked."
    "Samuelはカップを置いた。磁器が小さく鳴った。"

# game/script/ch04.rpy:46
translate japanese ch04_3646999c:

    # s "And now?"
    s "それで、今は？"

# game/script/ch04.rpy:47
translate japanese ch04_c65ab350:

    # m neutral "Under control. We've cleared the area. The locker room's locked down. The body hasn't been touched."
    m neutral "落ち着きました。周辺は人払いしてあります。更衣室は封鎖済み。遺体には誰も触れていません。"

# game/script/ch04.rpy:48
translate japanese ch04_16ced624:

    # m neutral "The four who found her, we've separated them in the counselor's office with an officer watching. They're shaken to hell, but stable."
    m neutral "見つけた四人は、カウンセラー室に分けて入れて、巡査を一人つけてあります。ひどく動揺してますが、落ち着いてはいます。"

# game/script/ch04.rpy:49
translate japanese ch04_dcfcec0f:

    # s "What about the rest of the students?"
    s "他の生徒は？"

# game/script/ch04.rpy:50
translate japanese ch04_5fbd5f04:

    # m neutral "We dismissed them. Sent them home. Headmaster's keeping it as quiet as possible, but word's already spreading through town."
    m neutral "解散させました。家に帰しました。校長はできるだけ伏せておこうとしてますが、噂はもう町じゅうに広がり始めてます。"

# game/script/ch04.rpy:51
translate japanese ch04_d041ffff:

    # "A pause. Samuel could hear his own breath against the phone."
    "間があった。Samuelには、受話器に当たる自分の息が聞こえた。"

# game/script/ch04.rpy:52
translate japanese ch04_987ce0e7:

    # m shaken "Detective... you should see this one yourself."
    m shaken "刑事……これは、自分の目で見たほうがいい。"

# game/script/ch04.rpy:53
translate japanese ch04_c30de929:

    # s "Keep the scene sealed. I'll be there in ten."
    s "現場は封鎖したままにしておけ。十分で行く。"

# game/script/ch04.rpy:54
translate japanese ch04_191e87df:

    # m neutral "Understood."
    m neutral "了解です。"

# game/script/ch04.rpy:56
translate japanese ch04_eca995c9:

    # "He drained the last of his coffee, bitter against his tongue, and was already pulling his coat from the chair."
    "彼は残りのコーヒーを飲み干した。舌に苦かった。そのときにはもう、椅子からコートを引き寄せていた。"

# game/script/ch04.rpy:60
translate japanese ch04_64723cb9:

    # "On the drive over, Mercer's words kept coming back. {i}A student this time.{/i}"
    "車を走らせるあいだ、Mercerの言葉が何度も戻ってきた。{i}今度は生徒です。{/i}"

# game/script/ch04.rpy:61
translate japanese ch04_56ccbf83:

    # "Somewhere between one light and the next, the word {i}student{/i} thinned toward a smaller one he would not let himself finish."
    "信号と信号のあいだのどこかで、{i}生徒{/i}という言葉は痩せていき、もっと小さな言葉へと向かった。彼は自分にその言葉を最後まで言わせなかった。"

# game/script/ch04.rpy:62
translate japanese ch04_50d25396:

    # "He kept his eyes on the road and drove, and did not finish it."
    "彼は道路から目を離さずに運転し、最後まで言わなかった。"

# game/script/ch04.rpy:72
translate japanese ch04_f54afbf5:

    # "By the time he pulled into the school lot his face was stone again."
    "学校の駐車場に車を入れる頃には、彼の顔はまた石に戻っていた。"

# game/script/ch04.rpy:73
translate japanese ch04_086759ab:

    # "Clusters of teenagers lingered by the gates, eyes darting to the cordon. A few craned their necks for a glimpse inside. Rumor already ran faster than any official word."
    "十代の生徒たちがいくつもの塊になって門のあたりにたむろし、規制線のほうへ視線を走らせていた。中を一目見ようと首を伸ばす者もいた。噂はもう、どんな公式発表よりも速く走っていた。"

# game/script/ch04.rpy:78
translate japanese ch04_976ff443:

    # "Samuel ignored them and cut straight to Officer Lara Whitfield, waiting just inside the entrance, her face set but pale."
    "Samuelは彼らを無視し、まっすぐLara Whitfield巡査のもとへ向かった。彼女は入口のすぐ内側で待っていた。表情は引き締まっていたが、青ざめていた。"

# game/script/ch04.rpy:79
translate japanese ch04_236fc55b:

    # l "Detective."
    l "刑事。"

# game/script/ch04.rpy:80
translate japanese ch04_08a27d54:

    # s "Let's see her."
    s "彼女を見せてくれ。"

# game/script/ch04.rpy:81
translate japanese ch04_3236d0aa:

    # "They moved quickly through the halls. The building smelled of cleaning fluid and too many coats drying on hooks."
    "二人は足早に廊下を進んだ。建物には洗剤の匂いと、フックで乾かされている多すぎるコートの匂いがこもっていた。"

# game/script/ch04.rpy:82
translate japanese ch04_2cbfcc30:

    # l stern "Victim's name is Clara Ward. Fifteen. Teachers say she struggled. Kept to herself, withdrawn. Self-harm scars on her arms. Had been sent to the counselor more than once."
    l stern "被害者の名前はClara Ward。十五歳。教師たちによれば、苦しんでいたそうです。人と関わらず、引きこもりがちで。腕に自傷の痕があります。何度もカウンセラーのところへ送られていました。"

# game/script/ch04.rpy:83
translate japanese ch04_9f8a0f7d:

    # "Samuel's jaw ticked."
    "Samuelの顎がぴくりと動いた。"

# game/script/ch04.rpy:84
translate japanese ch04_c1ff2c0c:

    # l stern "Home life's unstable. Parents fight constantly. Money problems too. Neighbors have filed a few noise complaints in the past."
    l stern "家庭は不安定です。両親はしょっちゅう喧嘩をしていて、お金の問題もあります。過去に近所から何度か騒音の苦情が出ています。"

# game/script/ch04.rpy:85
translate japanese ch04_5d6cac77:

    # "They stopped before the locker room doors, an officer standing guard. Lara pushed the door open."
    "二人は更衣室の扉の前で立ち止まった。巡査が一人、見張りに立っていた。Laraが扉を押し開けた。"

# game/script/ch04.rpy:90
translate japanese ch04_42098760:

    # "Inside, the room was heavy with silence, broken only by the hum of fluorescent lights."
    "中は重い沈黙に満ちていた。それを破るのは蛍光灯の唸りだけだった。"

# game/script/ch04.rpy:91
translate japanese ch04_d4e66469:

    # "The smell of blood pushed at every breath."
    "血の匂いが、息をするたびに押し寄せた。"

# game/script/ch04.rpy:92
translate japanese ch04_66e85f01:

    # "She sat against the far wall, still in her gym uniform. Her arms lay slack and pale at her sides. Two razors glinted faintly at her feet."
    "彼女は奥の壁にもたれて座っていた。体操着のままだった。両腕は脇にだらりと垂れ、白かった。足もとで剃刀が二本、かすかに光っていた。"

# game/script/ch04.rpy:93
translate japanese ch04_b1103313:

    # "Samuel steadied himself and crouched lower."
    "Samuelは気を落ち着け、さらに低くしゃがんだ。"

# game/script/ch04.rpy:95
translate japanese ch04_d46a49ac:

    # s "Lara. Get those razors collected. Both of them. Bag each separately, and don't smudge the blades."
    s "Lara。あの剃刀を回収してくれ。二本ともだ。一本ずつ別に袋に入れて、刃には触れないように。"

# game/script/ch04.rpy:96
translate japanese ch04_0cbb063e:

    # s "I want swabs taken from the handles, and photographs before you touch a thing. We need to know if anyone else ever held them."
    s "柄からは拭き取りの検体を。何かに触れる前に写真も。ほかに誰かが握ったことがあるかどうか、知る必要がある。"

# game/script/ch04.rpy:97
translate japanese ch04_b4121268:

    # l neutral "Yes, Detective."
    l neutral "はい、刑事。"

# game/script/ch04.rpy:98
translate japanese ch04_abb6f8d2:

    # "She signaled the officer on guard, who stepped in with gloves and an evidence kit. Samuel wrote, the words tight and economical."
    "彼女が見張りの巡査に合図すると、巡査は手袋と証拠採取キットを手に入ってきた。Samuelは書いた。言葉は短く、無駄がなかった。"

# game/script/ch04.rpy:100
translate japanese ch04_f7c8ad06:

    # note_voice "Body seated, wall support. Bilateral lacerations. Razors present."
    note_voice "遺体、座位、壁に寄りかかる。両側の切創。剃刀あり。"

# game/script/ch04.rpy:101
translate japanese ch04_93d8fccb:

    # "His eyes shifted to the bench, where Clara's schoolbag slouched open, notebooks fanned like wings."
    "彼の目はベンチへ移った。Claraの通学鞄が口を開けてくたりと置かれ、ノートが翼のように広がっていた。"

# game/script/ch04.rpy:102
translate japanese ch04_aeda9f16:

    # s "Bag the entire pack, untouched. We'll inventory at the station."
    s "鞄ごと袋に入れてくれ、手を付けずに。中身の確認は署でやる。"

# game/script/ch04.rpy:103
translate japanese ch04_654cc9a9:

    # l "Yes, sir."
    l "はい。"

# game/script/ch04.rpy:104
translate japanese ch04_fa00898e:

    # s "And check her locker. I want every item catalogued. Clothes, books, scraps of paper, whatever she kept in there. Photograph the locker before you move a thing."
    s "それと彼女のロッカーを調べてくれ。一つ残らず目録にしたい。服、本、紙切れ、あの中にしまってあったものは何でも。何かを動かす前にロッカーの写真を撮ること。"

# game/script/ch04.rpy:105
translate japanese ch04_f37678d9:

    # l stern "Understood."
    l stern "了解しました。"

# game/script/ch04.rpy:106
translate japanese ch04_9d234552:

    # "His gaze swept the tiles: small scattered belongings, a water bottle tipped on its side, the smudge of a shoe where one of the girls must have stumbled back in shock."
    "彼の視線がタイルの上を掃いた。散らばった小さな持ち物、横倒しになった水筒、少女の一人がショックで後ずさりしてよろめいたのだろう靴の跡。"

# game/script/ch04.rpy:107
translate japanese ch04_76480e76:

    # s "Get prints from the door handles, inside and out. And the bench surface. If anyone planted something, we'll know."
    s "扉の取っ手から指紋を採ってくれ。内側も外側も。それとベンチの表面も。誰かが何かを仕込んだなら、それで分かる。"

# game/script/ch04.rpy:108
translate japanese ch04_6857ec77:

    # "He glanced once more at the girl against the wall. A part of him wanted to look away. He didn't."
    "彼はもう一度、壁際の少女に目をやった。目を逸らしたいと思う自分がいた。彼は逸らさなかった。"

# game/script/ch04.rpy:109
translate japanese ch04_6b461d24:

    # s "And when that's done, we'll speak to the girls who found her."
    s "それが済んだら、彼女を見つけた子たちに話を聞く。"

# game/script/ch04.rpy:117
translate japanese ch04_fb0cba41:

    # "His shoes echoed down the corridor. Voices grew louder as he neared the counselor's office."
    "廊下に彼の靴音が響いた。カウンセラー室に近づくにつれ、声が大きくなった。"

# game/script/ch04.rpy:119
translate japanese ch04_dace17a7:

    # "Mercer stood at the door, hands lifted in a gesture meant to reassure. Four sets of parents and relatives pressed around him."
    "Mercerが戸口に立ち、なだめるつもりの仕草で両手を上げていた。四組の親や身内が彼を取り囲んで詰め寄っていた。"

# game/script/ch04.rpy:120
translate japanese ch04_f6cf7eef:

    # vo "They've been through enough—"
    vo "あの子たちはもう十分つらい思いをしたんだ――"

# game/script/ch04.rpy:121
translate japanese ch04_bcd6bf1f:

    # woman "She's only a child, you can't keep them locked up like this—"
    woman "まだ子供なのよ、こんなふうに閉じ込めておくなんて――"

# game/script/ch04.rpy:122
translate japanese ch04_4d1da04b:

    # vo "Traumatized, that's what this is! She needs rest, not questions—"
    vo "トラウマだよ、これは！　あの子に要るのは休息だ、質問じゃない――"

# game/script/ch04.rpy:123
translate japanese ch04_1ac8ae46:

    # m shaken "We just need a statement from each of them, nothing more. Please, I promise—"
    m shaken "一人ずつ供述をもらうだけです、それ以上は何も。お願いします、約束しますから――"

# game/script/ch04.rpy:124
translate japanese ch04_f3222dd8:

    # "Samuel stepped up, his coat brushing the doorway. His presence drew silence quicker than Mercer's words had."
    "Samuelが進み出た。コートが戸口をかすめた。彼がそこにいるだけで、Mercerの言葉よりも早く沈黙が生まれた。"

# game/script/ch04.rpy:125
translate japanese ch04_0ea12061:

    # s "It won't take long. Ten minutes with each girl, and then they go home. But we need to know what they saw. Without that, we have nothing."
    s "長くはかかりません。一人十分ずつ、それで帰れます。ですが、あの子たちが何を見たのかを知る必要がある。それがなければ、我々には何もない。"

# game/script/ch04.rpy:127
translate japanese ch04_2936c8ad:

    # "Reluctant nods. Mutters. No one argued further. Mercer exhaled in relief."
    "渋々の頷き。ぶつぶつと言う声。それ以上異を唱える者はいなかった。Mercerは安堵の息を吐いた。"

# game/script/ch04.rpy:131
translate japanese ch04_d084aedc:

    # "Inside the first room, a girl sat curled in the chair, feet barely reaching the floor. Twelve or so, a braid come loose, the hem of one sleeve worried to a fray."
    "最初の部屋では、少女が椅子の上で身を丸めていた。足がやっと床に届くくらいだった。十二歳ほど、三つ編みがほどけかけ、片方の袖口はいじられてほつれていた。"

# game/script/ch04.rpy:132
translate japanese ch04_a6eecef2:

    # "Chloe Harper, by Mercer's list. Samuel drew up a chair, sat below her eye line, and left the notebook shut."
    "Mercerのリストによれば、Chloe Harper。Samuelは椅子を引き寄せ、彼女の目線より低く座り、手帳は閉じたままにした。"

# game/script/ch04.rpy:133
translate japanese ch04_7b3ea8d0:

    # s "Chloe. I'm Detective Harris. Just tell me what happened, in your own words. Take your time."
    s "Chloe。私はHarris刑事だ。何があったのか、自分の言葉で話してくれればいい。ゆっくりでいいから。"

# game/script/ch04.rpy:134
translate japanese ch04_be8b2d66:

    # chloe "We went in to change after gym. We didn't know anyone was there."
    chloe "体育のあと、着替えに入ったの。誰かいるなんて知らなかった。"

# game/script/ch04.rpy:135
translate japanese ch04_edbb01b9:

    # chloe "She was just... against the wall. There was so much blood."
    chloe "あの人、ただ……壁にもたれてて。血がいっぱいで。"

# game/script/ch04.rpy:136
translate japanese ch04_d495392f:

    # "It came in pieces, around the crying. He let her get the whole of it out, then asked, easy, whether she'd seen anything else in the room. Anything wrong, apart from the blood."
    "話は泣き声の合間に切れ切れに出てきた。彼は全部を吐き出させてから、穏やかに尋ねた。部屋でほかに何か見なかったか。血のほかに、何かおかしなものは。"

# game/script/ch04.rpy:137
translate japanese ch04_b1f43d68:

    # "She shook her head into her sleeve."
    "彼女は袖に顔を埋めたまま首を振った。"

# game/script/ch04.rpy:138
translate japanese ch04_4627a8f3:

    # s "Did you know the girl?"
    s "その子を知っていたかい？"

# game/script/ch04.rpy:139
translate japanese ch04_6c18d470:

    # chloe "No. She was older. Upper classes. I didn't know her."
    chloe "ううん。年上だったから。上の学年。知らない人。"

# game/script/ch04.rpy:140
translate japanese ch04_2c181be6:

    # s "That's enough. You did well."
    s "もう十分だ。よく頑張ったね。"

# game/script/ch04.rpy:141
translate japanese ch04_f980339c:

    # "Whatever had happened in that locker room, the small ones had carried nothing out of it but the sight. He'd known that before he sat down."
    "あの更衣室で何が起きたにせよ、小さな子たちがそこから持ち出したのは光景だけだった。座る前から、彼にはそれが分かっていた。"

# game/script/ch04.rpy:142
translate japanese ch04_6fb9f6db:

    # "He'd sat down anyway, because the one who mattered was at the end of the hall, and you did not walk in on that one first."
    "それでも座ったのは、肝心の一人が廊下の突き当たりにいたからだ。そういう相手のところへ、いきなり最初に踏み込むものではない。"

# game/script/ch04.rpy:148
translate japanese ch04_22bce4d8:

    # "The next room. The counselor gave him a nod and withdrew."
    "次の部屋。カウンセラーが彼に頷いて、退いた。"

# game/script/ch04.rpy:150
translate japanese ch04_8519037e:

    # "Emily Carter sat straight-backed, hands folded, cheeks streaked but her breathing level. Held, almost practiced. Fragile, not broken."
    "Emily Carterは背筋を伸ばして座り、両手を組んでいた。頬には涙の筋があったが、呼吸は整っていた。抑えられていた。ほとんど練習したように。脆いが、壊れてはいない。"

# game/script/ch04.rpy:151
translate japanese ch04_ee5b348e:

    # s "Emily Carter? I'm Detective Harris."
    s "Emily Carterだね？　私はHarris刑事だ。"

# game/script/ch04.rpy:152
translate japanese ch04_3bc55ced:

    # "She nodded, eyes wet but direct."
    "彼女は頷いた。目は濡れていたが、まっすぐだった。"

# game/script/ch04.rpy:153
translate japanese ch04_51e38cfc:

    # s "You're older than the others."
    s "君はほかの子より年上だね。"

# game/script/ch04.rpy:154
translate japanese ch04_69af1f9c:

    # e worried "Fourteen."
    e worried "十四です。"

# game/script/ch04.rpy:155
translate japanese ch04_820b8455:

    # "He took in the skirt and sweater, every button aligned. Not gym clothes."
    "彼はスカートとセーターを見て取った。ボタンはひとつ残らず揃っている。体操着ではない。"

# game/script/ch04.rpy:156
translate japanese ch04_5c29db76:

    # s "You weren't in the class."
    s "君はその授業には出ていなかった。"

# game/script/ch04.rpy:157
translate japanese ch04_5ae1a268:

    # e worried "I had a quiz. Finished early. I went to find Alice. She's my best friend."
    e worried "小テストがあって。早く終わったから、Aliceを探しに行ったんです。私の親友なの。"

# game/script/ch04.rpy:158
translate japanese ch04_47d1cbc0:

    # e worried "She was in gym, so I waited, and walked back with her and the others when they were done."
    e worried "Aliceは体育だったから待ってて、終わってから、Aliceとほかの子たちと一緒に戻ったんです。"

# game/script/ch04.rpy:159
translate japanese ch04_c53285ed:

    # "The sadness ran through every word, but it stayed in tune."
    "悲しみはどの言葉にも流れていたが、音程は外れていなかった。"

# game/script/ch04.rpy:168
translate japanese ch04_de8d5e98:

    # "She was holding something back for later. Not a fact. A request, and she hadn't decided yet whether he was the one to ask."
    "彼女は何かを後のために取っておいていた。事実ではない。頼みごとだ。そして、それを頼む相手が彼でいいのか、まだ決めかねていた。"

# game/script/ch04.rpy:169
translate japanese ch04_f3933dac:

    # s "Did you know the girl who was found?"
    s "見つかった子のことは知っていたかい？"

# game/script/ch04.rpy:170
translate japanese ch04_e93a85c3:

    # e sad "Not really. I'd seen her. She was older. Once or twice I was with Alice when she had counseling, and Clara was there too."
    e sad "よくは知らないです。見かけたことはあって。年上だったし。Aliceのカウンセリングについて行ったことが一、二回あって、そこにClaraもいたんです。"

# game/script/ch04.rpy:171
translate japanese ch04_3c9ddc6a:

    # e sad "But I didn't know her. Not the way Alice did."
    e sad "でも、知り合いってほどじゃなかった。Aliceみたいには。"

# game/script/ch04.rpy:172
translate japanese ch04_6268bf2a:

    # e cry "I wish I had. Maybe then I'd understand why—"
    e cry "知ってたらよかった。そうしたら、どうしてなのか分かったかもしれないのに――"

# game/script/ch04.rpy:173
translate japanese ch04_fe3cfc33:

    # "She caught it and looked down."
    "彼女は言葉を呑み込み、うつむいた。"

# game/script/ch04.rpy:174
translate japanese ch04_245677e2:

    # s "Thank you, Emily. That's enough."
    s "ありがとう、Emily。もう十分だ。"

# game/script/ch04.rpy:175
translate japanese ch04_d683eb51:

    # "She hesitated, then raised her eyes, wide and earnest."
    "彼女はためらい、それから目を上げた。大きく見開かれた、真剣な目だった。"

# game/script/ch04.rpy:176
translate japanese ch04_bed2c278:

    # e cry "Detective? Please... don't think badly of her. She must have been hurting so much. People forget that. They just say ugly things."
    e cry "刑事さん？　お願い……あの人のこと、悪く思わないで。きっと、すごく苦しかったんです。みんなそれを忘れちゃう。ひどいことばっかり言って。"

# game/script/ch04.rpy:177
translate japanese ch04_66ddc5dd:

    # s "I won't forget."
    s "忘れないよ。"

# game/script/ch04.rpy:179
translate japanese ch04_7e29e163:

    # "Something eased in her shoulders, as if she'd carried that one request all afternoon and had only now found somewhere to set it down."
    "彼女の肩から何かがほどけた。その一つの頼みを午後じゅう抱えてきて、ようやく下ろせる場所を見つけたかのようだった。"

# game/script/ch04.rpy:186
translate japanese ch04_9dd9a03a:

    # "The last door. Alice Bennett, twelve. Emily's best friend, tied close to the dead girl."
    "最後の扉。Alice Bennett、十二歳。Emilyの親友で、死んだ少女と近しかった。"

# game/script/ch04.rpy:188
translate japanese ch04_63963e7d:

    # th "The bike racks. The girl who'd looked past me."
    th "自転車置き場。俺の向こうを見ていた少女。"

# game/script/ch04.rpy:189
translate japanese ch04_51651e39:

    # th "Tread carefully."
    th "慎重にいけ。"

# game/script/ch04.rpy:191
translate japanese ch04_14b0ed5b:

    # "She sat straight in the chair, hands folded, chin a shade raised. No tears, no tremor."
    "彼女は椅子にまっすぐ座っていた。両手を組み、顎をわずかに上げて。涙もなく、震えもない。"

# game/script/ch04.rpy:192
translate japanese ch04_8ee10449:

    # "Not the blankness of shock. Something quieter, and more finished than that."
    "ショックによる虚ろさではなかった。もっと静かで、もっと完成された何かだった。"

# game/script/ch04.rpy:193
translate japanese ch04_3b62b65f:

    # "Samuel took the seat across from her and left the notebook closed on his knee."
    "Samuelは向かいの椅子に腰を下ろし、手帳は膝の上で閉じたままにした。"

# game/script/ch04.rpy:194
translate japanese ch04_223475d3:

    # s "Alice. I'm Detective Harris. This won't take long."
    s "Alice。私はHarris刑事だ。長くはかからない。"

# game/script/ch04.rpy:195
translate japanese ch04_d71102e8:

    # "The smallest nod."
    "ごく小さな頷き。"

# game/script/ch04.rpy:196
translate japanese ch04_1e15c453:

    # s "You and Emily were together when it happened?"
    s "あれが起きたとき、君とEmilyは一緒だったのかな？"

# game/script/ch04.rpy:197
translate japanese ch04_c1c4c546:

    # a neutral "Yes. We had gym. Emily finished a quiz early, came to find me. We went to the locker room with Chloe and Sophie."
    a neutral "はい。私たちは体育でした。Emilyは小テストが早く終わって、私を探しに来ました。ChloeとSophieと一緒に更衣室へ行きました。"

# game/script/ch04.rpy:198
translate japanese ch04_f7a0d4a5:

    # s "Did you know the girl you found?"
    s "見つけた子のことは知っていたかい？"

# game/script/ch04.rpy:199
translate japanese ch04_c2272bea:

    # a neutral "Yes. I knew her. She was a friend of mine."
    a neutral "はい。知っていました。私の友達でした。"

# game/script/ch04.rpy:200
translate japanese ch04_a9d3cf19:

    # s "A friend? She was older than you. How did that come about? Were your parents friends?"
    s "友達？　君より年上だった。どうして知り合ったんだい？　ご両親同士が親しかったとか？"

# game/script/ch04.rpy:201
translate japanese ch04_a395757a:

    # "Alice's lips curled. Not a smile; the shape of one, sharp at the edge."
    "Aliceの唇が歪んだ。笑みではない。笑みの形をしたもので、縁が鋭かった。"

# game/script/ch04.rpy:202
translate japanese ch04_05988921:

    # a neutral "I haven't seen my parents for two years."
    a neutral "両親とは、もう二年会っていません。"

# game/script/ch04.rpy:203
translate japanese ch04_a4fc1eb5:

    # "The room went quiet."
    "部屋が静まり返った。"

# game/script/ch04.rpy:204
translate japanese ch04_f07febef:

    # a neutral "I moved here with my grandfather. George."
    a neutral "祖父とここへ越してきました。Georgeです。"

# game/script/ch04.rpy:205
translate japanese ch04_5dbaef09:

    # s "Ah. Apologies, I didn't know."
    s "ああ。すまない、知らなかった。"

# game/script/ch04.rpy:206
translate japanese ch04_99e64816:

    # "He gave her a little of himself, the way you do to take the weight off a room."
    "彼は自分のことを少しだけ差し出した。部屋の重さを和らげるときに、人がそうするように。"

# game/script/ch04.rpy:207
translate japanese ch04_14fcfdcb:

    # s "I'm new here too. Still finding my way."
    s "私もここへは来たばかりでね。まだ勝手が分からない。"

# game/script/ch04.rpy:208
translate japanese ch04_690c848c:

    # "She gave him nothing back. No twitch at the mouth, no shift in the eyes. She broke the silence herself."
    "彼女は何も返さなかった。口もとの引きつりもなく、目の動きもない。沈黙を破ったのは彼女のほうだった。"

# game/script/ch04.rpy:209
translate japanese ch04_7e716bd2:

    # a neutral "Clara had problems, Detective."
    a neutral "Claraには問題がありました、刑事さん。"

# game/script/ch04.rpy:210
translate japanese ch04_c1b59bad:

    # s "What kind?"
    s "どんな？"

# game/script/ch04.rpy:211
translate japanese ch04_5b82a8d2:

    # a neutral "People talked. Schoolmates. They called her names, pointed at the obvious, never looked under it. That's how it is here."
    a neutral "みんなが噂していました。学校の子たちが。あだ名で呼んで、見ればわかることばかり指さして、その下は決して見ようとしなかった。ここではそういうものなんです。"

# game/script/ch04.rpy:212
translate japanese ch04_7651f755:

    # "Her eyes didn't leave his."
    "彼女の目は彼から離れなかった。"

# game/script/ch04.rpy:213
translate japanese ch04_5fdc2a6a:

    # a neutral "It's a small town. Everyone learns your flaws—if you're poor, if your family's broken—and turns them into names. Into whispers that follow you everywhere."
    a neutral "小さな町ですから。誰もがあなたの欠点を知るんです――貧乏かどうか、家族が壊れているかどうか――そして、それをあだ名にする。どこへ行ってもついてくる囁きにするんです。"

# game/script/ch04.rpy:214
translate japanese ch04_46aad722:

    # a neutral "Clara carried all of it. For years."
    a neutral "Claraはそれを全部背負っていました。何年も。"

# game/script/ch04.rpy:215
translate japanese ch04_a1fc35bb:

    # s "Years."
    s "何年も。"

# game/script/ch04.rpy:216
translate japanese ch04_581da814:

    # a neutral "Years."
    a neutral "何年も。"

# game/script/ch04.rpy:217
translate japanese ch04_5fd5cbbb:

    # "He let it sit."
    "彼はその言葉を置いたままにした。"

# game/script/ch04.rpy:218
translate japanese ch04_02bcd3b3:

    # s "You say {i}flaws{/i} like it means something. Like it's more than schoolyard talk."
    s "君は{i}欠点{/i}という言葉を、何か意味があるように言うね。校庭の陰口以上のものみたいに。"

# game/script/ch04.rpy:219
translate japanese ch04_6643e3d5:

    # a neutral "In my family, flaws weren't tolerated. If you lied. If you were weak. If you pretended to be something you weren't. There were consequences."
    a neutral "私の家では、欠点は許されませんでした。嘘をついたら。弱かったら。自分ではないものの振りをしたら。報いがありました。"

# game/script/ch04.rpy:220
translate japanese ch04_f518fb76:

    # s "Consequences."
    s "報い。"

# game/script/ch04.rpy:221
translate japanese ch04_d5724819:

    # a neutral "That's how I was taught. That's how it still is. Weakness, dishonesty, hypocrisy—it all shows, in the end."
    a neutral "私はそう教わりました。今もそうです。弱さも、不誠実も、偽善も――最後には、全部表に出るんです。"

# game/script/ch04.rpy:222
translate japanese ch04_ade1157f:

    # a neutral "And when it shows, it has to be corrected."
    a neutral "そして表に出たら、矯正されなければならない。"

# game/script/ch04.rpy:223
translate japanese ch04_242806bb:

    # "Her hands folded tighter."
    "彼女の組んだ手に力がこもった。"

# game/script/ch04.rpy:224
translate japanese ch04_4db705bd:

    # a neutral "My grandfather believes the same. George. He says people are judged by what they carry, not what they pretend to be."
    a neutral "祖父も同じことを信じています。Georgeは。人は何の振りをしているかではなく、何を背負っているかで裁かれる、と言っています。"

# game/script/ch04.rpy:225
translate japanese ch04_b6d9055f:

    # a neutral "That's how it works. That's how it should work."
    a neutral "そういうものなんです。そうあるべきなんです。"

# game/script/ch04.rpy:226
translate japanese ch04_2b3fd5ba:

    # "When she said his name there was something in her mouth that sat very close to pride."
    "祖父の名を口にしたとき、彼女の口の中には、誇りにごく近い何かがあった。"

# game/script/ch04.rpy:227
translate japanese ch04_54f575e0:

    # s "That's a hard way to see the world, Alice."
    s "それは厳しい世界の見方だね、Alice。"

# game/script/ch04.rpy:228
translate japanese ch04_a21b79b8:

    # "The corner of her mouth moved. Not a smile; something between defiance and dismissal."
    "彼女の口の端が動いた。笑みではない。反抗と一蹴のあいだにある何か。"

# game/script/ch04.rpy:229
translate japanese ch04_10ad0491:

    # a neutral "I don't know, Detective. I'm just a kid. Doing as I'm told."
    a neutral "さあ、どうでしょう、刑事さん。私はただの子供です。言われたとおりにしているだけ。"

# game/script/ch04.rpy:232
translate japanese ch04_63b5c8f3:

    # note_voice "Alice Bennett, 12 — lives with grandfather George. 'Flaws have to be corrected.'"
    note_voice "Alice Bennett、12歳――祖父Georgeと同居。「欠点は矯正されなければならない」"

# game/script/ch04.rpy:237
translate japanese ch04_d03c37b3:

    # ev "Where is she? Where is my daughter?!"
    ev "どこなの？　娘はどこ！？"

# game/script/ch04.rpy:238
translate japanese ch04_72e586c5:

    # "A woman's scream tore through the wall, raw, dragging every ear toward it. The words broke into sobs and climbed again."
    "女の悲鳴が壁を突き破った。生々しく、あらゆる耳を引き寄せた。言葉は嗚咽に崩れ、また高く昇っていった。"

# game/script/ch04.rpy:239
translate japanese ch04_e21f2036:

    # ev "Let me see her! Where is my Clara?!"
    ev "会わせて！　私のClaraはどこなの！？"

# game/script/ch04.rpy:240
translate japanese ch04_1abce9d4:

    # "Samuel kept his face still and his hands where they lay."
    "Samuelは表情を動かさず、手も置いたままにした。"

# game/script/ch04.rpy:244
translate japanese ch04_123cedac:

    # "The corridor tangled beyond it: the mother's wail, a man's lower rumble, Mercer's calm stretched thin."
    "その向こうで廊下がもつれ合っていた。母親の泣き叫ぶ声、男の低い唸り、張りつめたMercerの落ち着いた声。"

# game/script/ch04.rpy:245
translate japanese ch04_637a795f:

    # "He counted the voices the way he'd been trained to. Three. Four. Somebody struck the wall with a flat hand."
    "彼は訓練されたとおりに声を数えた。三つ。四つ。誰かが平手で壁を打った。"

# game/script/ch04.rpy:250
translate japanese ch04_501a87c3:

    # "Across from him, Alice had turned toward the door. Not flinching. Not startled."
    "向かいで、Aliceは扉のほうへ顔を向けていた。たじろいではいない。驚いてもいない。"

# game/script/ch04.rpy:251
translate japanese ch04_f7b3a8b3:

    # "Her head tilted, as though she were studying the sound instead of recoiling from it."
    "首を傾げていた。その音から身を引くのではなく、観察しているかのように。"

# game/script/ch04.rpy:252
translate japanese ch04_039fb637:

    # th "Shock. Kids go strange in shock. They freeze, they go far away."
    th "ショックだ。子供はショックでおかしくなる。固まるか、どこか遠くへ行ってしまう。"

# game/script/ch04.rpy:253
translate japanese ch04_f1e8e76a:

    # "He filed it there, and let it lie."
    "彼はそれをそこに分類し、そのままにしておいた。"

# game/script/ch04.rpy:255
translate japanese ch04_a5ae3043:

    # "Then Lara's voice, flat and certain, cut through."
    "そのとき、Laraの声が、平板で揺るぎなく、割って入った。"

# game/script/ch04.rpy:256
translate japanese ch04_2035229e:

    # l "Enough. Come with me. This isn't the place."
    l "もう十分です。一緒に来てください。ここはそういう場所ではありません。"

# game/script/ch04.rpy:257
translate japanese ch04_63ac09c1:

    # "By inches it dragged down into sobs and moved off, and left its echo behind like smoke."
    "少しずつ、それは嗚咽へと沈んで遠ざかり、煙のように残響だけを残していった。"

# game/script/ch04.rpy:258
translate japanese ch04_5b798655:

    # "The counselor put her head in."
    "カウンセラーが顔をのぞかせた。"

# game/script/ch04.rpy:259
translate japanese ch04_3a78ddbf:

    # vo "Detective, the girls. They've been through enough. Can they go?"
    vo "刑事さん、あの子たち。もう十分つらい思いをしました。帰してもいいですか？"

# game/script/ch04.rpy:260
translate japanese ch04_bf9bdd8b:

    # s "Yes."
    s "ええ。"

# game/script/ch04.rpy:261
translate japanese ch04_ae989782:

    # s "Except her. I need a little more."
    s "この子以外は。もう少し聞きたいことがある。"

# game/script/ch04.rpy:263
translate japanese ch04_a22fcc7c:

    # "Alice looked from the door back to him, smooth, unhurried, as if she'd been waiting for exactly that. The door clicked shut."
    "Aliceは扉から彼へと視線を戻した。滑らかに、急がずに。まるでまさにそれを待っていたかのように。扉がかちりと閉まった。"

# game/script/ch04.rpy:264
translate japanese ch04_7fea76d9:

    # a neutral "Those people screaming. Were they the parents?"
    a neutral "叫んでいた人たち。あれはご両親ですか？"

# game/script/ch04.rpy:265
translate japanese ch04_057e9d93:

    # s "Yes. I understand their grief."
    s "ああ。あの人たちの悲しみは分かる。"

# game/script/ch04.rpy:266
translate japanese ch04_dd262fad:

    # "Her brows drew together, the first true shift in her since he'd sat down."
    "彼女の眉が寄った。彼が座って以来、彼女に起きた最初の本物の変化だった。"

# game/script/ch04.rpy:267
translate japanese ch04_79dca581:

    # a angry "How can you?"
    a angry "どうして分かるんですか？"

# game/script/ch04.rpy:268
translate japanese ch04_7c5e5270:

    # "Sharp, near accusing, as if she'd caught him at a lie."
    "鋭く、ほとんど責めるような声だった。嘘を見抜いたとでもいうように。"

# game/script/ch04.rpy:269
translate japanese ch04_549c1299:

    # s "Because I've stood where they're standing."
    s "私も、あの人たちと同じ場所に立ったことがあるからだ。"

# game/script/ch04.rpy:270
translate japanese ch04_2a1e236b:

    # "No softening, no weight laid on it. A plain stone dropped into the quiet."
    "和らげもせず、重みを乗せもしない。静けさの中に落とされた、ただの石。"

# game/script/ch04.rpy:272
translate japanese ch04_77432ba1:

    # "Her face eased."
    "彼女の顔が緩んだ。"

# game/script/ch04.rpy:273
translate japanese ch04_674308e3:

    # a neutral "I see."
    a neutral "そうですか。"

# game/script/ch04.rpy:275
translate japanese ch04_64477b58:

    # "And then, almost lightly, a quick smile with something mischievous in its curve."
    "それから、ほとんど軽やかに、素早い笑み。その曲線には悪戯めいたものがあった。"

# game/script/ch04.rpy:276
translate japanese ch04_243ebe21:

    # a smile "You know, I don't think the psychologist will help you. But Clara kept a diary."
    a smile "あの、心理士の先生はたぶん役に立たないと思います。でも、Claraは日記をつけていました。"

# game/script/ch04.rpy:277
translate japanese ch04_6d7aa9bf:

    # a smile "Her parents don't know. I do. She told me once. Under her mattress."
    a smile "ご両親は知りません。私は知っています。一度教えてくれたんです。マットレスの下です。"

# game/script/ch04.rpy:278
translate japanese ch04_f8961af8:

    # "His pen moved."
    "彼のペンが動いた。"

# game/script/ch04.rpy:280
translate japanese ch04_12b94ab0:

    # note_voice "Diary under the mattress (per Alice)."
    note_voice "日記はマットレスの下（Aliceの証言）。"

# game/script/ch04.rpy:281
translate japanese ch04_7932f8d1:

    # s "Thank you, Alice. That's useful."
    s "ありがとう、Alice。役に立つよ。"

# game/script/ch04.rpy:282
translate japanese ch04_283753f8:

    # "The smile stayed a moment, pleased at his approval."
    "笑みはしばらく残っていた。彼に認められたことを喜んでいた。"

# game/script/ch04.rpy:284
translate japanese ch04_1c7c466d:

    # "Then it folded away as her hands folded back into her lap, and the composure closed over her again."
    "やがてそれは、膝の上に組み直される両手とともに畳まれ、落ち着きが再び彼女を覆って閉じた。"

# game/script/ch04.rpy:285
translate japanese ch04_c03c6f3d:

    # s "Alright. You can go now."
    s "よし。もう行っていいよ。"

# game/script/ch04.rpy:292
translate japanese ch04_3dde6fbc:

    # "He followed her out into the corridor. Emily was waiting with her parents, her face blotched red, tears drying in uneven streaks."
    "彼は彼女に続いて廊下へ出た。Emilyが両親と一緒に待っていた。顔はまだらに赤く、涙が不揃いな筋になって乾きかけていた。"

# game/script/ch04.rpy:295
translate japanese ch04_e4c4aeb2:

    # "The moment she spotted Alice, she broke from her mother's side and rushed forward, arms clinging tight around her friend's waist."
    "Aliceを見つけた瞬間、Emilyは母親のそばを離れて駆け寄り、友達の腰にしっかりとしがみついた。"

# game/script/ch04.rpy:297
translate japanese ch04_918e5243:

    # "Alice didn't stumble. She didn't break. She stood straight, steady."
    "Aliceはよろめかなかった。崩れなかった。まっすぐ、揺るがずに立っていた。"

# game/script/ch04.rpy:298
translate japanese ch04_b4b3998e:

    # "Then she brought up one arm, slowly, deliberately, and laid it across Emily's shoulders."
    "それから片腕を、ゆっくりと、意図して持ち上げ、Emilyの肩に回した。"

# game/script/ch04.rpy:299
translate japanese ch04_6b6cb0c5:

    # "Her face remained calm, unreadable, while Emily's tears soaked into her sweater."
    "Emilyの涙がセーターに染みていくあいだも、彼女の顔は穏やかで、読めないままだった。"

# game/script/ch04.rpy:307
translate japanese ch04_697058f0:

    # "Slowly. Deliberately. An arm laid on the way you'd lay it if you had watched it done, and learned the weight."
    "ゆっくりと。意図して。それを人がするのを見て、その重みを覚えた者が置くような、置き方の腕だった。"

# game/script/ch04.rpy:308
translate japanese ch04_1aa7ffd8:

    # th "She's twelve. Twelve-year-olds learn comfort off television. That's all."
    th "十二歳だ。十二歳の子供は慰め方をテレビで覚える。それだけのことだ。"

# game/script/ch04.rpy:312
translate japanese ch04_901ff878:

    # mrsc "Come on, sweetheart. Come on. Let's get you home."
    mrsc "さあ、おいで。さあ。おうちに帰りましょう。"

# game/script/ch04.rpy:313
translate japanese ch04_ff767d07:

    # "After a few moments Alice released her, and Emily was folded back into her parents' arms. They moved off down the hall, the low hum of their voices shielding their daughter."
    "しばらくしてAliceが腕を解くと、Emilyは両親の腕の中に包み込まれた。一家は廊下を去っていった。低く続く話し声が娘を守っていた。"

# game/script/ch04.rpy:315
translate japanese ch04_65d91413:

    # "Alice stood still a moment, watching them go. Then she turned toward the far end of the corridor."
    "Aliceはしばらくじっと立って、彼らを見送った。それから廊下の向こう端へ向き直った。"

# game/script/ch04.rpy:317
translate japanese ch04_b4ef77ed:

    # "That was when Samuel saw him."
    "そのとき、Samuelは彼を見た。"

# game/script/ch04.rpy:318
translate japanese ch04_84e11ec3:

    # th "George."
    th "George。"

# game/script/ch04.rpy:319
translate japanese ch04_bfc2e8f6:

    # "He stood half in shadow near the corner, his tall frame braced against the wall, arms crossed. Relaxed, yet immovable."
    "彼は角のそばに半ば影に入って立っていた。長身を壁にもたせかけ、腕を組んでいた。くつろいでいながら、微動だにしない。"

# game/script/ch04.rpy:320
translate japanese ch04_dd886de2:

    # "The kind of stillness that drew attention even when it seemed to want none. His eyes were fixed only on Alice as she walked toward him."
    "注目を求めていないように見えて、かえって人目を引く類の静けさだった。彼の目は、近づいてくるAliceだけに注がれていた。"

# game/script/ch04.rpy:322
translate japanese ch04_2f571d4c:

    # "She didn't glance back. She didn't wave to Emily again. She simply walked the hall, each step even, until she reached him."
    "彼女は振り返らなかった。Emilyにもう一度手を振ることもなかった。ただ廊下を歩いた。一歩一歩を等しく刻み、彼のもとにたどり着くまで。"

# game/script/ch04.rpy:323
translate japanese ch04_3584a557:

    # "George pushed off the wall with one shoulder, and with a subtle tilt of his head guided her toward the exit."
    "Georgeは片方の肩で壁を押して身を起こし、首をかすかに傾けて、彼女を出口へと導いた。"

# game/script/ch04.rpy:324
translate japanese ch04_d7d3e11c:

    # "Not once did his eyes turn toward Samuel. Not a flicker of acknowledgment."
    "彼の目は一度もSamuelのほうを向かなかった。認めたという気配すらなかった。"

# game/script/ch04.rpy:328
translate japanese ch04_ddee54fc:

    # "Samuel watched them leave, their footsteps fading into the building's silence."
    "Samuelは二人が去っていくのを見ていた。足音は建物の静けさの中へ消えていった。"

# game/script/ch04.rpy:336
translate japanese ch04_aeee6ccc:

    # "Samuel stepped out into the yard, the cold biting sharper after the cramped corridors. He lit a cigarette and dragged deep until the smoke curled warm through his lungs."
    "Samuelは中庭へ出た。狭い廊下のあとでは、寒さがいっそう鋭く噛みついた。煙草に火をつけ、深く吸い込むと、煙が温かく肺に渦巻いた。"

# game/script/ch04.rpy:337
translate japanese ch04_9cca4739:

    # "Teachers ushered the last curious students home. The school stood quieter now, but the echo of screams still clung to the stone walls."
    "教師たちが最後の野次馬の生徒たちを家へ追い立てていた。校舎はもう静かになっていたが、悲鳴の残響がまだ石の壁にしがみついていた。"

# game/script/ch04.rpy:339
translate japanese ch04_ebbb82c2:

    # "A few minutes later Mercer emerged, shoulders sagging, uniform disheveled. He gave Samuel a look that said more than words, and held out a hand."
    "数分後、Mercerが出てきた。肩を落とし、制服は乱れていた。彼は言葉以上のことを語る目つきでSamuelを見て、手を差し出した。"

# game/script/ch04.rpy:340
translate japanese ch04_93624831:

    # m shaken "Got another one of those?"
    m shaken "一本、もらえますか？"

# game/script/ch04.rpy:342
translate japanese ch04_62a28e49:

    # "Two mornings ago Samuel had dragged him out of bed before six. He looked worse now."
    "二日前の朝、Samuelは彼を六時前にベッドから引きずり出した。今の彼はあのときよりひどい顔をしていた。"

# game/script/ch04.rpy:343
translate japanese ch04_b0236471:

    # "Samuel tapped the pack and slid one free. Mercer cupped it to the lighter and inhaled shakily."
    "Samuelは箱を叩いて一本を滑り出させた。Mercerは両手でライターの火を囲い、震えながら吸い込んだ。"

# game/script/ch04.rpy:344
translate japanese ch04_356906dd:

    # m shaken "I can't handle it today. First time I've ever seen a kid like that. It's... messed up."
    m shaken "今日はもう無理です。子供があんなふうになってるのを見たのは初めてで。あれは……ひどすぎる。"

# game/script/ch04.rpy:345
translate japanese ch04_45cdf20d:

    # s "It is. And I hope you never have to get used to it."
    s "ああ、ひどい。お前がそれに慣れずに済むよう願ってるよ。"

# game/script/ch04.rpy:346
translate japanese ch04_89784bbf:

    # "They stood side by side in silence for a while, smoke curling upward."
    "二人はしばらく黙って並んで立っていた。煙が上へと渦を巻いた。"

# game/script/ch04.rpy:347
translate japanese ch04_0806792f:

    # s "Do you know the Bennetts?"
    s "Bennett家のことは知ってるか？"

# game/script/ch04.rpy:349
translate japanese ch04_206ab806:

    # "Mercer's jaw shifted. His eyes narrowed."
    "Mercerの顎が動いた。目が細められた。"

# game/script/ch04.rpy:350
translate japanese ch04_70bd39cb:

    # m neutral "Yeah. Can't say I like George. He's not from here. Never quite fit. There's something... unsettling about him."
    m neutral "ええ。Georgeは好きになれませんね。よそ者です。ずっと馴染めないまま。なんというか……気味の悪いところがある。"

# game/script/ch04.rpy:351
translate japanese ch04_9f50a5a2:

    # "Samuel said nothing, letting him talk."
    "Samuelは何も言わず、話させておいた。"

# game/script/ch04.rpy:352
translate japanese ch04_d86b0fbd:

    # m neutral "As for his granddaughter, she's just a kid, but... hell, she makes your skin crawl a little. Cold. Doesn't look at you the way other kids do."
    m neutral "孫娘のほうは、まだ子供ですけど……くそ、ちょっと鳥肌が立つんですよ。冷たくて。ほかの子供と同じ目で人を見ないんです。"

# game/script/ch04.rpy:353
translate japanese ch04_6ab556a4:

    # m neutral "But to be fair, they've settled in pretty well. George keeps himself busy. Handyman. Gardens, woodcutting, plumbing, even roofs when someone needs it."
    m neutral "でも公平に言えば、二人ともかなりうまく馴染んでます。Georgeは働き者で。便利屋です。庭仕事、薪割り、配管、頼まれれば屋根だって。"

# game/script/ch04.rpy:354
translate japanese ch04_10d2dbbe:

    # m neutral "He's older, but still got the strength. People hire him because he gets the job done."
    m neutral "歳は食ってますが、まだ力はある。仕事をきっちりやるから、みんな雇うんです。"

# game/script/ch04.rpy:355
translate japanese ch04_58c41542:

    # "He flicked ash into the snow, his face hard."
    "彼は雪の上に灰を弾いた。顔は硬かった。"

# game/script/ch04.rpy:356
translate japanese ch04_9bd9eedf:

    # m neutral "Doesn't change the fact I wouldn't want him as a neighbor."
    m neutral "それでも、隣人にはしたくないってことに変わりはないですけど。"

# game/script/ch04.rpy:357
translate japanese ch04_9601b9d7:

    # "Samuel took another slow drag, his mind already turning the words over."
    "Samuelはもう一度ゆっくりと吸った。頭の中ではもう、その言葉を転がしていた。"

# game/script/ch04.rpy:358
translate japanese ch04_51c2f6b1:

    # m shaken "Detective... do you think it's all connected? The teacher, the shopkeeper, and now this girl?"
    m shaken "刑事……全部つながってると思いますか？　あの教師も、店主も、今度のこの子も？"

# game/script/ch04.rpy:359
translate japanese ch04_8172879e:

    # "Samuel dropped his cigarette and ground it under his heel. His breath misted toward the roofline."
    "Samuelは煙草を落とし、踵で踏み消した。吐く息が屋根の線のほうへ白く流れた。"

# game/script/ch04.rpy:360
translate japanese ch04_b02c391d:

    # s "It's possible. Too many bodies in too few days. Each carrying something more than just bad luck."
    s "ありうる。短すぎる日数に、死体が多すぎる。どれも、ただの不運以上のものを抱えている。"

# game/script/ch04.rpy:361
translate japanese ch04_437dd908:

    # m shaken "Christ."
    m shaken "なんてこった。"

# game/script/ch04.rpy:362
translate japanese ch04_034d3376:

    # s "I still need to talk to the school psychologist. Then her parents. And I'll check the girl's room."
    s "まだ学校の心理士に話を聞かなきゃならない。それから両親だ。あの子の部屋も調べる。"

# game/script/ch04.rpy:363
translate japanese ch04_4776693a:

    # "Mercer gave a slow nod, eyes on the snow at their feet. Neither man spoke again for a while."
    "Mercerは足もとの雪に目を落としたまま、ゆっくりと頷いた。それからしばらく、どちらも口をきかなかった。"

# game/script/ch04.rpy:375
translate japanese ch04_fe8508eb:

    # "By the time Samuel reached the edge of town, the storm had thickened. Snow blew in long, angry sheets across the road, the wipers struggling."
    "Samuelが町外れに着く頃には、吹雪は濃くなっていた。雪が長く荒々しい幕となって道路を横切り、ワイパーが追いつかなかった。"

# game/script/ch04.rpy:376
translate japanese ch04_96861ffc:

    # "He pulled into the gravel drive of a tall two-story building, the only light on the street burning from its ground floor."
    "彼は背の高い二階建ての建物の砂利敷きの私道に車を入れた。通りで灯りがともっているのは、その一階だけだった。"

# game/script/ch04.rpy:378
translate japanese ch04_699a7a81:

    # "The moment he opened the door, the wind cut into him like a blade. He gripped his collar high and pushed toward the entrance."
    "ドアを開けた瞬間、風が刃のように彼を切り裂いた。彼は襟を高く握りしめ、入口へと押し進んだ。"

# game/script/ch04.rpy:379
translate japanese ch04_1a77d48f:

    # "A brass plaque by the door read: {i}Dr. Helena Markou, Psychologist.{/i}"
    "ドアの脇の真鍮の表札にはこうあった。{i}Helena Markou博士　心理士{/i}"

# game/script/ch04.rpy:380
translate japanese ch04_46a1136d:

    # "He pressed the bell. The lock released almost at once with a low buzz."
    "彼はベルを押した。ほとんど間を置かず、低いブザー音とともに錠が外れた。"

# game/script/ch04.rpy:386
translate japanese ch04_c2472cf7:

    # "Inside, the storm dropped away. Warmth wrapped around him, carrying the faint, rich smell of burning oak."
    "中に入ると、吹雪は遠のいた。暖気が彼を包み、燃える樫のかすかで豊かな匂いを運んできた。"

# game/script/ch04.rpy:387
translate japanese ch04_007efb2f:

    # "He stamped the snow off his boots, hung his coat by the door. Polished panels, dim sconces, golden light."
    "彼はブーツの雪を踏み落とし、コートをドアの脇に掛けた。磨かれた羽目板、薄暗い壁灯、金色の光。"

# game/script/ch04.rpy:388
translate japanese ch04_70e83ac8:

    # h "Come in, Detective. I'm in my office."
    h "どうぞ、刑事さん。診察室にいます。"

# game/script/ch04.rpy:389
translate japanese ch04_904d2a24:

    # "High bookshelves climbed the walls: leather-bound psychology tomes, modern case studies. An oriental rug. A large oak desk by the window, neat but lived-in."
    "高い書棚が壁を這い上っていた。革装の心理学の大著、現代の症例研究。東洋の絨毯。窓際には大きな樫の机。整頓されているが、使い込まれている。"

# game/script/ch04.rpy:390
translate japanese ch04_b92b7a98:

    # "Two green leather armchairs faced it. By the crackling fireplace, a sofa and a low table, as though inviting longer sessions than mere consultations."
    "その前に緑の革張りの肘掛け椅子が二脚。爆ぜる暖炉のそばにはソファと低いテーブルがあり、ただの相談より長いセッションを誘っているかのようだった。"

# game/script/ch04.rpy:392
translate japanese ch04_77a4ce4d:

    # "Dr. Helena Markou stood waiting. Mid-forties, sharply dressed, her glasses catching the firelight as she closed the file she'd been reading."
    "Helena Markou医師が立って待っていた。四十代半ば、隙のない装い。読んでいたファイルを閉じると、眼鏡が暖炉の火を映した。"

# game/script/ch04.rpy:393
translate japanese ch04_e29432bb:

    # h neutral "Detective Harris. Quite a storm to be out in."
    h neutral "Harris刑事。ひどい吹雪の中をよくいらっしゃいました。"

# game/script/ch04.rpy:394
translate japanese ch04_b88583c6:

    # "Samuel eased into an armchair and let the warmth seep into him."
    "Samuelは肘掛け椅子に身を沈め、暖かさが体に染み込むにまかせた。"

# game/script/ch04.rpy:395
translate japanese ch04_2025ede2:

    # s "You're right about the storm. It's been years since I've driven through weather like this. Almost forgot what it feels like."
    s "本当にひどい吹雪です。こんな天気の中を運転したのは何年ぶりか。どんなものか、ほとんど忘れていました。"

# game/script/ch04.rpy:396
translate japanese ch04_7d55531e:

    # h neutral "Greyvale has a way of reminding people of things they'd rather forget. Even the weather."
    h neutral "Greyvaleには、人が忘れていたいことを思い出させる癖があるんです。天気でさえ。"

# game/script/ch04.rpy:397
translate japanese ch04_780e7c04:

    # "She crossed to the fireplace to adjust a log. The light flared across her glasses."
    "彼女は暖炉のところへ行って薪を直した。炎の光が眼鏡を横切って揺らめいた。"

# game/script/ch04.rpy:398
translate japanese ch04_0c204b0f:

    # h neutral "Tell me, Detective—cases aside—how do you find the town so far?"
    h neutral "教えてください、刑事さん――事件はさておき――この町をどう思われます？"

# game/script/ch04.rpy:399
translate japanese ch04_59f10b93:

    # s "Honestly? Quiet. Almost too quiet. Streets empty, rhythms slow. The kind of place that makes you wonder if you've stepped out of time."
    s "正直に？　静かです。静かすぎるくらいだ。通りは空っぽで、何もかもがゆっくりしている。時間の外に足を踏み出してしまったのかと思うような場所です。"

# game/script/ch04.rpy:400
translate japanese ch04_e6c8c76b:

    # h neutral "That's fair. Greyvale can be charming at first glance. But the charm is thin, and behind it... people carry more shadows than they admit."
    h neutral "もっともですね。Greyvaleは、ぱっと見には魅力的に見えることもあります。でもその魅力は薄くて、その裏では……人は認める以上に影を抱えているんです。"

# game/script/ch04.rpy:401
translate japanese ch04_211c8c5c:

    # s "I've noticed. They're not as welcoming as they'd like outsiders to believe. Polite, yes. But there's something colder underneath."
    s "気づいています。よそ者に信じさせたがっているほど、歓迎的ではない。礼儀正しくはある。だが、その下にもっと冷たいものがある。"

# game/script/ch04.rpy:402
translate japanese ch04_334edaea:

    # "Helena gave a laugh, short and dry, but not unkind."
    "Helenaは笑った。短く乾いた笑いだったが、意地の悪いものではなかった。"

# game/script/ch04.rpy:403
translate japanese ch04_5b19fc2d:

    # h smile "I'm an outsider too. You saw the plaque on my door. {i}Psychologist.{/i}"
    h smile "私もよそ者なんですよ。ドアの表札をご覧になったでしょう。{i}心理士。{/i}"

# game/script/ch04.rpy:404
translate japanese ch04_a3709406:

    # "Samuel raised a brow."
    "Samuelは片眉を上げた。"

# game/script/ch04.rpy:405
translate japanese ch04_e5b0d1a8:

    # h smile "In reality, I'm a psychiatrist. But believe me, if I'd written that on the brass plate, it wouldn't have taken a week before people started calling me 'doctor for crazy people.'"
    h smile "実際には精神科医なんです。でも本当に、あの真鍮の表札にそう書いていたら、一週間もしないうちに「頭のおかしい人の医者」と呼ばれ始めていたでしょうね。"

# game/script/ch04.rpy:406
translate japanese ch04_98f8739a:

    # h smile "And from there? Crazy myself. So I chose the softer title. A small, innocent lie. Easier for them. Easier for me."
    h smile "そこから先は？　私自身が頭のおかしい人、です。だから柔らかいほうの肩書きを選んだんです。小さな、罪のない嘘。彼らにとって楽だし、私にとっても楽。"

# game/script/ch04.rpy:407
translate japanese ch04_29ee9482:

    # "Samuel allowed himself a small smile."
    "Samuelは自分に小さな笑みを許した。"

# game/script/ch04.rpy:408
translate japanese ch04_442101ee:

    # s "Seems even doctors have to make compromises in Greyvale."
    s "Greyvaleでは医者でさえ妥協しなきゃならないらしい。"

# game/script/ch04.rpy:409
translate japanese ch04_84d52ab2:

    # "She came around the desk and sat casually on its edge, one leg folded over the other. Samuel's eyes brushed there by instinct before he forced them back to his notebook."
    "彼女は机を回り込み、無造作にその縁に腰掛けて、脚を組んだ。Samuelの目は本能的にそこをかすめたが、彼は無理に手帳へ引き戻した。"

# game/script/ch04.rpy:410
translate japanese ch04_d349a611:

    # "He cleared his throat. The moment hadn't escaped her. She gave the smallest smile, then reached for a folder."
    "彼は咳払いをした。その一瞬は彼女に見逃されていなかった。彼女はごく小さく微笑み、それからフォルダーに手を伸ばした。"

# game/script/ch04.rpy:411
translate japanese ch04_725c9272:

    # h neutral "So. You want to talk about Clara Ward."
    h neutral "さて。Clara Wardのことでいらしたのね。"

# game/script/ch04.rpy:412
translate japanese ch04_ec73c3cc:

    # s "Yes. I trust she had problems? More than a usual teenager?"
    s "ええ。彼女には問題があったんでしょうね？　普通のティーンエイジャー以上に？"

# game/script/ch04.rpy:414
translate japanese ch04_f9f14d81:

    # "The playful edge left her face. The air of practiced professionalism settled over her like a coat."
    "悪戯めいた色が彼女の顔から消えた。手慣れた職業人の空気が、コートのように彼女に降りた。"

# game/script/ch04.rpy:415
translate japanese ch04_5ec0334c:

    # h firm "She wasn't just troubled, Detective. Clara had a documented history of self-harm. Cutting episodes, often on her forearms. Not hidden well, either."
    h firm "単に悩みを抱えていたのではありません、刑事さん。Claraには記録に残る自傷の病歴がありました。切る行為を繰り返していて、多くは前腕です。隠し方も上手ではありませんでした。"

# game/script/ch04.rpy:416
translate japanese ch04_355361d4:

    # h firm "Teachers noticed. Classmates noticed. She carried the scars openly."
    h firm "教師たちも気づいていました。同級生たちも。彼女は傷痕を隠さずにいました。"

# game/script/ch04.rpy:417
translate japanese ch04_47cd6419:

    # h firm "My diagnosis was recurrent major depressive disorder. Severe. Coupled with social anxiety."
    h firm "私の診断は反復性の大うつ病性障害。重度です。それに社交不安が加わっていました。"

# game/script/ch04.rpy:418
translate japanese ch04_a4bfa245:

    # h firm "Prolonged withdrawal, loss of interest, recurring suicidal ideation. By fourteen, she was already at high risk. By fifteen, she was in the red zone."
    h firm "長引く引きこもり、興味の喪失、繰り返す希死念慮。十四歳の時点ですでに高リスクでした。十五歳では危険域に入っていました。"

# game/script/ch04.rpy:419
translate japanese ch04_6eef61d0:

    # "Samuel's pen moved slowly, but his eyes stayed on her."
    "Samuelのペンはゆっくりと動いていたが、目は彼女から離れなかった。"

# game/script/ch04.rpy:420
translate japanese ch04_16df5bc9:

    # h firm "She was often the target of ridicule. Other students sensed her isolation and amplified it. She internalized every word, every whisper, as self-blame."
    h firm "彼女はしばしば嘲笑の的になっていました。ほかの生徒たちは彼女の孤立を嗅ぎ取って、それを増幅させた。彼女はあらゆる言葉、あらゆる囁きを、自分を責める材料として取り込んでいました。"

# game/script/ch04.rpy:421
translate japanese ch04_1d686940:

    # h firm "She came to me more than once convinced she was fundamentally flawed. That she deserved the suffering."
    h firm "彼女は何度も、自分は根本から欠陥があるのだと思い込んで私のところへ来ました。自分は苦しんで当然なのだと。"

# game/script/ch04.rpy:422
translate japanese ch04_4e5c8df7:

    # h firm "Clara wasn't a typical teenager caught in the storm of adolescence. She was clinically depressed, chronically anxious, and acutely suicidal. Without constant support, she was always on the edge."
    h firm "Claraは思春期の嵐に巻き込まれた典型的なティーンエイジャーではありませんでした。臨床的にうつ状態で、慢性的に不安を抱え、急性の自殺の危険がありました。絶えず支えていなければ、いつも崖っぷちにいたんです。"

# game/script/ch04.rpy:423
translate japanese ch04_b25abf46:

    # "The only sound for a moment was the crack of the fire and the tick of a clock on the far wall."
    "しばらくのあいだ、聞こえるのは暖炉の爆ぜる音と、奥の壁の時計が刻む音だけだった。"

# game/script/ch04.rpy:425
translate japanese ch04_196242d5:

    # h neutral "There was one thing, though. Clara often spoke about Alice. Said she was the only one who seemed to understand her. That she felt safe when Alice was around."
    h neutral "ただ、一つだけ。ClaraはよくAliceの話をしていました。自分を分かってくれるように思えるのはAliceだけだと。Aliceがそばにいると安心できると。"

# game/script/ch04.rpy:426
translate japanese ch04_19455bbf:

    # h neutral "Sometimes Clara told me Alice understood her better than adults ever could. Almost as if Alice knew what she was thinking before she said it."
    h neutral "ときどきClaraは、Aliceは大人よりずっと自分を分かってくれる、と言っていました。まるで、口に出す前からAliceには自分の考えていることが分かっているみたいだ、と。"

# game/script/ch04.rpy:427
translate japanese ch04_12a89a23:

    # h neutral "It surprised me, honestly. Alice is younger, only twelve. But Clara insisted she was a steadying presence. That's all I can say about it."
    h neutral "正直、驚きました。Aliceは年下で、まだ十二歳です。でもClaraは、彼女がいると心が落ち着くのだと言い張っていました。それについて言えるのはそれだけです。"

# game/script/ch04.rpy:428
translate japanese ch04_7abf25ce:

    # "She closed the folder with a measured hand."
    "彼女は抑制された手つきでフォルダーを閉じた。"

# game/script/ch04.rpy:429
translate japanese ch04_740d093b:

    # h firm "If you want my advice, speaking with her parents won't help you much."
    h firm "助言させていただくなら、ご両親と話してもあまり役には立たないでしょう。"

# game/script/ch04.rpy:430
translate japanese ch04_e194f9fd:

    # h firm "I know both of them. They came here for couples sessions that quickly turned into family sessions. Those were... ugly."
    h firm "お二人とも知っています。夫婦カウンセリングで来ていたのが、すぐに家族セッションになりました。あれは……醜いものでした。"

# game/script/ch04.rpy:431
translate japanese ch04_89f18ffe:

    # h firm "They don't stay together for love. They stay together for tradition, for appearances. To show the town they're still a 'family.'"
    h firm "あの二人は愛情で一緒にいるんじゃありません。しきたりと体面のためです。自分たちはまだ「家族」なのだと町に見せるために。"

# game/script/ch04.rpy:432
translate japanese ch04_c0836eb7:

    # h firm "They're poor, but not because of bad luck. Her father is a gambling addict. And the mother... some years back, she was hooked on heroin. She clawed her way out, but the damage was carved into that household."
    h firm "貧しいのは運が悪いからではありません。父親はギャンブル依存症です。そして母親は……何年か前、ヘロインに溺れていました。這い上がりはしましたが、その傷はあの家に刻み込まれてしまった。"

# game/script/ch04.rpy:434
translate japanese ch04_8d262e38:

    # h concerned "Of course, none of it is a secret. But I'd bet no one spoke ill of them after Clara's death, did they? You know why, Detective?"
    h concerned "もちろん、どれも秘密ではありません。でも賭けてもいいわ、Claraが亡くなったあと、誰もあの二人を悪く言わなかったでしょう？　なぜだかお分かりになります、刑事さん？"

# game/script/ch04.rpy:435
translate japanese ch04_129192aa:

    # h concerned "Because everyone already knew. Everyone in this town knew what that girl was living with. What was under her skin. And nobody did anything."
    h concerned "みんな、とっくに知っていたからです。この町の誰もが、あの子が何を抱えて生きていたか知っていた。皮膚の下に何があったのか。そして誰も何もしなかった。"

# game/script/ch04.rpy:436
translate japanese ch04_a3ec4d34:

    # "She pushed her glasses up, and folded her arms tightly."
    "彼女は眼鏡を押し上げ、腕をきつく組んだ。"

# game/script/ch04.rpy:437
translate japanese ch04_0111998b:

    # h sad "Including myself."
    h sad "私も含めて。"

# game/script/ch04.rpy:438
translate japanese ch04_eeace0a9:

    # "The fire popped once, the only sound between them."
    "暖炉が一度爆ぜた。二人のあいだにある、唯一の音だった。"

# game/script/ch04.rpy:447
translate japanese ch04_293ed306:

    # "Folded tight across herself. Not a wall. A woman holding herself to account, and meaning it."
    "自分の体をきつく抱え込むように組まれた腕。壁ではない。自分に責任を問い、それを本気で受け止めている女の腕だった。"

# game/script/ch04.rpy:448
translate japanese ch04_ac02197c:

    # "Samuel sat still, his pen idle, and let the words weigh down the silence. Then he rose, sliding the notebook into his coat."
    "Samuelはじっと座り、ペンを止めたまま、その言葉が沈黙を重くするにまかせた。それから立ち上がり、手帳をコートに滑り込ませた。"

# game/script/ch04.rpy:449
translate japanese ch04_8884296c:

    # s "We all live with what we didn't do, Doctor. Some of us more than others. Thank you for your time, and your information."
    s "誰もが、しなかったことを抱えて生きているんですよ、先生。人よりそれが多い者もいる。お時間と情報をありがとうございました。"

# game/script/ch04.rpy:450
translate japanese ch04_4592841b:

    # "Helena gave a faint nod and offered no reply."
    "Helenaはかすかに頷いただけで、何も答えなかった。"

# game/script/ch04.rpy:457
translate japanese ch04_c1142315:

    # "He pushed back through the storm and shut the car door against the howl of the wind. He sat in silence a moment, part fury, part professionalism."
    "彼は吹雪の中を押し戻り、唸る風に逆らって車のドアを閉めた。しばらく黙って座っていた。半分は怒り、半分は職業意識だった。"

# game/script/ch04.rpy:458
translate japanese ch04_baaa3cef:

    # th "You're not here to feel. You're here to work."
    th "感じるために来たんじゃない。仕事をしに来たんだ。"

# game/script/ch04.rpy:459
translate japanese ch04_e059da62:

    # th "Still... It's a kid's life. A kid who'd been bleeding inside for years, and no one stopped it."
    th "それでも……子供の命だ。何年も内側で血を流していて、誰もそれを止めなかった子供の。"

# game/script/ch04.rpy:460
translate japanese ch04_4e4c29ee:

    # "He struck a match and lit a Marlboro. The ember glowed bright against the dim storm."
    "彼はマッチを擦り、マルボロに火をつけた。燃えさしが薄暗い吹雪を背に赤く光った。"

# game/script/ch04.rpy:461
translate japanese ch04_89320389:

    # th "Focus on the case, Harris. Focus."
    th "事件に集中しろ、Harris。集中しろ。"

# game/script/ch04.rpy:462
translate japanese ch04_70e42681:

    # "If Alice had been the only steady hand in Clara's chaos, then who else was there? No one, as far as the files said. Just that one girl."
    "AliceがClaraの混乱の中で唯一の確かな手だったのなら、ほかに誰がいたのか？　ファイルによれば、誰もいない。あの少女ひとりだけだ。"

# game/script/ch04.rpy:463
translate japanese ch04_c0ed6bf2:

    # s "It's late."
    s "もう遅い。"

# game/script/ch04.rpy:464
translate japanese ch04_5a5a8636:

    # "Tomorrow he would go to the parents. Tomorrow he would try to find the diary."
    "明日は両親のところへ行く。明日は日記を見つけてみる。"

# game/script/ch04.rpy:471
translate japanese ch04_027e86be:

    # "The night gave him little rest. That diary, real or imagined, gnawed at him. If it existed, it was the one voice Clara had left behind."
    "夜は彼にほとんど休息を与えなかった。あの日記が、実在するのか想像なのか、彼を苛んだ。もし存在するなら、それはClaraが残していった唯一の声だった。"

# game/script/ch04.rpy:472
translate japanese ch04_ffb6c76f:

    # "Breakfast was quick and joyless: three strong coffees and two pieces of chicken pie, swallowed for fuel. By half past nine he was back in the car."
    "朝食は手早く、味気なかった。濃いコーヒーを三杯と、チキンパイを二切れ、燃料として流し込んだ。九時半には、もう車に戻っていた。"

# game/script/ch04.rpy:476
translate japanese ch04_03882307:

    # "The Wards lived on the third floor of a tired block. Paint peeled from the stairwell walls; the air smelled of damp plaster. He knocked."
    "Ward家はくたびれた集合住宅の三階に住んでいた。階段の壁はペンキが剥がれ、空気は湿った漆喰の匂いがした。彼はノックした。"

# game/script/ch04.rpy:477
translate japanese ch04_74212834:

    # "The door opened after a long pause."
    "長い間があって、ドアが開いた。"

# game/script/ch04.rpy:479
translate japanese ch04_c6485e7b:

    # "A woman, shoulders narrow, face drawn and gray with exhaustion. Evelyn Ward."
    "肩の細い女だった。顔はやつれ、疲労で灰色になっていた。Evelyn Ward。"

# game/script/ch04.rpy:480
translate japanese ch04_56fa2202:

    # s "Detective Harris. I'd like to speak with you for a few minutes, if that's alright."
    s "Harris刑事です。少しお話を伺えればと思いまして。差し支えなければ。"

# game/script/ch04.rpy:481
translate japanese ch04_bd53cb29:

    # "The smallest nod. She stepped aside."
    "ごく小さな頷き。彼女は脇へ退いた。"

# game/script/ch04.rpy:482
translate japanese ch04_7d378289:

    # "Every blind was drawn, muting the morning into perpetual dusk. The radiators off, the fireplace dark. It felt less like a home than a waiting room for grief."
    "ブラインドはすべて下ろされ、朝を果てしない夕暮れへと押し殺していた。暖房は切られ、暖炉は暗い。家というより、悲しみのための待合室のようだった。"

# game/script/ch04.rpy:483
translate japanese ch04_c86fee7e:

    # "On a sagging couch a man sat with his jaw slack, eyes fixed on nothing. Richard Ward. When Evelyn lowered herself beside him, he blinked, as though returning from a long way off."
    "へたったソファに、男が顎を緩ませて座り、何もないところを見つめていた。Richard Ward。Evelynが隣に腰を下ろすと、彼は瞬きをした。遠いところから戻ってきたかのように。"

# game/script/ch04.rpy:484
translate japanese ch04_9d0d67a1:

    # "Samuel took the armchair opposite. Devastated wasn't enough. They were hollowed out, each breath a reminder of absence."
    "Samuelは向かいの肘掛け椅子に座った。打ちひしがれている、では足りなかった。二人はえぐり取られて空洞になっていた。息をひとつするたびに、不在を思い知らされていた。"

# game/script/ch04.rpy:489
translate japanese ch04_802ea8b8:

    # s "Did you notice anything different in your daughter's behavior these last days?"
    s "ここ数日、娘さんの様子に何か変わったところに気づかれましたか？"

# game/script/ch04.rpy:490
translate japanese ch04_48e430ae:

    # "Evelyn's eyes barely shifted. She shook her head slowly. Richard only stared at the floor."
    "Evelynの目はほとんど動かなかった。彼女はゆっくりと首を振った。Richardは床を見つめているだけだった。"

# game/script/ch04.rpy:491
translate japanese ch04_ef4a0d4b:

    # s "Did she seem more withdrawn than usual? Spending more time in her room?"
    s "いつもより引きこもっているように見えましたか？　部屋で過ごす時間が増えたとか？"

# game/script/ch04.rpy:492
translate japanese ch04_163bac95:

    # "Another small shake. Richard gave no sign he'd heard."
    "また小さく首を振る。Richardは聞こえた素振りすら見せなかった。"

# game/script/ch04.rpy:493
translate japanese ch04_4f370418:

    # s "Any arguments? Anything she said that seemed unusual?"
    s "言い争いは？　何か変わったことを口にしていませんでしたか？"

# game/script/ch04.rpy:494
translate japanese ch04_747a6c31:

    # "Silence. Then a dull shake, as if Evelyn's neck could barely carry the weight."
    "沈黙。それから鈍い首振り。Evelynの首は、その重みをかろうじて支えているかのようだった。"

# game/script/ch04.rpy:495
translate japanese ch04_c54d4daf:

    # s "Did she ever mention someone bothering her at school? Friends, teachers, anyone?"
    s "学校で誰かに嫌がらせをされていると話したことは？　友達、教師、誰でも。"

# game/script/ch04.rpy:496
translate japanese ch04_2c242608:

    # "Both shook their heads, automatic, detached, as if his words dissolved before reaching them."
    "二人とも首を振った。機械的に、うわの空で。彼の言葉が届く前に溶けて消えていくかのように。"

# game/script/ch04.rpy:497
translate japanese ch04_e1233f6b:

    # "His voice wasn't reaching them."
    "彼の声は二人に届いていなかった。"

# game/script/ch04.rpy:498
translate japanese ch04_0a72a8ed:

    # s "Would you mind if I had a quick look at Clara's room?"
    s "Claraさんの部屋を少しだけ見せていただいてもよろしいですか？"

# game/script/ch04.rpy:500
translate japanese ch04_0b95718a:

    # s "I'm sorry to ask this now. Would you mind if I had a quick look at Clara's room?"
    s "こんなときにお願いして申し訳ありません。Claraさんの部屋を少しだけ見せていただいてもよろしいですか？"

# game/script/ch04.rpy:503
translate japanese ch04_aebb9c85:

    # "Evelyn's face changed at once. Her eyes widened, her lips tightened."
    "Evelynの顔がたちまち変わった。目が見開かれ、唇が引き結ばれた。"

# game/script/ch04.rpy:504
translate japanese ch04_b2dcbcd7:

    # ev "Her... room? No, I don't think—"
    ev "あの子の……部屋？　いいえ、それは――"

# game/script/ch04.rpy:509
translate japanese ch04_2df73d6f:

    # "Not keeping it from him. Keeping it from herself. The room was the last place her daughter was still alive."
    "彼から隠しているのではない。自分自身から隠しているのだ。あの部屋は、娘がまだ生きている最後の場所だった。"

# game/script/ch04.rpy:514
translate japanese ch04_b64fe26a:

    # "Samuel lifted a hand gently, cutting the protest before it could swell."
    "Samuelはそっと片手を上げ、抗議が膨らむ前に遮った。"

# game/script/ch04.rpy:515
translate japanese ch04_dc50e5e4:

    # s "It's fine. Forget I asked. Please, just let me use your bathroom, and I'll be on my way."
    s "いいんです。今のは忘れてください。お手洗いだけお借りできますか、そうしたら失礼します。"

# game/script/ch04.rpy:517
translate japanese ch04_44fa1333:

    # "At once her face relaxed, slipping back into the state it had been in before."
    "たちまち彼女の顔は緩み、さっきまでの状態へと滑り戻った。"

# game/script/ch04.rpy:518
translate japanese ch04_39684171:

    # ev "Of course. Down the hall, left side."
    ev "ええ、どうぞ。廊下の先、左側です。"

# game/script/ch04.rpy:519
translate japanese ch04_b5d5ba8a:

    # s "Thank you."
    s "ありがとうございます。"

# game/script/ch04.rpy:521
translate japanese ch04_a171566d:

    # "He walked the hall with measured steps, boots silent on the old carpet. But instead of turning into the bathroom, he went straight for Clara's door."
    "彼は落ち着いた足取りで廊下を歩いた。古い絨毯の上でブーツは音を立てなかった。だが彼は手洗いへは曲がらず、まっすぐClaraの部屋の扉へ向かった。"

# game/script/ch04.rpy:524
translate japanese ch04_c1216f66:

    # "Untouched since her death. A still-life of a teenager's life interrupted. Clothes draped carelessly over the desk chair."
    "彼女が死んでから手つかずのままだった。中断されたティーンエイジャーの暮らしの静物画。服が無造作に机の椅子に掛けられていた。"

# game/script/ch04.rpy:525
translate japanese ch04_7141ff08:

    # "The desk scattered with doodles: black shapes, dark figures scratched in with heavy ink. Ominous. But not unusual for a girl drowning in shadows."
    "机には落書きが散らばっていた。黒い形、濃いインクで刻みつけられた暗い人影。不吉だ。だが、影に溺れている少女にとっては珍しくもない。"

# game/script/ch04.rpy:526
translate japanese ch04_b0d19d9d:

    # "One page showed the word {i}Liar{/i} scrawled over and over, the ink pressed so hard it had torn the paper."
    "あるページには{i}嘘つき{/i}という言葉が何度も何度も書き殴られ、インクを押しつける力が強すぎて紙が破れていた。"

# game/script/ch04.rpy:527
translate japanese ch04_fd81b9b2:

    # "He checked the desk and the drawers. No diary. Inside a small backpack. Not there either."
    "彼は机と引き出しを調べた。日記はない。小さなリュックの中。そこにもない。"

# game/script/ch04.rpy:528
translate japanese ch04_31f5c8e6:

    # "Alice's words echoed. He moved to the bed, gripped the mattress, and lifted it."
    "Aliceの言葉がよみがえった。彼はベッドへ移り、マットレスをつかんで持ち上げた。"

# game/script/ch04.rpy:530
translate japanese ch04_26b1e002:

    # "And there it was. The diary."
    "そして、そこにあった。日記だ。"

# game/script/ch04.rpy:531
translate japanese ch04_dea0e3e8:

    # "He slipped it into the inside pocket of his coat, the leather cover pressing against his ribs."
    "彼はそれをコートの内ポケットに滑り込ませた。革の表紙が肋骨に押し当たった。"

# game/script/ch04.rpy:532
translate japanese ch04_4f1a9f89:

    # th "Exigent seizure. Evidence removed before grieving parents destroy it. Log it, file for a retroactive warrant."
    th "緊急措置としての押収。悲嘆に暮れる両親が処分する前に証拠を確保。記録して、事後令状を申請する。"

# game/script/ch04.rpy:533
translate japanese ch04_c26353bb:

    # "For now, the choice was already made."
    "ともかく、選択はもう済んでいた。"

# game/script/ch04.rpy:534
translate japanese ch04_73a8f26b:

    # "He let the mattress fall, walked briskly to the bathroom, flushed, ran the tap, washed his hands. Quick, precise, rehearsed."
    "彼はマットレスを落とし、足早に手洗いへ行き、水を流し、蛇口をひねり、手を洗った。素早く、正確に、練習どおりに。"

# game/script/ch04.rpy:538
translate japanese ch04_cbf3262c:

    # "When he stepped back into the hall, both of them were standing there, side by side, faces pale in the dim light. Their eyes fixed on him."
    "廊下に戻ると、二人ともそこに立っていた。並んで、薄暗い光の中で顔を青白くして。二人の目が彼に据えられていた。"

# game/script/ch04.rpy:539
translate japanese ch04_55ab8c10:

    # "Samuel's chest tightened for an instant."
    "Samuelの胸が一瞬締めつけられた。"

# game/script/ch04.rpy:540
translate japanese ch04_ffe5c47e:

    # rw "It's better to leave now, Detective."
    rw "もうお帰りになったほうがいい、刑事さん。"

# game/script/ch04.rpy:541
translate japanese ch04_d03e7022:

    # ev "She didn't like people in her room."
    ev "あの子、部屋に人が入るのを嫌がったんです。"

# game/script/ch04.rpy:542
translate japanese ch04_5e518f9f:

    # s "Of course. Thank you, sir."
    s "もちろんです。ありがとうございました。"

# game/script/ch04.rpy:543
translate japanese ch04_8107b75a:

    # s "And... my condolences. For both of you."
    s "それと……お悔やみ申し上げます。お二人に。"

# game/script/ch04.rpy:544
translate japanese ch04_14110549:

    # "Neither spoke. They only watched him go, until the door closed behind him."
    "どちらも口をきかなかった。ただ、ドアが閉まるまで彼が去るのを見ていた。"

# game/script/ch04.rpy:551
translate japanese ch04_1f368286:

    # "On the way back he bought two take-away coffees, a plain sandwich and a fresh carton of Marlboros at a fogged corner café. The diary pressed against his ribs like a secret."
    "帰り道、曇った窓の街角のカフェで、持ち帰りのコーヒーを二つと、具の少ないサンドイッチ、マルボロを新しく一カートン買った。日記が秘密のように肋骨に押し当たっていた。"

# game/script/ch04.rpy:554
translate japanese ch04_0a38a1c9:

    # s "I've secured Clara's diary. Pulled it under exigent circumstances, logged it that way. Warrant paperwork will follow."
    s "Claraの日記を確保した。緊急措置として押収して、そのように記録してある。令状の書類は後から出す。"

# game/script/ch04.rpy:555
translate japanese ch04_5e47fd0f:

    # m neutral "Understood. Better to take the heat later than lose it for good."
    m neutral "了解です。失くすより、あとで叩かれるほうがましですからね。"

# game/script/ch04.rpy:557
translate japanese ch04_62bcef21:

    # "He ate in sharp, distracted bites, washed it down with scalding coffee, lit a cigarette, and sat in the armchair by the window."
    "彼は上の空で、がつがつと食べ、熱すぎるコーヒーで流し込み、煙草に火をつけ、窓際の肘掛け椅子に座った。"

# game/script/ch04.rpy:558
translate japanese ch04_aaf0e5b7:

    # "The diary's cover was worn, the corners soft with handling. He opened it."
    "日記の表紙はすり切れ、角は手擦れで柔らかくなっていた。彼はそれを開いた。"

# game/script/ch04.rpy:560
translate japanese ch04_83254650:

    # "The first page began in a small, tight hand."
    "最初のページは、小さく窮屈な字で始まっていた。"

# game/script/ch04.rpy:561
translate japanese ch04_259be7bc:

    # note_voice "Dear diary, I am writing to share my thoughts. Alice said it will help me manage my emotions and judgment. I want to believe her. She says she does the same herself."
    note_voice "親愛なる日記さん、私の気持ちを打ち明けるために書いています。Aliceが、そうすれば感情と判断をうまく扱えるようになるって言った。信じたい。Alice自身もそうしてるんだって。"

# game/script/ch04.rpy:562
translate japanese ch04_b4ad94e4:

    # "The entries came quick, the handwriting jagged in places, pressed so deep it looked carved rather than written."
    "書き込みは次々と続いた。ところどころ筆跡がぎざぎざで、深く押しつけられた字は、書いたというより刻んだように見えた。"

# game/script/ch04.rpy:564
translate japanese ch04_c3936b69:

    # note_voice "They fought again last night. He smashed a plate. She locked herself in the bathroom. I lay on the floor and covered my ears, but I still heard them. I always hear them."
    note_voice "昨日の夜、また喧嘩してた。あの人はお皿を叩き割った。あの人はバスルームに閉じこもった。私は床に寝転がって耳をふさいだけど、それでも聞こえた。いつだって聞こえる。"

# game/script/ch04.rpy:565
translate japanese ch04_68c35418:

    # note_voice "My shoes are falling apart. My sleeves are too short. They laugh when I walk past, tugging at their own coats like mine is diseased."
    note_voice "靴はぼろぼろ。袖は短すぎる。私がそばを通ると、みんな笑って、まるで私のが病気持ちみたいに自分のコートを引っぱる。"

# game/script/ch04.rpy:566
translate japanese ch04_e460a3af:

    # note_voice "I feel smaller every day. Like I'm not a person anymore, just a joke."
    note_voice "毎日、自分が小さくなっていく気がする。もう人間じゃなくて、ただの笑いものみたいに。"

# game/script/ch04.rpy:567
translate japanese ch04_897eb8df:

    # note_voice "They call me 'junkie's daughter.' Sometimes they say 'whore's kid.' They say it in front of teachers. No one stops them. Everyone hears it. Everyone knows it."
    note_voice "みんな私を「ヤク中の娘」って呼ぶ。ときどき「売女の子」とも。先生の前でも言う。誰も止めない。誰もが聞いてる。誰もが知ってる。"

# game/script/ch04.rpy:568
translate japanese ch04_c33806e2:

    # "He turned another page. The ink darker in places, smudged with old tears."
    "彼はまたページをめくった。インクはところどころ濃く、古い涙で滲んでいた。"

# game/script/ch04.rpy:569
translate japanese ch04_82fee235:

    # note_voice "I cut again today. I thought it would help. It didn't. Alice told me it wouldn't."
    note_voice "今日もまた切った。楽になると思った。ならなかった。Aliceはならないって言ってた。"

# game/script/ch04.rpy:570
translate japanese ch04_e2a846a5:

    # note_voice "She said hurting myself will never bring good attention, only pity or disgust. She said if I want things to change, I can't stay like this."
    note_voice "自分を傷つけても、いい注目なんて絶対に集まらない、集まるのは同情か嫌悪だけだって。何かを変えたいなら、このままじゃいられないって。"

# game/script/ch04.rpy:571
translate japanese ch04_2305806a:

    # "The next lines made Samuel pause, his jaw tightening."
    "次の数行で、Samuelは手を止めた。顎に力がこもった。"

# game/script/ch04.rpy:572
translate japanese ch04_ce976fa3:

    # note_voice "Alice says I need to make a drastic change. That people only notice when you do something they can't ignore."
    note_voice "Aliceは、私は思い切った変化を起こさなきゃいけないって言う。みんなが無視できないことをしたときだけ、人は気づくんだって。"

# game/script/ch04.rpy:573
translate japanese ch04_44d28faa:

    # note_voice "She said then they'll stop calling me names. Then it won't matter what they think anymore."
    note_voice "そうしたら、みんな私を悪く呼ぶのをやめるって。そうしたら、みんながどう思うかなんて、もうどうでもよくなるって。"

# game/script/ch04.rpy:574
translate japanese ch04_71353ae7:

    # "He stared at the words, smoke curling around his face."
    "彼はその言葉を見つめた。煙が顔のまわりに渦を巻いた。"

# game/script/ch04.rpy:575
translate japanese ch04_01cf7c1e:

    # th "Drastic change."
    th "思い切った変化。"

# game/script/ch04.rpy:576
translate japanese ch04_805d8b29:

    # th "To Clara, Alice was the only positive voice. The only friend who told her she mattered."
    th "Claraにとって、Aliceは唯一の前向きな声だった。お前には価値があると言ってくれた、ただ一人の友達だった。"

# game/script/ch04.rpy:579
translate japanese ch04_e5d9f44c:

    # "He read on."
    "彼は読み進めた。"

# game/script/ch04.rpy:580
translate japanese ch04_bce64343:

    # note_voice "Alice understands me. She listens. She says she knows what it feels like to be judged, to have people look at you like you don't belong."
    note_voice "Aliceは私を分かってくれる。聞いてくれる。裁かれるのがどんな気持ちか、ここにいるべきじゃないって目で見られるのがどんな気持ちか、知ってるって言う。"

# game/script/ch04.rpy:581
translate japanese ch04_c83aa54b:

    # note_voice "She's younger, but she feels older. Wiser. She tells me the truth."
    note_voice "年下なのに、年上みたいに感じる。賢い。本当のことを言ってくれる。"

# game/script/ch04.rpy:582
translate japanese ch04_a616991f:

    # note_voice "She says nobody will ever understand me the way she does."
    note_voice "Aliceみたいに私を分かってくれる人は、ほかに誰もいないって、Aliceは言う。"

# game/script/ch04.rpy:583
translate japanese ch04_35831147:

    # "The pages grew more fragmented, swinging like a pendulum: anguish, fury, brief hope, then back to despair."
    "ページはしだいに断片的になり、振り子のように揺れた。苦悶、激怒、つかの間の希望、そしてまた絶望へ。"

# game/script/ch04.rpy:584
translate japanese ch04_b8122b8b:

    # "Always circling one constant. Alice."
    "いつも、ひとつの定数のまわりを巡っていた。Alice。"

# game/script/ch04.rpy:594
translate japanese ch04_a9c9eda8:

    # "The next morning was clear. Pale sunlight across the snow, the air sharp and unmoving. For the first time in days, the sky was open and blue."
    "翌朝は晴れていた。淡い陽光が雪の上に差し、空気は鋭く、動かなかった。何日ぶりかで、空は開けて青かった。"

# game/script/ch04.rpy:595
translate japanese ch04_b73c5e0f:

    # "Samuel hadn't planned on attending. Not family, not a friend, not even part of the town."
    "Samuelは参列するつもりはなかった。家族でも、友人でもない。町の一員ですらない。"

# game/script/ch04.rpy:596
translate japanese ch04_8f4d037d:

    # "But he had read her most private confessions. He owed her the dignity of standing there."
    "だが彼は、彼女の最も私的な告白を読んだのだ。そこに立つという礼を、彼は彼女に負っていた。"

# game/script/ch04.rpy:597
translate japanese ch04_1713b3f8:

    # "The funeral drew nearly the whole of Greyvale: teachers, students, shopkeepers, the mayor stiff in his dark overcoat. The crowd overflowed beyond the fence, breath rising in pale clouds."
    "葬儀にはGreyvaleのほぼ全員が集まった。教師、生徒、店主たち、黒いオーバーコートに身を固くした町長。人波は柵の外まであふれ、吐く息が淡い雲となって立ちのぼった。"

# game/script/ch04.rpy:598
translate japanese ch04_4187eedc:

    # "The prayers were spoken plainly. The grave was small but made with care, the stone top quality. An expense covered by the mayor, no doubt. A gesture to the town's conscience."
    "祈りは飾り気なく唱えられた。墓は小さかったが丁寧に作られ、墓石は最上等のものだった。費用は町長持ちに違いない。町の良心に向けた身振りだ。"

# game/script/ch04.rpy:599
translate japanese ch04_28751d2b:

    # th "They pay for her coffin, but not her life. They honor her death, and ignored her cries while she was alive."
    th "あいつらは彼女の棺には金を払うが、命には払わない。死は称えるくせに、生きているあいだの叫びは無視した。"

# game/script/ch04.rpy:600
translate japanese ch04_3ca63c02:

    # "When the coffin began to lower, the silence broke."
    "棺が下ろされ始めたとき、沈黙が破れた。"

# game/script/ch04.rpy:601
translate japanese ch04_133d9104:

    # ev "No— no, no, Clara—!"
    ev "いや――いや、いや、Clara――！"

# game/script/ch04.rpy:602
translate japanese ch04_3ff1478d:

    # "Evelyn Ward collapsed forward, her scream tearing through the cold air. The sound of a realization settling permanent: her daughter was gone."
    "Evelyn Wardが前のめりに崩れ落ちた。その悲鳴が冷たい空気を引き裂いた。気づきが永遠に定まる音だった。娘はいなくなったのだ。"

# game/script/ch04.rpy:607
translate japanese ch04_02a23425:

    # "Samuel's chest clenched. The scene blurred against another: a cemetery, thirteen years earlier."
    "Samuelの胸が締めつけられた。その光景が、もうひとつの光景に重なってぼやけた。墓地。十三年前。"

# game/script/ch04.rpy:608
translate japanese ch04_7944375d:

    # "His baby's coffin, smaller even than Clara's, disappearing into the earth."
    "彼の赤ん坊の棺。Claraのものよりさらに小さく、土の中へ消えていく。"

# game/script/ch04.rpy:609
translate japanese ch04_ce64df1d:

    # "The word they had given him was SIDS, as if a neat acronym could soften the fact that death had stolen everything."
    "彼らが彼に与えた言葉は「乳幼児突然死症候群（SIDS）」だった。まるで整った略語ひとつで、死がすべてを奪ったという事実を和らげられるとでもいうように。"

# game/script/ch04.rpy:610
translate japanese ch04_40a17ee6:

    # cl "Thomas— give him back— {i}give him back{/i}—"
    cl "Thomas――返して――{i}返して{/i}――"

# game/script/ch04.rpy:611
translate japanese ch04_8a45189f:

    # "He could still hear Claire's screams, her voice cracking into hysteria, clawing at the ground, at him, at anyone."
    "Claireの叫び声がまだ聞こえた。声はひび割れて狂乱に変わり、地面を、彼を、誰彼かまわず掻きむしっていた。"

# game/script/ch04.rpy:612
translate japanese ch04_69737a2a:

    # "And he had stood motionless. No tears, no anger. Just staring at the tiny box as it was swallowed by dirt, feeling his life collapse in on itself."
    "そして彼は、身動きもせず立っていた。涙もなく、怒りもなく。ただ小さな箱が土に呑まれていくのを見つめ、自分の人生が内側へ崩れ落ちていくのを感じていた。"

# game/script/ch04.rpy:616
translate japanese ch04_bfe48694:

    # "His hand lifted to his face now, brushing at the wet warmth on his cheeks. Tears, unbidden, hot against the cold air."
    "今、彼の手が顔へ上がり、頬の濡れた温もりに触れた。涙だった。求めもしないのに、冷たい空気の中で熱かった。"

# game/script/ch04.rpy:617
translate japanese ch04_391ed556:

    # "Yet his expression didn't change. His eyes stayed fixed on the coffin as the grave closed over another child who should have been spared."
    "それでも表情は変わらなかった。目は棺に据えられたまま、救われるべきだったもう一人の子供の上で墓が閉じていった。"

# game/script/ch04.rpy:618
translate japanese ch04_31c19fd4:

    # "The cries around him blurred into the same chorus of grief that had haunted him for thirteen years."
    "まわりの泣き声は、十三年間彼につきまとってきたのと同じ悲嘆の合唱に溶けていった。"

# game/script/ch04.rpy:624
translate japanese ch04_f146b97f:

    # "The coffin had just disappeared into the earth when Samuel's eyes drifted sideways."
    "棺がちょうど土の中へ消えたとき、Samuelの目が横へ流れた。"

# game/script/ch04.rpy:625
translate japanese ch04_95ef835a:

    # "Among the crowd pressed closest to the grave, two small figures stood hand in hand."
    "墓のいちばん近くに詰めかけた人々の中に、小さな人影が二つ、手をつないで立っていた。"

# game/script/ch04.rpy:626
translate japanese ch04_447e6230:

    # "Emily Carter was sobbing openly, shoulders quaking, tears streaking her face."
    "Emily Carterは人目もはばからず泣いていた。肩が震え、涙が顔に筋を引いていた。"

# game/script/ch04.rpy:627
translate japanese ch04_2b10c17b:

    # "Beside her, Alice Bennett stood still, her grip firm on her friend's hand. No tears. No tremor. Her face calm, steady, her gaze fixed on the priest."
    "その隣で、Alice Bennettはじっと立っていた。友達の手をしっかりと握って。涙はない。震えもない。顔は穏やかで落ち着き、視線は神父に据えられていた。"

# game/script/ch04.rpy:631
translate japanese ch04_096ddbe8:

    # "Censer smoke still clung to the cold air. The priest stepped forward again, robes brushing the frost-darkened grass."
    "香炉の煙がまだ冷たい空気にまとわりついていた。神父が再び進み出た。法衣が、霜で黒ずんだ草をかすめた。"

# game/script/ch04.rpy:632
translate japanese ch04_0becd9eb:

    # "In one hand a small glass bottle of water; in the other, a thick Bible worn from years of use."
    "片手には水の入った小さなガラス瓶、もう片手には長年使い込まれた分厚い聖書。"

# game/script/ch04.rpy:633
translate japanese ch04_8ac2e97a:

    # fk "These events... these tragedies... they must not be tolerated in our community."
    fk "このような出来事……このような悲劇は……我々の共同体において、決して許されてはならないのである。"

# game/script/ch04.rpy:634
translate japanese ch04_5fbffad6:

    # fk "Evil has spread among us. And we must not turn away. We must face it with faith."
    fk "悪が我々の間に広がったのです。そして我々は目を背けてはならない。信仰をもって、それに立ち向かわねばならないのです。"

# game/script/ch04.rpy:635
translate japanese ch04_7b74644f:

    # "His voice grew sharper, a quiet fanaticism seeping into it. He lifted the Bible and recited from memory: phrases meant to console, ringing now like judgment."
    "彼の声は鋭さを増し、静かな狂信がそこに染み込んでいった。彼は聖書を掲げ、そらで唱えた。慰めのための言葉が、今は裁きのように響いた。"

# game/script/ch04.rpy:637
translate japanese ch04_e4490ee5:

    # "He paused, lifted the water, and took a long swallow. His throat worked. He wiped his mouth with the back of his hand."
    "彼は言葉を切り、水を持ち上げて、長くあおった。喉が動いた。手の甲で口をぬぐった。"

# game/script/ch04.rpy:639
translate japanese ch04_a4bd6af1:

    # fk "Only through—"
    fk "ただ――"

# game/script/ch04.rpy:640
translate japanese ch04_e649ada7:

    # "The word broke into a cough."
    "言葉は咳に砕けた。"

# game/script/ch04.rpy:642
translate japanese ch04_11262ec0:

    # "The priest staggered, a hand pressed to his chest. The Bible slipped from his grasp and fell to the dirt."
    "神父はよろめき、片手を胸に押し当てた。聖書が手から滑り落ち、土の上に落ちた。"

# game/script/ch04.rpy:644
translate japanese ch04_d3624e6b:

    # "The bottle tipped, water spilling across the ground. His face twisted, first in confusion, then in pain. He tried to speak. Only a harsh rasp came out."
    "瓶が傾き、水が地面にこぼれた。彼の顔が歪んだ。最初は困惑に、それから苦痛に。何か言おうとした。出てきたのは、しわがれた音だけだった。"

# game/script/ch04.rpy:645
translate japanese ch04_ef5c8ac0:

    # "Murmurs broke into shouts. He lurched forward, knees buckling, hands clawing briefly at the air."
    "ざわめきが叫び声に変わった。彼は前へよろけ、膝が崩れ、両手が一瞬、宙を掻いた。"

# game/script/ch04.rpy:651
translate japanese ch04_cd0afa32:

    # "His head struck the frozen ground at the edge of the grave."
    "彼の頭が、墓の縁の凍った地面を打った。"

# game/script/ch04.rpy:652
translate japanese ch04_313de43e:

    # "And then he lay still."
    "そして、彼は動かなくなった。"

# game/script/ch04.rpy:658
translate japanese ch04_973aeabf:

    # "For a moment, silence."
    "一瞬、静寂。"

# game/script/ch04.rpy:662
translate japanese ch04_cbe3e9ec:

    # "And then panic erupted. Voices screamed. People pushed back from the grave, some trying to help, others fleeing. The mayor shouted for calm, drowned in the roar."
    "そして、恐慌が噴き出した。声が叫んだ。人々は墓から押し戻り、助けようとする者もいれば、逃げ出す者もいた。町長が落ち着くよう叫んだが、その声は轟きにかき消された。"

# game/script/ch04.rpy:666
translate japanese ch04_5ce0805b:

    # "Samuel stepped forward at once, his coat snapping in the cold wind, shouldering through the scatter of black coats."
    "Samuelはすぐさま前に出た。コートが冷たい風にはためいた。散り散りになる黒いコートの群れを肩で押し分けて進んだ。"

# game/script/ch04.rpy:670
translate japanese ch04_e322d4a0:

    # "His eyes went first to the place where the two girls had stood."
    "彼の目はまず、二人の少女が立っていた場所へ向かった。"

# game/script/ch04.rpy:671
translate japanese ch04_cc539129:

    # "Alice had pulled Emily into her arms, turning her so the girl's face pressed against her shoulder."
    "AliceはEmilyを腕の中に引き寄せ、彼女の顔が自分の肩に押し当たるように向きを変えさせていた。"

# game/script/ch04.rpy:672
translate japanese ch04_55769d63:

    # "Over Emily's shoulder, Alice's eyes were open. Wide open. Calm. Not on the crowd, not on the mayor. On the man on the ground."
    "Emilyの肩越しに、Aliceの目は開いていた。大きく見開かれていた。穏やかに。群衆にでも、町長にでもない。地面に倒れた男に向けられていた。"

# game/script/ch04.rpy:673
translate japanese ch04_b08d0418:

    # th "She's protecting her friend. Keeping her from seeing it. That's all."
    th "友達を守ってるんだ。見せないようにしている。それだけのことだ。"

# game/script/ch04.rpy:674
translate japanese ch04_b0d8a163:

    # th "A kid with more sense than half the adults here."
    th "ここにいる大人の半分より分別のある子供だ。"

# game/script/ch04.rpy:675
translate japanese ch04_5e37d857:

    # "He turned, and pushed toward the grave."
    "彼は向き直り、墓のほうへ押し進んだ。"

# game/script/ch04.rpy:677
translate japanese ch04_6f8e6e18:

    # "He knelt by the priest. The signs were already familiar: sudden collapse, breath stolen, lips darkening faintly."
    "彼は神父のそばに膝をついた。その兆しはもう見慣れたものだった。突然の虚脱、奪われた呼吸、かすかに黒ずんでいく唇。"

# game/script/ch04.rpy:678
translate japanese ch04_e5745df9:

    # th "Yew. Again."
    th "イチイだ。また。"

# game/script/ch04.rpy:680
translate japanese ch04_84a9ab48:

    # note_voice "Priest collapsed after drinking from his bottle. Yew again?"
    note_voice "神父、自分の瓶から飲んだ後に倒れる。またイチイか？"

# game/script/ch04.rpy:681
translate japanese ch04_5f9ba1e6:

    # s "Nobody touches that bottle! Nobody touches anything!"
    s "誰もその瓶に触るな！　何にも触るな！"

# game/script/ch04.rpy:683
translate japanese ch04_b2a121ee:

    # "In the chaos, his gaze caught on Alice."
    "混乱の中で、彼の視線がAliceに引っかかった。"

# game/script/ch04.rpy:685
translate japanese ch04_636f4216:

    # "She had pulled Emily into her arms, turning her so the girl's face pressed against her shoulder. Emily sobbed, muffled in Alice's sweater, unaware of what lay a few feet away."
    "彼女はEmilyを腕の中に引き寄せ、彼女の顔が自分の肩に押し当たるように向きを変えさせていた。EmilyはAliceのセーターに顔を埋めてくぐもった声で泣いていた。数フィート先に何があるのか知らずに。"

# game/script/ch04.rpy:686
translate japanese ch04_b6bcdd41:

    # "Alice's own eyes, however, were wide open."
    "だが、Alice自身の目は大きく見開かれていた。"

# game/script/ch04.rpy:687
translate japanese ch04_c57d0fe0:

    # "Calm."
    "穏やかに。"

# game/script/ch04.rpy:688
translate japanese ch04_9f414474:

    # "Watching."
    "見つめていた。"

translate japanese strings:

    # game/script/ch04.rpy:162
    old "Her hands."
    new "彼女の手。"

    # game/script/ch04.rpy:164
    old "Her voice."
    new "彼女の声。"

    # game/script/ch04.rpy:166
    old "What she isn't saying."
    new "彼女が言わずにいること。"

    # game/script/ch04.rpy:243
    old "Watch the door."
    new "扉を見る。"

    # game/script/ch04.rpy:247
    old "Watch the girl."
    new "少女を見る。"

    # game/script/ch04.rpy:302
    old "Her face."
    new "彼女の顔。"

    # game/script/ch04.rpy:305
    old "Her arm."
    new "彼女の腕。"

    # game/script/ch04.rpy:309
    old "Emily."
    new "Emily。"

    # game/script/ch04.rpy:441
    old "Her glasses."
    new "彼女の眼鏡。"

    # game/script/ch04.rpy:443
    old "The folder."
    new "フォルダー。"

    # game/script/ch04.rpy:445
    old "Her arms."
    new "彼女の両腕。"

    # game/script/ch04.rpy:487
    old "Ask about Clara's last days."
    new "Claraの最後の数日について尋ねる。"

    # game/script/ch04.rpy:499
    old "Ask to see her room."
    new "彼女の部屋を見せてほしいと頼む。"

    # game/script/ch04.rpy:510
    old "Her husband."
    new "彼女の夫。"

    # game/script/ch04.rpy:665
    old "Go to the priest."
    new "神父のもとへ行く。"

    # game/script/ch04.rpy:668
    old "Look for the children."
    new "子供たちを探す。"

