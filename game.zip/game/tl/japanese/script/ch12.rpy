# TODO: Translation updated at 2026-10-11 10:23

# game/script/ch12.rpy:14
translate japanese ch12_e6e054dd:

    # "Helena Markou saw them off from the Petrous' step."
    "Helena MarkouはPetrous家の玄関先で二人を見送った。"

# game/script/ch12.rpy:15
translate japanese ch12_2eeca1fd:

    # "To Samuel, watching from the car, she had the look of a woman doing a thing she had every wish to refuse and no ground on which to."
    "車から見ていたSamuelには、彼女が、断りたくてたまらないのに断る根拠をひとつも持たない女の顔をしているように見えた。"

# game/script/ch12.rpy:18
translate japanese ch12_864a352a:

    # "She had brought the child down herself, the small holdall packed and checked, the coat buttoned."
    "子どもは彼女が自分で連れて下りてきた。小さなボストンバッグは荷を詰めて確かめてあり、コートのボタンも留めてあった。"

# game/script/ch12.rpy:19
translate japanese ch12_f7df340c:

    # "She stood now with one hand on Alice's shoulder in the cold, and the hand stayed there, Samuel saw, past the moment that asked for it."
    "いま彼女は寒さの中で片手をAliceの肩に置いて立っていた。その手は、とSamuelは見て取った、置くべき瞬間を過ぎてもそこに留まっていた。"

# game/script/ch12.rpy:24
translate japanese ch12_3af9cd39:

    # "Holding on past the goodbye. Not comfort. Reluctance, and no cause she could have named to anyone."
    "別れの挨拶を過ぎても離さない手。慰めではない。ためらいだ。それも、誰にも名指しできない理由の。"

# game/script/ch12.rpy:29
translate japanese ch12_70e83667:

    # "He understood the look on her face, because some cornered version of it was on his own."
    "彼女の顔に浮かぶものが彼にはわかった。追い詰められた形で、同じものが彼自身の顔にも浮かんでいたからだ。"

# game/script/ch12.rpy:30
translate japanese ch12_f0d58e54:

    # "A clinician who trusted her own eye above any instrument, who had read something in this child across a dozen warm hours, and could not, on her life, have told a review board what it was."
    "どんな器具よりも自分の目を信じる臨床医。十数時間の温かな対話のなかでこの子に何かを読み取り、それでいて、命を賭けても、それが何なのかを審査委員会に説明することはできなかった。"

# game/script/ch12.rpy:31
translate japanese ch12_e2602313:

    # "So she gave the child over. She had no cause to do otherwise, and every cause to do exactly this: the file, the tragedy, the plain arithmetic of an orphan needing a bed the city had and Greyvale did not."
    "だから彼女は子どもを引き渡した。そうしない理由は何ひとつなく、まさにこうする理由ならすべて揃っていた。ファイル、悲劇、そして身寄りのない子にはベッドが要り、それが市にはあってGreyvaleにはないという、ただの算数。"

# game/script/ch12.rpy:32
translate japanese ch12_5be5faf0:

    # "She crouched once to Alice's level and said something low, the same as she had said at her own door weeks ago."
    "彼女は一度だけAliceの目の高さまでしゃがみ込み、低く何かを言った。何週間も前、自分の家の戸口で言ったのと同じ言葉だった。"

# game/script/ch12.rpy:33
translate japanese ch12_1b191e40:

    # h concerned "You can come to me. Any hour."
    h concerned "私のところに来ていいのよ。いつでも。"

# game/script/ch12.rpy:34
translate japanese ch12_a8804456:

    # a "I will. Thank you, Dr. Markou."
    a "そうします。ありがとうございます、Markou先生。"

# game/script/ch12.rpy:35
translate japanese ch12_ca8cebda:

    # "Alice meant it, or wore meaning it so well that the seam did not show."
    "Aliceは本気でそう言っていた。あるいは、本気であることをあまりに見事に身にまとっていて、継ぎ目が見えなかった。"

# game/script/ch12.rpy:36
translate japanese ch12_2bb46a19:

    # "Then Markou straightened and met Samuel's eyes over the child's head, and held them a beat too long."
    "それからMarkouは身を起こし、子どもの頭越しにSamuelと目を合わせ、一拍長くそのまま見つめた。"

# game/script/ch12.rpy:37
translate japanese ch12_616893ea:

    # "What passed between the two adults was not words and was not comfort."
    "二人の大人のあいだを行き交ったのは、言葉ではなく、慰めでもなかった。"

# game/script/ch12.rpy:38
translate japanese ch12_c6be18d5:

    # "It was the shared, unspeakable, unprovable dread of two people handing something over that they could not name and could not keep."
    "それは、名づけることもできず、手元に留めておくこともできない何かを引き渡す二人の、共有された、口にできない、証明できない恐れだった。"

# game/script/ch12.rpy:39
translate japanese ch12_3490a0f1:

    # h sad "Drive carefully, Detective."
    h sad "運転、気をつけてくださいね、刑事さん。"

# game/script/ch12.rpy:40
translate japanese ch12_dab31f83:

    # "It came out with a weight the words did not carry on their own."
    "その言葉は、言葉そのものが持たない重さを帯びていた。"

# game/script/ch12.rpy:42
translate japanese ch12_3030d9bd:

    # th "Weeks ago I led with the only question that mattered to her. Was the girl safe in that house. Neither of us has asked the other one."
    th "何週間か前、俺は彼女にとって唯一大事な問いから切り出した。あの子はあの家で安全なのか。もう一方の問いは、どちらも口にしていない。"

# game/script/ch12.rpy:43
translate japanese ch12_b63d7cb6:

    # s tired "Always do."
    s tired "いつも気をつけていますよ。"

# game/script/ch12.rpy:44
translate japanese ch12_37b4e846:

    # "He did not look at her while he said it. She read faces the way he did, and he had one truth in him now that he could not let even her see."
    "そう言うあいだ、彼は彼女を見なかった。彼女も彼と同じように顔を読む。そして彼のなかにはいま、彼女にさえ見せるわけにいかない真実がひとつあった。"

# game/script/ch12.rpy:56
translate japanese ch12_b0515c57:

    # "They left Greyvale a little after two on a gray Thursday, the sky low and heavy with the snow it had not yet decided to drop."
    "二人がGreyvaleを発ったのは灰色の木曜日の二時過ぎだった。空は低く、降らせるかどうかまだ決めかねている雪を重く抱えていた。"

# game/script/ch12.rpy:57
translate japanese ch12_844c0b00:

    # "For the first twenty minutes neither of them said anything at all."
    "最初の二十分、二人ともひと言も口をきかなかった。"

# game/script/ch12.rpy:59
translate japanese ch12_e828f082:

    # "Alice sat in the passenger seat with a small bag at her feet, everything the world had left her folded into a canvas holdall a caseworker had packed."
    "Aliceは助手席に座り、足元に小さな鞄を置いていた。世界が彼女に残したもののすべてが、ケースワーカーの詰めた帆布のボストンバッグに畳まれて収まっていた。"

# game/script/ch12.rpy:60
translate japanese ch12_6f6e8e16:

    # "She was, in every particular the eye could catch, exactly what she appeared to be: a child being taken away from the only place she knew, by a tired man with a bruised face who was the nearest thing to a friend she had left."
    "目に捉えうるあらゆる点において、彼女はまさに見たとおりのものだった。知っている唯一の場所から連れ去られていく子ども。連れていくのは、痣の残る顔をした疲れた男で、彼女に残された、友人と呼べるものにいちばん近い存在だった。"

# game/script/ch12.rpy:61
translate japanese ch12_5d6f97ff:

    # "The heater ticked. The wipers stood idle against a windshield the snow kept threatening and withholding."
    "ヒーターがカチカチと鳴った。ワイパーは止まったまま、雪が降りそうでいて降らないフロントガラスに張りついていた。"

# game/script/ch12.rpy:62
translate japanese ch12_04df69ab:

    # "Route Nine unspooled ahead of them, cliff wall rising on the left, the gorge falling away on the right. The same road they had carried George down four days before."
    "Route Nineが前方にほどけていった。左には崖の壁がそそり立ち、右には峡谷が落ち込んでいる。四日前、Georgeを運んで下ったのと同じ道だった。"

# game/script/ch12.rpy:63
translate japanese ch12_b1e6ac2d:

    # "Samuel drove it carefully, both hands on the wheel, and did not look at the girl beside him any more than a man drives past a thing he is afraid of."
    "Samuelは慎重に運転した。両手でハンドルを握り、隣の少女のほうは見なかった。怖いものの横を車で通り過ぎる男が、それを見ないのと同じくらいに。"

# game/script/ch12.rpy:67
translate japanese ch12_c70f04ab:

    # "The pinch came up on them about eleven miles down, where the cliff wall crowded in and the guardrail on the gorge side ran out into thirty yards of nothing."
    "十一マイルほど下ったところで、隘路が迫ってきた。崖の壁がせり出し、峡谷側のガードレールが途切れて、三十ヤードの何もない空間になる場所だ。"

# game/script/ch12.rpy:68
translate japanese ch12_1c612422:

    # "Samuel felt his hands tighten on the wheel a half-second before his mind had caught up with why."
    "理由に頭が追いつく半秒前に、ハンドルを握る手に力がこもるのをSamuelは感じた。"

# game/script/ch12.rpy:69
translate japanese ch12_3c859d02:

    # "He had stood in it four nights ago with the sleet in his collar and a torch in his hand. Now he had to drive through it at forty miles an hour with the thing that had made it sitting a foot from his elbow."
    "四晩前、彼はそこに立っていた。襟元にみぞれを受け、懐中電灯を手にして。いま彼はそこを時速四十マイルで通り抜けなければならなかった。それを作り出したものを、肘から一フィートのところに座らせたまま。"

# game/script/ch12.rpy:70
translate japanese ch12_5b7043ca:

    # "The snow had been kind to it, the way snow is kind to everything. A thin skin of white over the churned ground, softening the ruts the crowd's boots had cut."
    "雪はそこに優しかった。雪が何にでも優しいように。掘り返された地面に白く薄い膜がかかり、群衆の靴が刻んだ轍をやわらげていた。"

# game/script/ch12.rpy:71
translate japanese ch12_699b33c0:

    # "But under the white, in one long patch below the broken rail, the ground showed through darker. A stain the frost had set into the earth like dye into cloth, spread the way a spilled thing spreads."
    "だが白の下、壊れたガードレールの下の細長い一帯で、地面が黒っぽく透けていた。布に染料が染み込むように、霜が土に定着させた染み。こぼれたものが広がるように広がっていた。"

# game/script/ch12.rpy:72
translate japanese ch12_a6a2e178:

    # "A man's whole finish, printed on a roadside, and four days of weather had not been enough to lift it out."
    "一人の男の最期のすべてが道端に刷り込まれ、四日間の天候もそれを抜き去ることはできなかった。"

# game/script/ch12.rpy:73
translate japanese ch12_8850416d:

    # "Samuel made his face do nothing, and he did not slow down, because to slow down was to say a thing aloud in a car where he had decided to say nothing at all."
    "Samuelは顔に何もさせなかった。速度も落とさなかった。速度を落とせば、何も言わないと決めた車内で、何かを声に出して言うことになるからだ。"

# game/script/ch12.rpy:77
translate japanese ch12_9b7d4414:

    # "He kept his eyes on the white line and the broken rail and let the place go by him, and did not give himself the test."
    "彼は白線と壊れたガードレールに目を据えたまま、その場所が通り過ぎていくに任せ、自分にその試しを課さなかった。"

# game/script/ch12.rpy:78
translate japanese ch12_0ffe35c5:

    # "But he felt her head turn beside him, all the same. He felt it the way you feel a draught."
    "それでも、隣で彼女の頭が向きを変えるのは感じた。隙間風を感じるように、それを感じた。"

# game/script/ch12.rpy:82
translate japanese ch12_126ec1e3:

    # "He caught it in the edge of his eye and hated himself for looking for it. It was the only test he had left that she could not see him giving."
    "彼は視界の端でそれを捉え、それを探した自分を憎んだ。彼女に気づかれずに課せる試しは、もうそれしか残っていなかった。"

# game/script/ch12.rpy:83
translate japanese ch12_43a2dc73:

    # "Her head turned as the pinch went by. Her eyes went to the broken rail and down to the dark patch under it, and rested there, unhurried."
    "隘路が過ぎていくとき、彼女の頭がそちらを向いた。目は壊れたガードレールへ、それからその下の黒ずんだ一帯へと移り、急ぐでもなくそこに留まった。"

# game/script/ch12.rpy:84
translate japanese ch12_29f96515:

    # "The way a passenger's eyes rest on any mildly interesting thing at the side of a road. A stalled car. A dead deer. A view."
    "乗客の目が、道端の少しばかり興味を引くものに留まるように。エンストした車。死んだ鹿。景色。"

# game/script/ch12.rpy:85
translate japanese ch12_4563dfbf:

    # "No flinch. No held breath, no quick glance away, no small performance of a child not-looking at something frightening."
    "たじろぎもない。息を詰めることも、さっと目を逸らすこともない。怖いものを見ないようにする子どもの、ささやかな演技もない。"

# game/script/ch12.rpy:86
translate japanese ch12_6499220e:

    # "Only a mild, clean attention, held for a moment and then released."
    "ただ穏やかで澄んだ注意が、一瞬向けられ、そして解かれただけだった。"

# game/script/ch12.rpy:87
translate japanese ch12_bd8ca5aa:

    # th "Kids go strange. Kids go numb. You know that."
    th "子どもはおかしくなる。子どもは麻痺する。知ってるだろう。"

# game/script/ch12.rpy:88
translate japanese ch12_03ca9b74:

    # "He knew that. He also knew it was not what he had just seen."
    "それは知っていた。そして、いま自分が見たものがそれではないことも知っていた。"

# game/script/ch12.rpy:90
translate japanese ch12_92deb0cc:

    # "Then she was watching the mountains again, and the place where a man had been pulled apart on her account slid off behind them and became road."
    "それから彼女はまた山並みを眺めていた。彼女のせいで一人の男が引き裂かれた場所は、二人の背後へと滑り去り、ただの道になった。"

# game/script/ch12.rpy:91
translate japanese ch12_6f0aba3c:

    # "Her face through all of it had stayed exactly as smooth as the snow."
    "そのあいだずっと、彼女の顔は雪とまったく同じくらい滑らかなままだった。"

# game/script/ch12.rpy:93
translate japanese ch12_096bac16:

    # note_voice "Route Nine. She looked at it like a view."
    note_voice "Route Nine。景色を見るように見ていた。"

# game/script/ch12.rpy:97
translate japanese ch12_bccdbd56:

    # "He knew what she was. He had spent two sleepless nights arriving at it, and he carried it now in the car like a live round in a chamber."
    "彼女が何者か、彼は知っていた。眠れない二晩を費やしてそこに辿り着き、いまそれを、薬室に込めた実弾のように車内に抱えていた。"

# game/script/ch12.rpy:98
translate japanese ch12_4199c735:

    # "He had made himself a plan: watch her, learn her, and somewhere in the four hours down to the city decide what a man does with a truth he cannot prove, and cannot say, and cannot, God help him, un-know."
    "彼は自分に計画を立てていた。彼女を見張り、彼女を知り、市までの四時間の下り道のどこかで決める。証明できず、口にもできず、そして――神よ――知らなかったことにもできない真実を、人はどうするのかを。"

# game/script/ch12.rpy:99
translate japanese ch12_73f62a8d:

    # "That was the plan. It lasted, more or less, until she spoke."
    "それが計画だった。それは、おおよそ、彼女が口を開くまでしかもたなかった。"

# game/script/ch12.rpy:100
translate japanese ch12_eada7654:

    # a "You don't have to be careful with me, Detective."
    a "私に気をつかわなくていいんですよ、刑事さん。"

# game/script/ch12.rpy:101
translate japanese ch12_9ded3777:

    # a "Everyone's been so careful. You can just talk. I'd like it if someone just talked."
    a "みんな、すごく気をつかってくれて。ただ話してくれればいいんです。誰かがただ話してくれたら、うれしいです。"

# game/script/ch12.rpy:102
translate japanese ch12_7848250c:

    # "It was so exactly the thing a lonely grieving child would say, in a voice with such an ordinary small weariness in it, that Samuel felt the live round shift in the chamber."
    "それはあまりにも、寂しく悲しみに沈んだ子どもが言いそうなことそのままで、その声にはあまりにありふれた小さな疲れがにじんでいたので、Samuelは薬室の実弾がずれるのを感じた。"

# game/script/ch12.rpy:103
translate japanese ch12_8754a150:

    # "His certainty of two nights bent, just slightly, like a straight stick put into water."
    "二晩かけた確信が、ほんの少し曲がった。水に差し入れたまっすぐな棒のように。"

# game/script/ch12.rpy:108
translate japanese ch12_bdbee561:

    # "He had interrogated killers who could not do what she did."
    "彼女がしたことをできない殺人者を、彼は何人も取り調べてきた。"

# game/script/ch12.rpy:109
translate japanese ch12_fdbc5afb:

    # "A comment about the snow. A question about the city. An observation so bright and so sideways that he answered it before he thought, and then another, and another."
    "雪についてのひと言。市についての質問。あまりに聡く、あまりに思いがけない角度からの観察に、彼は考えるより先に答え、そしてまた次、また次と答えた。"

# game/script/ch12.rpy:110
translate japanese ch12_5c7c84a5:

    # "Until without deciding to he was talking, and the car had become a warm place with two people in it instead of a rolling cell."
    "やがて、そうと決めたわけでもなく彼は話していた。車は、走る監房ではなく、二人の人間が乗った温かな場所になっていた。"

# game/script/ch12.rpy:111
translate japanese ch12_130fb109:

    # "Not one of the men he'd sat across steel tables from could have done what this twelve-year-old was doing without lifting her voice above the heater: taking a hard, closed, forty-seven-year-old man and, mile by mile, opening him."
    "鋼のテーブルを挟んで向き合ってきた男たちの誰ひとりとして、この十二歳がしていることはできなかっただろう。ヒーターの音より声を高めることもなく、硬く閉ざした四十七歳の男を、一マイルごとに開いていくことなど。"

# game/script/ch12.rpy:112
translate japanese ch12_4e8c16c1:

    # "He tried, in the first hour, to run it the other way. That was his trade, and he was not going to be gutted like a trout by a seventh-grader without at least putting a line in the water himself."
    "最初の一時間、彼は逆に回そうとした。それが彼の生業だった。七年生に鱒のようにはらわたを抜かれるのなら、せめて自分でも水に糸を垂らしてからにするつもりだった。"

# game/script/ch12.rpy:113
translate japanese ch12_a19dd1f6:

    # s neutral "Driftwood. What do you remember of it? The village. The sea."
    s neutral "Driftwood。何を覚えてる？村のこと。海のこと。"

# game/script/ch12.rpy:114
translate japanese ch12_3b82f4a6:

    # a "Salt in everything. A gray church. My father's hands."
    a "何にでも塩がついていました。灰色の教会。父の手。"

# game/script/ch12.rpy:115
translate japanese ch12_68326d17:

    # a "And a cold that lived in the walls."
    a "それと、壁の中に住んでいる寒さ。"

# game/script/ch12.rpy:116
translate japanese ch12_37e86774:

    # "All of it true, he was sure, and all of it nothing. A handful of pretty stones held out to a man panning for gold."
    "どれも本当なのだろう、と彼は確信していた。そしてどれも無意味だった。砂金を探す男に差し出された、ひと握りのきれいな石ころ。"

# game/script/ch12.rpy:117
translate japanese ch12_92c29562:

    # a smile "Did you grow up near the sea, Detective? Did you love it, or were you afraid of it?"
    a smile "刑事さんは海の近くで育ったんですか？海が好きでした？それとも怖かった？"

# game/script/ch12.rpy:118
translate japanese ch12_052d9c3a:

    # "He was halfway into an answer about a childhood he never discussed before he shut his mouth."
    "決して人に話したことのない子ども時代について半分ほど答えかけたところで、彼は口を閉じた。"

# game/script/ch12.rpy:119
translate japanese ch12_708c7d8a:

    # "And beside him, he could have sworn, something was quietly, warmly amused."
    "そして隣で、何かが静かに、温かく面白がっていた。そう誓ってもよかった。"

# game/script/ch12.rpy:120
translate japanese ch12_3b66a613:

    # s neutral "Was the winter hard on you? The funerals. The fear in the town."
    s neutral "この冬はつらかったか？葬式。町の恐怖。"

# game/script/ch12.rpy:121
translate japanese ch12_ca23be2d:

    # a neutral "Of course. Everyone was frightened."
    a neutral "もちろんです。みんな怖がっていました。"

# game/script/ch12.rpy:122
translate japanese ch12_8f4e0dd9:

    # a "Isn't it strange, how frightened people turn cruel? How they need someone to blame. Have you seen that, in your work? How fear takes ordinary people and makes them into something worse?"
    a "不思議じゃないですか、怖がっている人たちが残酷になるのって。誰かを責めずにはいられなくなる。お仕事で、そういうのを見たことありますか？恐怖が普通の人たちを、もっとひどいものに変えてしまうのを。"

# game/script/ch12.rpy:123
translate japanese ch12_3b806efb:

    # "And he had. God knew he had. He had watched it kill a man in a road four days back."
    "見たことはあった。神のみぞ知る、いやというほど見てきた。四日前、それが道の上で一人の男を殺すのを見た。"

# game/script/ch12.rpy:124
translate japanese ch12_35c5baed:

    # "He was three sentences into agreeing with her, into being understood by her, before he heard what had happened."
    "彼女に同意し、彼女に理解されることに三文ほど言葉を費やしてから、彼は何が起きたのかに気づいた。"

# game/script/ch12.rpy:125
translate japanese ch12_29344e11:

    # "She had lifted his own probe out of his hands and set it back in them as a gift."
    "彼女は彼自身の探り針を彼の手から取り上げ、贈り物として彼の手に戻したのだ。"

# game/script/ch12.rpy:126
translate japanese ch12_49133263:

    # "Twice more he cast, and twice more she simply was not where the hook came down."
    "さらに二度、彼は糸を投げた。そして二度とも、針が落ちた場所に彼女はいなかった。"

# game/script/ch12.rpy:127
translate japanese ch12_2c6b647d:

    # "Somewhere past the second hour he stopped. Not beaten. Because he had understood a thing that chilled him worse than her cleverness."
    "二時間を過ぎたあたりで、彼はやめた。負けたからではない。彼女の賢さよりもっと彼を凍えさせることに気づいたからだ。"

# game/script/ch12.rpy:128
translate japanese ch12_66936e4f:

    # "She was enjoying it. Not cruelly. The way a gifted child enjoys the rare pleasure of a game played against someone who can nearly keep up."
    "彼女は楽しんでいた。残酷にではない。才能のある子どもが、ほとんどついてこられる相手とのゲームという稀な喜びを楽しむように。"

# game/script/ch12.rpy:129
translate japanese ch12_3cc4d0a1:

    # "Because she found the wound. Of course she found the wound; she had found it weeks ago, across a notebook, and she had a map of it now."
    "なぜなら彼女は傷を見つけたからだ。もちろん見つけた。何週間も前、手帳越しに見つけていて、いまではその地図まで持っていた。"

# game/script/ch12.rpy:130
translate japanese ch12_5baf23fb:

    # "Not asking. Never asking. Only leaving small warm openings a lonelier man than he wanted to admit he was could not help but step into."
    "訊くのではない。決して訊かない。ただ小さく温かい入口を残しておくだけだ。彼が認めたいよりも孤独な男なら、踏み込まずにはいられない入口を。"

# game/script/ch12.rpy:131
translate japanese ch12_57b7a3b9:

    # a "Were you ever married, Detective?"
    a "結婚されていたことはありますか、刑事さん？"

# game/script/ch12.rpy:132
translate japanese ch12_348b608b:

    # s tired "Long time ago."
    s tired "ずっと昔に。"

# game/script/ch12.rpy:133
translate japanese ch12_4cdf8083:

    # a "Children?"
    a "お子さんは？"

# game/script/ch12.rpy:137
translate japanese ch12_2813e18d:

    # s neutral "No—"
    s neutral "いや――"

# game/script/ch12.rpy:138
translate japanese ch12_c1327c44:

    # "It was the professional answer, and the safe one, and the true-enough one. He had it in his mouth."
    "それが職業上の答えであり、安全な答えであり、十分に本当の答えだった。口の中まで出かかっていた。"

# game/script/ch12.rpy:139
translate japanese ch12_f6a08675:

    # "And then the road bent, and bent again, and a third time, and the silence lasted all three curves, and it would not hold."
    "そのとき道が曲がり、また曲がり、三度目に曲がった。沈黙はその三つのカーブのあいだずっと続き、持ちこたえなかった。"

# game/script/ch12.rpy:140
translate japanese ch12_d8057c6f:

    # s hurt "...One. A long time ago. He didn't— he wasn't with us long."
    s hurt "……一人。ずっと昔に。あの子は――長くは一緒にいられなかった。"

# game/script/ch12.rpy:142
translate japanese ch12_ae50af9f:

    # "He should have said no. It was the professional answer and the safe one."
    "いない、と言うべきだった。それが職業上の答えであり、安全な答えだった。"

# game/script/ch12.rpy:143
translate japanese ch12_1f00d148:

    # "He heard himself, instead, after a silence that lasted three curves of the road, say it."
    "だが代わりに、道の三つのカーブのあいだ続いた沈黙のあとで、自分がそれを口にするのを彼は聞いた。"

# game/script/ch12.rpy:144
translate japanese ch12_a6fa55ec:

    # s hurt "One. A long time ago. He didn't— he wasn't with us long."
    s hurt "一人。ずっと昔に。あの子は――長くは一緒にいられなかった。"

# game/script/ch12.rpy:146
translate japanese ch12_bf15c76d:

    # "He felt her attention change. Not sharpen. Soften, or seem to."
    "彼女の注意が変わるのを彼は感じた。鋭くなったのではない。やわらいだ。あるいは、そう見えた。"

# game/script/ch12.rpy:147
translate japanese ch12_526992fe:

    # a sad "I'm sorry."
    a sad "お気の毒です。"

# game/script/ch12.rpy:148
translate japanese ch12_a623b0e1:

    # "She let a mile go by."
    "彼女は一マイルをやり過ごした。"

# game/script/ch12.rpy:149
translate japanese ch12_8784e0e5:

    # a sad "Is that why you were kind to me? At the funeral. In the car, before."
    a sad "だから私に優しくしてくれたんですか？お葬式のとき。前に、車の中で。"

# game/script/ch12.rpy:150
translate japanese ch12_d7cbd445:

    # "A pause weighted like a stone dropped down a well."
    "井戸に落とした石のように重みのある間。"

# game/script/ch12.rpy:151
translate japanese ch12_c48e86f3:

    # a sad "Because you know what it is. To have the one that's yours taken."
    a sad "知っているから。自分のものを奪われるのがどういうことか。"

# game/script/ch12.rpy:152
translate japanese ch12_9a0e99c5:

    # "There it was: the hook set so gently he'd swallowed it before he felt the barb."
    "そこにあった。あまりにそっと掛けられた釣り針。返しを感じる前に、彼は呑み込んでいた。"

# game/script/ch12.rpy:153
translate japanese ch12_98313a4a:

    # "He understood, coldly, in the part of him that never slept, exactly what was being done to him and by whom."
    "決して眠らない彼のなかの一部で、彼は冷ややかに理解した。自分に何が、誰によってなされているのかを、正確に。"

# game/script/ch12.rpy:154
translate japanese ch12_08f1a3e7:

    # "And understood in the same instant that it changed nothing. The thing she was reaching for was real, and you cannot armor a wound by naming the hand that presses it."
    "そして同じ瞬間に、それが何ひとつ変えないことも理解した。彼女が手を伸ばしているものは本物で、傷を押さえつける手に名をつけたところで、傷に鎧を着せることはできない。"

# game/script/ch12.rpy:159
translate japanese ch12_1b69e9c9:

    # "They came down through the pines into the long middle stretch of the road, the gorge deepening beside them."
    "二人は松林を抜けて道の長い中間部へと下った。傍らで峡谷が深まっていった。"

# game/script/ch12.rpy:160
translate japanese ch12_ee69dcaf:

    # a "What's it like? The city. Where you're taking me."
    a "どんなところですか？市って。私を連れていくところ。"

# game/script/ch12.rpy:161
translate japanese ch12_17070971:

    # a "I've never been. George never took me anywhere. Are the people— are they kind, mostly? In a big place like that. Where nobody knows you and you don't know them."
    a "行ったことがないんです。Georgeはどこにも連れていってくれなかったから。そこの人たちは――だいたい優しいですか？あんなに大きなところで。誰も私を知らなくて、私も誰も知らないところで。"

# game/script/ch12.rpy:162
translate japanese ch12_823ea73a:

    # "Samuel knew exactly what that city did with children who arrived in it unclaimed. He did not want to answer, and made himself."
    "引き取り手のないまま辿り着いた子どもたちを、あの市がどう扱うか、Samuelは正確に知っていた。答えたくはなかったが、自分に答えさせた。"

# game/script/ch12.rpy:163
translate japanese ch12_7a72551f:

    # s neutral "It's big. It's easy to be nobody in. That cuts both ways."
    s neutral "大きいところだ。誰でもない者になりやすい。それは良くも悪くもある。"

# game/script/ch12.rpy:164
translate japanese ch12_c57f56d2:

    # s "Nobody knowing you means nobody watching out for you. But it means nobody's already decided what you are, either. You'd get to start clean. New school, new faces, none of this following you in."
    s "誰も君を知らないってことは、誰も君を見守ってくれないってことだ。でも、君が何者かを先に決めつけている人間もいないってことでもある。まっさらからやり直せる。新しい学校、新しい顔。ここのことは何もついてこない。"

# game/script/ch12.rpy:165
translate japanese ch12_1cc65fce:

    # s soft "There's good people in it. You just have to find them. Same as anywhere."
    s soft "いい人間もいる。見つければいい。どこでも同じだ。"

# game/script/ch12.rpy:166
translate japanese ch12_4d0887d9:

    # "He heard himself selling it, the way you sell a hard thing to a child, and believed the half of it that was kind."
    "子どもに厳しいことを売り込むときのように、自分がそれを売り込んでいるのを彼は聞いた。そしてそのうちの優しい半分だけを信じた。"

# game/script/ch12.rpy:167
translate japanese ch12_190f70a4:

    # a "A whole city of people who don't know me yet."
    a "街じゅう、まだ私を知らない人ばかり。"

# game/script/ch12.rpy:168
translate japanese ch12_97ed78ea:

    # "Something in the way she said it. The small satisfaction in it, turned over and set down, private and pleased, like a door she had found unlocked."
    "その言い方の何か。そこに含まれた小さな満足。裏返して眺め、そっと置かれた、ひそやかで嬉しげなもの。鍵の掛かっていない扉を見つけたときのような。"

# game/script/ch12.rpy:169
translate japanese ch12_cfff8460:

    # "The fine hairs stood along Samuel's arms for a reason he did not, in the moment, let himself chase."
    "Samuelの腕の産毛が逆立った。その理由を、その瞬間の彼は追いかけようとしなかった。"

# game/script/ch12.rpy:171
translate japanese ch12_2f760a91:

    # "Then she smiled a small tired child's smile at the glass, and it was gone, and she was only a lonely girl looking down the road at a frightening new place."
    "それから彼女は窓ガラスに向かって、疲れた子どもの小さな笑みを浮かべた。それは消え、彼女はただ、恐ろしい新しい場所へと続く道の先を見つめる、寂しい少女になった。"

# game/script/ch12.rpy:172
translate japanese ch12_26a391ab:

    # th "That's all it ever was."
    th "それだけのことだ。いつだって。"

# game/script/ch12.rpy:174
translate japanese ch12_c595bfcf:

    # a "Can I ask you something, and you'll tell me the truth? Everyone tells me the soft version. You don't, I think. I think you're the only one who wouldn't."
    a "ひとつ訊いてもいいですか。本当のことを教えてくれますか？みんな、私にはやわらかい言い方しかしないんです。刑事さんはしないと思う。しないのは刑事さんだけだと思います。"

# game/script/ch12.rpy:175
translate japanese ch12_9d69eaea:

    # s "Ask."
    s "訊いてごらん。"

# game/script/ch12.rpy:176
translate japanese ch12_2fe28794:

    # a "Did my grandfather do those things?"
    a "祖父は、ああいうことをしたんですか？"

# game/script/ch12.rpy:177
translate japanese ch12_a9f68dca:

    # a "They say he did. Everyone says he did, and then he died, and now it's like it was never even a question. But you were there. You know more than anyone."
    a "みんな、したって言います。みんながしたって言って、それから祖父は死んで、いまではもう、最初から疑問ですらなかったみたいになってる。でも刑事さんはその場にいました。誰よりも知っているはずです。"

# game/script/ch12.rpy:178
translate japanese ch12_57d695f8:

    # "She turned her head then, and her gray eyes were on the side of his face, patient, waiting."
    "そのとき彼女は顔を向けた。灰色の目が彼の横顔に注がれていた。辛抱強く、待っていた。"

# game/script/ch12.rpy:179
translate japanese ch12_fbdd91a2:

    # a "Did George kill those people?"
    a "Georgeがあの人たちを殺したんですか？"

# game/script/ch12.rpy:181
translate japanese ch12_436f4b45:

    # "Samuel Harris had the receipt and the nineteen seconds of tape locked in his room, and the whole ruinous truth locked in his chest."
    "Samuel Harrisは、レシートと十九秒の映像を部屋に鍵を掛けてしまい込み、破滅的な真実のすべてを胸に閉じ込めていた。"

# game/script/ch12.rpy:182
translate japanese ch12_17626d41:

    # "He drove down a mountain road beside the girl who had done it, and could not, for a long moment, make a sound."
    "それをやった少女の隣で山道を下りながら、彼は長いあいだ、声ひとつ出せなかった。"

# game/script/ch12.rpy:183
translate japanese ch12_08baaf4c:

    # "It was not a question. It was a test. She was reading him the way he was reading her, learning exactly how much the last dangerous man in her life knew."
    "それは質問ではなかった。試しだった。彼が彼女を読んでいるのと同じように、彼女も彼を読んでいた。自分の人生に残った最後の危険な男が、正確にどこまで知っているのかを探っていた。"

# game/script/ch12.rpy:184
translate japanese ch12_d531eafc:

    # "And it was also, in the same breath, a real child asking after her dead grandfather. The mask and the face grown so wholly into one another that he did not think even she could have found the seam."
    "そして同じ息のなかで、それは死んだ祖父のことを尋ねる本物の子どもでもあった。仮面と素顔があまりにすっかり互いに溶け合っていて、彼女自身にさえ継ぎ目は見つけられないだろうと彼は思った。"

# game/script/ch12.rpy:188
translate japanese ch12_e399cc4b:

    # s tired "I don't know."
    s tired "わからない。"

# game/script/ch12.rpy:189
translate japanese ch12_8a8fc109:

    # "He said it at last, carefully. It was the first lie he had told her, and it cost him."
    "ようやく、慎重に彼はそう言った。それは彼が彼女についた最初の嘘で、その嘘は彼に高くついた。"

# game/script/ch12.rpy:190
translate japanese ch12_f39d1eed:

    # s tired "There are things about it that don't sit right with me. That's the truth. There are things I'm still trying to understand."
    s tired "腑に落ちないところがある。それは本当だ。まだ理解しようとしていることがある。"

# game/script/ch12.rpy:191
translate japanese ch12_47555c09:

    # "Something moved behind the gray eyes. He watched for it and he saw it: the flicker, for a hair of a second, of a mind adjusting, recalculating, filing away a new and important fact."
    "灰色の目の奥で何かが動いた。彼はそれを待ち構え、そして見た。髪の毛一本ほどの一瞬、頭脳が調整し、計算し直し、新しく重要な事実を綴じ込むときのちらつきを。"

# game/script/ch12.rpy:192
translate japanese ch12_70589060:

    # "Then it was gone before he could read it."
    "それから、彼が読み取る前にそれは消えた。"

# game/script/ch12.rpy:196
translate japanese ch12_bd73a88a:

    # s stern "N—"
    s stern "違――"

# game/script/ch12.rpy:197
translate japanese ch12_d3be9f16:

    # "The truth got as far as his teeth. He felt the shape of it, and heard where it would go, and swallowed it."
    "真実は歯のところまで来た。彼はその形を感じ、それがどこへ行き着くかを聞き取り、呑み込んだ。"

# game/script/ch12.rpy:198
translate japanese ch12_93226b86:

    # s tired "...I don't know."
    s tired "……わからない。"

# game/script/ch12.rpy:199
translate japanese ch12_a79be44b:

    # "It was the first lie he had told her, and it cost him."
    "それは彼が彼女についた最初の嘘で、その嘘は彼に高くついた。"

# game/script/ch12.rpy:200
translate japanese ch12_f39d1eed_1:

    # s tired "There are things about it that don't sit right with me. That's the truth. There are things I'm still trying to understand."
    s tired "腑に落ちないところがある。それは本当だ。まだ理解しようとしていることがある。"

# game/script/ch12.rpy:202
translate japanese ch12_37e3e033:

    # "Something moved behind the gray eyes, and this time he saw it whole. The flicker of a mind that had heard the swallowed word and weighed it, and was filing it away beside everything else she knew of him."
    "灰色の目の奥で何かが動いた。今度はその全体が見えた。呑み込まれた言葉を聞き取って量り、彼について知っているほかのすべての事柄の隣にそれを綴じ込む頭脳の、ちらつき。"

# game/script/ch12.rpy:203
translate japanese ch12_02c07b3b:

    # th "She's twelve. She heard a man stumble over her grandfather. That's all."
    th "十二歳だぞ。祖父のことで男が言葉に詰まるのを聞いた。それだけだ。"

# game/script/ch12.rpy:205
translate japanese ch12_04ec30ad:

    # "He said nothing. The road said nothing. The heater ticked, and the silence stretched until it was its own answer, and he could not let it be that."
    "彼は何も言わなかった。道も何も言わなかった。ヒーターがカチカチと鳴り、沈黙はそれ自体が答えになるまで引き伸ばされ、彼はそれをそのままにしておけなかった。"

# game/script/ch12.rpy:206
translate japanese ch12_e399cc4b_1:

    # s tired "I don't know."
    s tired "わからない。"

# game/script/ch12.rpy:207
translate japanese ch12_a79be44b_1:

    # "It was the first lie he had told her, and it cost him."
    "それは彼が彼女についた最初の嘘で、その嘘は彼に高くついた。"

# game/script/ch12.rpy:208
translate japanese ch12_f39d1eed_2:

    # s tired "There are things about it that don't sit right with me. That's the truth. There are things I'm still trying to understand."
    s tired "腑に落ちないところがある。それは本当だ。まだ理解しようとしていることがある。"

# game/script/ch12.rpy:209
translate japanese ch12_0f8dba6b:

    # "Something moved behind the gray eyes: the flicker, for a hair of a second, of a mind adjusting. Then it was gone."
    "灰色の目の奥で何かが動いた。髪の毛一本ほどの一瞬の、調整する頭脳のちらつき。それから消えた。"

# game/script/ch12.rpy:213
translate japanese ch12_a27641f3:

    # "Her lip trembled, and she looked back at the road."
    "彼女の唇が震え、彼女は道へと視線を戻した。"

# game/script/ch12.rpy:214
translate japanese ch12_690304b7:

    # a cry "I hope he didn't. I know I'm not supposed to. But he was all I had, and I hope he didn't."
    a cry "してないといいなって思います。そう思っちゃいけないのはわかってます。でも、祖父しかいなかったから。してないといいなって。"

# game/script/ch12.rpy:215
translate japanese ch12_7114494f:

    # "And Samuel felt his two-night certainty thin to nothing. Become absurd, monstrous, the fever-dream of a broken man."
    "そしてSamuelは、二晩かけた確信が薄れて無になるのを感じた。馬鹿げたもの、おぞましいもの、壊れた男の熱に浮かされた夢になるのを。"

# game/script/ch12.rpy:216
translate japanese ch12_beb55958:

    # th "Look at her. She is twelve and her hands are folded and she is crying for a dead man, and you have built a serial killer out of a schoolgirl because you could not bear to have failed."
    th "見ろ。十二歳で、両手を組んで、死んだ男のために泣いてる。お前は、失敗したことに耐えられないばかりに、女子生徒から連続殺人鬼をこしらえ上げたんだ。"

# game/script/ch12.rpy:217
translate japanese ch12_58ea73ef:

    # "For one long stretch of white road Samuel Harris very nearly, with something close to relief, believed her."
    "白い道の長い一区間のあいだ、Samuel Harrisは、安堵にも近い何かとともに、ほとんど彼女を信じかけた。"

# game/script/ch12.rpy:218
translate japanese ch12_bd14e98d:

    # "Not the fact of it. The fact was locked in his hotel room, and no weeping child on earth could touch that. It was the meaning of the fact that thinned."
    "事実を、ではない。事実はホテルの部屋に鍵を掛けてしまってあり、地上のどんな泣く子もそれには触れられなかった。薄れたのは、事実の意味のほうだった。"

# game/script/ch12.rpy:219
translate japanese ch12_8e677065:

    # "It was not the reason failing. It was the reason drowning, quietly, in the ordinary flood of a human being in the next seat."
    "理屈が崩れたのではなかった。理屈が、隣の座席にいる一人の人間という、ありふれた洪水のなかで、静かに溺れていったのだ。"

# game/script/ch12.rpy:220
translate japanese ch12_42e2ce6e:

    # "And she knew it. It was the whole of her method, worked now on him as it had been worked on a teacher and a shopkeeper and a lonely girl with a diary."
    "そして彼女はそれを知っていた。それが彼女の方法のすべてだった。教師に、店主に、日記をつけていた孤独な少女に使ったのと同じ方法が、いま彼に使われていた。"

# game/script/ch12.rpy:221
translate japanese ch12_7b63e8e0:

    # "Get close, and stay close, and be warm and near, until the person beside her could no longer believe of her the thing that was true."
    "近づき、そばに居続け、温かく寄り添う。隣にいる人間が、彼女についての本当のことを、もう信じられなくなるまで。"

# game/script/ch12.rpy:228
translate japanese ch12_8fb255ba:

    # "For a while, then, they did not talk at all, and the not-talking was worse than the talk."
    "それからしばらく、二人はまったく話さなかった。話さないことは、話すことより悪かった。"

# game/script/ch12.rpy:229
translate japanese ch12_0f9a602d:

    # "The light went from gray to a deep failing blue, and the gorge filled up with dark first, the way water fills a glass from the bottom."
    "光は灰色から深く衰えていく青へと変わり、峡谷が先に闇で満ちていった。グラスに水が底から満ちていくように。"

# game/script/ch12.rpy:230
translate japanese ch12_3e9c7574:

    # "The car became a small lit box moving through a country that was losing its color, and the girl sat in the glow of the dash with her cheek against the cold window."
    "車は、色を失っていく土地を進む小さな明かりの箱になった。少女はダッシュボードの光のなかで、冷たい窓に頬を寄せて座っていた。"

# game/script/ch12.rpy:231
translate japanese ch12_9bd315e1:

    # a sad "Emily collected buttons."
    a sad "Emilyはボタンを集めていたんです。"

# game/script/ch12.rpy:232
translate japanese ch12_f38e734e:

    # a sad "And leaves. And once a coin so old you couldn't see the face on it anymore. She kept them in a tin."
    a sad "それと葉っぱも。それから一度、古すぎて顔が見えなくなったコインも。缶に入れてしまってました。"

# game/script/ch12.rpy:233
translate japanese ch12_6141247f:

    # a sad "And if she liked you she'd just give you one, right out of the tin, like it was nothing. Like she had a thousand."
    a sad "気に入った人がいると、缶からひとつ、ぽんとくれるんです。なんでもないみたいに。千個も持ってるみたいに。"

# game/script/ch12.rpy:234
translate japanese ch12_69c97bb9:

    # "A small breath fogged the glass."
    "小さな息がガラスを曇らせた。"

# game/script/ch12.rpy:235
translate japanese ch12_4ed9e9ea:

    # a sad "She gave me the coin. The one with no face. She said it was her best one, and that was why I should be the one to have it."
    a sad "Emilyは私にそのコインをくれました。顔のないコイン。いちばんいいやつだから、だから私が持つべきなんだって。"

# game/script/ch12.rpy:236
translate japanese ch12_eda7f968:

    # a sad "I still have it. It's in the bag."
    a sad "まだ持ってます。鞄の中に。"

# game/script/ch12.rpy:241
translate japanese ch12_b1bdfca5:

    # "She told him where things were. She had told him where the diary was, too."
    "彼女は物のありかを彼に教えた。日記のありかも、彼女は教えたのだった。"

# game/script/ch12.rpy:242
translate japanese ch12_91bedc3e:

    # th "Grieving people tell you where they keep things. That's all that is."
    th "悲しんでる人間は、物をどこにしまってるか話すもんだ。それだけのことだ。"

# game/script/ch12.rpy:249
translate japanese ch12_0512ebde:

    # "Samuel heard the grief in it and could not find the bottom of it, because there was no bottom. Because the grief was true."
    "Samuelはそこに悲しみを聞き取り、その底を見つけられなかった。底がなかったからだ。その悲しみが本物だったからだ。"

# game/script/ch12.rpy:250
translate japanese ch12_00a9f243:

    # "The girl beside him had loved Emily Carter. He could hear it, the way you can hear a true note under a hundred false ones."
    "隣の少女はEmily Carterを愛していた。彼にはそれが聞こえた。百の偽りの音の下に、ひとつの本当の音が聞こえるように。"

# game/script/ch12.rpy:251
translate japanese ch12_accb93f7:

    # "And she had knelt in the snow and poisoned her all the same, and kept the coin. Both of those were one girl, mourning the friend she had murdered and meaning every tear of it."
    "それでも彼女は雪の中に膝をつき、Emilyに毒を盛り、コインを手元に残した。そのどちらも一人の少女だった。自分が殺した友を悼み、その涙の一滴一滴まで本気である少女。"

# game/script/ch12.rpy:252
translate japanese ch12_719a8eb8:

    # "It was the most frightening thing he had ever sat beside, and it looked exactly like the most human."
    "それは彼がこれまで隣に座ったなかで最も恐ろしいものであり、そして、最も人間らしいものとそっくり同じ顔をしていた。"

# game/script/ch12.rpy:253
translate japanese ch12_10f11f4a:

    # "For a long stretch of the dark descent he drove and grieved, honestly, alongside the child, for the child she had killed. And hated himself for it, and could not stop."
    "暗い下り道の長い一区間、彼は運転しながら、子どもの隣で、子どもが殺した子どものために、正直に悲しんだ。そして自分を憎み、それでもやめられなかった。"

# game/script/ch12.rpy:254
translate japanese ch12_0cbed592:

    # "The not-being-able-to-stop was the softest and most fatal thing in him. It was precisely the thing she had spent four hours finding."
    "やめられないこと。それこそが彼のなかで最もやわらかく、最も致命的なものだった。四時間かけて彼女が探し当てたのは、まさにそれだった。"

# game/script/ch12.rpy:259
translate japanese ch12_6e80e016:

    # "After a while she stirred, and wiped the fog from the glass with her sleeve, and drew her knees up into the seat. Small, the holdall of her whole life at her feet."
    "しばらくして彼女は身じろぎし、袖でガラスの曇りを拭い、座席の上で膝を抱え込んだ。小さかった。人生のすべてが入ったボストンバッグが足元にあった。"

# game/script/ch12.rpy:261
translate japanese ch12_646662dd:

    # a "Can I tell you something I've never told anybody? About my family. About what they were like."
    a "誰にも話したことのないことを話してもいいですか？家族のこと。家族がどんな人たちだったか。"

# game/script/ch12.rpy:262
translate japanese ch12_ba78b761:

    # s soft "If you want to."
    s soft "話したければ。"

# game/script/ch12.rpy:264
translate japanese ch12_cfbba840:

    # a "They believed people are what they carry."
    a "家族は、人はその人が背負っているものそのものだって信じていました。"

# game/script/ch12.rpy:265
translate japanese ch12_89288be5:

    # a "Not what they say. Not what they pretend to be. Everybody's carrying something, and some people are strong enough to carry it in the open."
    a "言うことじゃなくて。ふりをしているものでもなくて。誰でも何かを背負っていて、なかにはそれを人前で背負えるくらい強い人もいる。"

# game/script/ch12.rpy:266
translate japanese ch12_a22dd83b:

    # a "And some people are weak and hide it and lie about it. And the lying— the pretending you're something you're not— that was the worst thing there was. Worse than being weak."
    a "そして弱くて、それを隠して、嘘をつく人もいる。それで、嘘をつくこと――自分じゃないもののふりをすること――それがいちばん悪いことでした。弱いことよりも悪い。"

# game/script/ch12.rpy:267
translate japanese ch12_ee38a472:

    # a "They taught me to see it. To look at a person and know which one they were."
    a "私はそれを見分けるように教えられました。人を見て、どっちなのかがわかるように。"

# game/script/ch12.rpy:268
translate japanese ch12_82da6f96:

    # "She was watching the side of his face again, the last gray light on her cheek."
    "彼女はまた彼の横顔を見つめていた。最後の灰色の光が頬にかかっていた。"

# game/script/ch12.rpy:269
translate japanese ch12_fb9556ac:

    # a "The strong ones and the pretenders. I've always been able to see it. It's the first thing I see about anybody."
    a "強き者と、偽る者。私にはずっとそれが見えていました。誰を見ても、最初に見えるのがそれなんです。"

# game/script/ch12.rpy:270
translate japanese ch12_479c8234:

    # "There it was, laid in his lap in a child's mild voice: the whole cold gospel written in cult-tongue on the bodies of five people. False purity cannot endure. The weak do not endure."
    "そこにあった。子どもの穏やかな声で、彼の膝の上に置かれていた。集いの言葉で五人の体に書かれた、冷たい教義のすべて。偽りの清らかさは持ちこたえられない。弱き者は持ちこたえられない。"

# game/script/ch12.rpy:271
translate japanese ch12_6fd2e88a:

    # "Recited to him now as a family recipe, by the girl who had written it."
    "それがいま、家に伝わる料理の作り方のように彼に向かって暗唱されていた。それを書いた少女自身の口から。"

# game/script/ch12.rpy:272
translate japanese ch12_500942bc:

    # "His certainty came back all at once, whole and cold. And with it the other thing, the thing that had no business in a detective: an ache, enormous and useless, for the child this creed had eaten."
    "確信が一度に戻ってきた。まるごと、冷たく。そしてそれと一緒に、もうひとつのもの、刑事のなかにあるべきではないものも戻ってきた。この教義に喰われた子どものための、途方もなく大きく、役に立たない痛み。"

# game/script/ch12.rpy:274
translate japanese ch12_49c89704:

    # "He knew even as he opened his mouth that it was the wrong thing to show her. That he would be handing her something."
    "口を開きかけたときにはもう、それが彼女に見せるべきではないものだとわかっていた。何かを彼女に手渡すことになると。"

# game/script/ch12.rpy:279
translate japanese ch12_9989632e:

    # "He did it anyway, because he was not, in the end, and to his own ruin, the machine he had spent thirteen years trying to be."
    "それでも彼はそうした。結局のところ、そして自らの破滅に至るまで、彼は十三年かけてなろうとしてきた機械ではなかったからだ。"

# game/script/ch12.rpy:282
translate japanese ch12_16ab75e7:

    # "He kept his eyes on the road. He held it behind his teeth for one mile, and half of another."
    "彼は道路に目を据えていた。一マイルと、もう半マイルのあいだ、それを歯の奥にとどめていた。"

# game/script/ch12.rpy:283
translate japanese ch12_6546eb28:

    # "And then he could not stop himself, because he was not, in the end, and to his own ruin, the machine he had spent thirteen years trying to be."
    "そしてそれから、自分を止められなかった。結局のところ、そして自らの破滅に至るまで、彼は十三年かけてなろうとしてきた機械ではなかったからだ。"

# game/script/ch12.rpy:285
translate japanese ch12_85ca7e45:

    # s hurt "You don't have to keep it."
    s hurt "それを持ち続けなくていいんだ。"

# game/script/ch12.rpy:286
translate japanese ch12_964cd9a2:

    # "It came out rougher than he'd meant. Scraped."
    "思っていたより荒い声になった。擦れていた。"

# game/script/ch12.rpy:287
translate japanese ch12_3de8faf1:

    # s hurt "Whatever they put in you. However early they started. A kid doesn't choose the house she's born in, and she is not the house. Not all the way down."
    s hurt "連中が君に何を植えつけたにせよ。どれほど早くから始めたにせよ。子どもは生まれる家を選べないし、その子はその家じゃない。底の底までそうってわけじゃない。"

# game/script/ch12.rpy:288
translate japanese ch12_c723bdfc:

    # "He stopped, and started again, worse at this than he had been at anything in years."
    "彼は言葉を切り、また始めた。ここ何年かのどんなことよりも、これが下手だった。"

# game/script/ch12.rpy:289
translate japanese ch12_f5def23f:

    # s soft "You're twelve. There's people whose whole job is helping kids set down things that got loaded on them too young to say no."
    s soft "君は十二歳だ。嫌だと言えないほど幼いうちに背負わされたものを、子どもが下ろせるよう手助けするのが仕事の人たちがいる。"

# game/script/ch12.rpy:290
translate japanese ch12_dd767440:

    # s soft "It can be set down, Alice. That's all I'm telling you. Somebody should've told you a long time ago that it can be set down."
    s soft "下ろせるんだ、Alice。私が言いたいのはそれだけだ。下ろせるんだって、ずっと前に誰かが君に言ってやるべきだった。"

# game/script/ch12.rpy:291
translate japanese ch12_4daaa364:

    # "The car was quiet a long moment."
    "車内は長いあいだ静かだった。"

# game/script/ch12.rpy:292
translate japanese ch12_733be1da:

    # "When Alice answered her voice was gentle, and there was something in it that had not been there before. Something that had finished considering him."
    "Aliceが答えたとき、その声は優しかった。そしてそこには、それまでなかった何かがあった。彼を見定め終えた何かが。"

# game/script/ch12.rpy:293
translate japanese ch12_8ecadeed:

    # a neutral "You're kind. You really are. I wasn't sure, at first."
    a neutral "優しいんですね。本当に。最初はわからなかった。"

# game/script/ch12.rpy:294
translate japanese ch12_e81b108f:

    # a "When I first met you, you didn't feel anything— or you didn't show it— and I thought, there's a strong one. There's one who carries it and doesn't pretend and doesn't break."
    a "最初に会ったとき、刑事さんは何も感じていなかった――それか、見せていなかった――だから思ったんです。ここに強き者がいる。背負っていて、ふりをしなくて、壊れない人がいるって。"

# game/script/ch12.rpy:295
translate japanese ch12_465a761d:

    # "She looked out at the dark coming up out of the gorge."
    "彼女は峡谷から立ちのぼってくる闇を見やった。"

# game/script/ch12.rpy:296
translate japanese ch12_79e9bf4f:

    # a "But you're just sad, aren't you. Underneath all of it. You're just as sad and soft as everybody, you only hid it better and longer."
    a "でも、ただ悲しいだけなんですね。その全部の下で。ほかのみんなと同じくらい悲しくて、やわらかい。ただ、うまく、長く隠していただけ。"

# game/script/ch12.rpy:297
translate japanese ch12_cdd1c657:

    # "A pause, small and final, a stone settling to the bottom of a well."
    "小さく、決定的な間。井戸の底に沈んでいく石のような。"

# game/script/ch12.rpy:299
translate japanese ch12_9e0bcae3:

    # th "Once, in a kitchen, I nearly told her I didn't know. It would have been the only true thing I gave her."
    th "一度、台所で、わからないと言いかけたことがある。言っていれば、それが俺があの子に与えた唯一の本当のことになっていただろう。"

# game/script/ch12.rpy:300
translate japanese ch12_6a3967ab:

    # a "That's alright. I don't mind. I just thought you were something you weren't."
    a "いいんです。気にしてません。ただ、刑事さんのことを、そうじゃないものだと思っていただけ。"

# game/script/ch12.rpy:301
translate japanese ch12_7e918290:

    # "Samuel heard it land two ways at once, and could stop neither."
    "Samuelにはそれが二通りに同時に響くのが聞こえた。どちらも止められなかった。"

# game/script/ch12.rpy:302
translate japanese ch12_6a7a1ee4:

    # "One way, a wounded child had seen through a tired man's armor to the grief underneath. That was true."
    "ひとつは、傷ついた子どもが、疲れた男の鎧を見透かし、その下の悲しみを見たということ。それは本当だった。"

# game/script/ch12.rpy:303
translate japanese ch12_956bd7ab:

    # "The other way was colder, and older, and carried no mercy at all. A judge closing a file she had kept open on him since the first day."
    "もうひとつはもっと冷たく、もっと古く、一片の慈悲もなかった。最初の日から彼について開いたままにしていたファイルを、裁く者が閉じたのだ。"

# game/script/ch12.rpy:304
translate japanese ch12_8b2b45e8:

    # "Weighing the last strong thing in her small cold world, and finding it, in the end, a pretender like the rest."
    "彼女の小さく冷たい世界に残った最後の強いものを量り、それが結局、ほかと同じ偽る者だと判じたのだ。"

# game/script/ch12.rpy:305
translate japanese ch12_f138c2eb:

    # "The verdict came down somewhere in the car. He did not let himself hear it."
    "評決は車内のどこかで下された。彼はそれを聞くことを自分に許さなかった。"

# game/script/ch12.rpy:306
translate japanese ch12_e178fef7:

    # "But the animal in him, the one that had been standing up in the dark since the first day, heard it, and lay down, and went cold."
    "だが彼のなかの獣、最初の日から闇の中で立ち上がっていたその獣は、それを聞き、身を伏せ、冷たくなった。"

# game/script/ch12.rpy:311
translate japanese ch12_84890b0b:

    # "Before he could find anything to say, the road bent a last time out of the trees."
    "何か言うことを見つける前に、道は最後にもう一度曲がり、木立を抜けた。"

# game/script/ch12.rpy:312
translate japanese ch12_1fd48d3d:

    # "Down in the blue dark of the valley floor, where the mountain road ran out at last onto the flat, a scatter of hard white light stood alone against the coming night."
    "谷底の青い闇の中、山道がようやく平地へと尽きるところに、硬く白い光の群れが、迫りくる夜を背にぽつんと立っていた。"

# game/script/ch12.rpy:316
translate japanese ch12_bb5a32f9:

    # "A gas station. Six pumps under a lit canopy."
    "ガソリンスタンド。明かりの灯ったキャノピーの下に、給油機が六基。"

# game/script/ch12.rpy:317
translate japanese ch12_a4f17cff:

    # "A low shop, a squat row of toilets off to one side. And beyond them, at the edge of the lot, the black drop of the gorge behind a run of old barrier rail, some of it bent, some of it gone."
    "低い売店。その脇にずんぐりと並んだトイレ。そしてその向こう、敷地の端の古いガードレールの先に、峡谷の黒い落ち込みがあった。ガードレールは一部が曲がり、一部は失われていた。"

# game/script/ch12.rpy:319
translate japanese ch12_afd8bc55:

    # "Beside him, without a word, Alice went very still."
    "隣で、ひと言もなく、Aliceがひどく静かになった。"

# game/script/ch12.rpy:320
translate japanese ch12_5fc8b6cf:

    # "The amber tank light glowed on the dash. The long day's fuel nearly gone, the last hour of road still between them and the city."
    "ダッシュボードで琥珀色の燃料警告灯が光っていた。長い一日の燃料はほとんど尽き、市までにはまだ最後の一時間の道が残っていた。"

# game/script/ch12.rpy:321
translate japanese ch12_83cc54f2:

    # "He put on his signal, though there was no one for miles to see it, and slowed, and turned in toward the hard white light."
    "何マイル先まで見る者は誰もいなかったが、彼はウインカーを出し、速度を落とし、硬く白い光のほうへと車を入れた。"

# game/script/ch12.rpy:322
translate japanese ch12_37b1c411:

    # "Every hair on him had quietly stood. He put it down to the long day and the girl's silence, and did not look too hard at whether that was the whole of it."
    "全身の毛が音もなく逆立っていた。長い一日と少女の沈黙のせいだと彼は片づけ、それがすべてなのかどうかを深く見ようとはしなかった。"

# game/script/ch12.rpy:323
translate japanese ch12_a2595e29:

    # "Her eyes were on the lit island as it swung toward them. Fixed. Unblinking. She did not so much as glance at the road, or at him."
    "彼女の目は、こちらへ回り込んでくる光の島に注がれていた。じっと。瞬きもせずに。道にも、彼にも、ちらりとも目を向けなかった。"

# game/script/ch12.rpy:325
translate japanese ch12_a7d7890c:

    # "As he brought the car in under the canopy and the cold light washed over them both, he felt it come up off her small silent shape and fill the car."
    "彼が車をキャノピーの下に入れ、冷たい光が二人を洗ったとき、彼はそれが、彼女の小さく黙った姿から立ちのぼって車内を満たすのを感じた。"

# game/script/ch12.rpy:326
translate japanese ch12_292e94c7:

    # "Not fear. Nothing so warm as fear."
    "恐怖ではない。恐怖ほど温かいものではない。"

# game/script/ch12.rpy:327
translate japanese ch12_d75901e9:

    # "A kind of attention, wide and patient and old. The attention of a thing that has arrived, at last, somewhere it knows."
    "一種の注意だった。広く、辛抱強く、古い。ついに、知っている場所に辿り着いたものの注意。"

translate japanese strings:

    # game/script/ch12.rpy:22
    old "Her hand."
    new "彼女の手。"

    # game/script/ch12.rpy:27
    old "The holdall."
    new "ボストンバッグ。"

    # game/script/ch12.rpy:76
    old "Watch the road."
    new "道を見る。"

    # game/script/ch12.rpy:80
    old "Watch her look at the stain."
    new "染みを見る彼女を見る。"

    # game/script/ch12.rpy:136
    old "\"No.\""
    new "「いや」"

    # game/script/ch12.rpy:141
    old "\"One.\""
    new "「一人」"

    # game/script/ch12.rpy:239
    old "\"In the bag.\""
    new "「鞄の中に」"

    # game/script/ch12.rpy:246
    old "The glass."
    new "窓ガラス。"

    # game/script/ch12.rpy:277
    old "Tell her."
    new "伝える。"

    # game/script/ch12.rpy:280
    old "Keep driving."
    new "運転を続ける。"

