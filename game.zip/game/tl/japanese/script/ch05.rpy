# TODO: Translation updated at 2026-10-11 10:23

# game/script/ch05.rpy:18
translate japanese ch05_2cdc9218:

    # "The moment the priest fell, the funeral fractured into chaos."
    "神父が倒れた瞬間、葬儀は混乱に砕け散った。"

# game/script/ch05.rpy:19
translate japanese ch05_71d12793:

    # "What had been a still, somber crowd became a surging knot of voices, shouts and movement."
    "静かで沈痛だった人の群れは、声と叫びと動きが渦を巻く塊に変わった。"

# game/script/ch05.rpy:20
translate japanese ch05_41040446:

    # "Samuel Harris stepped forward, coat tugged tight against the bitter air, his arm lifted."
    "Samuel Harrisは前へ出た。凍てつく空気に抗うようにコートをきつく引き寄せ、片腕を上げた。"

# game/script/ch05.rpy:21
translate japanese ch05_4b61f05a:

    # s "Everyone calm down! Please, stay back!"
    s "皆さん、落ち着いて！下がってください！"

# game/script/ch05.rpy:22
translate japanese ch05_3a05fa6c:

    # "Some froze at his voice, startled by its command. Others pressed closer, curiosity outweighing caution."
    "その声の命令の響きに、凍りついた者もいた。用心よりも好奇心が勝って、さらに詰め寄る者もいた。"

# game/script/ch05.rpy:23
translate japanese ch05_be3b871c:

    # "People shoved, some craning their necks to see the priest's crumpled body at the grave's edge, others backing away in fear."
    "人々は押し合った。墓の縁にくずおれた神父の体を見ようと首を伸ばす者もいれば、怯えて後ずさる者もいた。"

# game/script/ch05.rpy:24
translate japanese ch05_001d10a4:

    # "And then Evelyn Ward's voice cut through like a knife."
    "そのとき、Evelyn Wardの声がナイフのように割って入った。"

# game/script/ch05.rpy:27
translate japanese ch05_e81795db:

    # ev "You!"
    ev "あんた！"

# game/script/ch05.rpy:28
translate japanese ch05_f6c9fcd4:

    # "Her face was white with rage and grief. She pointed at Samuel, her hand trembling."
    "その顔は怒りと悲しみで白くなっていた。彼女は震える手でSamuelを指さした。"

# game/script/ch05.rpy:29
translate japanese ch05_30a6ad80:

    # ev "What are you doing here? My girl is dead, and now the priest—"
    ev "ここで何をしてるの？うちの子は死んだ。それに今度は神父さままで――"

# game/script/ch05.rpy:30
translate japanese ch05_0e9839c8:

    # "Her voice cracked, but she pushed on, louder."
    "声はひび割れたが、彼女はかまわず、さらに声を張った。"

# game/script/ch05.rpy:31
translate japanese ch05_d2d4c572:

    # ev "It's you. You brought this here. You're not from this town. Why are you even here?"
    ev "あんたよ。あんたがこれを持ちこんだの。この町の人間じゃないくせに。そもそもなんでここにいるのよ？"

# game/script/ch05.rpy:33
translate japanese ch05_9479f04d:

    # th "Four questions in that dark room, and she'd shaken her head at every one. She'd found her answer now."
    th "あの暗い部屋で四つ質問した。彼女はそのすべてに首を振った。その答えを、今になって見つけたわけだ。"

# game/script/ch05.rpy:34
translate japanese ch05_bfa9054a:

    # "Richard Ward staggered beside her, eyes glazed but filled with bitterness."
    "その隣でRichard Wardがよろめいた。目はうつろだったが、苦々しさに満ちていた。"

# game/script/ch05.rpy:35
translate japanese ch05_004567a0:

    # rw "Leave us alone. You don't belong here!"
    rw "俺たちに構うな。あんたはここの人間じゃない！"

# game/script/ch05.rpy:37
translate japanese ch05_e3ffa0fb:

    # "It landed like a slap. And what came after was worse than the slap."
    "それは平手打ちのように響いた。そして、そのあとに来たものは平手打ちよりも悪かった。"

# game/script/ch05.rpy:39
translate japanese ch05_94494df1:

    # "Not a roar. A settling."
    "怒号ではない。沈殿だった。"

# game/script/ch05.rpy:40
translate japanese ch05_445b55d7:

    # "The noise went out of the crowd where Evelyn's words had passed. Faces turned toward him one by one, and stayed turned."
    "Evelynの言葉が通り過ぎたところから、群衆のざわめきが消えていった。顔がひとつ、またひとつと彼のほうへ向き、向いたまま動かなかった。"

# game/script/ch05.rpy:46
translate japanese ch05_9af684ac:

    # "No one else spoke. They didn't need to."
    "ほかに口を開く者はいなかった。その必要もなかった。"

# game/script/ch05.rpy:47
translate japanese ch05_76914007:

    # "A whole churchyard simply looked at the outsider standing over their second body in a week, and let him feel the look."
    "墓地にいる全員が、一週間で二つ目の死体のそばに立つよそ者をただ見つめ、その視線を彼に感じさせた。"

# game/script/ch05.rpy:48
translate japanese ch05_067ba549:

    # "Samuel kept his face blank, his tone steady."
    "Samuelは表情を消し、声の調子を崩さなかった。"

# game/script/ch05.rpy:49
translate japanese ch05_4b4acf45:

    # s "I'm here to do my job. That's all. Now step back. Let the medics through."
    s "私は仕事をしに来ただけです。それだけです。さあ、下がって。救急隊を通してください。"

# game/script/ch05.rpy:53
translate japanese ch05_0e9d86c6:

    # "Into that cold quiet, one voice came loud."
    "その冷たい静けさのなかに、ひとつの声が大きく響いた。"

# game/script/ch05.rpy:54
translate japanese ch05_5fe5a482:

    # "Kurt Leary. Samuel knew him from Hensley's shop, the kind of man always loudest in a corner. He jabbed a finger over the heads between them."
    "Kurt Leary。Hensleyの店で見かけた男だ。どこにいても隅でいちばんうるさい類の男。彼は間にいる人々の頭越しに指を突きつけた。"

# game/script/ch05.rpy:55
translate japanese ch05_0397f6f8:

    # kl "We never had bodies dropping like this until he showed up!"
    kl "こいつが来るまで、こんなふうにばたばた人が死ぬことなんかなかったんだ！"

# game/script/ch05.rpy:56
translate japanese ch05_cdab9608:

    # "No one took it up. No one had to."
    "誰もそれに乗らなかった。乗る必要もなかった。"

# game/script/ch05.rpy:63
translate japanese ch05_28df800d:

    # "Leary was only the mouth. The rest had agreed without a sound, and a town that agrees in silence acts in silence."
    "Learyは口にすぎなかった。残りの者たちは音もなく同意していた。そして、黙って同意する町は、黙って動く。"

# game/script/ch05.rpy:71
translate japanese ch05_46046140:

    # "It hung there in the silence, agreed with by every face that wouldn't say so."
    "その言葉は沈黙のなかに浮かんだまま、口には出さないすべての顔に同意されていた。"

# game/script/ch05.rpy:72
translate japanese ch05_9e45cc33:

    # "That was worse than a crowd shouting back would have been."
    "群衆が怒鳴り返してくるより、そのほうがずっと悪かった。"

# game/script/ch05.rpy:77
translate japanese ch05_558824cf:

    # "Before the hostility could swell further, Mercer pushed through, his broad frame forcing space where there was none."
    "敵意がさらに膨らむ前に、Mercerが人を押し分けてきた。がっしりした体で、隙間のないところに隙間をこじ開けた。"

# game/script/ch05.rpy:78
translate japanese ch05_e9f131f0:

    # m "Enough! Step back! Everyone back!"
    m "そこまでだ！下がれ！全員下がれ！"

# game/script/ch05.rpy:79
translate japanese ch05_a2f6d431:

    # "He shoved a man back with one hand, the other held up. His voice was raw with strain, but it carried the authority of someone desperate to keep order."
    "彼は片手で男を押し戻し、もう片方の手を掲げた。声は緊張でかすれていたが、なんとしても秩序を保とうとする者の権威があった。"

# game/script/ch05.rpy:81
translate japanese ch05_d11d683c:

    # "Beside him, Officer Lara Whitfield shouldered her way forward."
    "その横で、Lara Whitfield巡査が肩で人をかき分けて進み出た。"

# game/script/ch05.rpy:82
translate japanese ch05_c333c103:

    # l "Clear the area! Right now! Move back, give space!"
    l "ここから離れてください！今すぐ！下がって、場所を空けて！"

# game/script/ch05.rpy:83
translate japanese ch05_1a5a1428:

    # "She gestured toward the road. The resistance broke unevenly."
    "彼女は道路のほうを示した。抵抗はまばらに崩れていった。"

# game/script/ch05.rpy:84
translate japanese ch05_942dd336:

    # "Some obeyed, retreating with mutters. Others bristled and shouted, but Mercer's hands and Lara's sharp tone pushed them back a step at a time."
    "ぶつぶつ言いながら引き下がる者もいた。いきり立って叫ぶ者もいたが、Mercerの手とLaraの鋭い声が、一歩ずつ彼らを押し戻した。"

# game/script/ch05.rpy:88
translate japanese ch05_0e914dac:

    # "The fire department arrived minutes later, the red truck forcing its way up the narrow path to the cemetery."
    "数分後に消防が到着した。赤い車両が墓地へ続く細い道を無理やり登ってきた。"

# game/script/ch05.rpy:89
translate japanese ch05_16709394:

    # "Firefighters in reflective jackets jumped down and spread their arms wide, pushing the crowd into smaller clusters."
    "反射材のジャケットを着た消防士たちが飛び降り、両腕を広げて、群衆を小さな塊に分けていった。"

# game/script/ch05.rpy:90
translate japanese ch05_19ad49a9:

    # "Behind them an ambulance pulled in. One medic crouched at the priest's side, checking for vitals, and shook his head almost immediately."
    "その後ろに救急車が入ってきた。救急隊員のひとりが神父の脇にしゃがんで生命徴候を確かめ、ほとんどすぐに首を横に振った。"

# game/script/ch05.rpy:91
translate japanese ch05_ba2d6570:

    # "The other pulled a sheet from the kit."
    "もうひとりが用具からシーツを引き出した。"

# game/script/ch05.rpy:93
translate japanese ch05_af774ab6:

    # "Samuel's eyes stayed fixed on the scene, but his hands were already moving. He snapped on his gloves."
    "Samuelの目は現場に据えられたままだったが、手はすでに動いていた。彼は手袋をはめた。"

# game/script/ch05.rpy:95
translate japanese ch05_f439ff20:

    # s "Help me secure what we can before the crowd tramples everything."
    s "群衆が何もかも踏み荒らす前に、確保できるものを確保する。手を貸してくれ。"

# game/script/ch05.rpy:96
translate japanese ch05_02aaa116:

    # "She nodded quickly, pulling her own gloves from her belt."
    "彼女はすばやくうなずき、ベルトから自分の手袋を引き抜いた。"

# game/script/ch05.rpy:97
translate japanese ch05_da5ce71f:

    # "They started near the priest's fallen Bible. Samuel lifted the leather-bound book gently, noting the scuff on its cover from the fall, and set it into the bag Lara held open."
    "二人は神父が落とした聖書のあたりから始めた。Samuelは革装の本をそっと持ち上げ、落ちたときについた表紙の擦り傷を確かめてから、Laraが広げて持つ袋に収めた。"

# game/script/ch05.rpy:98
translate japanese ch05_23a45631:

    # "He signaled a patrol officer to start a perimeter log and snap phone photos before anything moved. Optics mattered as much as evidence."
    "彼はパトロールの巡査に合図して、何かが動かされる前に現場出入りの記録をつけさせ、携帯で写真を撮らせた。見え方は証拠と同じくらい重要だった。"

# game/script/ch05.rpy:99
translate japanese ch05_492eaf91:

    # "The bottle of water came next. Still half-full, its cap resting in the dirt nearby. He lifted it with care, fingers away from the rim."
    "次は水のボトルだった。まだ半分残っていて、キャップはそばの土の上に落ちていた。彼は飲み口に指が触れないよう、慎重に持ち上げた。"

# game/script/ch05.rpy:100
translate japanese ch05_1d8e0cc1:

    # "The closest medic gave him a sharp look, but said nothing as Samuel bagged it too."
    "いちばん近くにいた救急隊員が鋭い視線を向けたが、Samuelがそれも袋に入れるのを黙って見ていた。"

# game/script/ch05.rpy:101
translate japanese ch05_03e6e4ff:

    # s "Check the ground. Any scrap, paper, anything that doesn't belong."
    s "地面を調べてくれ。切れ端でも紙でも、ここにあるはずのないものは何でも。"

# game/script/ch05.rpy:102
translate japanese ch05_8d12ba49:

    # "Lara crouched lower, eyes scanning the grass near the grave. She lifted a small slip of white. Torn paper, faintly smudged."
    "Laraはさらに身を低くし、墓のそばの草に目を走らせた。彼女は小さな白いものを拾い上げた。破れた紙。うっすらと汚れている。"

# game/script/ch05.rpy:103
translate japanese ch05_f00232e0:

    # "Another word, Samuel realized. But the mud had blurred it past recognition. He bagged it anyway."
    "また言葉だ、とSamuelは気づいた。だが泥が判読できないほどに滲ませていた。それでも彼は袋に入れた。"

# game/script/ch05.rpy:106
translate japanese ch05_ce6b66f5:

    # "The medics drew the sheet over the priest. A collective gasp went through the crowd, then fresh cries of prayer and panic."
    "救急隊員が神父にシーツをかけた。群衆のあいだに一斉に息をのむ音が走り、続いて祈りと恐慌の叫びがまた上がった。"

# game/script/ch05.rpy:107
translate japanese ch05_122d653c:

    # "Samuel stood, coat snapping in the wind. His eyes swept the graveyard until they found Emily Carter, sobbing violently into her father's coat as her mother pulled her back."
    "Samuelは立ち上がった。コートが風にはためいた。彼の目は墓地を見渡し、やがてEmily Carterを見つけた。父親のコートに顔をうずめて激しく泣きじゃくり、母親が彼女を引き離そうとしていた。"

# game/script/ch05.rpy:108
translate japanese ch05_6e4e25b9:

    # "Her hands clawed at her face as though the sight had scarred her."
    "彼女の手は、その光景に傷つけられたかのように、自分の顔をかきむしっていた。"

# game/script/ch05.rpy:109
translate japanese ch05_a22cff28:

    # "Alice stood beside her, one hand still clamped on Emily's arm."
    "Aliceがその隣に立っていた。片手はまだEmilyの腕をしっかりとつかんでいた。"

# game/script/ch05.rpy:110
translate japanese ch05_d4e362e0:

    # "Unlike Emily, she wasn't looking away."
    "Emilyとちがって、彼女は目をそらしていなかった。"

# game/script/ch05.rpy:111
translate japanese ch05_b9cc4068:

    # "When the Carters finally dragged Emily off, Alice resisted for only a moment before letting go. She stayed near the grave, her gaze following the medics as they lifted the priest onto the stretcher."
    "Carter夫妻がようやくEmilyを引き離すと、Aliceはほんの一瞬抗ってから手を放した。彼女は墓のそばにとどまり、救急隊員が神父を担架に載せるのを目で追っていた。"

# game/script/ch05.rpy:114
translate japanese ch05_9bb58020:

    # "Too still. Too attentive."
    "静かすぎる。注意深すぎる。"

# game/script/ch05.rpy:118
translate japanese ch05_242f1fc2:

    # "Samuel didn't let himself linger on it. A crowd still churned at his back, and evidence waited under his boots."
    "Samuelはそこにこだわらないようにした。背後ではまだ群衆が渦巻き、足もとでは証拠が待っていた。"

# game/script/ch05.rpy:122
translate japanese ch05_1dace108:

    # "He let himself look. She wasn't staring the way children stare at a body: fixed, frightened, unable to look away."
    "彼は見ることを自分に許した。子どもが死体を見るときの見方ではなかった。凍りつき、怯え、目をそらせなくなる、あの見方ではない。"

# game/script/ch05.rpy:123
translate japanese ch05_a5bf8aaa:

    # "Her eyes moved. The stretcher, the medics' hands, the bagged bottle, the gap in the crowd. Then back."
    "彼女の目は動いていた。担架、救急隊員の手、袋に入ったボトル、群衆の切れ目。そしてまた戻る。"

# game/script/ch05.rpy:124
translate japanese ch05_6245a197:

    # "She was taking in the scene the way he took in a scene."
    "彼が現場を見るのと同じやり方で、彼女は現場を見ていた。"

# game/script/ch05.rpy:125
translate japanese ch05_c42bd62a:

    # th "Numb. That's all. She's watched her best friend buried and a priest fall dead in the same hour. Kids go flat in shock."
    th "麻痺してるだけだ。親友が埋葬されるのを見て、同じ一時間のうちに神父が倒れて死ぬのを見た。ショックで子どもは平板になる。"

# game/script/ch05.rpy:127
translate japanese ch05_357bbe23:

    # "He walked toward her, the evidence bags heavy in his hand. Behind him the firemen pushed the crowd farther back, leaving a circle of relative calm around the grave."
    "彼は彼女のほうへ歩いた。証拠袋が手に重かった。背後では消防士たちが群衆をさらに押し下げ、墓のまわりに比較的静かな輪ができていた。"

# game/script/ch05.rpy:129
translate japanese ch05_6c41046b:

    # s "You should go."
    s "君はもう行きなさい。"

# game/script/ch05.rpy:130
translate japanese ch05_ce9c5566:

    # "Alice didn't move. Her eyes shifted to him, calm, curious, too composed for twelve."
    "Aliceは動かなかった。その目が彼に移った。穏やかで、好奇心を帯び、十二歳にしては落ち着きすぎていた。"

# game/script/ch05.rpy:131
translate japanese ch05_8f61ebaf:

    # a "I'd rather not go home right now. Not before lunch."
    a "今は家に帰りたくないんです。お昼の前には。"

# game/script/ch05.rpy:132
translate japanese ch05_b397f4f7:

    # "Her voice was steady, her face blank, but the words hung in the air with a strange weight."
    "声は落ち着いていて、顔には何の表情もなかった。だがその言葉は奇妙な重みをもって宙に残った。"

# game/script/ch05.rpy:133
translate japanese ch05_c3d22d9a:

    # s "Why not?"
    s "どうして？"

# game/script/ch05.rpy:134
translate japanese ch05_2ec54bcf:

    # a "Because when George tells me to do something, he doesn't like when I disobey. I don't want to make him upset."
    a "Georgeに何かするよう言われたら、言いつけに背くのを、Georgeは嫌がるんです。Georgeを怒らせたくありません。"

# game/script/ch05.rpy:135
translate japanese ch05_c336b2fb:

    # "Most children would have said it dramatically, inflating a scolding into a punishment. Alice spoke with gravity, every syllable certain."
    "たいていの子どもなら、芝居がかった言い方をしただろう。叱られることを罰にまで膨らませて。Aliceは重々しく話した。一音一音に確信があった。"

# game/script/ch05.rpy:136
translate japanese ch05_fff08bc1:

    # "She meant it. If she disobeyed, she would be in trouble. And not the kind of slammed doors or raised voices."
    "本気だった。背けば、面倒なことになる。それも、ドアを叩きつけるとか、声を荒らげるとかいう類のものではない。"

# game/script/ch05.rpy:137
translate japanese ch05_8a0443e6:

    # "Samuel didn't like the weight behind her tone. But the graveyard wasn't the place to analyze it."
    "その口調の裏にある重みが、Samuelには気に入らなかった。だが墓地はそれを分析する場所ではなかった。"

# game/script/ch05.rpy:138
translate japanese ch05_acdf255f:

    # s "Alright. Then for now, go with Officer Whitfield. Stay close to her until I'm finished here."
    s "わかった。じゃあ今のところは、Whitfield巡査と一緒にいなさい。私がここを終えるまで、彼女のそばを離れないで。"

# game/script/ch05.rpy:140
translate japanese ch05_f44fe452:

    # "He tapped his radio, logging it aloud."
    "彼は無線を叩き、声に出して記録した。"

# game/script/ch05.rpy:141
translate japanese ch05_03104217:

    # s "Juvenile transport, with officer escort."
    s "少年移送、巡査が付き添う。"

# game/script/ch05.rpy:143
translate japanese ch05_2389150b:

    # note_voice "Juvenile transport, Alice Bennett, with officer escort."
    note_voice "少年移送。Alice Bennett。巡査付き添い。"

# game/script/ch05.rpy:147
translate japanese ch05_f9a92177:

    # s "Lara. Take Alice outside the graveyard, away from the crowd. Stay with her until I catch up."
    s "Lara。Aliceを墓地の外へ連れていってくれ。人混みから離して。俺が追いつくまで一緒にいてやってくれ。"

# game/script/ch05.rpy:148
translate japanese ch05_5598a379:

    # "Lara gave a short nod and bent slightly, a hand on Alice's shoulder."
    "Laraは短くうなずき、軽く身をかがめて、Aliceの肩に手を置いた。"

# game/script/ch05.rpy:149
translate japanese ch05_a616b85d:

    # l concerned "Come on, sweetheart. Let's get you some air."
    l concerned "行きましょう。少し外の空気を吸いましょうね。"

# game/script/ch05.rpy:150
translate japanese ch05_1a2ed881:

    # "Alice didn't resist. She cast one last look toward the grave, then let herself be led away. Small, but unnervingly composed."
    "Aliceは抗わなかった。墓のほうへ最後に一度目をやり、それから連れていかれるままになった。小さいのに、不気味なほど落ち着いていた。"

# game/script/ch05.rpy:154
translate japanese ch05_8ed28ead:

    # "The mayor's voice still carried faintly, calling the town to unity and faith. The people weren't listening."
    "町長の声がまだかすかに聞こえていた。町に団結と信仰を呼びかけていた。人々は聞いていなかった。"

# game/script/ch05.rpy:155
translate japanese ch05_111542f5:

    # "They huddled in tight groups, muttering about curses, outsiders, sins."
    "彼らは固まって身を寄せ合い、呪いのこと、よそ者のこと、罪のことをぼそぼそと話していた。"

# game/script/ch05.rpy:157
translate japanese ch05_9ee32f24:

    # "The ambulance doors shut with a metallic thud that echoed across the cemetery."
    "救急車の扉が金属音を立てて閉まり、その音が墓地じゅうに反響した。"

# game/script/ch05.rpy:158
translate japanese ch05_3d3f82c4:

    # "The siren didn't wail. The priest was already gone."
    "サイレンは鳴らなかった。神父はもう逝っていた。"

# game/script/ch05.rpy:159
translate japanese ch05_26697199:

    # "Samuel knelt again by the grave. Bottle, paper scrap, disturbed dirt. All bagged. But he kept looking."
    "Samuelはふたたび墓のそばに膝をついた。ボトル、紙の切れ端、掘り返された土。すべて袋に入れた。それでも彼は見つづけた。"

# game/script/ch05.rpy:160
translate japanese ch05_14ef61f2:

    # th "He doesn't like when I disobey."
    th "言いつけに背くのを、Georgeは嫌がる。"

# game/script/ch05.rpy:169
translate japanese ch05_a6b9ff42:

    # "Inside the chapel, Samuel and Mercer worked quickly but thoroughly."
    "礼拝堂のなかで、SamuelとMercerは手早く、しかし抜かりなく作業した。"

# game/script/ch05.rpy:171
translate japanese ch05_fd79bfa9:

    # "From the vestry and the altar table: reading glasses in a worn leather case, a small wooden crucifix, a rosary, a pocket notebook of sermon notes in tight script, a ring of old brass keys."
    "香部屋と祭壇の台から。使いこまれた革ケースに入った老眼鏡、小さな木の十字架、ロザリオ、細かな字で説教の覚え書きが綴られたポケット手帳、古い真鍮の鍵の束。"

# game/script/ch05.rpy:172
translate japanese ch05_f9728f96:

    # "From the lectern, his Bible, still open at the passage he had recited, and a second bottle of water resting in a tray, untouched."
    "説教台から。彼が朗読した箇所で開いたままの聖書と、トレイに置かれた手つかずの二本目の水のボトル。"

# game/script/ch05.rpy:173
translate japanese ch05_582b3ff2:

    # "Mercer swept up the priest's pen and a few loose sheets where he had marked references. Everything went into separate bags, labeled and logged."
    "Mercerは神父のペンと、出典に印がつけられたばらの紙を何枚か集めた。すべてが別々の袋に入れられ、ラベルを貼られ、記録された。"

# game/script/ch05.rpy:174
translate japanese ch05_00d0cbb8:

    # "When it was done, Samuel closed his notebook. The chapel was silent again, the air heavy with candle smoke."
    "終わると、Samuelは手帳を閉じた。礼拝堂はふたたび静まり返り、空気は蝋燭の煙で重かった。"

# game/script/ch05.rpy:175
translate japanese ch05_f6b799e5:

    # s "That's it. Let's wrap it."
    s "以上だ。撤収しよう。"

# game/script/ch05.rpy:180
translate japanese ch05_0e4291c1:

    # "Outside, snowflakes drifted lightly at first, but the wind was picking up, carrying the promise of another storm. The grave markers blurred in the growing white."
    "外では、はじめは雪がかすかに舞っているだけだったが、風が強まり、また嵐が来る気配を運んでいた。墓標が深まる白のなかでぼやけていった。"

# game/script/ch05.rpy:183
translate japanese ch05_4830b2a8:

    # "At the gate, Lara stood waiting. Beside her, Alice, hands tucked into her sleeves, hair stirred by the wind."
    "門のところでLaraが待っていた。その隣にAlice。両手を袖に引っこめ、髪が風に揺れていた。"

# game/script/ch05.rpy:184
translate japanese ch05_73fe8cab:

    # "The two had been speaking quietly. Both looked up when he approached."
    "二人は小声で話していた。彼が近づくと、二人とも顔を上げた。"

# game/script/ch05.rpy:185
translate japanese ch05_24d48436:

    # s "I'll take her home."
    s "私がこの子を家まで送る。"

# game/script/ch05.rpy:186
translate japanese ch05_9a47eaeb:

    # a "Alright."
    a "わかりました。"

# game/script/ch05.rpy:189
translate japanese ch05_9bd694f0:

    # "Samuel opened the passenger door for her. Alice climbed in without a word, her small hands smoothing the skirt over her knees."
    "Samuelは助手席のドアを開けてやった。Aliceは何も言わずに乗りこみ、小さな手で膝の上のスカートをなでつけた。"

# game/script/ch05.rpy:200
translate japanese ch05_1dd1e45e:

    # "The heater roared faintly, filling the cabin with dry warmth. The road out of town was nearly deserted."
    "ヒーターがかすかに唸り、車内を乾いた暖かさで満たした。町を出る道はほとんど人影がなかった。"

# game/script/ch05.rpy:201
translate japanese ch05_b80fc119:

    # "For a while neither spoke. The only sound was snow brushing the windshield."
    "しばらくどちらも口をきかなかった。聞こえるのは、フロントガラスをかすめる雪の音だけだった。"

# game/script/ch05.rpy:206
translate japanese ch05_dafec308:

    # s "How did you get to the funeral? Did George bring you?"
    s "葬儀にはどうやって来たんだ？Georgeが連れてきたのか？"

# game/script/ch05.rpy:207
translate japanese ch05_bb24b863:

    # a "No. George is usually occupied. I walk."
    a "いいえ。Georgeはたいてい用事があるので。歩いてきます。"

# game/script/ch05.rpy:208
translate japanese ch05_99da020e:

    # s "Even in weather like this?"
    s "こんな天気でも？"

# game/script/ch05.rpy:210
translate japanese ch05_f1ad88be:

    # "Alice laughed softly, a quick burst that fogged the glass."
    "Aliceはそっと笑った。短く漏れた息が、ガラスを曇らせた。"

# game/script/ch05.rpy:211
translate japanese ch05_442aa6da:

    # a "Yes. It's nothing too weird. I'm used to it."
    a "はい。そんなに変なことじゃありません。慣れていますから。"

# game/script/ch05.rpy:212
translate japanese ch05_f47cbffa:

    # s "Tougher than half the officers I know."
    s "私の知っている巡査の半分より、よほどたくましいな。"

# game/script/ch05.rpy:214
translate japanese ch05_66f5f55a:

    # "She didn't answer. So he asked the other thing."
    "彼女は答えなかった。それで彼は、もうひとつのことを訊いた。"

# game/script/ch05.rpy:215
translate japanese ch05_c41cc9ec:

    # s "What about your parents?"
    s "ご両親は？"

# game/script/ch05.rpy:216
translate japanese ch05_674e57a7:

    # "That drew silence. Her gaze stayed fixed forward, lips pressed."
    "それは沈黙を招いた。彼女の視線はまっすぐ前に据えられたまま、唇は固く結ばれていた。"

# game/script/ch05.rpy:217
translate japanese ch05_82ce6de0:

    # s "Is something wrong?"
    s "何かあるのか？"

# game/script/ch05.rpy:218
translate japanese ch05_3aaa6c17:

    # a "I'm not allowed to talk or ask about them. It's for my own good."
    a "両親のことは、話すのも訊くのも許されていないんです。私のためなんです。"

# game/script/ch05.rpy:220
translate japanese ch05_83ca27c7:

    # s "Your parents. Where are they?"
    s "ご両親は。どこにいるんだ？"

# game/script/ch05.rpy:221
translate japanese ch05_674e57a7_1:

    # "That drew silence. Her gaze stayed fixed forward, lips pressed."
    "それは沈黙を招いた。彼女の視線はまっすぐ前に据えられたまま、唇は固く結ばれていた。"

# game/script/ch05.rpy:222
translate japanese ch05_82ce6de0_1:

    # s "Is something wrong?"
    s "何かあるのか？"

# game/script/ch05.rpy:223
translate japanese ch05_3aaa6c17_1:

    # a "I'm not allowed to talk or ask about them. It's for my own good."
    a "両親のことは、話すのも訊くのも許されていないんです。私のためなんです。"

# game/script/ch05.rpy:224
translate japanese ch05_53597c84:

    # "He let it sit. Tried an easier door."
    "彼はそのままにしておいた。もっと開けやすい扉を試した。"

# game/script/ch05.rpy:225
translate japanese ch05_dafec308_1:

    # s "How did you get to the funeral? Did George bring you?"
    s "葬儀にはどうやって来たんだ？Georgeが連れてきたのか？"

# game/script/ch05.rpy:226
translate japanese ch05_bb24b863_1:

    # a "No. George is usually occupied. I walk."
    a "いいえ。Georgeはたいてい用事があるので。歩いてきます。"

# game/script/ch05.rpy:227
translate japanese ch05_99da020e_1:

    # s "Even in weather like this?"
    s "こんな天気でも？"

# game/script/ch05.rpy:229
translate japanese ch05_f1ad88be_1:

    # "Alice laughed softly, a quick burst that fogged the glass."
    "Aliceはそっと笑った。短く漏れた息が、ガラスを曇らせた。"

# game/script/ch05.rpy:230
translate japanese ch05_442aa6da_1:

    # a "Yes. It's nothing too weird. I'm used to it."
    a "はい。そんなに変なことじゃありません。慣れていますから。"

# game/script/ch05.rpy:232
translate japanese ch05_89aa82c0:

    # "The lightness didn't reach back to the other answer. It hadn't been meant to."
    "その軽さは、もうひとつの答えまでは届かなかった。届かせるつもりもなかったのだ。"

# game/script/ch05.rpy:234
translate japanese ch05_d0184ddb:

    # "Samuel's grip tightened slightly on the wheel."
    "ハンドルを握るSamuelの手に、わずかに力がこもった。"

# game/script/ch05.rpy:235
translate japanese ch05_dd418ad8:

    # s "What's that supposed to mean? Not allowed?"
    s "どういう意味だ？許されていない？"

# game/script/ch05.rpy:236
translate japanese ch05_a2649b5b:

    # "This time she turned her head, her eyes meeting his. Clear. Unwavering."
    "今度は彼女が顔を向け、目が彼の目と合った。澄んでいた。揺るぎなかった。"

# game/script/ch05.rpy:237
translate japanese ch05_1c01048b:

    # a "It's okay. George is my grandfather. He takes good care of me. He gets things done. And I'm grateful."
    a "大丈夫です。Georgeは私の祖父です。私をちゃんと世話してくれています。やるべきことをやる人です。私は感謝しています。"

# game/script/ch05.rpy:238
translate japanese ch05_f6edd4f2:

    # "Samuel held her look a moment, then nodded faintly. He didn't press further. Not now."
    "Samuelはしばらく彼女の視線を受けとめ、それからかすかにうなずいた。それ以上は押さなかった。今は。"

# game/script/ch05.rpy:240
translate japanese ch05_f3a568d7:

    # "The rest of the drive passed in silence. The houses grew sparser, the road bending toward the edge of Greyvale."
    "残りの道のりは沈黙のうちに過ぎた。家々はまばらになり、道はGreyvaleのはずれへと曲がっていった。"

# game/script/ch05.rpy:241
translate japanese ch05_7576fc83:

    # a "There."
    a "あそこです。"

# game/script/ch05.rpy:251
translate japanese ch05_ba40b68b:

    # "The house stood back from the road, framed by a high wooden fence and a wide garden, surprisingly well kept despite the season."
    "家は道から奥まったところに建っていた。高い木の塀と広い庭に囲まれ、季節のわりに驚くほど手入れが行き届いていた。"

# game/script/ch05.rpy:252
translate japanese ch05_72424222:

    # "Snow dusted the hedges. The path was cleared to bare stone. Plants trimmed, boundaries neat, nothing out of place."
    "生垣にうっすらと雪が積もっていた。小道は石がむき出しになるまで雪がかかれていた。植木は刈りこまれ、境界は整い、何ひとつ乱れていなかった。"

# game/script/ch05.rpy:253
translate japanese ch05_53946bc1:

    # "Shutters closed tight. Wood dark and polished by years of care."
    "鎧戸はぴったりと閉ざされていた。木は暗い色で、長年の手入れで磨かれていた。"

# game/script/ch05.rpy:254
translate japanese ch05_90013143:

    # "Samuel walked Alice to the front door and knocked. The sound echoed through the winter air."
    "SamuelはAliceを玄関まで送り、ノックした。その音が冬の空気に響いた。"

# game/script/ch05.rpy:258
translate japanese ch05_be03437e:

    # "The door swung open before his knuckles had left the wood."
    "拳が木から離れるより早く、ドアが開いた。"

# game/script/ch05.rpy:259
translate japanese ch05_d33af6e3:

    # "George Bennett filled the frame. Tall, broad-shouldered, his face set in hard lines. As though he'd been standing just behind it, waiting."
    "George Bennettが戸口をふさいでいた。背が高く、肩幅が広く、顔は硬い線で固まっていた。まるでドアのすぐ裏に立って、待っていたかのようだった。"

# game/script/ch05.rpy:261
translate japanese ch05_f7ae829d:

    # "His eyes went to Alice first."
    "彼の目はまずAliceに向いた。"

# game/script/ch05.rpy:262
translate japanese ch05_354cb258:

    # g "What is he doing here?"
    g "こいつはここで何をしてる？"

# game/script/ch05.rpy:263
translate japanese ch05_fa0e60e6:

    # "Alice opened her mouth. George cut across her."
    "Aliceが口を開いた。Georgeがそれを遮った。"

# game/script/ch05.rpy:264
translate japanese ch05_847d7d69:

    # g angry "And what's this? You got in a car with a stranger?"
    g angry "それに、これは何だ？知らない男の車に乗ったのか？"

# game/script/ch05.rpy:265
translate japanese ch05_f8136df3:

    # g "Go. To your room. Now."
    g "行け。部屋へ。今すぐ。"

# game/script/ch05.rpy:266
translate japanese ch05_c48b6d94:

    # "Alice dipped her head once, said nothing, and vanished into the house without hesitation. Her steps were light and swift, fading up the stairs."
    "Aliceは一度だけ頭を下げ、何も言わず、ためらいもなく家のなかへ消えた。その足音は軽く、すばやく、階段を上って遠ざかっていった。"

# game/script/ch05.rpy:278
translate japanese ch05_94775326:

    # "Light. Unhurried. No fear in them at all. Not the sound a child makes when she's running from a temper."
    "軽い。急いでいない。恐れはまったくない。癇癪から逃げる子どもの足音ではなかった。"

# game/script/ch05.rpy:279
translate japanese ch05_f3f25f5e:

    # th "Drilled. That's what drilled sounds like. A house with rules."
    th "仕込まれている。仕込まれた足音とはこういうものだ。規則のある家だ。"

# game/script/ch05.rpy:280
translate japanese ch05_0a001a2f:

    # "Samuel hadn't moved to intervene. It wasn't his place. Only once she was gone did he speak, low but sincere."
    "Samuelは割って入ろうとはしなかった。彼の立場ではなかった。彼女がいなくなってはじめて、彼は口を開いた。低く、だが誠実に。"

# game/script/ch05.rpy:281
translate japanese ch05_0d487eb8:

    # s "Apologies. I didn't want to let her walk home in this storm."
    s "申し訳ない。この吹雪のなかを歩いて帰らせたくなかったんだ。"

# game/script/ch05.rpy:282
translate japanese ch05_de729087:

    # "George made a noise in his throat, half growl, half grunt, his eyes narrowing."
    "Georgeは喉の奥で音を立てた。半分は唸り、半分はうめき。目が細くなった。"

# game/script/ch05.rpy:283
translate japanese ch05_0ea64267:

    # "Then, without a word more, he pushed the door shut."
    "それから、それ以上ひとことも言わずに、ドアを押して閉めた。"

# game/script/ch05.rpy:286
translate japanese ch05_197ae7f2:

    # "The latch clicked into place. The sound was final."
    "掛け金がかちりと収まった。決定的な音だった。"

# game/script/ch05.rpy:287
translate japanese ch05_50cafc04:

    # "Samuel stood on the porch a moment, snowflakes gathering on his coat, before he turned back to the car."
    "Samuelはしばらくポーチに立っていた。雪片がコートに積もっていった。それから車へ引き返した。"

# game/script/ch05.rpy:298
translate japanese ch05_08b708ab:

    # "The drive back was slow, the snow thickening, the road narrowing beneath the storm."
    "帰りの運転はのろかった。雪は濃くなり、嵐の下で道は狭まっていった。"

# game/script/ch05.rpy:299
translate japanese ch05_2ebf755a:

    # "One hand on the wheel. The other tapping an unlit cigarette against the ashtray. His thoughts were circling the Bennett house."
    "片手はハンドルに。もう片方の手は、火のついていない煙草で灰皿を叩いていた。彼の考えはBennettの家のまわりを回っていた。"

# game/script/ch05.rpy:300
translate japanese ch05_73996fb3:

    # th "George isn't just strict. He's dominant."
    th "Georgeはただ厳しいんじゃない。支配している。"

# game/script/ch05.rpy:301
translate japanese ch05_79f33b60:

    # "The way Alice obeyed, without a breath of hesitation, without a glance back. That wasn't respect, and it wasn't a child's defiant obedience either."
    "Aliceの従い方。息ひとつのためらいもなく、振り返りもしなかった。あれは敬意ではないし、子どもが反抗まじりに従うのともちがう。"

# game/script/ch05.rpy:302
translate japanese ch05_356cfbd6:

    # "It was drilled into her. Conditioned."
    "叩きこまれていたのだ。条件づけられていた。"

# game/script/ch05.rpy:303
translate japanese ch05_ab6cee6c:

    # th "Abuse?"
    th "虐待か？"

# game/script/ch05.rpy:304
translate japanese ch05_8066f019:

    # "He hadn't seen marks. Not yet. But control like that, forbidding her even to speak of her parents, left a different kind of scar."
    "傷痕は見ていない。まだ。だがあれほどの支配は、両親のことを口にすることさえ禁じるような支配は、別の種類の傷を残す。"

# game/script/ch05.rpy:305
translate japanese ch05_a78bcaaf:

    # th "I don't want to make him upset."
    th "Georgeを怒らせたくありません。"

# game/script/ch05.rpy:306
translate japanese ch05_d4bef10c:

    # "With her, it hadn't sounded like a complaint. It had sounded like a warning."
    "あの子が言うと、不満には聞こえなかった。警告に聞こえた。"

# game/script/ch05.rpy:307
translate japanese ch05_24c82b85:

    # th "Why can't she talk about her parents?"
    th "なぜ両親のことを話せない？"

# game/script/ch05.rpy:308
translate japanese ch05_a1769623:

    # "If they were estranged, or dead, or dangerous themselves, why not just say so? Unless George wanted the silence. Unless the silence served him."
    "疎遠なのか、死んだのか、それとも両親自身が危険なのか。それならそう言えばいい。Georgeが沈黙を望んでいるのでなければ。沈黙が彼の役に立っているのでなければ。"

# game/script/ch05.rpy:310
translate japanese ch05_3b6b18a3:

    # note_voice "George: dominant. Child forbidden to speak of parents."
    note_voice "George：支配的。子は両親の話を禁じられている。"

# game/script/ch05.rpy:311
translate japanese ch05_d86e4e48:

    # "He'd talk to Mercer. See whether anyone had looked too closely at George Bennett and his granddaughter since they arrived."
    "Mercerと話そう。ここへ来て以来、George Bennettとその孫娘を詳しく調べた者がいるかどうか確かめよう。"

# game/script/ch05.rpy:312
translate japanese ch05_cd844fd9:

    # "For now, there was still the case. Three bodies in a week, and the evidence piling up in uneven layers."
    "今は、まだ事件がある。一週間で三つの死体。証拠はいびつな層をなして積み上がっていた。"

# game/script/ch05.rpy:322
translate japanese ch05_7ed6cb8d:

    # "He parked, braced against the storm, and went up to his room. The diary waited on the table. But there was one call to make first."
    "彼は車を停め、嵐に身構え、部屋へ上がった。日記がテーブルの上で待っていた。だが先にかけなければならない電話がひとつあった。"

# game/script/ch05.rpy:325
translate japanese ch05_77636598:

    # s "Captain. I've got updates."
    s "警部。報告があります。"

# game/script/ch05.rpy:326
translate japanese ch05_02a1afec:

    # d angry "Harris. You better have something, because all I've got on my desk are calls from Greyvale's mayor, county officials, and a goddamn state rep asking why a priest dropped dead at a funeral in broad daylight."
    d angry "Harris。何かつかんでるんだろうな。こっちの机にあるのは、Greyvaleの町長と郡の役人と、くそったれの州議員からの電話だけだ。白昼の葬式でなんで神父がぶっ倒れて死んだのかってな。"

# game/script/ch05.rpy:327
translate japanese ch05_3cab9f34:

    # "Samuel pinched the bridge of his nose."
    "Samuelは鼻梁をつまんだ。"

# game/script/ch05.rpy:328
translate japanese ch05_863da60d:

    # s "It happened right in front of me. Same pattern as Hensley. Sudden collapse, signs of poisoning. We collected the bottle he drank from. Forensics will confirm, but I'll bet it's yew again."
    s "俺の目の前で起きた。Hensleyと同じパターンだ。突然の昏倒、中毒の兆候。彼が飲んだボトルは回収した。鑑識が確認するが、賭けてもいい、またイチイだ。"

# game/script/ch05.rpy:329
translate japanese ch05_f46b673f:

    # "Doyle swore hard, the sound muffled but venomous."
    "Doyleは激しく毒づいた。くぐもってはいたが、毒のある声だった。"

# game/script/ch05.rpy:330
translate japanese ch05_560bf1ac:

    # d angry "Christ, Sam. Do you know what this means? We're not chasing a troubled kid, or a bad marriage turned ugly."
    d angry "なんてこった、Sam。これがどういうことかわかってるのか？俺たちが追ってるのは、問題を抱えたガキでも、こじれた夫婦でもない。"

# game/script/ch05.rpy:331
translate japanese ch05_67f1f11c:

    # d angry "We're hunting a serial. A goddamn serial killer in a town of less than three thousand people. And we've got nothing. No suspects, no witnesses, no goddamn trail."
    d angry "連続殺人犯を追ってるんだ。人口三千にも満たない町で、くそったれの連続殺人犯をな。なのにこっちには何もない。容疑者も、目撃者も、手がかりのかけらもない。"

# game/script/ch05.rpy:332
translate japanese ch05_83dc9f4d:

    # s "We've got breadcrumbs. Notes. That USB. The paper scraps with words cut out. There's a message in it. Someone's judging, picking targets for their flaws."
    s "パン屑ならある。メモ。あのUSB。言葉を切り出した紙の切れ端。そこにはメッセージがある。誰かが裁いてるんだ。欠点を理由に標的を選んで。"

# game/script/ch05.rpy:333
translate japanese ch05_0daaaabe:

    # d angry "Breadcrumbs don't catch killers. You've been there a week and now I've got three bodies and a goddamn panic brewing in a town that should've been a quiet assignment."
    d angry "パン屑で殺人犯は捕まらん。お前がそっちへ行って一週間、今じゃ死体が三つに、くそったれのパニックが煮えたぎってる。静かな仕事のはずだった町でな。"

# game/script/ch05.rpy:334
translate japanese ch05_47011524:

    # d angry "You realize how this looks? Like we sent our best man to shuffle paper in Greyvale, and instead he brought the devil to town."
    d angry "どう見えるかわかってるのか？うちのいちばんの男をGreyvaleに書類整理に送ったら、悪魔を町に連れこんだみたいに見えるんだぞ。"

# game/script/ch05.rpy:336
translate japanese ch05_10932874:

    # th "I called him at dawn to keep him calm. It bought two days."
    th "夜明けに電話して落ち着かせた。それで二日稼げた。"

# game/script/ch05.rpy:341
translate japanese ch05_11f95f38:

    # "Samuel's jaw tightened, but his voice stayed calm."
    "Samuelの顎がこわばった。だが声は平静なままだった。"

# game/script/ch05.rpy:342
translate japanese ch05_ef0b16e8:

    # s angry "I didn't bring anyone. Whoever's behind this was already here. I'm just uncovering the trail."
    s angry "俺は誰も連れこんじゃいない。これをやってるやつは最初からここにいた。俺はその跡を掘り起こしてるだけだ。"

# game/script/ch05.rpy:343
translate japanese ch05_f5bc0496:

    # d angry "Trail? Sam, there isn't a trail. There's a goddamn ghost running circles around us."
    d angry "跡だと？Sam、跡なんかない。くそったれの幽霊が俺たちのまわりをぐるぐる回ってるだけだ。"

# game/script/ch05.rpy:346
translate japanese ch05_41e1c06f:

    # "Samuel let it land. Doyle needed somewhere to put it, and Samuel had been a wall for worse."
    "Samuelはそれを受けとめた。Doyleにはそれをぶつける場所が必要だったし、Samuelはもっとひどいもののために壁になってきた。"

# game/script/ch05.rpy:347
translate japanese ch05_bd70a1da:

    # "Then, quietly, only the one correction."
    "それから静かに、ひとつだけ訂正した。"

# game/script/ch05.rpy:348
translate japanese ch05_fa7056a9:

    # s "Whoever's behind this was already here, Ray. I'm just uncovering the trail."
    s "これをやってるやつは最初からここにいたんだ、Ray。俺はその跡を掘り起こしてるだけだ。"

# game/script/ch05.rpy:349
translate japanese ch05_4912c178:

    # d angry "Trail? There isn't a trail. There's a goddamn ghost running circles around us."
    d angry "跡だと？跡なんかない。くそったれの幽霊が俺たちのまわりをぐるぐる回ってるだけだ。"

# game/script/ch05.rpy:351
translate japanese ch05_ae2a6c35:

    # d angry "Do you have a single suspect? A name? A face?"
    d angry "容疑者はひとりでもいるのか？名前は？顔は？"

# game/script/ch05.rpy:352
translate japanese ch05_2723408a:

    # "Samuel's silence was answer enough."
    "Samuelの沈黙が、何よりの答えだった。"

# game/script/ch05.rpy:353
translate japanese ch05_b88f5592:

    # d angry "Then get one. I don't care if you shake every house in that town. I don't care if you piss off every councilman. We cannot afford another body, you understand? Not one more."
    d angry "なら見つけろ。その町の家を一軒残らず揺さぶろうがかまわん。町議会の連中を全員怒らせようがかまわん。これ以上死体を出すわけにはいかないんだ、わかるか？あとひとつもだ。"

# game/script/ch05.rpy:358
translate japanese ch05_81597b40:

    # "Fear. Ray shouted when he was scared, and in nine years Samuel had never heard him this loud."
    "恐怖。Rayは怯えると怒鳴る。九年間で、Samuelは彼がこれほど大声を出すのを聞いたことがなかった。"

# game/script/ch05.rpy:363
translate japanese ch05_a9574a07:

    # "Samuel rubbed his temple, his eyes on the diary."
    "Samuelはこめかみをさすった。目は日記に向けられていた。"

# game/script/ch05.rpy:364
translate japanese ch05_7b473f33:

    # s neutral "I understand."
    s neutral "わかった。"

# game/script/ch05.rpy:365
translate japanese ch05_049ae48d:

    # d worried "Good. Because if there's another, the feds are going to crawl all over this, and they'll burn both of us in the process."
    d worried "よし。もうひとつ出たら、連邦の連中がこの件に群がってくる。その過程で俺たち二人とも焼かれるぞ。"

# game/script/ch05.rpy:366
translate japanese ch05_b75e20e9:

    # d angry "Find me a suspect, Sam. Fast. Or pack it up and come home."
    d angry "容疑者を見つけろ、Sam。急げ。でなきゃ荷物をまとめて帰ってこい。"

# game/script/ch05.rpy:369
translate japanese ch05_d03d5416:

    # "The line went dead."
    "電話が切れた。"

# game/script/ch05.rpy:370
translate japanese ch05_98c0df3f:

    # "He looked at the diary, its cover half-shadowed in the lamplight. The last thing Clara Ward had left behind."
    "彼は日記を見た。ランプの光のなかで、表紙は半分影になっていた。Clara Wardが遺した最後のもの。"

# game/script/ch05.rpy:371
translate japanese ch05_41cbfe2b:

    # th "A suspect. A face. A ghost doesn't leave trails."
    th "容疑者。顔。幽霊は跡を残さない。"

# game/script/ch05.rpy:372
translate japanese ch05_3b32f997:

    # th "But someone had to put the knife in her hand. Someone had to drop poison in their cups."
    th "だが誰かがあの子の手に刃物を握らせた。誰かがあいつらのカップに毒を落とした。"

# game/script/ch05.rpy:373
translate japanese ch05_1e30adee:

    # "He called Mercer on the way out, clipped."
    "出がけに彼はMercerに電話した。短く、要点だけ。"

# game/script/ch05.rpy:374
translate japanese ch05_977bb528:

    # s "Meet me at the department. You should be done with the priest's family by now."
    s "署で会おう。神父の家族の聴取はもう済んでるはずだな。"

# game/script/ch05.rpy:383
translate japanese ch05_b09f8e65:

    # "The station was half-dark when Samuel stepped in, snow dripping from his coat."
    "Samuelが入ったとき、署は半分暗かった。コートから雪がしたたった。"

# game/script/ch05.rpy:385
translate japanese ch05_1cc594f0:

    # "Mercer waited in a side office, a file open on the desk, his face pale with fatigue."
    "Mercerは脇の部屋で待っていた。机の上にファイルを開き、疲れで顔が青ざめていた。"

# game/script/ch05.rpy:386
translate japanese ch05_41a1f1b8:

    # s "What do we have?"
    s "何がわかった？"

# game/script/ch05.rpy:387
translate japanese ch05_d37fe68a:

    # m "Father Dimitrios Karalis. Fifty-six. Born and raised here in Greyvale, serving the parish nearly thirty years."
    m "Dimitrios Karalis神父。五十六歳。このGreyvaleで生まれ育って、三十年近く教区に仕えてました。"

# game/script/ch05.rpy:388
translate japanese ch05_c24d8bf7:

    # m "Married. His wife, Anna, has been away the last three days, visiting their children. No history of illness, no record of enemies."
    m "既婚。妻のAnnaはここ三日、子どもたちのところへ行っていて留守でした。病歴なし、敵がいた記録もなし。"

# game/script/ch05.rpy:389
translate japanese ch05_be38db1e:

    # m "People described him as stern but fair. Everyone knew him."
    m "厳しいが公平な人だった、とみんな言ってます。誰もが彼を知ってた。"

# game/script/ch05.rpy:390
translate japanese ch05_259253c5:

    # "He closed the file with a heavy hand."
    "彼は重い手つきでファイルを閉じた。"

# game/script/ch05.rpy:391
translate japanese ch05_3a1dba9b:

    # m "Detective, this wasn't random. He was as rooted in this town as the cemetery we buried Clara in."
    m "刑事、これは無差別じゃない。あの人は、Claraを埋めたあの墓地と同じくらい、この町に根を下ろしてたんです。"

# game/script/ch05.rpy:395
translate japanese ch05_416f7a8b:

    # "Before Samuel could answer, the door banged open. Lara rushed in, coat still dusted with snow, the priest's Bible pressed carefully to her chest."
    "Samuelが答える前に、ドアが勢いよく開いた。Laraが駆けこんできた。コートにはまだ雪がついていて、神父の聖書を大事そうに胸に押しあてていた。"

# game/script/ch05.rpy:396
translate japanese ch05_74bd5eed:

    # l "I found something."
    l "見つけたものがあります。"

# game/script/ch05.rpy:397
translate japanese ch05_b7223374:

    # "She set the book down, opened it to the middle, and with two fingers turned it so the men could see."
    "彼女は本を置き、真ん中あたりを開いて、二本の指で男たちに見えるよう向きを変えた。"

# game/script/ch05.rpy:399
translate japanese ch05_8223daa2:

    # "In the margin, in heavier ink that pressed fresh indentations visible under the lamp:"
    "余白に、濃いインクで。ランプの下で、筆圧による新しいへこみが見えた。"

# game/script/ch05.rpy:406
translate japanese ch05_4a0ff6ca:

    # note_voice "Your voice was false. Silence is purer."
    note_voice "お前の声は偽りだった。沈黙こそ清い。"

# game/script/ch05.rpy:416
translate japanese ch05_2418f408:

    # "The handwriting was sharp, deliberate. Letters cut into the paper rather than flowing across it."
    "筆跡は鋭く、意図的だった。文字は紙の上を流れているのではなく、紙に刻みこまれていた。"

# game/script/ch05.rpy:417
translate japanese ch05_5a4d6274:

    # m shaken "Holy hell..."
    m shaken "なんてこった……"

# game/script/ch05.rpy:418
translate japanese ch05_5dba8cd3:

    # "Samuel didn't move. The same style. The same cold judgment threaded through Maria's USB, through Hensley's scrap."
    "Samuelは動かなかった。同じ書き方。MariaのUSBを、Hensleyの切れ端を貫いていたのと同じ、冷たい裁き。"

# game/script/ch05.rpy:420
translate japanese ch05_0c043c16:

    # th "Liar. Weakness. Silence."
    th "嘘つき。弱さ。沈黙。"

# game/script/ch05.rpy:421
translate japanese ch05_1b9e17de:

    # "A pattern of judgment. Maybe not random. Maybe a taxonomy forming."
    "裁きのパターン。無作為ではないのかもしれない。分類体系ができつつあるのかもしれない。"

# game/script/ch05.rpy:424
translate japanese ch05_12b23e1a:

    # note_voice "LIAR — WEAKNESS — SILENCE. A taxonomy?"
    note_voice "嘘つき――弱さ――沈黙。分類体系？"

# game/script/ch05.rpy:426
translate japanese ch05_f7174371:

    # "He straightened slowly, his hand resting on the open Bible."
    "彼はゆっくりと身を起こした。手は開いた聖書の上に置かれていた。"

# game/script/ch05.rpy:427
translate japanese ch05_a2836c52:

    # s "We have a serial killer."
    s "連続殺人犯だ。"

# game/script/ch05.rpy:428
translate japanese ch05_3be27fd3:

    # "Mercer pointed at the evidence bag before Samuel could."
    "Samuelより先に、Mercerが証拠袋を指さした。"

# game/script/ch05.rpy:429
translate japanese ch05_b5353bdd:

    # m neutral "That scrap's cut from thicker stock. Not notebook paper. Could be from a hymn book."
    m neutral "その切れ端は厚い紙から切ってある。ノートの紙じゃない。賛美歌集かもしれません。"

# game/script/ch05.rpy:430
translate japanese ch05_d93c80a7:

    # "Samuel gave a brief nod. He hadn't noticed."
    "Samuelは短くうなずいた。彼は気づいていなかった。"

# game/script/ch05.rpy:431
translate japanese ch05_1ffd0a51:

    # "The statement hung in the room like frost. Lara shifted, lips pressed tight. Mercer's eyes darkened. They had known it in their bones already. Hearing it was worse."
    "その言葉は霜のように部屋に垂れこめた。Laraは身じろぎし、唇を固く結んだ。Mercerの目が暗くなった。二人とも骨の髄ではもうわかっていた。それを耳で聞くのは、もっと悪かった。"

# game/script/ch05.rpy:432
translate japanese ch05_2bcac519:

    # s "And the person who's doing this... believes they're a judge. Criticizing. Weighing. Passing sentence."
    s "そして、これをやっている人物は……自分が裁判官だと信じている。非難し。量り。判決を下す。"

# game/script/ch05.rpy:433
translate japanese ch05_b79314d0:

    # "He let the silence stretch. Then he turned to Mercer."
    "彼は沈黙を長引かせた。それからMercerのほうを向いた。"

# game/script/ch05.rpy:434
translate japanese ch05_fc567cb7:

    # s "Can you run a background check on George Bennett?"
    s "George Bennettの身元を洗ってくれるか？"

# game/script/ch05.rpy:435
translate japanese ch05_e143f69f:

    # m "Of course. But... why George?"
    m "もちろん。でも……なんでGeorgeなんです？"

# game/script/ch05.rpy:436
translate japanese ch05_36da3fe5:

    # s "Because his granddaughter told me this: Weakness. Dishonesty. Hypocrisy. It all shows in the end. And when it does, it has to be corrected."
    s "孫娘が俺にこう言ったからだ。弱さ。不誠実。偽善。最後には全部表に出る。そして出たら、正されなければならない。"

# game/script/ch05.rpy:437
translate japanese ch05_475b744b:

    # s "That's not childhood wisdom. That's what George is teaching her. Or better: enforcing on her."
    s "あれは子どもの知恵じゃない。Georgeが教えてることだ。いや、もっと言えば、あの子に強いてることだ。"

# game/script/ch05.rpy:438
translate japanese ch05_81943569:

    # "The disgust was visible on both their faces. Lara's jaw tightened, her eyes flashing."
    "嫌悪が二人の顔にありありと浮かんだ。Laraは顎をこわばらせ、目をぎらりと光らせた。"

# game/script/ch05.rpy:439
translate japanese ch05_8293466b:

    # m angry "That's not something you drill into a twelve-year-old. That's—"
    m angry "そんなこと、十二歳の子に叩きこむもんじゃない。そんなのは――"

# game/script/ch05.rpy:440
translate japanese ch05_2e95e191:

    # "He cut himself short, anger simmering."
    "彼は言葉を切った。怒りがくすぶっていた。"

# game/script/ch05.rpy:441
translate japanese ch05_6d3f8525:

    # "Samuel closed the Bible gently and slid it into the evidence bag. His expression remained unreadable."
    "Samuelは聖書をそっと閉じ、証拠袋に滑りこませた。その表情は読めないままだった。"

# game/script/ch05.rpy:442
translate japanese ch05_03f01f18:

    # m neutral "I'll dig. As much as I can. But don't expect much. He's clean on the surface. When they moved here, I checked him out myself. Nothing in the system. Not even a speeding ticket."
    m neutral "掘ってみます。できるかぎり。でも期待しないでください。表向きはきれいなもんです。あいつらがここへ越してきたとき、俺が自分で調べたんです。システムには何もなかった。スピード違反の切符一枚も。"

# game/script/ch05.rpy:443
translate japanese ch05_b2c1afdb:

    # s "Check again. This time, deeper."
    s "もう一度調べろ。今度はもっと深く。"

# game/script/ch05.rpy:444
translate japanese ch05_71510bb3:

    # m "Alright."
    m "わかりました。"

# game/script/ch05.rpy:445
translate japanese ch05_9eb8d49f:

    # "The storm's whistle leaked faintly through the windows. Samuel turned to Lara."
    "嵐の唸りが窓からかすかに漏れてきた。SamuelはLaraのほうを向いた。"

# game/script/ch05.rpy:446
translate japanese ch05_fb3120e8:

    # s "What about yew? Anyone local who'd know the plant? Where it grows, who's been buying it?"
    s "イチイのほうは？地元でこの植物に詳しい人間は？どこに生えてるか、誰が買ってるか。"

# game/script/ch05.rpy:448
translate japanese ch05_25f1a99e:

    # l "Nick Green. Runs the nursery just outside of town, near the old mill road. People go to him for anything green. Hedges, garden plants, specialty orders."
    l "Nick Greenです。町のすぐ外、古い製粉所の道の近くで園芸店をやっています。緑のものなら何でも、みんな彼のところへ行きます。生垣も、庭の植物も、特別注文も。"

# game/script/ch05.rpy:449
translate japanese ch05_1484b68b:

    # l "If anyone knows about yew in this area, it's him."
    l "この辺りのイチイのことを知っている人がいるとしたら、彼です。"

# game/script/ch05.rpy:450
translate japanese ch05_da23aaaa:

    # s "Good. Let's pay him a visit."
    s "いいだろう。会いに行こう。"

# game/script/ch05.rpy:451
translate japanese ch05_551978c7:

    # m "I'll stay and start pulling everything I can on Bennett."
    m "俺は残って、Bennettのことを引っぱれるだけ引っぱり始めます。"

# game/script/ch05.rpy:452
translate japanese ch05_e4b2c628:

    # s "Do that."
    s "頼む。"

# game/script/ch05.rpy:463
translate japanese ch05_1a7eec42:

    # "Snow was piling against the curbs, the wind sharper than before. The engine coughed before the heater began to hum."
    "雪が縁石に吹き寄せられ、風は前より鋭くなっていた。エンジンが咳きこみ、それからヒーターが低く唸りはじめた。"

# game/script/ch05.rpy:464
translate japanese ch05_7d706a91:

    # "Past shuttered shops and houses already swallowed in snow. Fifteen minutes later, the headlights caught a wooden sign. Green's Nursery."
    "閉ざされた店々と、すでに雪にのまれた家々を過ぎて。十五分後、ヘッドライトが木の看板をとらえた。Green's Nursery。"

# game/script/ch05.rpy:469
translate japanese ch05_f31fe85d:

    # "A squat building with a glasshouse attached, its roof glowing faintly from inside. Rows of covered plants. Tools arranged neatly under awnings."
    "ずんぐりした建物に温室がくっついていて、その屋根が内側からかすかに光っていた。覆いをかけた植物の列。軒の下にきちんと並べられた道具。"

# game/script/ch05.rpy:470
translate japanese ch05_5ee1ae87:

    # "Inside, the air was damp and rich with soil. The smell of green life, clashing with the death they'd carried all week."
    "なかの空気は湿っていて、土の匂いが濃かった。緑の生命の匂いが、彼らが一週間ずっと抱えてきた死とぶつかった。"

# game/script/ch05.rpy:472
translate japanese ch05_56561d85:

    # "Behind the counter stood a stocky man in his late forties, wiping soil-stained hands on his apron."
    "カウンターの奥に、四十代後半のずんぐりした男が立っていた。土で汚れた手をエプロンで拭いていた。"

# game/script/ch05.rpy:473
translate japanese ch05_ff296e25:

    # ng "Detective. Officer. What brings you out here in this weather?"
    ng "刑事さん。巡査さん。こんな天気に、こんなところまで何の用です？"

# game/script/ch05.rpy:475
translate japanese ch05_463bb69a:

    # l "Nick Green. Sorry to bother you. We've got some questions about yew."
    l "Nick Greenさん。お邪魔してすみません。イチイについていくつか伺いたいことがあって。"

# game/script/ch05.rpy:476
translate japanese ch05_1375a180:

    # "His brows lifted. He waved them deeper into the greenhouse, where lamps glowed warm against rows of potted shrubs. The air smelled of damp soil and resin."
    "彼は眉を上げた。そして二人を温室の奥へ手招きした。そこでは鉢植えの低木の列に、ランプが暖かく灯っていた。空気は湿った土と樹脂の匂いがした。"

# game/script/ch05.rpy:477
translate japanese ch05_68d3efc7:

    # ng "Yew? Yes, of course. Common enough around here. You'd be surprised how many people keep it without realizing what it is."
    ng "イチイ？ええ、もちろん。この辺じゃよくある木ですよ。それと知らずに植えてる人がどれだけ多いか、驚きますよ。"

# game/script/ch05.rpy:481
translate japanese ch05_e364100b:

    # s "Give me examples."
    s "例を挙げてください。"

# game/script/ch05.rpy:485
translate japanese ch05_3e9bb010:

    # s "Start with the poison. How hard is it to make it kill?"
    s "まず毒のほうから。人を殺せるようにするのは、どれくらい難しいですか？"

# game/script/ch05.rpy:487
translate japanese ch05_7483a66e:

    # s "And where would someone get it? Give me examples."
    s "それと、どこで手に入れられますか？例を挙げてください。"

# game/script/ch05.rpy:490
translate japanese ch05_b409f102:

    # "Nick leaned his arms on the counter, his expression serious."
    "Nickはカウンターに両腕をもたせかけた。表情は真剣だった。"

# game/script/ch05.rpy:491
translate japanese ch05_3201db68:

    # ng "Detective, if someone is using yew in this town, they didn't have to buy it. It's everywhere. Every hedge you passed on your way here could be the source."
    ng "刑事さん、もしこの町で誰かがイチイを使ってるなら、わざわざ買う必要なんかなかった。どこにでもあるんです。ここへ来る途中で通り過ぎた生垣のどれだって、出どころになりえる。"

# game/script/ch05.rpy:492
translate japanese ch05_061a9724:

    # "Samuel shut his notebook, jaw tightening."
    "Samuelは手帳を閉じた。顎がこわばった。"

# game/script/ch05.rpy:493
translate japanese ch05_fd0aaadb:

    # th "Widespread. Accessible. Invisible. A perfect weapon for someone who wanted judgment to look like chance."
    th "どこにでもある。手に入る。目に見えない。裁きを偶然に見せかけたい人間には、完璧な凶器だ。"

# game/script/ch05.rpy:495
translate japanese ch05_7e4c6a9f:

    # note_voice "Yew: every hedge in Greyvale. Resin on hands for hours."
    note_voice "イチイ：Greyvaleの生垣すべて。手に樹脂、数時間残る。"

# game/script/ch05.rpy:496
translate japanese ch05_94b25068:

    # s "Thank you, Mr. Green. That's what I needed."
    s "ありがとう、Greenさん。それが聞きたかったんです。"

# game/script/ch05.rpy:497
translate japanese ch05_d3422e18:

    # ng "If you want samples tested or plants cataloged, I can help. But finding the source? That'll be near impossible."
    ng "サンプルの検査とか、植物の目録づくりなら手伝えます。でも出どころを突きとめるとなると？まず無理でしょうね。"

# game/script/ch05.rpy:498
translate japanese ch05_9399b412:

    # "Samuel and Lara exchanged a look."
    "SamuelとLaraは目を見交わした。"

# game/script/ch05.rpy:499
translate japanese ch05_08723f67:

    # s "Near impossible. That's exactly what this bastard wants."
    s "まず無理。まさにそれこそ、この野郎の狙いだ。"

# game/script/ch05.rpy:500
translate japanese ch05_d8f1479f:

    # "He slid a business card across the counter."
    "彼はカウンター越しに名刺を滑らせた。"

# game/script/ch05.rpy:501
translate japanese ch05_3bdb1ca2:

    # s "If you think of anything — someone asking strange questions, anyone taking cuttings, anything out of place — call me directly. Day or night."
    s "何か思い当たることがあったら――妙なことを訊いてくる人間、挿し木用に枝を切っていく人間、何かおかしなこと――直接私に電話してください。昼でも夜でも。"

# game/script/ch05.rpy:502
translate japanese ch05_7116a3c7:

    # ng "I'll keep my eyes open."
    ng "気をつけて見ておきますよ。"

# game/script/ch05.rpy:503
translate japanese ch05_c644b1fb:

    # s "Let's go, Lara."
    s "行こう、Lara。"

# game/script/ch05.rpy:509
translate japanese ch05_yew_where_e982e53d:

    # "Nick pointed toward a long row of tall, dark evergreens beyond the glass, needles bristling even in the storm."
    "Nickはガラスの向こうを指さした。背の高い暗い常緑樹が長く列をなし、嵐のなかでも針のような葉を逆立てていた。"

# game/script/ch05.rpy:510
translate japanese ch05_yew_where_6c524626:

    # ng "Those hedges you see in half the gardens? Yew. People like them because they grow thick, make good privacy screens."
    ng "半分の庭にあるあの生垣が見えますか？イチイです。厚く茂るんで、いい目隠しになるってみんな好きなんですよ。"

# game/script/ch05.rpy:511
translate japanese ch05_yew_where_e7fd0a44:

    # ng "You'll find them around schools, old estates, even the cemetery. Hardy plant, grows in poor soil, easy to trim."
    ng "学校のまわりにも、古い屋敷にも、墓地にだってある。丈夫な木で、痩せた土でも育つし、刈りこむのも楽だ。"

# game/script/ch05.rpy:512
translate japanese ch05_yew_where_842b7461:

    # ng "There's ornamental yew too. Dwarf varieties for decoration. Shrubs in front yards, sometimes even potted inside lobbies. No shortage of it in Greyvale."
    ng "観賞用のイチイもあります。飾り用の矮性種。前庭の低木とか、ときにはロビーの鉢植えとか。Greyvaleじゃ不足することはありませんよ。"

# game/script/ch05.rpy:514
translate japanese ch05_yew_where_b1a76de0:

    # l "So anyone could just... walk outside and cut some?"
    l "じゃあ、誰でも……外へ出て、ちょっと切ってくればいいってことですか？"

# game/script/ch05.rpy:515
translate japanese ch05_yew_where_78ce4304:

    # ng "Easily."
    ng "簡単にね。"

# game/script/ch05.rpy:519
translate japanese ch05_yew_how_89f9d0d3:

    # ng "Every trimming has enough toxin to cause trouble if someone knows what they're doing. The leaves, the seeds — almost the entire plant is poisonous, except the fleshy red berries."
    ng "刈りこんだ枝のどれにだって、扱い方を知ってる人間が使えば厄介を起こせるだけの毒がある。葉も、種も――ほとんど木全体が有毒です。赤い果肉の実を別にすればね。"

# game/script/ch05.rpy:520
translate japanese ch05_yew_how_ad07b68e:

    # ng "But the seeds inside those berries? Lethal. Doesn't take much to crush them into powder or steep them in water."
    ng "でも、その実のなかの種は？命取りです。砕いて粉にするのも、水に浸して煎じるのも、たいした手間じゃない。"

# game/script/ch05.rpy:521
translate japanese ch05_yew_how_c6682832:

    # "Samuel scribbled quickly."
    "Samuelはすばやく書きつけた。"

# game/script/ch05.rpy:522
translate japanese ch05_yew_how_0b4f5d31:

    # s "Could someone without training use it? Or would they need knowledge?"
    s "訓練を受けていない人間にも使えますか？それとも知識が要りますか？"

# game/script/ch05.rpy:523
translate japanese ch05_yew_how_7ae682ad:

    # ng "Knowledge helps, but you don't need to be a chemist. Anyone with curiosity could look it up. Even an amateur could make an extract dangerous enough to kill."
    ng "知識があれば助かるけど、化学者である必要はない。好奇心のある人間なら誰だって調べられる。素人でも、人を殺せるくらい危ない抽出液はつくれますよ。"

# game/script/ch05.rpy:524
translate japanese ch05_yew_how_a52a41b9:

    # ng "A concentrated tea. Ground seeds in food or drink."
    ng "濃く煎じたお茶。食べ物か飲み物に挽いた種を入れる。"

# game/script/ch05.rpy:525
translate japanese ch05_yew_how_894f010f:

    # ng "But anyone handling it would reek of resin for hours. On clothes, under nails. You'd know if you leaned close enough."
    ng "ただ、扱った人間は何時間も樹脂の匂いがぷんぷんしますよ。服にも、爪の下にも。顔を近づければわかるはずです。"

# game/script/ch05.rpy:532
translate japanese ch05_car_lara_b07959e2:

    # "The cold hit them hard. By the time they reached the car, the windshield was already dusted white."
    "寒さが二人を激しく打った。車にたどり着いたときには、フロントガラスはもう白く粉をふいていた。"

# game/script/ch05.rpy:533
translate japanese ch05_car_lara_b14cdc50:

    # "The heater groaned to life. Samuel rubbed his palms together, watching the storm whip the glass."
    "ヒーターがうめきながら動きだした。Samuelは手のひらをこすり合わせ、嵐がガラスを鞭打つのを見ていた。"

# game/script/ch05.rpy:535
translate japanese ch05_car_lara_c0067076:

    # "Lara buckled in, jaw tight, tapping her glove against her knee."
    "Laraはシートベルトを締めた。顎をこわばらせ、手袋で膝を叩いていた。"

# game/script/ch05.rpy:536
translate japanese ch05_car_lara_aa9b911d:

    # l "Everything about this feels... too perfect."
    l "何もかもが……完璧すぎる気がします。"

# game/script/ch05.rpy:537
translate japanese ch05_car_lara_66ed9c57:

    # l "The blackmail, the words left behind, the poison. It's all too well-orchestrated. Like someone's rehearsed it."
    l "脅迫、残された言葉、毒。全部、手際がよすぎる。誰かがリハーサルしたみたいに。"

# game/script/ch05.rpy:538
translate japanese ch05_car_lara_4043bd89:

    # "Samuel struck a match, lit a cigarette, and leaned back."
    "Samuelはマッチを擦り、煙草に火をつけて、背にもたれた。"

# game/script/ch05.rpy:539
translate japanese ch05_car_lara_2575485b:

    # s "That's because they have. Whoever this is, they've been planning for a long time."
    s "実際にしたからだ。これが誰であれ、長いあいだ計画してきたんだ。"

# game/script/ch05.rpy:540
translate japanese ch05_car_lara_67c5e6d2:

    # "Lara exhaled sharply, staring out at the snow."
    "Laraは鋭く息を吐き、雪を見つめた。"

# game/script/ch05.rpy:552
translate japanese ch05_car_lara_cdccd7d7:

    # "By morning the storm had eased. The streets were still caked with snow, the air brittle with cold, but the department hummed with purpose."
    "朝には嵐はおさまっていた。通りはまだ雪で固まり、空気は寒さでもろかったが、署は目的をもってざわめいていた。"

# game/script/ch05.rpy:553
translate japanese ch05_car_lara_15e86b75:

    # "Samuel sat in the cramped conference room, blinds half-drawn, a fresh mug of coffee cooling by his hand."
    "Samuelは狭い会議室に座っていた。ブラインドは半分下ろされ、淹れたてのコーヒーのマグが手もとで冷めていった。"

# game/script/ch05.rpy:556
translate japanese ch05_car_lara_60197838:

    # m "Toxicology came back this morning. No doubt about it. The priest's bottle contained yew alkaloids, same as Patrick Hensley."
    m "今朝、毒物検査の結果が出ました。疑いの余地なし。神父のボトルにはイチイのアルカロイドが入ってました。Patrick Hensleyと同じです。"

# game/script/ch05.rpy:557
translate japanese ch05_car_lara_55015941:

    # m "Autopsy confirms the same. Cardiac arrest brought on by poisoning. We've got a consistent method."
    m "解剖も同じ結論です。中毒による心停止。手口は一貫してます。"

# game/script/ch05.rpy:558
translate japanese ch05_car_lara_2dc56c34:

    # l "So it's official. Three bodies. Same killer."
    l "じゃあ公式ですね。死体が三つ。同じ犯人。"

# game/script/ch05.rpy:559
translate japanese ch05_car_lara_ec8ec4d5:

    # "Samuel tapped ash into the tray, his eyes on Mercer."
    "Samuelは灰皿に灰を落とした。目はMercerに向けていた。"

# game/script/ch05.rpy:560
translate japanese ch05_car_lara_5c84e201:

    # s "And Bennett?"
    s "で、Bennettは？"

# game/script/ch05.rpy:561
translate japanese ch05_car_lara_fd7da737:

    # "Mercer leaned forward, opening a thin file."
    "Mercerは身を乗り出し、薄いファイルを開いた。"

# game/script/ch05.rpy:562
translate japanese ch05_car_lara_33a05688:

    # m "This one's strange. George Bennett's house was bought outright, in cash. No loans, no mortgage. Title cleared and clean."
    m "こいつは妙です。George Bennettの家は一括で、現金で買われてる。ローンもない、抵当もない。権利関係はきれいなもんです。"

# game/script/ch05.rpy:563
translate japanese ch05_car_lara_d7657a2c:

    # m "He's registered as originating from Driftwood Bay. Small coastal village, three hours south. Barely more than a cluster of houses."
    m "出身はDriftwood Bayで登録されてます。南へ三時間の、小さな海辺の村です。家が何軒か寄り集まってるだけみたいなとこです。"

# game/script/ch05.rpy:564
translate japanese ch05_car_lara_a4c88f98:

    # s "Driftwood Bay..."
    s "Driftwood Bay……"

# game/script/ch05.rpy:566
translate japanese ch05_car_lara_71573b47:

    # m "I dug deeper last night. No criminal record, no financial trail, no ties outside Driftwood Bay."
    m "昨夜もっと深く掘ってみました。前科なし、金の流れなし、Driftwood Bayの外とのつながりもなし。"

# game/script/ch05.rpy:568
translate japanese ch05_car_lara_b58e3306:

    # m "Only thing that surfaced was a missing-persons report. Two sisters went missing there about two years ago."
    m "ひとつだけ出てきたのが、行方不明者届です。二年ほど前に、あそこで姉妹が二人いなくなってる。"

# game/script/ch05.rpy:569
translate japanese ch05_car_lara_e2261e64:

    # m "File's barebones, just a couple of patrol notes. Investigation went cold almost immediately. When I asked Driftwood Bay PD for the file, they were quick to dismiss it."
    m "ファイルはすかすかで、パトロールのメモがいくつかあるだけ。捜査はほとんどすぐに行き詰まってます。Driftwood Bayの警察にファイルを頼んだら、さっさとはねつけられました。"

# game/script/ch05.rpy:571
translate japanese ch05_car_lara_18c296f3:

    # l "That's all?"
    l "それだけ？"

# game/script/ch05.rpy:572
translate japanese ch05_car_lara_9580edd7:

    # m "That's all. No follow-up, no statements worth a damn. Like it was buried before it started."
    m "それだけです。追跡調査もなし、まともな供述もひとつもなし。始まる前に埋められたみたいに。"

# game/script/ch05.rpy:573
translate japanese ch05_car_lara_148b8427:

    # m "Locals don't talk about it. Driftwood Bay's like a wall. Outsiders get shrugs, silence, or ghost stories. If Bennett came from there, whatever shaped him didn't make it into a report."
    m "地元の人間はそのことを話さない。Driftwood Bayは壁みたいなもんです。よそ者が聞いても、肩をすくめられるか、黙られるか、怪談を聞かされるか。Bennettがあそこの出なら、あいつをつくったものが何であれ、報告書には載ってない。"

# game/script/ch05.rpy:575
translate japanese ch05_car_lara_20362c41:

    # note_voice "Bennett: cash purchase. Driftwood Bay. Two sisters missing, file buried."
    note_voice "Bennett：現金購入。Driftwood Bay。姉妹二人失踪、ファイルは埋もれた。"

# game/script/ch05.rpy:576
translate japanese ch05_car_lara_12b19986:

    # "Samuel's fingers drummed once against the folder. He reached for his cigarette case, stopped short, and closed it with a snap."
    "Samuelの指がフォルダーを一度だけ叩いた。彼は煙草入れに手を伸ばしかけて止め、ぱちんと閉じた。"

# game/script/ch05.rpy:577
translate japanese ch05_car_lara_cbfb5d7d:

    # s "I'll tell you both what I'm going to do."
    s "俺がこれからどうするか、二人に言っておく。"

# game/script/ch05.rpy:578
translate japanese ch05_car_lara_98e43fd4:

    # s "George Bennett leaves nothing on paper. But Alice has been under observation. If anyone has something solid, it'll be in her file."
    s "George Bennettは紙に何も残さない。だがAliceは経過観察を受けてる。誰かが確かなものを握ってるとしたら、あの子のファイルのなかだ。"

# game/script/ch05.rpy:579
translate japanese ch05_car_lara_3b3c9762:

    # m "The school's psychologist?"
    m "学校の心理士ですか？"

# game/script/ch05.rpy:580
translate japanese ch05_car_lara_ed51c939:

    # s "Dr. Markou. She's already talked with Clara. She's seen Alice too. If I can get those notes, we stop guessing about George's influence and start reading it in black and white."
    s "Markou医師だ。Claraとはもう話をしてる。Aliceのことも診てる。あのメモを手に入れれば、Georgeの影響を推測するのはやめて、白黒はっきりした記録で読めるようになる。"

# game/script/ch05.rpy:581
translate japanese ch05_car_lara_c8cdfe30:

    # l "You think she'll hand that over?"
    l "彼女がそれを渡すと思いますか？"

# game/script/ch05.rpy:582
translate japanese ch05_car_lara_3ea7967e:

    # s "She'll understand it's part of the investigation."
    s "捜査の一環だとわかってくれるさ。"

# game/script/ch05.rpy:583
translate japanese ch05_car_lara_7798d557:

    # "He stood, slipping the case back into his coat."
    "彼は立ち上がり、煙草入れをコートに戻した。"

# game/script/ch05.rpy:584
translate japanese ch05_car_lara_d7bdd65a:

    # s "One way or another, I'll get it."
    s "どうやってでも、手に入れる。"

# game/script/ch05.rpy:597
translate japanese ch05_car_lara_3f3da8ba:

    # "Snow clung to his shoulders as he came in out of the gray morning. The lobby smelled of oak smoke and polish. A clock ticked with the slow certainty of a metronome."
    "灰色の朝から入ってきた彼の肩に、雪がしがみついていた。ロビーは樫の煙と磨き剤の匂いがした。時計がメトロノームのようにゆっくりと確かに時を刻んでいた。"

# game/script/ch05.rpy:598
translate japanese ch05_car_lara_07c91910:

    # "He didn't bother with pleasantries. He hung his coat and pushed into Helena Markou's office."
    "彼は挨拶に手間をかけなかった。コートを掛け、Helena Markouの診察室へ押し入った。"

# game/script/ch05.rpy:600
translate japanese ch05_car_lara_e1772d3e:

    # "She was already standing, one hand on the back of her chair, the other flattening a page in an open notebook. Professionally neutral."
    "彼女はもう立っていた。片手を椅子の背に、もう片方の手で開いた手帳のページを押さえていた。職業的に中立な顔だった。"

# game/script/ch05.rpy:601
translate japanese ch05_car_lara_75a73f1f:

    # h "Detective Harris."
    h "Harris刑事。"

# game/script/ch05.rpy:602
translate japanese ch05_car_lara_4059eca2:

    # s "I need Alice Bennett's file."
    s "Alice Bennettのファイルが必要です。"

# game/script/ch05.rpy:603
translate japanese ch05_car_lara_c67e822e:

    # "No softening, no lead-in. The words landed like a stamp on wet paper."
    "和らげもせず、前置きもなく。その言葉は濡れた紙に捺された判のように落ちた。"

# game/script/ch05.rpy:604
translate japanese ch05_car_lara_7ad3782f:

    # "Helena's eyes flicked to the door as it clicked shut, then back to his face."
    "ドアがかちりと閉まると、Helenaの目はそちらへ走り、また彼の顔に戻った。"

# game/script/ch05.rpy:605
translate japanese ch05_car_lara_faeb5921:

    # h "You're direct."
    h "単刀直入ですね。"

# game/script/ch05.rpy:606
translate japanese ch05_car_lara_d7efb5d9:

    # s "I'm out of time. Three deaths in a week. One of them a child, the last in front of half the town."
    s "時間がないんです。一週間で三人が死んだ。ひとりは子どもで、最後のひとりは町の半分の目の前で死んだ。"

# game/script/ch05.rpy:607
translate japanese ch05_car_lara_c61129e7:

    # s "Whoever's doing this writes in judgments. And the only person I've heard use the same language is a twelve-year-old repeating her grandfather."
    s "これをやっている人間は、裁きの言葉で書く。そして同じ言葉を使うのを私が聞いたのは、祖父の言葉を繰り返す十二歳の子だけです。"

# game/script/ch05.rpy:608
translate japanese ch05_car_lara_d4df8f88:

    # "Helena drew out the chair and sat, folding her hands on the desk."
    "Helenaは椅子を引いて座り、机の上で両手を組んだ。"

# game/script/ch05.rpy:609
translate japanese ch05_car_lara_07e54531:

    # h "You're referring to 'flaws' and 'correction.'"
    h "「欠点」と「矯正」のことをおっしゃっているのですね。"

# game/script/ch05.rpy:610
translate japanese ch05_car_lara_d9f30ddc:

    # s "That's right."
    s "そうです。"

# game/script/ch05.rpy:611
translate japanese ch05_car_lara_f0b994dc:

    # h "And you believe access to her confidential record will — what? Prove a murderer's philosophy?"
    h "それで、あの子の秘密の記録を見れば――何ですか？殺人者の哲学が証明できるとでも？"

# game/script/ch05.rpy:612
translate japanese ch05_car_lara_bdb7c4ab:

    # s "I believe it will tell me whether Alice is speaking in her own voice or someone else's. Whether she's a mirror, or a mouthpiece."
    s "あの子が自分の声で話しているのか、誰か別の人間の声で話しているのか、それがわかると思っています。鏡なのか、それとも代弁者なのか。"

# game/script/ch05.rpy:613
translate japanese ch05_car_lara_00dcfe09:

    # s "And whether George Bennett is more than a strict guardian."
    s "そして、George Bennettがただの厳しい保護者以上のものなのかどうか。"

# game/script/ch05.rpy:614
translate japanese ch05_car_lara_c78d4b97:

    # h "You've seen abused children before, Detective?"
    h "虐待された子どもを見たことはおありですか、刑事さん？"

# game/script/ch05.rpy:615
translate japanese ch05_car_lara_bf9bdd8b:

    # s "Yes."
    s "あります。"

# game/script/ch05.rpy:616
translate japanese ch05_car_lara_56210b29:

    # h concerned "Then you know how thin the ice is. You know how quickly a child's trust fractures when adults with badges treat them as sources instead of patients."
    h concerned "なら、氷がどれほど薄いかご存じでしょう。バッジをつけた大人が子どもを患者ではなく情報源として扱ったとき、子どもの信頼がどれほどあっけなく割れるか。"

# game/script/ch05.rpy:617
translate japanese ch05_car_lara_4b3762ce:

    # "She slid the notebook aside, revealing a neat stack of folders."
    "彼女は手帳を脇へ滑らせた。きちんと積まれたフォルダーの山が現れた。"

# game/script/ch05.rpy:618
translate japanese ch05_car_lara_8766259e:

    # h firm "I won't give you her file."
    h firm "あの子のファイルはお渡ししません。"

# game/script/ch05.rpy:635
translate japanese ch05_car_lara_f9951c58:

    # "The fire cracked behind her. The room had the calm of a cathedral and the tension of a wire."
    "彼女の背後で暖炉の火がはぜた。部屋には大聖堂の静けさと、張りつめた針金の緊張があった。"

# game/script/ch05.rpy:642
translate japanese ch05_car_lara_89aebcba:

    # "The file was on the desk. She had put it there before he came in, so that he could watch her not give it to him."
    "ファイルは机の上にあった。彼女は彼が来る前にそこに置いておいたのだ。それを彼に渡さないところを、彼に見せるために。"

# game/script/ch05.rpy:645
translate japanese ch05_car_lara_d1bce25d:

    # s "Then meet me halfway. Tell me, as a clinician, whether what she says is indoctrination, or precocity. Whether she parrots phrases, or believes them. No names. No details. Just the shape."
    s "なら歩み寄ってください。臨床医として教えてほしい。あの子の言うことが教化によるものなのか、早熟なのか。言葉をおうむ返しにしているのか、信じているのか。名前はいらない。詳細もいらない。輪郭だけでいい。"

# game/script/ch05.rpy:646
translate japanese ch05_car_lara_9748bacb:

    # h "You're a clever man. You know that even answering that much is a step down a slope designed for speed."
    h "あなたは賢い方です。それだけ答えることさえ、速く滑り落ちるようにできた坂へ一歩踏み出すことだと、わかっていらっしゃるはずです。"

# game/script/ch05.rpy:647
translate japanese ch05_car_lara_9559cc54:

    # s "I'll take the slope. Children are dying."
    s "坂なら引き受けます。子どもたちが死んでいるんです。"

# game/script/ch05.rpy:648
translate japanese ch05_car_lara_ba1cbfd9:

    # "She adjusted her glasses."
    "彼女は眼鏡の位置を直した。"

# game/script/ch05.rpy:649
translate japanese ch05_car_lara_3700c7f0:

    # h "Children have always been dying. Some by their own hands, some because men decide their flaws demand correction. That isn't solved by handing you a girl's insides on paper."
    h "子どもたちはいつだって死んできました。自分の手で死ぬ子もいれば、大人の男たちが、この子の欠点には矯正が必要だと決めたせいで死ぬ子もいる。女の子の内側を紙にしてあなたに渡したところで、それは解決しません。"

# game/script/ch05.rpy:650
translate japanese ch05_car_lara_d687a097:

    # s "You can document a case history without betraying a patient. You can speak in generalities."
    s "患者を裏切らずに病歴をまとめることはできるはずです。一般論で話すこともできる。"

# game/script/ch05.rpy:651
translate japanese ch05_car_lara_dfb2ae6b:

    # h "I can. And I won't."
    h "できます。でも、しません。"

# game/script/ch05.rpy:652
translate japanese ch05_car_lara_f7547362:

    # "Samuel's knuckles whitened against the desk. He forced them flat. Took it in. Recalibrated."
    "机に押しつけたSamuelの拳が白くなった。彼は無理にそれを平らにした。受けとめた。調整し直した。"

# game/script/ch05.rpy:653
translate japanese ch05_car_lara_ffa3ddc0:

    # "He opened his hands, palms up, as if offering something invisible."
    "彼は両手を開き、手のひらを上に向けた。目に見えない何かを差し出すように。"

# game/script/ch05.rpy:654
translate japanese ch05_car_lara_64e1eb2a:

    # s "You told me yesterday that this town knew what Clara lived with and did nothing. You included yourself in that failure."
    s "昨日あなたは言った。この町はClaraがどんな暮らしをしているか知っていて、何もしなかったと。その過ちに、自分も含めた。"

# game/script/ch05.rpy:655
translate japanese ch05_car_lara_7138bb0b:

    # h sad "Yes. I did."
    h sad "ええ。含めました。"

# game/script/ch05.rpy:656
translate japanese ch05_car_lara_0d6495f8:

    # s "And today you're choosing the same caution that kept everyone comfortable while a girl wrote that she was made of glass."
    s "そして今日、あなたは同じ慎重さを選んでいる。女の子が自分はガラスでできていると書いているあいだ、みんなを安楽なままにしておいた、あの慎重さを。"

# game/script/ch05.rpy:657
translate japanese ch05_car_lara_d01d15d8:

    # h firm "No. Today I am choosing the only thing that has ever kept children like Alice from being ground between the police and the mob: a line."
    h firm "いいえ。今日私が選んでいるのは、Aliceのような子どもたちが警察と群衆のあいだですり潰されないよう、これまで守ってきた唯一のものです。一本の線です。"

# game/script/ch05.rpy:658
translate japanese ch05_car_lara_88edb4c5:

    # h "You want me to move it because you are desperate. Desperation is how bad detectives excuse broken rules. Don't make me watch you become one of them."
    h "あなたは追い詰められているから、私にそれを動かせとおっしゃる。追い詰められることは、悪い刑事が規則を破る言い訳です。あなたがそのひとりになるところを、私に見せないでください。"

# game/script/ch05.rpy:659
translate japanese ch05_car_lara_7b2c153f:

    # "The clock ticked. Samuel's fingers twitched toward a cigarette he couldn't light in here. He rubbed at the scar in his palm."
    "時計が時を刻んだ。Samuelの指が、ここでは火をつけられない煙草のほうへぴくりと動いた。彼は手のひらの傷痕をこすった。"

# game/script/ch05.rpy:660
translate japanese ch05_car_lara_00fe74dc:

    # s "Then give me process. Tell me how to request a court order for a limited review."
    s "なら手続きを教えてください。限定的な閲覧のための裁判所命令をどう請求すればいいか。"

# game/script/ch05.rpy:661
translate japanese ch05_car_lara_f1427458:

    # s "Tell me what threshold a judge needs. A clinician's affidavit, a risk assessment, a sworn statement that a child's worldview has been weaponized."
    s "判事にはどんな基準が要るのか教えてください。臨床医の宣誓供述書か、リスク評価か、子どもの世界観が武器にされたという宣誓陳述か。"

# game/script/ch05.rpy:662
translate japanese ch05_car_lara_016791f9:

    # "She reached for a pen, then set it back down."
    "彼女はペンに手を伸ばし、それからまた置いた。"

# game/script/ch05.rpy:663
translate japanese ch05_car_lara_42b18a0b:

    # h "You won't get it before another body falls, if that is where your fear rests."
    h "もしあなたの恐れがそこにあるのなら、次の死体が出る前には手に入りませんよ。"

# game/script/ch05.rpy:664
translate japanese ch05_car_lara_0e46f01d:

    # s "My fear rests in a sentence written inside a priest's Bible. 'Your voice was false. Silence is purer.'"
    s "私の恐れは、神父の聖書のなかに書かれた一文にあります。『お前の声は偽りだった。沈黙こそ清い』。"

# game/script/ch05.rpy:665
translate japanese ch05_car_lara_f4c6dc2e:

    # s "Someone thinks they are cleansing this town. If Alice has been taught to admire that righteousness, I need to know."
    s "誰かが、この町を浄めていると思っている。もしAliceがその正しさを敬うよう教えこまれているなら、私は知る必要がある。"

# game/script/ch05.rpy:667
translate japanese ch05_car_lara_6092c36d:

    # "Her gaze softened by a degree. Not enough to yield."
    "彼女のまなざしがわずかに和らいだ。譲るほどではなかった。"

# game/script/ch05.rpy:668
translate japanese ch05_car_lara_9a44305a:

    # h "And if she has been taught to survive by sounding like the person who feeds her? If mimicry is safety? If the words are shield and not sword? You would still turn them into evidence."
    h "では、もしあの子が、自分を養ってくれる人間と同じ話し方をすることで生き延びるよう教えこまれていたら？真似ることが身を守ることだとしたら？言葉が剣ではなく盾だとしたら？それでもあなたは、それを証拠に変えるでしょう。"

# game/script/ch05.rpy:669
translate japanese ch05_car_lara_c3fa7e38:

    # s "I would turn them into understanding."
    s "私はそれを理解に変えます。"

# game/script/ch05.rpy:670
translate japanese ch05_car_lara_f7dbdcf3:

    # "It came out closer to pleading than he liked. He reined it back."
    "思ったより懇願に近い響きになった。彼は手綱を引き戻した。"

# game/script/ch05.rpy:671
translate japanese ch05_car_lara_46a7c8ba:

    # s "And maybe a way to stop whoever is putting poison in people's hands."
    s "そしてたぶん、人の手に毒を渡している誰かを止める方法に。"

# game/script/ch05.rpy:672
translate japanese ch05_car_lara_bdf0a7ae:

    # "Helena folded her arms."
    "Helenaは腕を組んだ。"

# game/script/ch05.rpy:673
translate japanese ch05_car_lara_2f4e6651:

    # h firm "No file, Detective. Not today. Not on my discretion. If a judge compels me, I will comply to the word of the order and not a syllable more. Until then, I am her doctor."
    h firm "ファイルはお渡ししません、刑事さん。今日は。私の裁量では。判事が命じるなら、命令の文言どおりに従います。一音たりともそれ以上は出しません。それまでは、私はあの子の医師です。"

# game/script/ch05.rpy:674
translate japanese ch05_car_lara_ca603cae:

    # "The fire murmured. Snow whispered against the window. He felt the old pulse behind his eyes: frustration, tempered by the part of him that respected a line held."
    "火がささやいた。雪が窓にささやきかけた。目の奥に、あの古い脈動を感じた。苛立ち。それを和らげているのは、線を守り抜く者を敬う、彼自身のなかの一部だった。"

# game/script/ch05.rpy:675
translate japanese ch05_car_lara_063491fb:

    # s "Then we're done for now."
    s "では、今のところはここまでですね。"

# game/script/ch05.rpy:676
translate japanese ch05_car_lara_c3c3d947:

    # "The smallest dip of her chin."
    "彼女の顎が、ごくわずかに下がった。"

# game/script/ch05.rpy:677
translate japanese ch05_car_lara_801545e0:

    # h neutral "For now."
    h neutral "今のところは。"

# game/script/ch05.rpy:679
translate japanese ch05_car_lara_1c389eaf:

    # note_voice "Markou: no file. 'For now.'"
    note_voice "Markou：ファイルなし。「今のところは」。"

# game/script/ch05.rpy:685
translate japanese ch05_car_lara_6c0dbce2:

    # "Outside, the snow pressed harder. He buttoned his coat, jaw tight."
    "外では雪がいっそう強く押し寄せていた。彼はコートのボタンをとめた。顎がこわばっていた。"

# game/script/ch05.rpy:686
translate japanese ch05_car_lara_b25b848b:

    # th "For now."
    th "今のところは。"

# game/script/ch05.rpy:687
translate japanese ch05_car_lara_23dfe03c:

    # "But children were bleeding out in locker rooms. Priests were dropping in front of crowds."
    "だが子どもたちがロッカールームで血を流して死んでいる。神父が群衆の前で倒れている。"

# game/script/ch05.rpy:688
translate japanese ch05_car_lara_6074244a:

    # "And George Bennett's granddaughter spoke in judgments like scripture."
    "そしてGeorge Bennettの孫娘は、聖典のように裁きの言葉を語る。"

# game/script/ch05.rpy:689
translate japanese ch05_car_lara_48668efa:

    # "'For now' wasn't going to last. He lit a cigarette on the steps, the smoke torn by the snow."
    "「今のところは」は長くはもたない。彼は階段で煙草に火をつけた。煙が雪に引き裂かれた。"

# game/script/ch05.rpy:702
translate japanese ch05_car_lara_50e7e8e7:

    # "Alice paced slowly near the tiled entrance of the girls' restroom, her shoes clicking faintly."
    "Aliceは女子トイレのタイル張りの入口の近くを、ゆっくりと行ったり来たりしていた。靴がかすかに音を立てた。"

# game/script/ch05.rpy:703
translate japanese ch05_car_lara_0a71d218:

    # "Mid-break. The corridors buzzed with scattered voices and laughter. She was waiting for Emily, probably doodling in the library again."
    "休み時間の半ば。廊下にはばらばらの声と笑いがざわめいていた。彼女はEmilyを待っていた。たぶんまた図書室で落書きをしているのだろう。"

# game/script/ch05.rpy:705
translate japanese ch05_car_lara_5b4b5972:

    # "Then came the noise. Muffled at first, then sharper. A squeal, a stifled sob, scuffling against ceramic."
    "そのとき、物音がした。はじめはくぐもって、それから鋭く。甲高い悲鳴、押し殺したすすり泣き、陶器に何かがこすれる音。"

# game/script/ch05.rpy:706
translate japanese ch05_car_lara_20dfbdd1:

    # "Someone was being shoved inside. Alice tilted her head toward the door, then pushed it open."
    "誰かがなかで押されていた。Aliceはドアのほうへ首をかしげ、それから押し開けた。"

# game/script/ch05.rpy:709
translate japanese ch05_car_lara_6e5db48f:

    # "The air smelled of disinfectant and damp cotton."
    "空気は消毒剤と湿った綿の匂いがした。"

# game/script/ch05.rpy:710
translate japanese ch05_car_lara_1585cbf0:

    # "Three older girls, fifteen or maybe sixteen, had another pressed hard against the mirror, her cheek smearing on the glass. Her shoulders shook as she sobbed."
    "年上の女の子が三人、十五か、ひょっとすると十六か、もうひとりの子を鏡に強く押しつけていた。その頬がガラスの上で擦れていた。肩がすすり泣きに震えていた。"

# game/script/ch05.rpy:711
translate japanese ch05_car_lara_9e7f5a73:

    # bully "Think you can flirt with Johnathan? He's mine. Everyone knows it."
    bully "Jonathanに色目使えると思ってんの？あの人は私のものなんだけど。みんな知ってるし。"

# game/script/ch05.rpy:712
translate japanese ch05_car_lara_ce3285d8:

    # "The others laughed, forcing the girl closer to the mirror, her breath fogging the cold surface."
    "ほかの子たちが笑い、その子をさらに鏡へ押しつけた。息が冷たい表面を曇らせた。"

# game/script/ch05.rpy:714
translate japanese ch05_car_lara_81c9de41:

    # "Alice lingered in the doorway, quiet, her gray-brown eyes flicking across the scene. They hadn't noticed her yet."
    "Aliceは戸口にとどまっていた。静かに、灰褐色の目で場面をすばやく見て取った。彼女たちはまだAliceに気づいていなかった。"

# game/script/ch05.rpy:715
translate japanese ch05_car_lara_f9fde1f2:

    # "The sobbing girl's gaze caught Alice's reflection in the mirror. Pleading, wordless."
    "泣いている子の目が、鏡に映ったAliceの姿をとらえた。言葉のない懇願。"

# game/script/ch05.rpy:716
translate japanese ch05_car_lara_f884460c:

    # "Alice stepped further in. She didn't look at the girl doing the barking. She tilted her head slightly, as if measuring the room rather than the people in it."
    "Aliceはさらに一歩なかへ入った。吠えている子のほうは見なかった。そこにいる人間ではなく部屋そのものを測るように、わずかに首をかしげた。"

# game/script/ch05.rpy:717
translate japanese ch05_car_lara_605d0ea9:

    # "Then her gaze locked on the tall one with the braided hair. The leader."
    "それから、彼女の視線は三つ編みの背の高い子に定まった。リーダーだ。"

# game/script/ch05.rpy:718
translate japanese ch05_car_lara_3930eb13:

    # a "I'm pretty sure the janitor cleans the restrooms during the twelves. Lunch break."
    a "用務員さん、十二時台にトイレの掃除をすると思うんですけど。お昼休みに。"

# game/script/ch05.rpy:719
translate japanese ch05_car_lara_1e18508e:

    # "She let it hang a beat, her tone flat as stone."
    "彼女はひと拍、その言葉を宙に置いた。口調は石のように平らだった。"

# game/script/ch05.rpy:720
translate japanese ch05_car_lara_b9a7e23a:

    # a "So he'll be here any minute now."
    a "だから、もうすぐここに来ますよ。"

# game/script/ch05.rpy:721
translate japanese ch05_car_lara_f49cff96:

    # "The bully froze. Her grip slackened. Doubt crossed her face, then calculation."
    "いじめっ子は凍りついた。握る手がゆるんだ。顔に疑いがよぎり、それから計算がよぎった。"

# game/script/ch05.rpy:722
translate japanese ch05_car_lara_4b5a8f4b:

    # bully "She's right. Let's go."
    bully "この子の言うとおりだ。行こ。"

# game/script/ch05.rpy:723
translate japanese ch05_car_lara_377cdbe2:

    # "One spat on the floor. Another shot Alice a look sharp enough to cut. None of them spoke as they left."
    "ひとりが床に唾を吐いた。もうひとりが、切れそうなほど鋭い目でAliceをにらんだ。出ていくあいだ、誰もひとことも口をきかなかった。"

# game/script/ch05.rpy:724
translate japanese ch05_car_lara_ef1ca751:

    # "The room fell quiet except for the hitching sobs of the girl at the mirror. A streak of moisture smeared down the glass where her cheek had been."
    "部屋は静まり返った。鏡の前の子の、しゃくりあげる声のほかは。頬があったところから、湿った筋がガラスを伝って垂れていた。"

# game/script/ch05.rpy:725
translate japanese ch05_car_lara_998fa772:

    # "She stumbled to the sink, splashed cold water on her blotched face, dried it on her sleeve, and pulled her bag onto her shoulder."
    "その子はよろめきながら流しへ行き、赤くまだらになった顔に冷たい水をかけ、袖で拭き、鞄を肩に引っかけた。"

# game/script/ch05.rpy:726
translate japanese ch05_car_lara_9da20339:

    # "Not once did she look at Alice."
    "一度も、Aliceのほうを見なかった。"

# game/script/ch05.rpy:730
translate japanese ch05_car_lara_855f86ff:

    # "The girl pushed out into the hallway, past Emily, who stood just outside clutching her books to her chest. The two locked eyes, and the girl was gone."
    "その子は廊下へ押し出ていった。すぐ外に本を胸に抱えて立っていたEmilyの横を通り過ぎて。二人の目が合い、そしてその子は行ってしまった。"

# game/script/ch05.rpy:732
translate japanese ch05_car_lara_6a175088:

    # e "Alice! I've been looking everywhere for you."
    e "Alice！あちこち探してたんだよ。"

# game/script/ch05.rpy:734
translate japanese ch05_car_lara_17d00efc:

    # "Alice's lips curved faintly. An echo of warmth."
    "Aliceの唇がかすかに弧を描いた。温もりの残響。"

# game/script/ch05.rpy:735
translate japanese ch05_car_lara_6fea6b20:

    # a "And I was waiting for you."
    a "私は、あなたを待ってた。"

# game/script/ch05.rpy:736
translate japanese ch05_car_lara_dac83d64:

    # e "Good. Because I didn't want to eat alone."
    e "よかった。ひとりでお昼食べたくなかったから。"

# game/script/ch05.rpy:737
translate japanese ch05_car_lara_680ea38a:

    # "They walked side by side toward the cafeteria. After a few steps, Emily leaned closer."
    "二人は並んで食堂へ歩いた。数歩行ったところで、Emilyが身を寄せた。"

# game/script/ch05.rpy:739
translate japanese ch05_car_lara_39801b02:

    # e "What happened in there? That girl looked... upset."
    e "あそこで何があったの？あの子……動揺してたみたいだけど。"

# game/script/ch05.rpy:741
translate japanese ch05_car_lara_1edff8fc:

    # a "She was being bullied."
    a "いじめられてたの。"

# game/script/ch05.rpy:742
translate japanese ch05_car_lara_f899c20d:

    # e "Oh."
    e "そっか。"

# game/script/ch05.rpy:743
translate japanese ch05_car_lara_04e5b24b:

    # a "I don't like bullies. They remind me of George."
    a "いじめっ子は嫌い。Georgeを思い出すから。"

# game/script/ch05.rpy:744
translate japanese ch05_car_lara_197255e3:

    # "A flicker of unease crossed Emily's face. But Alice's didn't shift. No drama, no complaint. Just fact."
    "Emilyの顔に不安がちらりとよぎった。だがAliceの顔は変わらなかった。芝居がかったところも、不平もない。ただの事実。"

# game/script/ch05.rpy:746
translate japanese ch05_car_lara_4f5d0bc6:

    # e "Well... I'm glad you were there. She was lucky you showed up."
    e "そっか……Aliceがいてよかった。あの子、Aliceが来てくれてラッキーだったね。"

# game/script/ch05.rpy:747
translate japanese ch05_car_lara_5578eb61:

    # "Alice's eyes lingered on the crowded room beyond the doors. Then a small nod."
    "Aliceの目は、扉の向こうの混み合った部屋にとどまっていた。それから小さくうなずいた。"

# game/script/ch05.rpy:748
translate japanese ch05_car_lara_e7d98c63:

    # a "Maybe."
    a "かもね。"

# game/script/ch05.rpy:757
translate japanese ch05_car_lara_add85d9f:

    # "They found a table near the windows. Emily picked at her bread roll, her gaze on the scratches in the tabletop."
    "二人は窓際のテーブルを見つけた。Emilyはロールパンをつつき、目はテーブルの引っかき傷に落としていた。"

# game/script/ch05.rpy:758
translate japanese ch05_car_lara_3c9d14d1:

    # e "My parents... they said I should start seeing Dr. Elena. After... you know. Everything that happened."
    e "うちの親……Elena先生のところに通いはじめたほうがいいって。そのあと……ほら。いろいろあったから。"

# game/script/ch05.rpy:759
translate japanese ch05_car_lara_7ede9dca:

    # "Alice looked at her calmly, waiting."
    "Aliceは落ち着いた目で彼女を見て、待っていた。"

# game/script/ch05.rpy:760
translate japanese ch05_car_lara_4f583771:

    # e scared "I don't know if it will help. I wake up almost every night. Nightmares. I see her face. The way it was..."
    e scared "効くのかどうかわかんない。ほとんど毎晩、目が覚めるの。悪い夢。あの子の顔が見えるの。あのときの……"

# game/script/ch05.rpy:761
translate japanese ch05_car_lara_a361faf3:

    # "She stopped, swallowing hard, eyes glistening."
    "彼女は言葉を止め、ごくりと唾をのんだ。目がうるんでいた。"

# game/script/ch05.rpy:762
translate japanese ch05_car_lara_f2c57126:

    # "Without hesitation, Alice reached across the table and took her hand. Her grip was steady, warm."
    "ためらいもなく、Aliceはテーブル越しに手を伸ばし、彼女の手を取った。その握り方は確かで、温かかった。"

# game/script/ch05.rpy:763
translate japanese ch05_car_lara_6212ff3d:

    # a "It's okay. It will pass if you focus on your daily tasks. Hold on to the good memories."
    a "大丈夫。毎日やることに集中してれば、過ぎていくよ。いい思い出につかまってて。"

# game/script/ch05.rpy:764
translate japanese ch05_car_lara_f92a55fb:

    # "Emily sniffled and managed a weak smile."
    "Emilyは鼻をすすり、弱々しく笑ってみせた。"

# game/script/ch05.rpy:766
translate japanese ch05_car_lara_40a5df76:

    # a "And if there aren't enough... make more."
    a "それで、もし足りなかったら……もっとつくればいい。"

# game/script/ch05.rpy:767
translate japanese ch05_car_lara_0b0b6a8b:

    # "Emily squeezed her hand, holding on like it was a lifeline."
    "Emilyはその手を握り返した。命綱にしがみつくように。"

# game/script/ch05.rpy:773
translate japanese ch05_car_lara_78a03eed:

    # "Afterward they walked the wide hall in silence, sun slanting through tall windows, catching the frost on the glass."
    "そのあと二人は広い廊下を黙って歩いた。日の光が高い窓から斜めに差しこみ、ガラスの霜をきらめかせていた。"

# game/script/ch05.rpy:774
translate japanese ch05_car_lara_85fbd06f:

    # "Then Emily spoke, careful, as if testing whether the words should be said aloud."
    "それからEmilyが口を開いた。その言葉を声に出していいのか確かめるように、慎重に。"

# game/script/ch05.rpy:775
translate japanese ch05_car_lara_4fd5b69b:

    # e "I heard my parents talking yesterday..."
    e "昨日、うちの親が話してるの聞いちゃったんだ……"

# game/script/ch05.rpy:776
translate japanese ch05_car_lara_846d60b0:

    # "She hugged her books tighter."
    "彼女は本をさらにきつく抱きしめた。"

# game/script/ch05.rpy:777
translate japanese ch05_car_lara_7ac86ff4:

    # e "They believe George is involved... you know. With what's been happening."
    e "Georgeが関わってるって思ってるみたい……ほら。今起きてることに。"

# game/script/ch05.rpy:778
translate japanese ch05_car_lara_936c0680:

    # "Alice kept walking, eyes forward, her silence deliberate. Emily glanced at her, waiting."
    "Aliceは歩きつづけた。目は前に向けたまま、意図して黙っていた。Emilyはちらりと彼女を見て、待った。"

# game/script/ch05.rpy:779
translate japanese ch05_car_lara_5fe61dce:

    # a "I don't know. George is different from the time we came here. I hardly see him when I'm home."
    a "わからない。Georgeはここに来たころとは変わったの。家にいても、ほとんど顔を合わせないし。"

# game/script/ch05.rpy:780
translate japanese ch05_car_lara_a0a48d45:

    # a "He's always doing things. Outside, in the garden, around the house. I'm in my room, studying or reading."
    a "いつも何かしてる。外で、庭で、家のまわりで。私は自分の部屋で勉強したり、本を読んだりしてる。"

# game/script/ch05.rpy:781
translate japanese ch05_car_lara_c35761a5:

    # "Plain words, delivered without hesitation. They hung between them with a weight that made Emily's brow crease."
    "飾り気のない言葉が、ためらいなく語られた。それは二人のあいだに重く垂れこめ、Emilyの眉を寄せさせた。"

# game/script/ch05.rpy:782
translate japanese ch05_car_lara_3b5979d6:

    # e "Still... it makes me nervous."
    e "それでも……なんか不安になる。"

# game/script/ch05.rpy:794
translate japanese ch05_car_lara_16defbe5:

    # "School ended, and Alice set out on the long walk home. Twenty-five minutes through snow. Her small steps stretched it longer."
    "学校が終わり、Aliceは家までの長い道のりを歩きはじめた。雪のなかを二十五分。小さな歩幅のせいで、それはもっと長くなった。"

# game/script/ch05.rpy:795
translate japanese ch05_car_lara_0f529da6:

    # "She didn't mind. The cold didn't bother her, and neither did the solitude. She welcomed it. Her time to let the noise of the day fall away."
    "彼女は気にしなかった。寒さは苦にならなかったし、ひとりでいることもそうだった。むしろ歓迎していた。一日の騒音を剥がれ落ちさせるための、自分の時間だった。"

# game/script/ch05.rpy:796
translate japanese ch05_car_lara_0ea8b281:

    # "Even after two years in Greyvale, some things were still hard to get used to. School, for one."
    "Greyvaleに来て二年経っても、まだ慣れにくいことがあった。たとえば、学校。"

# game/script/ch05.rpy:797
translate japanese ch05_car_lara_c4f8ae4c:

    # "Before, she had been homeschooled. A special, advanced program that pressed her far beyond her age. History, philosophy, mathematics, sciences. Lessons tailored to sharpen her."
    "以前は家で教育を受けていた。年齢をはるかに超えたところまで押し上げる、特別な先取りの課程。歴史、哲学、数学、科学。彼女を研ぎ澄ますためにあつらえられた授業。"

# game/script/ch05.rpy:798
translate japanese ch05_car_lara_0205e9cb:

    # "Now: crowded classrooms, dozens of students shifting and whispering, a new teacher for every subject, each measuring her with grades and tests."
    "今は、ぎゅうぎゅうの教室。何十人もの生徒がもぞもぞ動き、ひそひそ話す。教科ごとにちがう先生がいて、それぞれが成績とテストで彼女を測る。"

# game/script/ch05.rpy:799
translate japanese ch05_car_lara_bb00a6cc:

    # "Learning had been hers alone before. Now it was a performance, divided into parts, weighed and tallied."
    "以前、学ぶことは彼女だけのものだった。今それは演技であり、部分に切り分けられ、量られ、集計されるものだった。"

# game/script/ch05.rpy:806
translate japanese ch05_car_lara_20ef4f54:

    # "Her knuckles were red from the cold when she knocked."
    "ノックしたとき、彼女の拳は寒さで赤くなっていた。"

# game/script/ch05.rpy:808
translate japanese ch05_car_lara_bca2a447:

    # "George stood in the doorway, tall and immovable. His eyes narrowed briefly. A single nod. No greeting. Just passage."
    "Georgeが戸口に立っていた。背が高く、動かない。彼の目が一瞬細くなった。一度だけのうなずき。挨拶はない。ただ通すだけ。"

# game/script/ch05.rpy:813
translate japanese ch05_car_lara_ab6aab56:

    # "The house was warmer, heavy with woodsmoke. Her bag went into her room, neatly set aside. Then she returned to the table."
    "家のなかはもっと暖かく、薪の煙が重く立ちこめていた。鞄は自分の部屋へ、きちんと片づけた。それから彼女はテーブルに戻った。"

# game/script/ch05.rpy:816
translate japanese ch05_car_lara_30cf3428:

    # "George was already setting down two bowls of porridge. Not a trace of surprise crossed her face. It was always this."
    "Georgeはもう粥の椀を二つ並べているところだった。彼女の顔には驚きのかけらも浮かばなかった。いつもこうだった。"

# game/script/ch05.rpy:817
translate japanese ch05_car_lara_9ac488c6:

    # "They ate in silence. George slow, every motion deliberate."
    "二人は黙って食べた。Georgeはゆっくりと、ひとつひとつの動きを確かめるように。"

# game/script/ch05.rpy:818
translate japanese ch05_car_lara_31780ccd:

    # g "We will need to travel soon. We will go to another place."
    g "近いうちに、旅に出なけりゃならん。別の場所へ行く。"

# game/script/ch05.rpy:820
translate japanese ch05_car_lara_53442ced:

    # "Alice's spoon slipped and clattered against the bowl, splattering porridge onto her wrist. The heat bit her skin. She didn't flinch."
    "Aliceのスプーンが滑って椀にぶつかり、粥が手首に跳ねた。熱が肌に噛みついた。彼女はびくりともしなかった。"

# game/script/ch05.rpy:821
translate japanese ch05_car_lara_6fce4f83:

    # "George's eyes lifted to her, steady, unblinking. She lowered her gaze, picked up the spoon, and resumed eating."
    "Georgeの目が彼女に上がった。揺るがず、まばたきもしない。彼女は視線を落とし、スプーンを拾い、また食べはじめた。"

# game/script/ch05.rpy:822
translate japanese ch05_car_lara_c10a8a8c:

    # a "Are we going back home?"
    a "家に帰るんですか？"

# game/script/ch05.rpy:823
translate japanese ch05_car_lara_647fa1d6:

    # g "No. Somewhere else."
    g "いや。別のところだ。"

# game/script/ch05.rpy:824
translate japanese ch05_car_lara_b66fba8a:

    # a "Why do we need to go?"
    a "どうして行かなきゃいけないんですか？"

# game/script/ch05.rpy:825
translate japanese ch05_car_lara_e3518bfc:

    # g "Because I said so."
    g "俺がそう言ったからだ。"

# game/script/ch05.rpy:826
translate japanese ch05_car_lara_9a47eaeb:

    # a "Alright."
    a "わかりました。"

# game/script/ch05.rpy:827
translate japanese ch05_car_lara_2f8da5c6:

    # "Only the scrape of spoons after that. The crackle of the fire. The wind clawing at the shutters."
    "そのあとはスプーンのこすれる音だけだった。火のはぜる音。鎧戸をかきむしる風。"

# game/script/ch05.rpy:828
translate japanese ch05_car_lara_692edd48:

    # "Then, before she could stop herself, something in her broke the silence. The words pushed up, almost too loud for the room."
    "そのとき、止める間もなく、彼女のなかの何かが沈黙を破った。言葉が押し上がってきた。部屋にはほとんど大きすぎる声だった。"

# game/script/ch05.rpy:829
translate japanese ch05_car_lara_5dc7bd31:

    # a angry "What about Emily? She is my friend."
    a angry "Emilyはどうなるんですか？私の友だちです。"

# game/script/ch05.rpy:830
translate japanese ch05_car_lara_cf2c8d7a:

    # "For the first time all meal, George looked at her fully. Heavy. Assessing. His reply came almost indifferent."
    "食事のあいだではじめて、Georgeは彼女をまともに見た。重く。値踏みするように。返事はほとんど無関心に返ってきた。"

# game/script/ch05.rpy:831
translate japanese ch05_car_lara_cf8f54ff:

    # g neutral "You don't need friends. Not now."
    g neutral "友だちなどいらん。今はな。"

# game/script/ch05.rpy:833
translate japanese ch05_car_lara_76b293ac:

    # "The fire popped in the hearth. Alice's pulse thudded in her ears. She clenched the spoon tighter, breathing evenly, keeping her face steady."
    "暖炉の火がぱちんとはぜた。Aliceの耳の奥で脈が打った。彼女はスプーンをきつく握りしめ、呼吸を乱さず、顔を崩さなかった。"

# game/script/ch05.rpy:834
translate japanese ch05_car_lara_2420ff55:

    # "Inside, her thoughts coiled tighter, hotter. Outside, the mask held."
    "内側では、考えがきつく、熱く、とぐろを巻いた。外側では、仮面が持ちこたえた。"

# game/script/ch05.rpy:835
translate japanese ch05_car_lara_df3c839e:

    # "George finished, set his bowl down with a dull scrape of porcelain on wood, and rose. He smoothed his shirt and reached for his coat by the door."
    "Georgeは食べ終えると、陶器が木にこすれる鈍い音とともに椀を置き、立ち上がった。シャツをなでつけ、ドアのそばのコートに手を伸ばした。"

# game/script/ch05.rpy:836
translate japanese ch05_car_lara_94056358:

    # g "I have things to take care of. I will be late."
    g "片づける用がある。遅くなる。"

# game/script/ch05.rpy:839
translate japanese ch05_car_lara_74473c07:

    # "A gust of cold air spilled in. Then he was gone. The latch clicked shut."
    "冷たい風がひと吹き流れこんだ。そして彼は行ってしまった。掛け金がかちりと閉まった。"

# game/script/ch05.rpy:841
translate japanese ch05_car_lara_f6362cf2:

    # "Alice alone in the dim room, the half-empty bowls cooling on the table, the silence pressing in like another wall."
    "薄暗い部屋にひとりのAlice。半分残った椀がテーブルの上で冷めていき、沈黙がもうひとつの壁のように迫ってきた。"

# game/script/ch05.rpy:843
translate japanese ch05_car_lara_794cae43:

    # "Her thoughts twisted over themselves, sharper with every turn. Confusion. Panic. Anger. Clawing inside her chest, too strong to contain."
    "考えがよじれ、ねじれるたびに鋭くなっていった。混乱。恐慌。怒り。胸のなかで爪を立て、抑えきれないほど強かった。"

# game/script/ch05.rpy:844
translate japanese ch05_car_lara_86ec4051:

    # ath "Losing control is weakness. And weakness is intolerable."
    ath "自制を失うのは弱さだ。そして弱さは許されない。"

# game/script/ch05.rpy:849
translate japanese ch05_car_lara_ca9d6f3b:

    # "The scream tore out of her before she realized it, shrill and raw, scraping her throat until it burned, until the sound faltered and died."
    "気づく前に悲鳴がほとばしっていた。甲高く、生々しく、喉を焼けるまでこすり上げ、やがて音はよろめき、消えた。"

# game/script/ch05.rpy:853
translate japanese ch05_car_lara_39f1147e:

    # "Then only her ragged breath, echoing in the empty house. As though the house itself had heard, and would not forget."
    "あとには荒い息だけが、空っぽの家に響いていた。まるで家そのものが聞いていて、決して忘れないかのように。"

# game/script/ch05.rpy:856
translate japanese ch05_car_lara_2b412d05:

    # "Alice stood. Straightened her back. Smoothed her skirt."
    "Aliceは立ち上がった。背筋を伸ばした。スカートをなでつけた。"

# game/script/ch05.rpy:857
translate japanese ch05_car_lara_4df508fe:

    # "Piece by piece, her posture rebuilt itself, as if the scream had never been. Her face calm again."
    "少しずつ、姿勢がひとりでに組み直されていった。悲鳴などなかったかのように。顔はまた穏やかだった。"

# game/script/ch05.rpy:858
translate japanese ch05_car_lara_eccdb3c5:

    # "She lifted her coat from the peg, slipped it on, and buttoned it carefully."
    "彼女は掛け釘からコートを取り、袖を通し、丁寧にボタンをとめた。"

# game/script/ch05.rpy:865
translate japanese ch05_car_lara_e53f8efa:

    # "When she opened the door, the cold met her full in the face. She welcomed it. It bit her skin and cleared the heat from her head."
    "ドアを開けると、寒さが真正面から顔を打った。彼女はそれを歓迎した。寒さは肌に噛みつき、頭から熱を払った。"

# game/script/ch05.rpy:866
translate japanese ch05_car_lara_0eab5600:

    # "There was distance to cover. A long walk ahead. But she had time."
    "行かなければならない距離があった。長い道のり。だが時間はあった。"

# game/script/ch05.rpy:875
translate japanese ch05_car_lara_8e1fcd34:

    # "An hour later, snow clinging to her coat, Alice pushed open the psychologist's door. The warmth hit her like a wave."
    "一時間後、コートに雪をつけたまま、Aliceは心理士のドアを押し開けた。暖かさが波のように彼女を打った。"

# game/script/ch05.rpy:876
translate japanese ch05_car_lara_7fac3add:

    # "Her hair was damp, her cheeks raw. She looked smaller than usual, her coat weighed down with ice."
    "髪は湿り、頬は赤くすりむけたようだった。いつもより小さく見えた。コートは氷で重くなっていた。"

# game/script/ch05.rpy:878
translate japanese ch05_car_lara_ab14a6e8:

    # h "Alice! Good heavens, what on earth are you doing out in this weather?"
    h "Alice！まあ、こんな天気にいったい外で何をしているの？"

# game/script/ch05.rpy:880
translate japanese ch05_car_lara_5d73233a:

    # "Helena guided her to the armchair by the fire and draped a blanket across her lap. She checked her pulse at the wrist without comment, then returned with a steaming mug."
    "Helenaは彼女を暖炉のそばの肘掛け椅子へ連れていき、膝に毛布をかけた。何も言わずに手首で脈を確かめ、それから湯気の立つマグを持って戻ってきた。"

# game/script/ch05.rpy:881
translate japanese ch05_car_lara_e8a7d3f0:

    # h "Here. Careful, it's hot."
    h "はい。気をつけて、熱いから。"

# game/script/ch05.rpy:882
translate japanese ch05_car_lara_0d55895a:

    # "Alice cupped the tea in both hands, staring into the steam."
    "Aliceは両手で紅茶を包み、湯気を見つめた。"

# game/script/ch05.rpy:883
translate japanese ch05_car_lara_19bdf547:

    # a "I can't handle it anymore, Dr. Markou. I need someone to talk to."
    a "もう耐えられないんです、Markou先生。誰かに話を聞いてほしいんです。"

# game/script/ch05.rpy:884
translate japanese ch05_car_lara_2fddfd5b:

    # h "You're talking to me now, Alice. And that's good."
    h "今、私に話しているじゃない、Alice。それはいいことよ。"

# game/script/ch05.rpy:885
translate japanese ch05_car_lara_eae558ec:

    # "Alice shook her head. Her lips pressed tight, then parted again with effort."
    "Aliceは首を横に振った。唇が固く結ばれ、それから苦労してまた開いた。"

# game/script/ch05.rpy:886
translate japanese ch05_car_lara_b275155f:

    # a "No. Not just you. I... I need to talk to the detective."
    a "いいえ。先生だけじゃなくて。私……刑事さんと話さなきゃいけないんです。"

# game/script/ch05.rpy:887
translate japanese ch05_car_lara_5897dd75:

    # "The room went still. Helena's brows rose, then her expression softened. She brushed damp hair from Alice's face."
    "部屋が静まり返った。Helenaの眉が上がり、それから表情が和らいだ。彼女はAliceの顔から湿った髪を払った。"

# game/script/ch05.rpy:888
translate japanese ch05_car_lara_2c30676b:

    # h "You want to talk to Detective Harris?"
    h "Harris刑事と話したいの？"

# game/script/ch05.rpy:890
translate japanese ch05_car_lara_c9b4ad31:

    # a "Yes. He should know. I want him to know."
    a "はい。あの人は知っておくべきです。知ってほしいんです。"

# game/script/ch05.rpy:891
translate japanese ch05_car_lara_e6384872:

    # "Helena studied her a long moment, weighing something. Then she laid her hand over Alice's and smiled."
    "Helenaは長いあいだ彼女を見つめ、何かを量っていた。それからAliceの手に自分の手を重ねて、微笑んだ。"

# game/script/ch05.rpy:892
translate japanese ch05_car_lara_89bbffdc:

    # h neutral "Of course, my dear. If that's what you want, I'll call him right now."
    h neutral "もちろんよ。あなたがそうしたいなら、今すぐ電話するわ。"

# game/script/ch05.rpy:893
translate japanese ch05_car_lara_f6d206e2:

    # "Alice's shoulders eased for the first time since she stepped inside."
    "なかに入ってからはじめて、Aliceの肩から力が抜けた。"

# game/script/ch05.rpy:894
translate japanese ch05_car_lara_678d2d4f:

    # h "Detective Harris? It's Dr. Markou. You need to come to my office immediately. There's someone here who wishes to speak with you."
    h "Harris刑事ですか？Markouです。すぐに私の診察室に来てください。あなたと話したいという人がここにいます。"

# game/script/ch05.rpy:903
translate japanese ch05_car_lara_0a608760:

    # "Samuel parked out front, the engine ticking as it cooled. He pulled his collar high and crossed the path in quick, deliberate steps."
    "Samuelは表に車を停めた。冷えていくエンジンがかちかちと鳴った。彼は襟を高く立て、すばやく確かな足取りで小道を渡った。"

# game/script/ch05.rpy:904
translate japanese ch05_car_lara_660c3fdc:

    # "Inside, warmth and oak smoke. Alice curled in the armchair by the fire, a blanket across her lap. Helena seated just beside her. Both turned as he entered."
    "なかは暖かく、樫の煙の匂いがした。Aliceは暖炉のそばの肘掛け椅子で身を丸め、膝に毛布をかけていた。Helenaがそのすぐ横に座っていた。二人とも、彼が入ってくると振り向いた。"

# game/script/ch05.rpy:907
translate japanese ch05_car_lara_a03d380f:

    # "He gave Helena a short nod, then crouched in front of Alice so his eyes were level with hers."
    "彼はHelenaに短くうなずき、それからAliceの前にしゃがんで、目の高さを彼女に合わせた。"

# game/script/ch05.rpy:908
translate japanese ch05_car_lara_e99ed394:

    # s "Hello, Alice. You asked for me. What's wrong?"
    s "こんにちは、Alice。私を呼んだそうだね。どうしたんだ？"

# game/script/ch05.rpy:909
translate japanese ch05_car_lara_60808df2:

    # "Her small hands were folded tightly in her lap. Her voice came calm, steady, threaded with an odd weight."
    "小さな両手が膝の上できつく組まれていた。声は穏やかで落ち着いていたが、奇妙な重みが織りこまれていた。"

# game/script/ch05.rpy:910
translate japanese ch05_car_lara_7f22a8dc:

    # a "I need to share some things with you, Detective."
    a "お話ししなければいけないことがあるんです、刑事さん。"

# game/script/ch05.rpy:911
translate japanese ch05_car_lara_86656825:

    # s "I'm listening."
    s "聞いているよ。"

# game/script/ch05.rpy:912
translate japanese ch05_car_lara_496302bc:

    # h "I can step out if that makes it easier."
    h "そのほうが話しやすければ、私は席を外しましょうか。"

# game/script/ch05.rpy:913
translate japanese ch05_car_lara_229bd1d9:

    # "Alice's hand shot out and caught Helena's sleeve. Not pleading. Precise."
    "Aliceの手がさっと伸びて、Helenaの袖をつかんだ。すがるのではない。正確に。"

# game/script/ch05.rpy:914
translate japanese ch05_car_lara_f66f7c79:

    # a "No. Stay. It's better if you both hear it. For everyone's sake."
    a "いいえ。いてください。お二人とも聞いてくれたほうがいいんです。みんなのために。"

# game/script/ch05.rpy:915
translate japanese ch05_car_lara_9cdee0bc:

    # "Helena hesitated, caught between her training and the quiet steel in the girl's voice. Then she sank back, guarded."
    "Helenaはためらった。自分の受けた訓練と、少女の声にひそむ静かな鋼とのあいだで。それから、警戒しながらも椅子に身を沈めた。"

# game/script/ch05.rpy:916
translate japanese ch05_car_lara_d23184fd:

    # s "Alright. We'll do this together."
    s "わかった。一緒に聞こう。"

# game/script/ch05.rpy:917
translate japanese ch05_car_lara_93eaf4c8:

    # "Alice smoothed the blanket over her knees and drew a slow breath, preparing her words with a care most adults never managed."
    "Aliceは膝の上の毛布をなでつけ、ゆっくりと息を吸った。たいていの大人がついぞできないほどの注意深さで、言葉を整えながら。"

# game/script/ch05.rpy:919
translate japanese ch05_car_lara_eeb578f4:

    # a "As you both know, I am not from here. I am from a small coastal village. Life there was different. Especially inside the family."
    a "お二人ともご存じのとおり、私はここの出身ではありません。小さな海辺の村から来ました。あそこでの暮らしはちがっていました。とくに、家族のなかでは。"

# game/script/ch05.rpy:920
translate japanese ch05_car_lara_59955921:

    # a "My family were believers. Too devoted. And their belief had strict guidelines to follow."
    a "私の家族は信者でした。信心が深すぎました。そしてその信仰には、守るべき厳しい決まりがありました。"

# game/script/ch05.rpy:921
translate japanese ch05_car_lara_084e6eaf:

    # "Her fingers tightened slightly in the blanket."
    "毛布をつかむ指に、わずかに力がこもった。"

# game/script/ch05.rpy:922
translate japanese ch05_car_lara_7ac6f874:

    # a "Of course, the previous generation — like George — was also enforcing it. Maybe even more than my parents did."
    a "もちろん、上の世代も――Georgeみたいに――それを強いていました。たぶん、両親よりももっと。"

# game/script/ch05.rpy:923
translate japanese ch05_car_lara_d428a84c:

    # "Samuel's eyes flicked to Helena. Her expression stayed neutral, but her posture had stiffened."
    "Samuelの目がHelenaへ走った。彼女の表情は中立のままだったが、姿勢はこわばっていた。"

# game/script/ch05.rpy:928
translate japanese ch05_car_lara_f92a3fbe:

    # "He let the words come and took them as given. A frightened child, finally talking. That was what the room was for."
    "彼は言葉が来るにまかせ、それをそのまま受けとった。怯えた子どもが、ようやく話している。この部屋はそのためにあるのだ。"

# game/script/ch05.rpy:933
translate japanese ch05_car_lara_7a5e93b3:

    # "He kept his eyes below her face. Her hands folded tighter exactly when she said 'George'. Not before. Not after."
    "彼は目を彼女の顔より下に置いた。彼女の両手がきつく組まれたのは、ちょうど「George」と言ったときだった。その前でもなく、あとでもなく。"

# game/script/ch05.rpy:934
translate japanese ch05_car_lara_bc90dd80:

    # "And the rest of her stayed composed. Too finished, like a drawing someone had already erased and redone."
    "そして、それ以外の彼女は落ち着いたままだった。仕上がりすぎていた。誰かが一度消して描き直した絵のように。"

# game/script/ch05.rpy:935
translate japanese ch05_car_lara_d8156439:

    # th "Fear. Kids who live with a man like that learn to hold still. The hands are the only thing that tells the truth."
    th "恐怖だ。ああいう男と暮らす子どもは、じっとしていることを覚える。本当のことを言うのは手だけだ。"

# game/script/ch05.rpy:937
translate japanese ch05_car_lara_97482b85:

    # s "Enforcing how, Alice? With rules? With punishment?"
    s "強いていた、というのはどんなふうに、Alice？規則で？罰で？"

# game/script/ch05.rpy:938
translate japanese ch05_car_lara_2825da73:

    # a "Both."
    a "両方です。"

# game/script/ch05.rpy:939
translate japanese ch05_car_lara_bb9fffeb:

    # "Flat. Not dramatized. But the certainty behind it made the room feel tighter."
    "平板だった。大げさにはしない。だがその裏にある確信が、部屋を狭くしたように感じさせた。"

# game/script/ch05.rpy:940
translate japanese ch05_car_lara_427fc8c9:

    # a "So, in this belief, I had a role to play. I am not sure what. I only know I needed to extend my knowledge in all major topics. More than other kids my age. That is why I was homeschooled too."
    a "それで、その信仰のなかで、私には果たすべき役目がありました。何なのかはよくわかりません。わかっているのは、主な分野すべてで知識を広げなければならなかったということだけです。同じ年の子たちよりもずっと。だから私は、家で勉強もしていたんです。"

# game/script/ch05.rpy:941
translate japanese ch05_car_lara_ad642f43:

    # th "Accelerated education. Indoctrination disguised as discipline."
    th "先取り教育。しつけに見せかけた教化。"

# game/script/ch05.rpy:943
translate japanese ch05_car_lara_8f224b2b:

    # h "Alice, when you say 'belief,' what do you mean exactly? A religion? A sect?"
    h "Alice、「信仰」と言うとき、正確にはどういう意味？宗教？宗派？"

# game/script/ch05.rpy:944
translate japanese ch05_car_lara_2ab9e548:

    # a "It's... devotion. To purity. To truth. To being stronger than weakness."
    a "それは……献身です。清らかさへの。真実への。弱さよりも強くあることへの。"

# game/script/ch05.rpy:945
translate japanese ch05_car_lara_2e038124:

    # "A chill traced down Samuel's spine. His jaw worked once."
    "Samuelの背筋を寒気が伝い下りた。顎が一度だけ動いた。"

# game/script/ch05.rpy:946
translate japanese ch05_car_lara_a9875a09:

    # s "And George. He taught you that?"
    s "それで、Georgeが。それを君に教えたのか？"

# game/script/ch05.rpy:947
translate japanese ch05_car_lara_fe0d679b:

    # "A small nod. Slow. Deliberate."
    "小さなうなずき。ゆっくりと。意図して。"

# game/script/ch05.rpy:948
translate japanese ch05_car_lara_1eb4154e:

    # a "In my family, I was taught that part of my role was to distinguish the pure from the impure in people."
    a "家族のなかで、私の役目のひとつは、人のなかの清いものと清くないものを見分けることだと教えられました。"

# game/script/ch05.rpy:949
translate japanese ch05_car_lara_8d53d1f3:

    # a "Of course, this meant I was constantly corrected, disciplined, put into long sessions of visual and verbal examples."
    a "もちろん、それはつまり、私がいつも正され、しつけられ、目で見せる例と言葉の例の長い時間に入れられるということでした。"

# game/script/ch05.rpy:950
translate japanese ch05_car_lara_08396e85:

    # a "I was reminded that weak people are not worth anything. And that we should use them only to justify our means."
    a "弱い人間には何の価値もないと、繰り返し言い聞かされました。そして私たちは、自分たちの手段を正当化するためにだけ彼らを使えばいいのだと。"

# game/script/ch05.rpy:951
translate japanese ch05_car_lara_39500229:

    # "Samuel's pen stilled halfway across the page."
    "Samuelのペンがページの途中で止まった。"

# game/script/ch05.rpy:953
translate japanese ch05_car_lara_c25c9081:

    # a "Yet my parents were not like George. He scolded them. Argued with them. I witnessed it myself."
    a "でも、両親はGeorgeのようではありませんでした。Georgeは両親を叱りつけました。言い争っていました。私はこの目で見ました。"

# game/script/ch05.rpy:954
translate japanese ch05_car_lara_4bc4ece3:

    # "The firelight flickered across her face."
    "暖炉の光が彼女の顔の上で揺れた。"

# game/script/ch05.rpy:955
translate japanese ch05_car_lara_2a2a7388:

    # a "Then, one day, he took me and brought me here. I wasn't able to see my parents again. He said he did what he had to do. And he told me it was part of my training."
    a "そしてある日、Georgeは私を連れてここへ来ました。それきり両親には会えていません。やらなければならないことをやったのだと、Georgeは言いました。そして、これは私の訓練の一部なのだと。"

# game/script/ch05.rpy:956
translate japanese ch05_car_lara_abad93e4:

    # "Samuel's chest tightened."
    "Samuelの胸が締めつけられた。"

# game/script/ch05.rpy:957
translate japanese ch05_car_lara_5b2e4746:

    # s "Alice... do you know what he meant by that?"
    s "Alice……それがどういう意味か、わかるかい？"

# game/script/ch05.rpy:959
translate japanese ch05_car_lara_8f9545c0:

    # a "No. And every time I ask him if I can see my family again, he gets angry."
    a "いいえ。それに、家族にまた会えるかと訊くたびに、Georgeは怒るんです。"

# game/script/ch05.rpy:961
translate japanese ch05_car_lara_259e712f:

    # "Helena's hands, folded neatly until now, tightened on the armrest. She didn't speak."
    "それまできちんと組まれていたHelenaの両手が、肘掛けをつかんだ。彼女は何も言わなかった。"

# game/script/ch05.rpy:962
translate japanese ch05_car_lara_e050ced4:

    # a "And today... he told me that he will soon finish his work here. And that we will leave again."
    a "それで今日……Georgeは、ここでの仕事をもうすぐ終えると言いました。そして、私たちはまた出ていくのだと。"

# game/script/ch05.rpy:963
translate japanese ch05_car_lara_4b5817b0:

    # "The silence stretched. Samuel's thumb brushed the spine of his notebook."
    "沈黙が長く伸びた。Samuelの親指が手帳の背をなぞった。"

# game/script/ch05.rpy:964
translate japanese ch05_car_lara_d3f4024f:

    # s "Work. He used that word?"
    s "仕事。そういう言葉を使ったのか？"

# game/script/ch05.rpy:965
translate japanese ch05_car_lara_1ab6a4d4:

    # a "Yes. Work."
    a "はい。仕事、と。"

# game/script/ch05.rpy:966
translate japanese ch05_car_lara_c9f18d50:

    # th "Finish his work here."
    th "ここでの仕事を終える。"

# game/script/ch05.rpy:967
translate japanese ch05_car_lara_b5c92c78:

    # "A twelve-year-old might not know what that meant. But Samuel had heard killers use the same phrasing."
    "十二歳の子には、それが何を意味するのかわからないかもしれない。だがSamuelは、殺人者が同じ言い回しを使うのを聞いたことがあった。"

# game/script/ch05.rpy:968
translate japanese ch05_car_lara_eb543754:

    # a "Today he said he has work to do. Preparations. And that he will be late."
    a "今日、Georgeはやらなければならない仕事があると言いました。準備だと。それで、遅くなると。"

# game/script/ch05.rpy:969
translate japanese ch05_car_lara_281762d5:

    # "Her eyes went to the fire, reflecting the flames."
    "彼女の目は暖炉へ向き、炎を映していた。"

# game/script/ch05.rpy:970
translate japanese ch05_car_lara_c7cbadbc:

    # a "So I came here. To Mrs. Markou."
    a "だから、ここへ来たんです。Markou先生のところへ。"

# game/script/ch05.rpy:971
translate japanese ch05_car_lara_16b8c0d8:

    # "Preparations. The word hooked him, heavy with implication, vague enough to be useless. His cigarette hand twitched against his knee."
    "準備。その言葉が彼に引っかかった。含みは重いのに、役に立たないほど曖昧だった。煙草を持つほうの手が、膝の上でぴくりと動いた。"

# game/script/ch05.rpy:972
translate japanese ch05_car_lara_70f65d0e:

    # s "Preparations for what, Alice?"
    s "何の準備だ、Alice？"

# game/script/ch05.rpy:973
translate japanese ch05_car_lara_9a44d976:

    # a "He didn't say."
    a "言いませんでした。"

# game/script/ch05.rpy:975
translate japanese ch05_car_lara_eca6110a:

    # note_voice "'He will finish his work here.' Preparations tonight."
    note_voice "「ここでの仕事を終える」。今夜、準備。"

# game/script/ch05.rpy:976
translate japanese ch05_car_lara_5403e248:

    # s "Did he bring this belief here, Alice? The same rules?"
    s "Georgeはその信仰をここへも持ちこんだのか、Alice？同じ規則を？"

# game/script/ch05.rpy:978
translate japanese ch05_car_lara_b0a16f1e:

    # a "Of course."
    a "もちろんです。"

# game/script/ch05.rpy:979
translate japanese ch05_car_lara_d7c6842b:

    # "She lifted her eyes from the mug and met his directly for the first time in minutes."
    "彼女はマグから目を上げ、数分ぶりにはじめて、まっすぐ彼の目を見た。"

# game/script/ch05.rpy:980
translate japanese ch05_car_lara_905f7c9d:

    # a "George doesn't leave things behind. He says truth doesn't change with place. He carries it everywhere, and so must I."
    a "Georgeは物事を置いていきません。真実は場所によって変わらない、と言います。Georgeはそれをどこへでも持っていく。だから私も、そうしなければいけないんです。"

# game/script/ch05.rpy:981
translate japanese ch05_car_lara_d198695b:

    # a "George says I don't need friends. He says they make you weak, pull you away from what matters."
    a "Georgeは、私に友だちはいらないと言います。友だちは人を弱くする、大事なものから引き離す、と。"

# game/script/ch05.rpy:982
translate japanese ch05_car_lara_59269898:

    # a "That's why he doesn't like Emily. He says she clouds my judgment."
    a "だからGeorgeはEmilyを嫌うんです。Emilyは私の判断を曇らせる、と言って。"

# game/script/ch05.rpy:994
translate japanese ch05_markou_redacted_b285139a:

    # s "You can give me a redacted summary. Initial impressions. Risk flags. I don't need the raw session transcripts."
    s "伏せ字を入れた要約でかまいません。初見の印象。危険信号。セッションの記録そのものはいりません。"

# game/script/ch05.rpy:995
translate japanese ch05_markou_redacted_1e1ac63c:

    # h "You don't need any of it. The law is not on your side here. Nor am I inclined to stretch it in spirit."
    h "あなたには、そのどれも必要ありません。ここでは法はあなたの味方ではありません。そして私も、その精神を拡大解釈する気はありません。"

# game/script/ch05.rpy:996
translate japanese ch05_markou_redacted_60e034a9:

    # h "Confidentiality for a minor is not a courtesy; it's a scaffold. You kick at it, she falls."
    h "未成年者の秘密保持は礼儀ではありません。足場です。あなたがそれを蹴れば、あの子が落ちるのです。"

# game/script/ch05.rpy:1000
translate japanese ch05_markou_emergency_7ea8f879:

    # "He stepped closer and planted his hands on the edge of the desk."
    "彼は一歩近づき、机の縁に両手をついた。"

# game/script/ch05.rpy:1001
translate japanese ch05_markou_emergency_08f7add0:

    # s "We have a serial killer. That scaffold won't mean much if there's a fourth grave."
    s "連続殺人犯がいるんです。四つ目の墓ができたら、その足場にたいした意味はなくなる。"

# game/script/ch05.rpy:1002
translate japanese ch05_markou_emergency_4fb4542a:

    # h "And if trampling a child's privacy today buys you nothing and costs her everything tomorrow?"
    h "では、もし今日子どものプライバシーを踏みにじって、あなたが何も得られず、明日あの子がすべてを失うとしたら？"

# game/script/ch05.rpy:1003
translate japanese ch05_markou_emergency_3f95db2f:

    # h "You are talking about burning a bridge you may need to cross again. If the girl is truly in danger, she will come to people like me before she goes to people like you."
    h "あなたは、もう一度渡る必要があるかもしれない橋を焼こうとしているのです。もしあの子が本当に危険にさらされているなら、あなたのような人のところへ行く前に、私のような人のところへ来るでしょう。"

# game/script/ch05.rpy:1004
translate japanese ch05_markou_emergency_bc6584ba:

    # s "You've treated Clara. You of all people know how small this town lets children become."
    s "あなたはClaraを診ていた。この町が子どもをどれほど小さくしてしまうか、誰よりもあなたが知っているはずだ。"

# game/script/ch05.rpy:1005
translate japanese ch05_markou_emergency_67e812b4:

    # s "If Alice is a lever in someone's hand — if George has turned her into an instrument — keeping this sealed helps him, not her."
    s "もしAliceが誰かの手のなかの梃子なら――もしGeorgeがあの子を道具に変えてしまったのなら――これを封印しておくことは、あの子ではなく彼を助けることになる。"

# game/script/ch05.rpy:1006
translate japanese ch05_markou_emergency_af922213:

    # h "Speculation. You want me to violate a child's confidentiality on speculation."
    h "推測です。あなたは推測にもとづいて、子どもの秘密を破れと私に言っている。"

# game/script/ch05.rpy:1007
translate japanese ch05_markou_emergency_a97e4b9c:

    # s "I'm asking you to exercise professional judgment in a state of emergency."
    s "非常事態のなかで、専門家としての判断を行使してほしいとお願いしているんです。"

# game/script/ch05.rpy:1008
translate japanese ch05_markou_emergency_b3fecfbb:

    # h "And I'm exercising it by saying no."
    h "ですから行使しています。お断りすることで。"

# game/script/ch05.rpy:1012
translate japanese ch05_markou_safe_10d69e8d:

    # s "Tell me this. Do you believe Alice is safe in that house?"
    s "これだけ教えてください。あの家にいてAliceは安全だと思いますか？"

# game/script/ch05.rpy:1013
translate japanese ch05_markou_safe_4badd178:

    # "Helena breathed once, unblinking."
    "Helenaは一度だけ息をした。まばたきもせずに。"

# game/script/ch05.rpy:1014
translate japanese ch05_markou_safe_be21ee54:

    # h "If I believed she was in immediate physical danger, you would not need to ask me for her file. You would already have a court order and a child removed. That is not what I see."
    h "もしあの子が差し迫った身体的危険にさらされていると思っていたら、あなたが私にファイルを求める必要などありません。とうに裁判所命令が出て、子どもは保護されているはずです。私に見えているのは、そういうものではありません。"

# game/script/ch05.rpy:1015
translate japanese ch05_markou_safe_6c1dea03:

    # s "Immediate physical danger. So not bruises. Not burns. But the other kind."
    s "差し迫った身体的危険。つまり痣ではない。火傷でもない。だが、もうひとつの種類のほうは。"

# game/script/ch05.rpy:1016
translate japanese ch05_markou_safe_70710df2:

    # s "The kind that teaches a child the world is a courtroom and she is the judge's apprentice."
    s "世界は法廷で、自分は裁判官の見習いなのだと子どもに教える、あの種類の。"

# game/script/ch05.rpy:1017
translate japanese ch05_markou_safe_cf7e04d1:

    # h "You are not wrong to be afraid of ideas. They are harder to document than injuries. And they last longer. But your fear does not license me."
    h "考えを恐れるのはまちがっていません。考えは傷よりも記録しにくい。そして傷よりも長く残る。でも、あなたの恐れが私に許可を与えるわけではありません。"

translate japanese strings:

    # game/script/ch05.rpy:59
    old "Leary."
    new "Leary。"

    # game/script/ch05.rpy:61
    old "The crowd."
    new "群衆。"

    # game/script/ch05.rpy:64
    old "Evelyn."
    new "Evelyn。"

    # game/script/ch05.rpy:117
    old "Send her off."
    new "彼女を下がらせる。"

    # game/script/ch05.rpy:120
    old "Study her a moment."
    new "少し彼女を観察する。"

    # game/script/ch05.rpy:205
    old "Ask how she got to the funeral."
    new "葬儀にどうやって来たか訊く。"

    # game/script/ch05.rpy:219
    old "Ask about her parents."
    new "両親のことを訊く。"

    # game/script/ch05.rpy:270
    old "George's face."
    new "Georgeの顔。"

    # game/script/ch05.rpy:276
    old "Her steps."
    new "彼女の足音。"

    # game/script/ch05.rpy:339
    old "Push back."
    new "言い返す。"

    # game/script/ch05.rpy:344
    old "Take it."
    new "受けとめる。"

    # game/script/ch05.rpy:356
    old "What's under it."
    new "その下にあるもの。"

    # game/script/ch05.rpy:359
    old "His anger."
    new "彼の怒り。"

    # game/script/ch05.rpy:361
    old "His breathing."
    new "彼の息づかい。"

    # game/script/ch05.rpy:480
    old "Ask where it grows."
    new "どこに生えているか訊く。"

    # game/script/ch05.rpy:484
    old "Ask how easy it is to kill with."
    new "どれほど簡単に人を殺せるか訊く。"

    # game/script/ch05.rpy:621
    old "Settle for a redacted summary."
    new "伏せ字の要約で手を打つ。"

    # game/script/ch05.rpy:625
    old "Call it an emergency."
    new "非常事態だと訴える。"

    # game/script/ch05.rpy:629
    old "Ask if Alice is safe in that house."
    new "Aliceがあの家で安全か訊く。"

    # game/script/ch05.rpy:640
    old "The folders."
    new "フォルダー。"

    # game/script/ch05.rpy:926
    old "Believe her."
    new "彼女を信じる。"

    # game/script/ch05.rpy:930
    old "Watch her hands."
    new "彼女の手を見る。"

