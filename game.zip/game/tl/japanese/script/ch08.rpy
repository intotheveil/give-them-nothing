# TODO: Translation updated at 2026-10-11 10:23

# game/script/ch08.rpy:16
translate japanese ch08_530b26bd:

    # "By dusk the crowd outside the station had doubled, and it had stopped being a crowd."
    "夕暮れには、署の外の人だかりは倍に膨れ上がり、もはや人だかりではなくなっていた。"

# game/script/ch08.rpy:17
translate japanese ch08_cc744083:

    # "Samuel watched it from the second-floor window with a cold cup of coffee going colder in his hand."
    "Samuelは二階の窓からそれを見ていた。手の中で、冷めたコーヒーがさらに冷えていった。"

# game/script/ch08.rpy:18
translate japanese ch08_331e246f:

    # "They stood in the square in the blue dark, a hundred of them now, more, their faces lit orange from below by the little fires some of them had lit in oil drums against the cold."
    "彼らは青い闇の広場に立っていた。いまや百人、いやそれ以上。寒さしのぎにドラム缶で焚かれた小さな火が、彼らの顔を下からオレンジ色に照らしていた。"

# game/script/ch08.rpy:19
translate japanese ch08_6e047bf1:

    # "They were not shouting yet, which was worse than shouting."
    "まだ叫んではいなかった。叫ぶよりも悪かった。"

# game/script/ch08.rpy:20
translate japanese ch08_952fa907:

    # "They had settled into the patient, upright waiting of people who believe they have been wronged and have found, at last, the thing responsible."
    "不当な目に遭わされたと信じ、ついにその元凶を見つけた人々の、辛抱強く、背筋を伸ばした待ち方に、彼らは落ち着いていた。"

# game/script/ch08.rpy:21
translate japanese ch08_8dd8ee8d:

    # "Now and then a voice went up and the mass around it stirred and murmured and went still again, the way a fire breathes."
    "ときおり声がひとつ上がると、そのまわりの塊がざわめき、つぶやき、また静まった。火が息をするように。"

# game/script/ch08.rpy:22
translate japanese ch08_e87e369c:

    # "Samuel had been a policeman long enough to know that a crowd that waits is a crowd that has decided, and only lacks the moment."
    "待っている群衆とは、すでに心を決め、あとはきっかけを欠くだけの群衆だ。Samuelはそれを知るほどには長く警官をやってきた。"

# game/script/ch08.rpy:23
translate japanese ch08_03a54159:

    # "And they had never, Samuel thought, needed much convincing."
    "そしてこの連中は、とSamuelは思った、そもそも大して説得など必要としなかったのだ。"

# game/script/ch08.rpy:24
translate japanese ch08_6eed8562:

    # "He had spent the day learning George Bennett the way you learn a man only after you have arrested him: too late and all at once. The George the town handed him was a shape with a hole in the middle of it."
    "彼はその日一日を、George Bennettという男を知ることに費やした。逮捕してから初めて人を知るときのやり方で――遅すぎて、しかも一度に。町が差し出したGeorgeは、真ん中に穴の空いた輪郭だった。"

# game/script/ch08.rpy:25
translate japanese ch08_04b7ddab:

    # "Two years the man had lived out at the tree line, and two years the town had hired his hands and never once asked him in."
    "二年間、男は森の際に住み、二年間、町は彼の手を雇いながら、一度も家に招き入れなかった。"

# game/script/ch08.rpy:26
translate japanese ch08_6bd5b54c:

    # "He fixed their roofs and their fences and their frozen pipes, took his pay, said little, and went home to the edge of the woods."
    "彼は町の屋根を、柵を、凍った水道管を直し、賃金を受け取り、口数少なく、森のはずれの家へ帰っていった。"

# game/script/ch08.rpy:27
translate japanese ch08_573ee108:

    # "They had let him stay the way you let a stray stay at the edge of the yard — useful, watched, unloved, and the first thing your eye goes to when something turns up missing."
    "町は彼を置いてやっていた。庭の隅に野良犬を置いてやるように――役に立ち、見張られ、愛されず、何かがなくなったとき真っ先に目が向く存在として。"

# game/script/ch08.rpy:28
translate japanese ch08_684cb1c9:

    # "A town that has spent two years not trusting a man needs almost nothing, when the bodies come, to hate him. The outsider is always the readiest answer."
    "二年間ひとりの男を信用せずにきた町は、死体が出たとき、彼を憎むのにほとんど何も要らない。よそ者はいつだって、いちばん手近な答えだ。"

# game/script/ch08.rpy:29
translate japanese ch08_e2523516:

    # th "I'm the valley's other outsider. Some other morning, with some other set of dead, they'd have lit those fires for me."
    th "俺はこの谷のもうひとりのよそ者だ。別の朝、別の死体の並びなら、あの火は俺のために焚かれていた。"

# game/script/ch08.rpy:30
translate japanese ch08_25066b0b:

    # "Above him, on the third floor, in the narrow holding cell Greyvale kept for drunks and thieves, George Bennett sat and said nothing."
    "その上の三階、Greyvaleが酔っ払いと盗人のために置いている狭い留置房で、George Bennettは座り、何も言わなかった。"

# game/script/ch08.rpy:31
translate japanese ch08_5d375058:

    # "He had said nothing since the house. Not in the car, not at the booking desk while Lara logged his belt and his boot-laces and the few worn things from his pockets."
    "家を出てから、何も言っていなかった。車の中でも。Laraがベルトと靴紐と、ポケットから出たわずかな使い古しの品を記録していた受付でも。"

# game/script/ch08.rpy:32
translate japanese ch08_8a7d1a34:

    # "Not when Samuel had read him his rights slowly and clearly and given him every opening a man could want to speak into. He had answered his name. He had answered nothing else."
    "Samuelがゆっくりとはっきり権利を読み上げ、口を開くための隙をこれでもかと与えたときでさえ。名前には答えた。それ以外には何も答えなかった。"

# game/script/ch08.rpy:33
translate japanese ch08_8b9d73b9:

    # "He had the terrible patience of the crowd below turned inside out — a man waiting, too, for a thing he had long since decided was coming."
    "彼には、下の群衆の恐ろしい忍耐を裏返しにしたようなところがあった――彼もまた待っていたのだ。とうに来ると決めていたものを。"

# game/script/ch08.rpy:36
translate japanese ch08_56c4975b:

    # "The phone on Mercer's desk rang. Mercer looked at it, and looked at Samuel, and Samuel set down the cold coffee and picked it up, because there was only one person it would be."
    "Mercerの机の電話が鳴った。Mercerは電話を見て、Samuelを見た。Samuelは冷めたコーヒーを置いて受話器を取った。かけてくる相手はひとりしかいなかった。"

# game/script/ch08.rpy:38
translate japanese ch08_9c11bd31:

    # s tired "Harris."
    s tired "Harrisだ。"

# game/script/ch08.rpy:39
translate japanese ch08_d9e43435:

    # d neutral "It's out. The city paper. Online an hour ago, print by morning. {i}Cult Killings Grip Mountain Town; Local Man Held.{/i}"
    d neutral "出たぞ。市の新聞だ。一時間前にネットに出た、朝には紙面に載る。{i}カルト殺人、山の町を覆う。地元の男を拘束。{/i}"

# game/script/ch08.rpy:40
translate japanese ch08_54d2146d:

    # d "They've got the word cult, they've got the word ritual, they've got a photograph of your George holding his hands out for the cuffs like he's done it a hundred times."
    d "「カルト」って言葉も、「儀式」って言葉も入ってる。お前のGeorgeが、もう百回もやったみたいに手錠に両手を差し出してる写真までな。"

# game/script/ch08.rpy:41
translate japanese ch08_6254594d:

    # d "By noon tomorrow it will be on every screen in the country. The mayor's been on to the county. They want him moved."
    d "明日の昼には国じゅうの画面に出る。町長が郡に掛け合った。奴を移せとさ。"

# game/script/ch08.rpy:42
translate japanese ch08_6f4d3a90:

    # s "Moved where?"
    s "どこへ？"

# game/script/ch08.rpy:43
translate japanese ch08_770ccd6e:

    # d neutral "County seat. Proper remand facility, two hours down the mountain. Somewhere with walls that mean it and men to watch them."
    d neutral "郡庁所在地だ。まともな勾留施設、山を下って二時間。本気の壁と、それを見張る人間がいる場所だ。"

# game/script/ch08.rpy:44
translate japanese ch08_ce547147:

    # d "You've seen the square, Sam. You cannot hold a man that town wants dead in a cell with a lock a determined child could pick."
    d "広場を見たろう、Sam。あの町が殺したがってる男を、本気になった子どもでも開けられる錠の房に置いとくわけにはいかん。"

# game/script/ch08.rpy:45
translate japanese ch08_323ec796:

    # d "One night. That's what you've got. First light they send a transport up and it takes him down, and he becomes the county's problem and the state's."
    d "一晩だ。お前にあるのはそれだけだ。夜明けに移送車が上がってきて奴を下ろす。そこから先は郡の問題で、州の問題だ。"

# game/script/ch08.rpy:46
translate japanese ch08_e66e83a1:

    # s "First light's a long way off."
    s "夜明けまではまだ長い。"

# game/script/ch08.rpy:47
translate japanese ch08_522ed309:

    # d "Then make the night count."
    d "なら、その夜を無駄にするな。"

# game/script/ch08.rpy:48
translate japanese ch08_35fefd6b:

    # d "You've got him for one night in your own house, Sam, before he's gone behind county walls and a county lawyer and never says another word."
    d "一晩だけ、お前の家に奴がいる、Sam。郡の壁と郡の弁護士の向こうへ消えて、二度と口を開かなくなる前にな。"

# game/script/ch08.rpy:49
translate japanese ch08_549e4ebd:

    # d "Whatever you're going to get out of George Bennett, you get it tonight. Because tomorrow he stops being a frightened old man in a small-town cell and becomes a case."
    d "George Bennettから何を引き出すにしろ、今夜引き出せ。明日になりゃ奴は田舎町の房にいる怯えた老いぼれじゃなくなる。事件になる。"

# game/script/ch08.rpy:50
translate japanese ch08_01a8b909:

    # d "And cases don't confess."
    d "そして事件は自白しない。"

# game/script/ch08.rpy:52
translate japanese ch08_67331c2e:

    # "The line clicked. Samuel stood a while longer at the glass, watching the town he had promised an answer by dark."
    "回線が切れた。Samuelはしばらく窓辺に立ち続け、日暮れまでに答えを出すと約束した町を見ていた。"

# game/script/ch08.rpy:54
translate japanese ch08_50e2af14:

    # note_voice "Transfer to county at first light."
    note_voice "夜明けに郡へ移送。"

# game/script/ch08.rpy:55
translate japanese ch08_31532f79:

    # m "Detective? You going up?"
    m "刑事？上に行くんですか？"

# game/script/ch08.rpy:56
translate japanese ch08_e883c8c9:

    # s "Give me a minute."
    s "少し待ってくれ。"

# game/script/ch08.rpy:57
translate japanese ch08_781b8609:

    # s "I want to know who I'm talking to first."
    s "まず、誰と話すのかを知っておきたい。"

# game/script/ch08.rpy:69
translate japanese ch08_b4dbfc7b:

    # "The cell was six feet by eight, and George Bennett had measured every inch of it in the first hour, out of an old habit he had never lost."
    "房は六フィート×八フィート。George Bennettは最初の一時間でその隅々まで測っていた。捨てきれなかった古い習慣だった。"

# game/script/ch08.rpy:70
translate japanese ch08_0a0a184c:

    # gth "Know the size of the box they put you in. Know the door. Know the hinges. Know the time between the guard's steps."
    gth "入れられた箱の大きさを知れ。扉を知れ。蝶番を知れ。看守の足音の間隔を知れ。"

# game/script/ch08.rpy:71
translate japanese ch08_ca618270:

    # "He had been putting himself in boxes his whole life and getting himself out of them. Some cold and certain part of him understood that this was the box he did not get out of."
    "生涯、彼は自分を箱に入れては、そこから抜け出してきた。冷たく確かな彼のどこかが、これは抜け出せない箱だと理解していた。"

# game/script/ch08.rpy:72
translate japanese ch08_5049d4d7:

    # "They had taken his laces and his belt so he could not hang himself. That was almost funny."
    "首を吊れないように、靴紐とベルトを取り上げられていた。ほとんど笑い話だった。"

# game/script/ch08.rpy:73
translate japanese ch08_96b0a657:

    # gth "As if a man who kept himself and the girl alive two years by never once giving in to despair would quit now, with the work half done."
    gth "絶望に一度も屈しないことで二年間、自分とあの子を生かしてきた男が、仕事を半分残して今さら投げ出すとでも思うのか。"

# game/script/ch08.rpy:74
translate japanese ch08_573aa713:

    # gth "I will not give them that. I will not give them anything."
    gth "奴らにそれは与えない。何ひとつ与えない。"

# game/script/ch08.rpy:75
translate japanese ch08_51dd7b2f:

    # "Giving them nothing was the only country he had left."
    "何も与えないこと。それが、彼に残された唯一の国だった。"

# game/script/ch08.rpy:76
translate japanese ch08_2f511908:

    # "He kept his hands loose on his knees and his breathing slow and let the noise of the crowd come up through the floor, and he did the arithmetic of it the way he did the arithmetic of everything."
    "彼は両手を膝の上で緩め、呼吸をゆっくり保ち、群衆のざわめきが床を通して上ってくるにまかせた。そして何事についてもそうするように、その計算をした。"

# game/script/ch08.rpy:77
translate japanese ch08_5bf2af03:

    # gth "Three days. I needed three more days."
    gth "三日。あと三日必要だった。"

# game/script/ch08.rpy:78
translate japanese ch08_a0a4ebe6:

    # "The money was lifted and counted and waiting where he'd cached it; the fuel was staged."
    "金は引き出され、数えられ、隠した場所で待っていた。燃料も用意してあった。"

# game/script/ch08.rpy:79
translate japanese ch08_834b8b28:

    # "Renner had the truck and the route and the crossing arranged, had named his price and been paid half. The other half was to change hands the night they left."
    "Rennerはトラックと経路と越境の手筈を整え、値を言い、半額を受け取っていた。残りの半分は、発つ夜に手渡すことになっていた。"

# game/script/ch08.rpy:80
translate japanese ch08_c0bd6de7:

    # gth "Three days and she'd have been out of this valley. Gone the way we went before. Quiet, complete. A door closing on an empty house."
    gth "三日あれば、あの子はこの谷を出ていた。前と同じように消えていた。静かに、跡形もなく。空き家の扉が閉まるように。"

# game/script/ch08.rpy:81
translate japanese ch08_06a7145b:

    # "He had felt the danger coming for weeks — felt it the way he felt weather in his bad shoulder — and he had done what he always did when he felt it, which was move."
    "何週間も前から危険が近づくのを感じていた――悪い肩で天気を感じるように――そして感じたときにいつもすることをした。動くことだ。"

# game/script/ch08.rpy:82
translate japanese ch08_d5c6fd20:

    # "He had simply, this once, been three days too slow."
    "ただ今回に限って、三日遅すぎたのだ。"

# game/script/ch08.rpy:84
translate japanese ch08_e76afc11:

    # "That was where the nights had gone — the nights the girl heard the truck on the gravel and he told her only that he had work."
    "夜はそこへ消えていたのだ――少女が砂利を踏むトラックの音を聞き、彼がただ仕事だとだけ告げた夜は。"

# game/script/ch08.rpy:85
translate japanese ch08_0075745c:

    # "The nights the whole town would later decide were a killer going out to kill."
    "のちに町じゅうが、殺人者が殺しに出かけた夜だと決めつけることになる夜は。"

# game/script/ch08.rpy:86
translate japanese ch08_a0d50fb1:

    # gth "I was building the road out."
    gth "俺は逃げ道を造っていたんだ。"

# game/script/ch08.rpy:87
translate japanese ch08_7dd6e081:

    # "Week after week, after she was asleep, he had driven the black roads down the far side of the mountain with his lights low, over the gorge and out toward the county highway."
    "来る週も来る週も、彼女が眠ったあと、彼はライトを落として山の向こう側の暗い道を下り、峡谷を越えて郡の幹線道路へと走った。"

# game/script/ch08.rpy:88
translate japanese ch08_3e251234:

    # "He met Renner in the places Renner chose and never the same one twice: a closed filling station, a timber yard."
    "Rennerとは、Rennerが選んだ場所で会った。同じ場所は二度となかった。閉鎖したガソリンスタンド。材木置き場。"

# game/script/ch08.rpy:89
translate japanese ch08_cffa9a90:

    # "Once, a lay-by above the gorge, where the wind came up the drop so hard it rocked the truck."
    "一度は峡谷の上の待避所で、崖下から吹き上げる風がトラックを揺らすほどだった。"

# game/script/ch08.rpy:90
translate japanese ch08_d404592d:

    # "And there in the cab with the engine ticking they had built the escape a piece at a time. Cash counted out under the dome light and counted again."
    "そして運転台で、冷えていくエンジンがかちかちと鳴るなか、ふたりは逃亡をひとつずつ組み上げた。室内灯の下で数えられ、また数え直される現金。"

# game/script/ch08.rpy:91
translate japanese ch08_1f7b6e02:

    # "A name for the girl that was not her name, on paper good enough to cross with. A route that ran south and then west and then off the edge of anywhere either of them had ever been."
    "少女のための、彼女のものではない名前。それで国境を越えられるだけの出来の書類。南へ、それから西へ、そしてふたりのどちらも行ったことのあるどこかの縁から外へ出ていく経路。"

# game/script/ch08.rpy:92
translate japanese ch08_1889cec1:

    # "Renner asking no questions — that was what you paid Renner for, the not-asking — only naming his figure and his conditions and his crossing."
    "Rennerは何も訊かなかった――Rennerに金を払うのはそのため、訊かないことのためだった――ただ額と条件と越境地点を告げるだけだった。"

# game/script/ch08.rpy:93
translate japanese ch08_72b888fb:

    # "And George paying, and driving home in the last of the dark, and pausing on the stair outside her door out of a habit of listening, and lying down for two hours before the valley woke."
    "そしてGeorgeは払い、闇の名残のなかを帰り、聞き耳を立てる習慣から彼女の部屋の前の階段で立ち止まり、谷が目覚めるまでの二時間、横になった。"

# game/script/ch08.rpy:94
translate japanese ch08_52547d2f:

    # "Ordinary, careful, criminal, invisible work: the work of a man moving a child out of danger by the only means a man with no past he could show would ever have."
    "ありふれた、慎重な、犯罪の、目に見えない仕事。人に見せられる過去を持たない男が手にしうる唯一の手段で、子どもを危険の外へ移そうとする男の仕事。"

# game/script/ch08.rpy:95
translate japanese ch08_0e797b88:

    # "And every night of it was now a night with no alibi he could give. To explain where he had been was to explain who he had been with, and what he had been buying, and why—"
    "そしてそのすべての夜が、いまや彼の差し出せるアリバイのない夜だった。どこにいたかを説明すれば、誰といたか、何を買っていたか、そしてなぜかを説明することになる――"

# game/script/ch08.rpy:96
translate japanese ch08_f3b121c9:

    # "—and there was a man on the far side of the gorge, twenty-five miles off, who could stand up and say {i}George Bennett was over here with me the whole of that night.{/i}"
    "――峡谷の向こう側、二十五マイル先には、立ち上がってこう言える男がいた。{i}George Bennettはあの晩ずっと、こっちで俺と一緒にいた。{/i}"

# game/script/ch08.rpy:97
translate japanese ch08_ecc3b100:

    # gth "A mountain and an hour's road away from your dead girl. And I'll go into the ground before I say his name aloud."
    gth "お前らの死んだ娘からは、山ひとつと一時間の道のりを隔てていた。だが奴の名を口にするくらいなら、俺は墓に入る。"

# game/script/ch08.rpy:98
translate japanese ch08_f404a2ac:

    # "Renner moved people who could not be moved. Renner did not exist, as far as any badge in the world was concerned."
    "Rennerは、動かせない人間を動かした。世界のどのバッジにとっても、Rennerは存在しなかった。"

# game/script/ch08.rpy:99
translate japanese ch08_37a3a3a0:

    # "The day George handed a detective the thread that led to Renner was the day he handed over the whole architecture: the money, the route, the fact of the flight."
    "Georgeが刑事にRennerへつながる糸を渡す日は、仕組みのすべてを渡す日だった。金、経路、逃亡という事実。"

# game/script/ch08.rpy:100
translate japanese ch08_d30205eb:

    # "The fact that the child in this town's mouth as the killer's granddaughter was a child he had taken out of a house in the night without her parents' leave, and run with across half a country."
    "この町が殺人鬼の孫娘と噂するその子が、夜のうちに親の許しもなく家から連れ出され、国の半分を越えて連れて逃げられた子だという事実。"

# game/script/ch08.rpy:101
translate japanese ch08_61fc9e66:

    # gth "Say one true thing and you say all of them."
    gth "ひとつ本当のことを言えば、全部を言うことになる。"

# game/script/ch08.rpy:102
translate japanese ch08_7ea3245b:

    # "He had learned that lesson young, in a colder house than this, and it had never once been wrong."
    "その教訓を彼は若いうちに、ここよりも寒い家で学んだ。そしてそれは一度も外れたことがなかった。"

# game/script/ch08.rpy:103
translate japanese ch08_fddaf718:

    # "So he would say nothing. He would give the detective his name and give him silence and give the rope its due."
    "だから何も言うまい。刑事には名前を与え、沈黙を与え、縄には縄の取り分を与えよう。"

# game/script/ch08.rpy:104
translate japanese ch08_8b8fb302:

    # "The only thing in the whole business he could not make himself hold still and look at directly was the question of why."
    "この一件のなかで、どうしても腰を据えて正面から見ることができないものはただひとつ、なぜかという問いだった。"

# game/script/ch08.rpy:105
translate japanese ch08_5614a41e:

    # "Why the deaths. Why the marks he had heard the officers murmur about, the words, the staging that stank — he made himself use the word, {i}stank{/i} — of the very thing he had spent his life first serving and then fleeing."
    "なぜ死んだのか。巡査たちがひそひそ話していた印は、言葉は、なぜなのか。あの演出はなぜ――彼はあえてその言葉を使った、{i}臭う{/i}と――彼が生涯をかけて、はじめは仕え、のちに逃れてきたまさにそのものの臭いがするのか。"

# game/script/ch08.rpy:106
translate japanese ch08_9e1dee49:

    # "He looked at the question the way you look at the sun: sideways, for less than a second. Then he looked away."
    "彼はその問いを、太陽を見るように見た。横目で、一秒にも満たないあいだ。それから目を逸らした。"

# game/script/ch08.rpy:107
translate japanese ch08_28f1daf7:

    # gth "A man can go blind that way. I went half-blind already, years ago, refusing to look at it."
    gth "そうやって人は目を潰す。俺はもう何年も前に、それを見まいとして半分目を潰した。"

# game/script/ch08.rpy:112
translate japanese ch08_8cf5e793:

    # "His son had been six the first time George made him kneel."
    "Georgeがはじめて息子をひざまずかせたとき、息子は六歳だった。"

# game/script/ch08.rpy:113
translate japanese ch08_31048441:

    # "It came up now, uninvited, the way the old things came up in boxes: the cold front room of the house in Driftwood, the salt smell that lived in every wall."
    "それがいま、招かれもせず浮かんできた。箱のなかでは古いものがいつもそうやって浮かんでくる。Driftwoodの家の冷えた表の部屋、どの壁にも棲みついていた潮の匂い。"

# game/script/ch08.rpy:114
translate japanese ch08_f24a3b48:

    # "The boy's thin knees on the bare boards. The boy's voice, high and careful, going through the recitation he had fumbled at the gathering that afternoon and shamed them both."
    "むき出しの床板についた少年の細い膝。高く、慎重な少年の声。その日の午後、集いでしくじり、ふたりともに恥をかかせた暗誦を繰り返している。"

# game/script/ch08.rpy:115
translate japanese ch08_0271df9e:

    # "{i}A blessing shared is a blessing halved. Weakness named is weakness bled.{/i}"
    "{i}分かち合う恵みは半分の恵み。名指された弱さは血を抜かれた弱さ。{/i}"

# game/script/ch08.rpy:116
translate japanese ch08_bd93dd35:

    # "On and on, the whole cold catechism, and every time the boy stumbled George made him start again from the top."
    "延々と、冷たい教理問答のすべてを。少年がつかえるたびに、Georgeは最初からやり直させた。"

# game/script/ch08.rpy:117
translate japanese ch08_65553837:

    # "Not in anger — that was the thing George had believed, then, that made it holy — but in love."
    "怒りからではなかった――それこそが、当時のGeorgeがそれを神聖にするものだと信じていたことだった――愛からだった。"

# game/script/ch08.rpy:118
translate japanese ch08_00ba2d07:

    # "Because the world was a machine that ground weak men to nothing, and the only kindness a father could do was to make his son too hard to grind."
    "世界は弱い男をすり潰して無にする機械であり、父親にできる唯一の優しさは、息子をすり潰せないほど硬くしてやることだったからだ。"

# game/script/ch08.rpy:119
translate japanese ch08_253c978c:

    # "The boy had cried, once, near the end. Silent, the tears just running while his mouth kept going."
    "終わり近く、少年は一度だけ泣いた。声もなく、口は動き続けたまま、涙だけが流れていた。"

# game/script/ch08.rpy:120
translate japanese ch08_bb7ca34c:

    # "And George had crouched to his level the way his own father had crouched to his, and wiped the boy's face with his thumb, almost tender."
    "Georgeは、自分の父親がかつて自分にそうしたように、少年の目の高さまでしゃがみ込み、親指でその顔を拭った。ほとんど優しく。"

# game/script/ch08.rpy:125
translate japanese ch08_a5aefb13:

    # g grim "Stop."
    g grim "やめろ。"

# game/script/ch08.rpy:126
translate japanese ch08_7ea537cc:

    # g "You do not give them water."
    g "奴らに水を与えるな。"

# game/script/ch08.rpy:130
translate japanese ch08_d3d4c18f:

    # g "You give them nothing."
    g "何も与えるな。"

# game/script/ch08.rpy:134
translate japanese ch08_0b59d298:

    # "And the boy had stopped. Had learned to stop."
    "そして少年は泣きやんだ。やめることを覚えた。"

# game/script/ch08.rpy:135
translate japanese ch08_256373fc:

    # "Had grown into a hard, closed, correct man who married a hard woman and got a daughter of his own, and set about, with the total confidence of the well-taught, making her too hard to grind."
    "硬く、閉ざされた、正しい男に育ち、硬い女と結婚し、自分の娘をもうけ、よく教え込まれた者の揺るぎない自信をもって、その娘をすり潰せないほど硬くすることに取りかかった。"

# game/script/ch08.rpy:140
translate japanese ch08_7dd6b75f:

    # "George had done that. Whatever else was true, that was true and his: he had taken a soft-faced boy and built the machine that built the girl."
    "Georgeがそうしたのだ。ほかに何が真実であれ、それは真実で、彼のものだった。柔らかな顔の少年を取って、あの少女を造った機械を造ったのだ。"

# game/script/ch08.rpy:141
translate japanese ch08_91793e02:

    # gth "I was so sure."
    gth "俺はあれほど確信していた。"

# game/script/ch08.rpy:142
translate japanese ch08_6c62dd64:

    # "That was the part he could not get past, waiting in his own box for his own grinding — not that he had been cruel, but that he had been cruel and certain."
    "自分の箱のなかで、自分がすり潰される番を待ちながら、どうしても越えられないのはそこだった――残酷だったことではない。残酷で、しかも確信していたことだ。"

# game/script/ch08.rpy:143
translate japanese ch08_fe24ac8d:

    # "Certain it was love. Certain it was mercy. And the certainty had felt exactly, indistinguishably, like the thing he now knew it was not."
    "それが愛だと確信していた。慈悲だと確信していた。そしてその確信の感触は、いまではそうではなかったとわかっているものと、寸分違わず、見分けがつかないほど同じだった。"

# game/script/ch08.rpy:145
translate japanese ch08_a8a3f1d6:

    # "Boots in the corridor. The measured tread of the detective, coming up."
    "廊下にブーツの音。刑事の規則正しい足音が上ってくる。"

# game/script/ch08.rpy:146
translate japanese ch08_a0f830b0:

    # "George straightened his back against the wall, put his hands loose on his knees, gave his face to the middle distance, and made himself, once more, into nothing they could use."
    "Georgeは壁に背を伸ばし、両手を膝の上で緩め、顔を中空に向け、もう一度、奴らが何ひとつ使えないものへと自分を変えた。"

# game/script/ch08.rpy:158
translate japanese ch08_9a9a6c62:

    # "Samuel had them bring George down to the little second-floor office instead of questioning him through the bars."
    "Samuelは鉄格子越しに尋問する代わりに、Georgeを二階の小さな事務室へ連れてこさせた。"

# game/script/ch08.rpy:159
translate japanese ch08_55792741:

    # th "Bars give a man something to be brave against. I don't want him brave. I want him tired, and warm, in an ordinary chair across an ordinary desk."
    th "鉄格子があれば、男は何かに向かって勇敢でいられる。勇敢でいてほしくはない。疲れて、温まって、ありふれた机を挟んだありふれた椅子に座っていてほしい。"

# game/script/ch08.rpy:161
translate japanese ch08_f312f0a1:

    # "He did not turn on the recorder. He set it on the desk, in plain view, and left it dark."
    "録音機のスイッチは入れなかった。よく見えるように机の上に置き、消したままにした。"

# game/script/ch08.rpy:162
translate japanese ch08_bbb8b784:

    # "George's eyes went to it once and understood the message — {i}this is not for the file yet; this is just us{/i} — and filed the understanding away behind his face and gave nothing back."
    "Georgeの目が一度だけそちらへ行き、意図を理解した――{i}これはまだ記録用じゃない。俺たちだけの話だ{/i}――そしてその理解を顔の奥にしまい込み、何も返さなかった。"

# game/script/ch08.rpy:163
translate japanese ch08_77464cdf:

    # "Samuel had run a thousand of these. He knew inside the first minute this was going to be one of the hard ones, and some worn-out part of him was almost glad of it, the way you are glad of a real winter."
    "Samuelはこういう場を千回はこなしてきた。最初の一分で、これは難しい部類になるとわかった。そして彼のどこかすり切れた部分が、それをほとんど喜んでいた。本物の冬を喜ぶように。"

# game/script/ch08.rpy:164
translate japanese ch08_fdadfca5:

    # "He took out his cigarettes and put two on the desk and pushed one across."
    "煙草を取り出し、二本を机に置いて、一本を向こうへ押しやった。"

# game/script/ch08.rpy:165
translate japanese ch08_a3b144e3:

    # s "They took your tobacco with your laces. Bureaucracy. Go ahead."
    s "靴紐と一緒に煙草も取られただろう。お役所仕事だ。吸えよ。"

# game/script/ch08.rpy:166
translate japanese ch08_6f562099:

    # "George looked at the cigarette. For a moment Samuel thought he wouldn't. Then the old man's hand came out, unhurried, and took it."
    "Georgeは煙草を見た。一瞬、Samuelは手を出さないだろうと思った。やがて老人の手が急ぐでもなく伸び、それを取った。"

# game/script/ch08.rpy:167
translate japanese ch08_a20fe460:

    # "Samuel lit it for him and lit his own, and for a little while the two of them sat in the small room and smoked and said nothing, and that was fine."
    "Samuelはそれに火をつけてやり、自分のにも火をつけた。しばらくのあいだ、ふたりは小さな部屋に座って煙草を吸い、何も言わなかった。それでよかった。"

# game/script/ch08.rpy:168
translate japanese ch08_69dfd8a2:

    # th "No hurry. Hurry is the crowd's disease, and Doyle's. I have all night, and I mean to spend it."
    th "急ぐことはない。急ぎは群衆の病だ。Doyleの病でもある。俺には一晩まるごとある。そのすべてを使うつもりだ。"

# game/script/ch08.rpy:169
translate japanese ch08_d59d1df1:

    # s neutral "Four we're calling murder."
    s neutral "殺人と見ているのは四件だ。"

# game/script/ch08.rpy:170
translate japanese ch08_19f1dfc1:

    # s "A teacher we were quick to write off as a suicide, until I found the blackmail. A shopkeeper, poisoned over his own counter. A priest, in front of his whole church. And a girl of fourteen, laid out in the snow."
    s "教師は、俺が恐喝を見つけるまで、さっさと自殺で片づけられかけた。店主は自分の店のカウンター越しに毒を盛られた。神父は教会じゅうの目の前で。そして十四歳の少女が、雪の上に横たえられた。"

# game/script/ch08.rpy:171
translate japanese ch08_71f5f5c5:

    # "He tapped ash."
    "彼は灰を落とした。"

# game/script/ch08.rpy:172
translate japanese ch08_9106b928:

    # s "Laid out, as it happens, on the grave of a fifth. Clara Ward, fifteen, wrists opened in a school locker room, days ago. Suicide, everyone agreed."
    s "横たえられた場所は、たまたま五人目の墓の上だ。Clara Ward、十五歳。数日前、学校のロッカールームで手首を切った。自殺だと、誰もが認めた。"

# game/script/ch08.rpy:173
translate japanese ch08_5984b376:

    # s "I'm less sure than everyone lately. Somebody left your granddaughter's best friend on that dead girl's grave like a note pinned to a door."
    s "近ごろの俺は、みんなほどには確信が持てなくてな。誰かが、お前の孫娘の親友を、あの死んだ少女の墓の上に置いていった。扉にピンで留めた書き置きみたいに。"

# game/script/ch08.rpy:174
translate japanese ch08_9cb3a4cd:

    # s "I'm not going to ask you if you did it. You'll say no or you'll say nothing, and either way we're no further on. So let's not do that part."
    s "お前がやったのかとは訊かない。お前は違うと言うか、何も言わないかだ。どっちにしても一歩も進まない。だからそこは飛ばそう。"

# game/script/ch08.rpy:175
translate japanese ch08_27b0db59:

    # "George smoked, and watched him, and said nothing, exactly as promised."
    "Georgeは煙草を吸い、彼を見つめ、予告どおり何も言わなかった。"

# game/script/ch08.rpy:176
translate japanese ch08_20548cc1:

    # s "Here's what I'll do instead. I'll tell you what I know. And you can sit there and let me be wrong, if I'm wrong."
    s "代わりにこうする。俺が知っていることを話す。俺が間違っているなら、お前はそこに座って、間違わせておけばいい。"

# game/script/ch08.rpy:177
translate japanese ch08_fde583ab:

    # "He opened the folder he had not needed to bring and did not look at."
    "持ってくる必要もなかったファイルを開いたが、目は落とさなかった。"

# game/script/ch08.rpy:179
translate japanese ch08_1a7efb41:

    # th "Three keys to this lock. Where he came from. The girl. The hours he can't account for."
    th "この錠に鍵は三つ。どこから来たか。あの子。説明のつかない時間。"

# game/script/ch08.rpy:198
translate japanese ch08_key_driftwood_3189d40b:

    # th "Go back to the start of him. The place he came from."
    th "奴の始まりに戻れ。奴が来た場所に。"

# game/script/ch08.rpy:199
translate japanese ch08_key_driftwood_6cd13f01:

    # s "Driftwood Bay. Little place on the coast, three hours south, the kind of town that doesn't answer the phone when a detective calls."
    s "Driftwood Bay。海沿いの小さな町だ。南へ三時間。刑事が電話しても出ないような町だ。"

# game/script/ch08.rpy:200
translate japanese ch08_key_driftwood_7442950e:

    # s "You came from there. You and the girl, two years back, cash for the house, no mortgage, no paper trail worth the name."
    s "お前はそこから来た。お前とあの子で、二年前に。家は現金払い、ローンなし、書類の足跡と呼べるものもない。"

# game/script/ch08.rpy:201
translate japanese ch08_key_driftwood_5fd5cbbb:

    # "He let it sit."
    "彼はその言葉をしばらく置いた。"

# game/script/ch08.rpy:202
translate japanese ch08_key_driftwood_e2631b40:

    # s "Funny town, Driftwood. I made some calls. People there don't talk about it, and the ones who do, talk about it the way you talk about a church you left."
    s "妙な町だな、Driftwoodは。何本か電話をかけた。あそこの人間はそのことを話したがらない。話す者も、抜けた教会の話をするような口ぶりだ。"

# game/script/ch08.rpy:203
translate japanese ch08_key_driftwood_20ec1a94:

    # s "And the year you came up out of it with a ten-year-old girl and no mother and no father in the picture — that same year, two sisters went missing off that coast."
    s "そしてお前が、母親も父親も見当たらない十歳の女の子を連れてそこから出てきた年――その同じ年に、あの海岸で姉妹がふたり行方不明になっている。"

# game/script/ch08.rpy:204
translate japanese ch08_key_driftwood_0a91ad60:

    # s "Girls. Never found. Investigation went cold so fast it was never warm."
    s "女の子だ。見つかっていない。捜査はあっという間に冷えて、温まったことすらなかった。"

# game/script/ch08.rpy:206
translate japanese ch08_key_driftwood_631764ac:

    # "He watched George's face while he said it, and saw the thing he had come up the stairs to see. Not guilt — he had expected guilt, and this was not it — but something rawer, gone almost before it surfaced."
    "話しながら、彼はGeorgeの顔を見ていた。そして、わざわざ階段を上ってきてまで見たかったものを見た。罪悪感ではない――罪悪感を予想していたが、これは違った――もっと生々しい何か。浮かび上がるとほぼ同時に消えた。"

# game/script/ch08.rpy:207
translate japanese ch08_key_driftwood_a218ac64:

    # "The big frame flinched a quarter-inch. The eyes went, for half a heartbeat, to the door, and to the window, and back."
    "大きな体が四分の一インチびくりとした。目が、鼓動半分のあいだ、扉へ、窓へ、そして戻った。"

# game/script/ch08.rpy:208
translate japanese ch08_key_driftwood_5d9abfc4:

    # "The reflex of a man who has spent every day of two years believing his past was buried, and has just heard a stranger speak its name aloud."
    "二年間毎日、自分の過去は埋めたと信じてきた男が、見知らぬ者がその名を口にするのをいま聞いた。その反射だった。"

# game/script/ch08.rpy:209
translate japanese ch08_key_driftwood_35c747b4:

    # "It lasted less than a second. George's face closed over it like water over a stone."
    "一秒も続かなかった。石の上で水面が閉じるように、Georgeの顔はそれを覆い隠した。"

# game/script/ch08.rpy:210
translate japanese ch08_key_driftwood_3ed69c55:

    # th "Right country. Wrong map, maybe. But the right country."
    th "国は合ってる。地図は違うかもしれない。だが国は合ってる。"

# game/script/ch08.rpy:212
translate japanese ch08_key_driftwood_493ae04a:

    # note_voice "Driftwood — flinch at the sisters."
    note_voice "Driftwood――姉妹の話でびくつく。"

# game/script/ch08.rpy:213
translate japanese ch08_key_driftwood_fdaa1f51:

    # s soft "I don't know what you did in Driftwood. Maybe nothing. Maybe everything."
    s soft "Driftwoodでお前が何をしたのかは知らない。何もしていないのかもしれない。何もかもしたのかもしれない。"

# game/script/ch08.rpy:214
translate japanese ch08_key_driftwood_4a45c991:

    # s "But you ran from it, and you brought a child with you, and you've spent two years in this valley being a man nobody could get a look at."
    s "だがお前はそこから逃げた。子どもを連れて。そしてこの谷で二年間、誰にも正体をつかませない男として過ごしてきた。"

# game/script/ch08.rpy:215
translate japanese ch08_key_driftwood_ab608a9b:

    # s "And now the people around that child are dying in a language that sounds an awful lot like the church you left."
    s "そしていま、その子のまわりの人間が死んでいる。お前の抜けた教会にずいぶんよく似た言葉で。"

# game/script/ch08.rpy:216
translate japanese ch08_key_driftwood_7ac11841:

    # "Silence. But George's jaw had set, and his breathing had changed — slowed, deepened, the deliberate control of a man holding a door shut from the inside."
    "沈黙。だがGeorgeの顎はこわばり、呼吸が変わっていた――遅く、深く。内側から扉を押さえている男の、意図した制御だった。"

# game/script/ch08.rpy:217
translate japanese ch08_key_driftwood_f7feab28:

    # "Samuel let the silence run a long time."
    "Samuelは長いあいだ、その沈黙を流れるにまかせた。"

# game/script/ch08.rpy:221
translate japanese ch08_key_alice_66f449b4:

    # "Samuel changed the ground under the silence."
    "Samuelは沈黙の下の地面を変えた。"

# game/script/ch08.rpy:222
translate japanese ch08_key_alice_d76b591a:

    # s neutral "Let's talk about Alice."
    s neutral "Aliceの話をしよう。"

# game/script/ch08.rpy:224
translate japanese ch08_key_alice_321c30b2:

    # "And there it was: the only thing in the room that reached the old man. Not a flinch. Something worse."
    "そして、それがあった。部屋のなかで唯一、老人に届くもの。びくつきではない。もっと悪いもの。"

# game/script/ch08.rpy:225
translate japanese ch08_key_alice_61f20adb:

    # "A stillness that went one degree stiller, the whole big frame of him gathering, bracing, the way a man braces over the one part of himself he cannot afford to have touched."
    "静けさが、さらに一段静まった。大きな体全体が身を寄せ、身構えた。触れられては困るたったひとつの部分をかばって、男が身構えるように。"

# game/script/ch08.rpy:226
translate japanese ch08_key_alice_3fe5a3b8:

    # s "She's twelve years old and she has nobody. You understand what happens to her now? Tonight she's with the psychiatrist, on a kindness. Tomorrow she's the state's."
    s "あの子は十二歳で、誰もいない。これからあの子がどうなるかわかってるか？今夜は精神科医のところだ、好意でな。明日には州のものになる。"

# game/script/ch08.rpy:227
translate japanese ch08_key_alice_1383712d:

    # s "And the state is going to want to know exactly what I want to know — where she came from, who her people were, what happened to them."
    s "そして州は、俺が知りたいのとまったく同じことを知りたがる――あの子がどこから来たのか、家族は誰だったのか、その家族に何があったのか。"

# game/script/ch08.rpy:228
translate japanese ch08_key_alice_bd814dd8:

    # s "It is going to pull that thread all the way back to Driftwood, and it is going to keep pulling until it finds whatever you ran from. Unless someone gives it a reason not to."
    s "州はその糸をDriftwoodまでずっとたぐっていく。お前が逃げてきたものが何であれ、それを見つけるまでたぐり続ける。誰かが、やめる理由を与えない限りはな。"

# game/script/ch08.rpy:229
translate japanese ch08_key_alice_48b263d0:

    # "He leaned in, no threat in his voice, which was the threat."
    "彼は身を乗り出した。声に脅しはなかった。それが脅しだった。"

# game/script/ch08.rpy:230
translate japanese ch08_key_alice_fe6fa0c7:

    # s "You've spent two years keeping that child out of the hands of whatever's back there. One night in a cell and it's out of your hands entirely — unless you talk to me."
    s "お前は二年間、あの子を、向こうにある何かの手から守ってきた。房で一晩過ごせば、もうお前の手には負えなくなる――俺に話さない限りは。"

# game/script/ch08.rpy:231
translate japanese ch08_key_alice_85bf5b89:

    # s "I'm the only man in this building who can steer where that thread goes. Help me, and I can protect her. Sit there, and I can't protect anyone."
    s "この建物で、その糸の行き先を操れるのは俺だけだ。手を貸せば、あの子を守ってやれる。そこに座ってるだけなら、俺は誰も守れない。"

# game/script/ch08.rpy:232
translate japanese ch08_key_alice_aaf0c23e:

    # "It was a good key. Samuel felt it turn even as he said it, felt the old man's whole being lean toward the girl like a plant toward light."
    "いい鍵だった。言いながら、Samuelはそれが回るのを感じた。老人の存在そのものが、光へ向かう植物のように少女のほうへ傾くのを感じた。"

# game/script/ch08.rpy:233
translate japanese ch08_key_alice_b4e7e027:

    # "For one held breath he thought the wall was going to come down."
    "息を詰めたひととき、壁が崩れるかと思った。"

# game/script/ch08.rpy:236
translate japanese ch08_key_alice_e497b9dd:

    # "Then George Bennett spoke — more than one word, for the first time since his own front door — and his voice was gravel dragged over gravel."
    "そのとき、George Bennettが口を開いた――自宅の玄関以来はじめて、ひと言以上のことを――その声は、砂利の上を引きずられる砂利だった。"

# game/script/ch08.rpy:238
translate japanese ch08_key_alice_27f12479:

    # "Then George Bennett spoke, for the first time since his own front door, and his voice was gravel dragged over gravel."
    "そのとき、George Bennettが口を開いた。自宅の玄関以来はじめてのことだった。その声は、砂利の上を引きずられる砂利だった。"

# game/script/ch08.rpy:239
translate japanese ch08_key_alice_c12da411:

    # g grim "You want to protect her."
    g grim "あの子を守りたいのか。"

# game/script/ch08.rpy:240
translate japanese ch08_key_alice_6fc7ded4:

    # "It was not a question. The old man's eyes came up off the middle distance and fixed on Samuel's."
    "問いではなかった。老人の目が中空から上がり、Samuelの目に据えられた。"

# game/script/ch08.rpy:241
translate japanese ch08_key_alice_9b8633b0:

    # "There was something in them Samuel could not read — something that in another man he'd have called grief, and in this one looked more like warning."
    "そこには、Samuelに読めない何かがあった――ほかの男なら悲しみと呼んだだろうが、この男の場合はむしろ警告に見える何かが。"

# game/script/ch08.rpy:242
translate japanese ch08_key_alice_9af6a539:

    # g "Then be careful what you decide she is."
    g "それなら、あの子を何者だと決めるか、気をつけることだ。"

# game/script/ch08.rpy:243
translate japanese ch08_key_alice_e16e8c2c:

    # g "All of you. Whoever ends up choosing what that girl is—"
    g "お前ら全員だ。あの子が何者かを選ぶことになる奴は、誰であれ――"

# game/script/ch08.rpy:244
translate japanese ch08_key_alice_e7a590b5:

    # "He stopped. His jaw worked once."
    "彼は言葉を止めた。顎が一度動いた。"

# game/script/ch08.rpy:248
translate japanese ch08_key_alice_07fd6aca:

    # s soft "Choosing what she is. What is she, George?"
    s soft "あの子が何者かを選ぶ。あの子は何者なんだ、George？"

# game/script/ch08.rpy:249
translate japanese ch08_key_alice_46d71ec4:

    # "For a second the old man's mouth stayed open on the shape of the next word. His eyes went past Samuel, to the door, and down — toward the stair, toward wherever the girl was sleeping tonight."
    "一瞬、老人の口は次の言葉の形に開いたままだった。その目はSamuelを通り越して扉へ、そして下へ向かった――階段のほうへ、今夜少女が眠っているどこかのほうへ。"

# game/script/ch08.rpy:250
translate japanese ch08_key_alice_5bf0abe2:

    # "Not the look of a man protecting a secret about himself. The look of a man standing between something and the light."
    "自分自身の秘密を守る男の目ではなかった。何かと光のあいだに立ちはだかる男の目だった。"

# game/script/ch08.rpy:251
translate japanese ch08_key_alice_2441ec70:

    # "Then the door closed again."
    "それから扉がまた閉じた。"

# game/script/ch08.rpy:252
translate japanese ch08_key_alice_844a1336:

    # g "Be careful. That's all."
    g "気をつけろ。それだけだ。"

# game/script/ch08.rpy:253
translate japanese ch08_key_alice_c393937d:

    # th "Grief. A grandfather who knows what his church did to that kid and can't say it. That's all that is."
    th "悲しみだ。自分の教会があの子に何をしたか知っていて、それを口にできない祖父。それだけのことだ。"

# game/script/ch08.rpy:255
translate japanese ch08_key_alice_479e3e46:

    # "Samuel let it lie. He had heard grandfathers before, and fathers, and what they sounded like when they finally understood what they'd made of a child."
    "Samuelはそのままにした。祖父の声も、父親の声も聞いてきた。自分たちが子どもを何に作り上げてしまったか、ようやく悟ったときの声を。"

# game/script/ch08.rpy:256
translate japanese ch08_key_alice_0b312f04:

    # "And then the door closed again, and the last of it came out flat and final."
    "そして扉がまた閉じ、最後の言葉が平板に、決定的に出てきた。"

# game/script/ch08.rpy:257
translate japanese ch08_key_alice_844a1336_1:

    # g "Be careful. That's all."
    g "気をつけろ。それだけだ。"

# game/script/ch08.rpy:259
translate japanese ch08_key_alice_c64faf2d:

    # g "That's the only thing I've got to say to you, and it's more than I meant to."
    g "お前に言えるのはそれだけだ。それでも、言うつもりだったより多い。"

# game/script/ch08.rpy:260
translate japanese ch08_key_alice_c89e0895:

    # s "Careful how, George?"
    s "どう気をつけろってんだ、George？"

# game/script/ch08.rpy:261
translate japanese ch08_key_alice_5d39537e:

    # "But he was gone again, back behind the gray, and Samuel knew the tone of a door that had shut for the night."
    "だが彼はまた去っていた。灰色の向こうへ戻っていた。Samuelは、今夜はもう開かない扉の音色を知っていた。"

# game/script/ch08.rpy:263
translate japanese ch08_key_alice_d3e0fb8f:

    # note_voice "'Be careful what you decide she is.'"
    note_voice "「あの子を何者だと決めるか、気をつけることだ」"

# game/script/ch08.rpy:269
translate japanese ch08_key_alibi_7d2b1327:

    # "He tried the last key anyway, because you always tried it."
    "それでも彼は最後の鍵を試した。いつだって試すものだからだ。"

# game/script/ch08.rpy:271
translate japanese ch08_key_alibi_24e9c319:

    # "He went straight at the hours, because the hours were the whole of it."
    "彼はまっすぐ時間を突いた。時間こそがすべてだったからだ。"

# game/script/ch08.rpy:272
translate japanese ch08_key_alibi_c063d02d:

    # s stern "Where were you, the night the Carter girl died."
    s stern "Carterの娘が死んだ夜、どこにいた。"

# game/script/ch08.rpy:273
translate japanese ch08_key_alibi_91ad84df:

    # s "You were out of your house. Your own granddaughter says she heard you leave, heard you come home after two. That's the whole night, George. That's every hour that matters."
    s "お前は家を出ていた。お前の孫娘が、出ていく音を聞いた、二時過ぎに帰ってくる音を聞いたと言っている。それがあの夜のすべてだ、George。肝心な時間のすべてだ。"

# game/script/ch08.rpy:274
translate japanese ch08_key_alibi_da1ff629:

    # s "So tell me where you were. Give me one name, one place, one man who saw you, and I will get up from this desk and start taking your case apart instead of building it."
    s "だから、どこにいたか言え。名前ひとつ、場所ひとつ、お前を見た人間ひとりでいい。そうすれば俺はこの机から立って、お前の事件を組み立てる代わりにばらしにかかる。"

# game/script/ch08.rpy:275
translate japanese ch08_key_alibi_f40087c2:

    # s "An innocent man gives me something."
    s "無実の人間は、何かを差し出すものだ。"

# game/script/ch08.rpy:276
translate japanese ch08_key_alibi_77ca6b0e:

    # "He watched George Bennett hear the lifeline and understand it completely — Samuel saw the understanding, clear as print — and set it down untouched."
    "彼は、George Bennettが命綱を聞き取り、完全に理解するのを見た――Samuelにはその理解が活字のようにはっきり見えた――そして、手もつけずにそれを置くのを。"

# game/script/ch08.rpy:277
translate japanese ch08_key_alibi_641f2b9a:

    # g neutral "Nothing."
    g neutral "何も。"

# game/script/ch08.rpy:278
translate japanese ch08_key_alibi_ec362851:

    # s "You were somewhere. A man is somewhere."
    s "どこかにはいたはずだ。人間はどこかにいるものだ。"

# game/script/ch08.rpy:282
translate japanese ch08_key_alibi_9672d5a0:

    # g "Nothing."
    g "何も。"

# game/script/ch08.rpy:283
translate japanese ch08_key_alibi_c141a97b:

    # "George closed his eyes."
    "Georgeは目を閉じた。"

# game/script/ch08.rpy:292
translate japanese ch08_key_alibi_72cfd172:

    # "Not a card held close. A door held shut from the inside, with the whole weight of the man against it."
    "伏せたカードではなかった。内側から押さえつけられた扉だった。男の全体重をかけて。"

# game/script/ch08.rpy:294
translate japanese ch08_key_alibi_2a6ed73a:

    # note_voice "Bennett: no alibi offered. 'Nothing.'"
    note_voice "Bennett――アリバイの申し出なし。「何も」"

# game/script/ch08.rpy:298
translate japanese ch08_keys_done_7dbdf877:

    # "And somewhere in the last of it, Samuel felt it — the small, wrong, snagging thing, so quiet under the noise of the evidence that he almost missed it."
    "そしてその最後のどこかで、Samuelはそれを感じた――小さく、間違った、引っかかるもの。証拠の騒音の下であまりに静かで、危うく見逃すところだった。"

# game/script/ch08.rpy:299
translate japanese ch08_keys_done_d97c9864:

    # "He had sat across from a hundred guilty men refusing to give up their alibis, and their silence had a texture. A smugness. The held card of a man who knows the truth would sink him."
    "アリバイを明かそうとしない有罪の男たちと、百回は向かい合ってきた。その沈黙には手触りがあった。したり顔。真実が自分を沈めると知っている男の、伏せたカード。"

# game/script/ch08.rpy:300
translate japanese ch08_keys_done_505b030f:

    # "This was not that. This was the silence of a man refusing a rope thrown to him in a flood. Refusing it deliberately. Choosing the water."
    "これはそれではなかった。これは、洪水のなかで投げられた綱を拒む男の沈黙だった。わざと拒んでいる。水を選んでいる。"

# game/script/ch08.rpy:301
translate japanese ch08_keys_done_73ff128c:

    # th "There's only one reason I've ever known a man to do that. Because the shore the rope is tied to is worse than drowning."
    th "人がそうするのを、俺はひとつの理由でしか見たことがない。綱の結ばれた岸のほうが、溺れるよりひどいからだ。"

# game/script/ch08.rpy:302
translate japanese ch08_keys_done_828c342e:

    # "The thought went through him and was gone before he could hold it, buried under the fires in the square and the graves and the photograph on every screen by morning."
    "その考えは彼の中を通り抜け、つかむ前に消えた。広場の火と、墓と、朝には全国の画面に出るあの写真の下に埋もれて。"

# game/script/ch08.rpy:303
translate japanese ch08_keys_done_53dc035b:

    # "He was too tired and too pressed and too far in to chase a feeling down a hole. But it had been there, for a second, snagging, and no weight of exhaustion quite pressed it flat again."
    "彼は疲れすぎ、追い詰められすぎ、深入りしすぎていて、感覚ひとつを穴の底まで追いかける余裕はなかった。だがそれは一瞬、そこにあって引っかかった。どれほどの疲労の重みも、それをすっかり押し潰すことはできなかった。"

# game/script/ch08.rpy:304
translate japanese ch08_keys_done_cbb8e330:

    # "He stood, and gathered the folder he hadn't opened."
    "彼は立ち上がり、開かなかったファイルをまとめた。"

# game/script/ch08.rpy:305
translate japanese ch08_keys_done_1615a9dd:

    # s tired "They're moving you at first light. County."
    s tired "夜明けにお前を移す。郡へ。"

# game/script/ch08.rpy:306
translate japanese ch08_keys_done_a39c6453:

    # s "Once you're down there, I can't help you, and I won't be able to hurt you either, and everything you didn't say tonight, you'll wish you had."
    s "向こうへ行ったら、俺はお前を助けられない。傷つけることもできなくなる。そして今夜言わなかったことを全部、言っておけばよかったと思うことになるぞ。"

# game/script/ch08.rpy:307
translate japanese ch08_keys_done_c83b1d99:

    # "He paused at the door."
    "扉のところで、彼は足を止めた。"

# game/script/ch08.rpy:308
translate japanese ch08_keys_done_46e9cf6b:

    # s soft "Think about the girl, George. Whatever else. Think about who's going to decide what she is."
    s soft "あの子のことを考えろ、George。ほかはどうでもいい。あの子が何者かを誰が決めるのか、考えろ。"

# game/script/ch08.rpy:309
translate japanese ch08_keys_done_f0b84517:

    # "George raised his eyes."
    "Georgeは目を上げた。"

# game/script/ch08.rpy:310
translate japanese ch08_keys_done_ad455649:

    # "For a moment the two men looked at each other across the small warm room — two outsiders in a town that wanted them both gone, each carrying a weight the other couldn't see."
    "一瞬、ふたりの男は小さく暖かい部屋を挟んで見つめ合った――ふたりとも消えてほしいと町に望まれているふたりのよそ者が、それぞれ相手には見えない重荷を背負って。"

# game/script/ch08.rpy:311
translate japanese ch08_keys_done_b1b367f1:

    # g neutral "I have thought about nothing else..."
    g neutral "ほかのことは何も考えてこなかった……"

# game/script/ch08.rpy:312
translate japanese ch08_keys_done_e9dee5a1:

    # extend " for two years."
    extend "この二年間ずっと。"

# game/script/ch08.rpy:313
translate japanese ch08_keys_done_bd23696b:

    # "And Samuel, who heard in it only the grief of a grandfather who had ruined a child and knew it, nodded once, and went out, and left the old man to the dark."
    "そしてSamuelは、そこに、子どもを壊してしまい、それを自覚している祖父の悲しみだけを聞き取り、一度うなずいて部屋を出た。老人を闇に残して。"

# game/script/ch08.rpy:324
translate japanese ch08_keys_done_e9118e9b:

    # "They brought Alice to him in the gray hour before they moved him."
    "移送される前の灰色の時刻に、Aliceが彼のもとへ連れてこられた。"

# game/script/ch08.rpy:325
translate japanese ch08_keys_done_912201b3:

    # "George Bennett understood, when he heard the small footsteps on the stair, that whatever mercy this was meant to be, it was the last one he would get, and that it would cost him more than the rope."
    "階段に小さな足音を聞いたとき、George Bennettは悟った。これがどんな慈悲のつもりであれ、自分が受ける最後の慈悲であり、縄よりも高くつくだろうと。"

# game/script/ch08.rpy:327
translate japanese ch08_keys_done_35386b58:

    # "The psychiatrist came first — Markou, the sharp-eyed woman, her face tight with the wrongness of what she was allowing, and allowing all the same."
    "最初に来たのは精神科医だった――Markou、鋭い目の女。自分が許していることの間違いに顔をこわばらせ、それでも許していた。"

# game/script/ch08.rpy:328
translate japanese ch08_keys_done_a4255f0f:

    # "The child had begged through the whole of the night and would not be quieted. In an hour the old man would be gone down the mountain, perhaps out of the girl's life for good."
    "子どもは夜通し懇願し、なだめても静まらなかった。一時間後には老人は山を下り、もしかすると少女の人生から永遠に消える。"

# game/script/ch08.rpy:329
translate japanese ch08_keys_done_218ac2a9:

    # "And Helena Markou had judged, in the end, that a child forbidden her goodbye carries the deeper wound."
    "そしてHelena Markouは最後に、別れを禁じられた子どものほうが深い傷を負うと判断したのだった。"

# game/script/ch08.rpy:331
translate japanese ch08_keys_done_22a33477:

    # "Behind her came a young officer, and behind him, small in a coat too big for her, the child."
    "その後ろに若い巡査が続き、さらにその後ろに、大きすぎるコートのなかで小さく、子どもがいた。"

# game/script/ch08.rpy:332
translate japanese ch08_keys_done_08ee7c86:

    # "They stopped the girl a careful distance from the bars. Markou crouched to her, murmured something, kept one hand on her shoulder."
    "彼らは鉄格子から慎重に距離を取ったところで少女を止めた。Markouが少女の前にしゃがみ、何かささやき、片手を肩に置いたままにした。"

# game/script/ch08.rpy:333
translate japanese ch08_keys_done_549559a5:

    # "Rules. Protections. The whole apparatus of adults deciding they knew what stood in the room with them."
    "規則。保護。自分たちと同じ部屋に何が立っているのか、わかっていると決め込んだ大人たちの仕掛けのすべて。"

# game/script/ch08.rpy:334
translate japanese ch08_keys_done_c7a3d3c1:

    # a cry "Grandpa."
    a cry "おじいちゃん。"

# game/script/ch08.rpy:335
translate japanese ch08_keys_done_952a8e3c:

    # "The girl's voice broke on the word, and her face crumpled, and tears came."
    "その言葉で少女の声は割れ、顔がくしゃくしゃになり、涙があふれた。"

# game/script/ch08.rpy:336
translate japanese ch08_keys_done_9aee9441:

    # "To every soul in that corridor but one she was exactly and only what she appeared to be: a frightened child brought to see the last of her family behind bars."
    "その廊下にいたひとりを除くすべての者にとって、彼女は見たとおりのもの、ただそれだけだった。鉄格子の向こうの最後の家族に会いに連れてこられた、怯えた子ども。"

# game/script/ch08.rpy:337
translate japanese ch08_keys_done_bfcddc04:

    # a "They said— they won't tell me anything— Grandpa, tell them it isn't true. Tell them."
    a "みんなが――誰も何も教えてくれないの――おじいちゃん、本当じゃないって言って。言ってよ。"

# game/script/ch08.rpy:338
translate japanese ch08_keys_done_8f612d62:

    # "George looked at her, and could not speak, and the not-speaking was not the wall this time. It was the flashback taking him, whole, the way they took him now."
    "Georgeは彼女を見て、口がきけなかった。今度の沈黙は壁ではなかった。過去の光景が彼をまるごと奪っていったのだ。近ごろはいつもそうだった。"

# game/script/ch08.rpy:345
translate japanese ch08_keys_done_d03b300c:

    # "She had been five."
    "彼女は五歳だった。"

# game/script/ch08.rpy:346
translate japanese ch08_keys_done_fbfb02ae:

    # "His son had made her stand in the yard in the rain — some failure, some softness, a doll she'd loved too openly, George never learned which."
    "息子は彼女を雨の庭に立たせた――何かのしくじりか、何かの甘さか、あまりにあからさまに可愛がった人形か。Georgeには、どれだったのかついにわからなかった。"

# game/script/ch08.rpy:348
translate japanese ch08_keys_done_4c65bb02:

    # "Made her stand there in the cold coastal rain until she learned that comfort was a thing you did not need and did not show."
    "海辺の冷たい雨のなかに立たせ続けた。慰めとは必要とせず、見せもしないものだと覚えるまで。"

# game/script/ch08.rpy:349
translate japanese ch08_keys_done_46ed2cdf:

    # "George had watched from the window of the little house, watched his granddaughter's thin shoulders in the rain."
    "Georgeは小さな家の窓から見ていた。雨のなかの孫娘の細い肩を見ていた。"

# game/script/ch08.rpy:350
translate japanese ch08_keys_done_4ff2bac1:

    # "And he had seen, laid over her, the shape of a six-year-old boy on bare boards forty years gone, and something in him that had been set hard since before that boy was born had cracked straight across."
    "そして彼女に重なって、四十年前にむき出しの床板にいた六歳の少年の姿が見えた。あの少年が生まれる前から硬く固まっていた彼のなかの何かが、まっすぐ横に割れた。"

# game/script/ch08.rpy:351
translate japanese ch08_keys_done_09bf99ea:

    # "He had gone out. He had not planned to; he had simply been unable, for the first time in his life, not to."
    "彼は外に出た。そうするつもりはなかった。ただ生まれてはじめて、出ずにいることができなかったのだ。"

# game/script/ch08.rpy:352
translate japanese ch08_keys_done_5443f8aa:

    # "He walked into his son's yard and his son's discipline and picked the child up out of the rain without a word, and carried her inside."
    "彼は息子の庭へ、息子のしつけのなかへ踏み込み、ひと言もなく子どもを雨のなかから抱き上げ、家に運び入れた。"

# game/script/ch08.rpy:353
translate japanese ch08_keys_done_9ce38da3:

    # "His son had stared at him — stared at him, the man who had taught him the rule — and George had met the stare and said nothing, and dried the girl's hair with his own shirt."
    "息子は彼を見つめた――その掟を教えた当の男を見つめた――Georgeはその視線を受け止め、何も言わず、自分のシャツで少女の髪を拭いた。"

# game/script/ch08.rpy:355
translate japanese ch08_keys_done_6513a9d9:

    # "And later, when the house was asleep, he had crept to her room the way a thief creeps, and sat on the edge of her bed, and told her — whispering, ashamed, defiant—"
    "そしてのちに、家が寝静まると、彼は泥棒のように彼女の部屋へ忍び込み、ベッドの端に腰かけて、言い聞かせた――ささやき声で、恥じながら、逆らうように――"

# game/script/ch08.rpy:356
translate japanese ch08_keys_done_39c53eea:

    # g soft "You're not weak. The rain is just rain."
    g soft "お前は弱くない。雨はただの雨だ。"

# game/script/ch08.rpy:357
translate japanese ch08_keys_done_64dbe604:

    # g "There are things they'll tell you you have to be. You do not have to be what they make you. Not all of it. Not the coldest parts."
    g "お前がならなきゃならないと、奴らが言うものがある。だが奴らが作ろうとするものに、お前がなる必要はない。全部はな。いちばん冷たいところは。"

# game/script/ch08.rpy:358
translate japanese ch08_keys_done_66487ddc:

    # "He had given her, in secret, in the dark, against everything he had ever believed and taught and enforced, the one thing he had never given his son and never given himself: the permission to be soft."
    "彼は彼女に与えたのだ。ひそかに、闇のなかで、自分が信じ、教え、強いてきたすべてに逆らって。息子にも自分自身にも一度も与えなかった、たったひとつのものを。柔らかくあってもいいという許しを。"

# game/script/ch08.rpy:359
translate japanese ch08_keys_done_19a9fad4:

    # "He had thought he was saving her. He had gone on thinking it, right up until this valley, this winter, these graves."
    "彼女を救っているのだと思っていた。そう思い続けていた。この谷まで、この冬まで、これらの墓まで。"

# game/script/ch08.rpy:361
translate japanese ch08_keys_done_77ae53af:

    # "He was less sure than he had been. Some nights the old fear came and sat on his chest and asked him quietly what, exactly, he had saved."
    "以前ほど確信はなかった。ある夜には古い恐れがやってきて胸の上に座り、静かに尋ねた。いったい何を救ったのか、と。"

# game/script/ch08.rpy:362
translate japanese ch08_keys_done_116d891e:

    # "Whether the softness he had smuggled to her in the dark had grown up into a girl — or had only been folded, neat and deep, over something he had never had the courage to name."
    "闇のなかでこっそり渡した柔らかさは、ひとりの少女に育ったのか――それとも、名づける勇気を彼が一度も持てなかった何かの上に、きちんと深く折り重ねられただけなのか。"

# game/script/ch08.rpy:363
translate japanese ch08_keys_done_f2d675fe:

    # "He did not answer the fear. He never answered it. He had gotten very good, across two years, at not answering it."
    "彼はその恐れに答えなかった。一度も答えなかった。この二年で、答えないことがすっかりうまくなっていた。"

# game/script/ch08.rpy:364
translate japanese ch08_keys_done_3428eb3a:

    # "And he did not intend to start tonight, in a cell, with the answer maybe waiting for him at the far end of one more thought he refused to think."
    "そして今夜、房のなかで答え始めるつもりもなかった。考えることを拒んでいるもうひとつの考えの先に、答えが待っているかもしれないときに。"

# game/script/ch08.rpy:372
translate japanese ch08_keys_done_47dd07da:

    # a cry "Grandpa. Please."
    a cry "おじいちゃん。お願い。"

# game/script/ch08.rpy:373
translate japanese ch08_keys_done_5e219386:

    # "He came back to the cell, to the bars, to the weeping child three feet away."
    "彼は房へ、鉄格子へ、三フィート先で泣いている子どものもとへ戻ってきた。"

# game/script/ch08.rpy:374
translate japanese ch08_keys_done_ee07e9a9:

    # "Markou glanced at her watch and murmured to the officer, and the two adults stepped back a few paces to give, in their kindness, the old man and the girl a moment that was almost private."
    "Markouは腕時計に目をやって巡査に何かつぶやき、ふたりの大人は数歩下がった。親切心から、老人と少女に、ほとんどふたりきりの時間を与えるために。"

# game/script/ch08.rpy:383
translate japanese ch08_keys_done_2242b29d:

    # "And in that moment — in the two seconds when no other eyes in the world were on her face but his — Alice stopped crying."
    "そしてその瞬間――世界で彼の目のほかに、彼女の顔を見ている目がひとつもなかった二秒間――Aliceは泣きやんだ。"

# game/script/ch08.rpy:384
translate japanese ch08_keys_done_89718dd4:

    # "Not slowly. All at once, the way you set down something you have been carrying only because someone was watching."
    "ゆっくりではなかった。一度に。誰かが見ていたから運んでいただけの荷物を下ろすように。"

# game/script/ch08.rpy:385
translate japanese ch08_keys_done_673dd39a:

    # "The tears stayed on her cheeks, wet and real, but the thing behind them simply went out, like a lamp."
    "涙は頬に残っていた。濡れて、本物だった。だがその奥にあったものは、ランプのように、ふっと消えた。"

# game/script/ch08.rpy:386
translate japanese ch08_keys_done_8abdc89a:

    # "What looked at George Bennett out of his granddaughter's eyes across those three feet of cold air was not a child, and was not grieving, and was not afraid."
    "三フィートの冷たい空気を隔て、孫娘の目からGeorge Bennettを見ていたものは、子どもではなく、悲しんでもおらず、怯えてもいなかった。"

# game/script/ch08.rpy:387
translate japanese ch08_keys_done_cfd9dd66:

    # "It was calm. It was patient. It considered him the way she must have considered all of them at the end, weighing, and finding the weight."
    "それは落ち着いていた。辛抱強かった。それは彼を吟味していた。最後に彼ら全員をそうしたにちがいないように、量り、その重さを見定めながら。"

# game/script/ch08.rpy:388
translate japanese ch08_keys_done_3456d93e:

    # "And it let him see it — deliberately, as a gift or a test or a mercy of its own, because he was the one person on earth who already knew and would never, could never, say."
    "そしてそれは、彼に見せた――わざと。贈り物として、試しとして、あるいはそれなりの慈悲として。彼こそが、すでに知っていて、決して言わない、言えない、地上でただひとりの人間だったからだ。"

# game/script/ch08.rpy:389
translate japanese ch08_keys_done_20eb1da8:

    # gth "There you are."
    gth "そこにいたのか。"

# game/script/ch08.rpy:390
translate japanese ch08_keys_done_0989d0c3:

    # "He did not know if the thought was grief or love or the final closing of the sun he had refused for two years to look at."
    "その思いが悲しみなのか、愛なのか、それとも二年間見ることを拒んできた太陽が最後に閉じていくことなのか、彼にはわからなかった。"

# game/script/ch08.rpy:391
translate japanese ch08_keys_done_7195c9e9:

    # gth "There you are. I made you. I ran across the whole world with you and I could not run far enough, because I was carrying the thing I was running from."
    gth "そこにいたのか。俺がお前を作った。お前を連れて世界じゅうを逃げ回ったが、逃げきれなかった。逃げているそのものを、俺が抱えて運んでいたからだ。"

# game/script/ch08.rpy:395
translate japanese ch08_keys_done_81ed37a8:

    # "She held his eyes a moment longer. Then, unhurried, she picked the child back up — put it on the way you put on a coat — and the tears meant something again, and her lip trembled."
    "彼女はもう少しのあいだ彼の目を捉えていた。それから急ぐでもなく、子どもをまた拾い上げた――コートを着るように身にまとった――すると涙はふたたび意味を持ち、唇が震えた。"

# game/script/ch08.rpy:396
translate japanese ch08_keys_done_74854baa:

    # "She whispered, so low that only he could hear it, in a voice with nothing at all underneath:"
    "彼女はささやいた。彼にしか聞こえないほど低く、その下に何ひとつない声で。"

# game/script/ch08.rpy:397
translate japanese ch08_keys_done_8d3d8abf:

    # a "It's alright, Grandpa. I'll be alright. I always am."
    a "大丈夫だよ、おじいちゃん。私は大丈夫。いつだってそうだから。"

# game/script/ch08.rpy:398
translate japanese ch08_keys_done_50ed7e95:

    # "And George Bennett opened his mouth."
    "そしてGeorge Bennettは口を開いた。"

# game/script/ch08.rpy:399
translate japanese ch08_keys_done_b163e5e2:

    # "It would have taken four words. {i}It's her. Watch her.{/i}"
    "四語で足りたはずだった。{i}この子だ。この子を見張れ。{/i}"

# game/script/ch08.rpy:400
translate japanese ch08_keys_done_6233804c:

    # "Four words to the psychiatrist, to the officer, to the detective who had all but begged him — and the thread would swing off his own neck and onto hers."
    "精神科医に、巡査に、懇願せんばかりだった刑事に、四語。それで糸は彼自身の首から外れ、彼女の首へ移る。"

# game/script/ch08.rpy:401
translate japanese ch08_keys_done_986c47da:

    # "He would not hang, and the town would have its answer, and the dying, perhaps, would stop."
    "彼は吊られずにすみ、町は答えを得て、死はおそらく止む。"

# game/script/ch08.rpy:405
translate japanese ch08_keys_done_0cf7cb1c:

    # "He drew the breath for it. His tongue found the first word."
    "彼はそのための息を吸った。舌が最初の言葉を探り当てた。"

# game/script/ch08.rpy:406
translate japanese ch08_keys_done_5998fdf7:

    # "And the word would not come. His jaw held the way it had held on the boards, forty years ago, with his own father's thumb on his face."
    "だがその言葉は出てこなかった。顎は固まっていた。四十年前の床板の上で、自分の父親の親指を顔に当てられて固まったように。"

# game/script/ch08.rpy:407
translate japanese ch08_keys_done_1babb62e:

    # "Because the four words were every one of them a confession."
    "その四語は、どれひとつ残らず告白だったからだ。"

# game/script/ch08.rpy:409
translate japanese ch08_keys_done_e06e9441:

    # "He did not try. He knew before he opened his mouth what was behind the four words."
    "彼は試みもしなかった。口を開く前から、四語の後ろに何があるかわかっていた。"

# game/script/ch08.rpy:410
translate japanese ch08_keys_done_8f1e563d:

    # "Every one of them a confession."
    "どれひとつ残らず、告白。"

# game/script/ch08.rpy:412
translate japanese ch08_keys_done_01f016ee:

    # "That the doctrine had not failed. That the cold house and the bare boards and the rain and the forty years of it had worked — had come to fruit at last in this small calm patient girl."
    "教義は失敗しなかったということ。冷たい家も、むき出しの床板も、雨も、四十年に及ぶそのすべてが功を奏した――ついに、この小さく落ち着いた辛抱強い少女のなかで実を結んだということ。"

# game/script/ch08.rpy:413
translate japanese ch08_keys_done_115d18e2:

    # "That he had spent his life building the machine and his last two years pretending he had unbuilt it."
    "自分は生涯をかけて機械を造り、最後の二年を、それを解体したふりをして過ごしたということ。"

# game/script/ch08.rpy:414
translate japanese ch08_keys_done_2450f9e2:

    # "That the thing he had refused for two years to look at was standing three feet away, weeping on command, wearing the very face he had helped it learn."
    "二年間見ることを拒んできたものが三フィート先に立ち、意のままに涙を流し、彼自身が覚えさせる手助けをしたまさにその顔をまとっているということ。"

# game/script/ch08.rpy:415
translate japanese ch08_keys_done_3bc93e5f:

    # "To name her was to say aloud, in front of witnesses, that everything he was, was true. He had run from that sentence across a whole country. He found he could not run to it now."
    "彼女を名指すことは、証人の前で声に出して言うことだった。自分という人間のすべてが真実だったと。その一文から、彼は国じゅうを越えて逃げてきた。いまさらそこへ向かって走ることはできないと、彼は知った。"

# game/script/ch08.rpy:416
translate japanese ch08_keys_done_bd1f03e5:

    # "And under all of it, deeper than the shame, older than the doctrine, was the thing that had put him out in the rain when she was five."
    "そしてそのすべての下に、恥よりも深く、教義よりも古く、彼女が五歳のとき彼を雨のなかへ出ていかせたものがあった。"

# game/script/ch08.rpy:417
translate japanese ch08_keys_done_e39c017a:

    # gth "She's mine. And I failed her. And a man does not answer his own failure by handing the child of it to a rope."
    gth "あの子は俺のものだ。そして俺はあの子をしくじった。男は自分のしくじりの償いに、そのしくじりの子を縄に差し出したりはしない。"

# game/script/ch08.rpy:418
translate japanese ch08_keys_done_06d019cc:

    # "He closed his mouth."
    "彼は口を閉じた。"

# game/script/ch08.rpy:425
translate japanese ch08_keys_done_204f7e95:

    # g grim "Go on, now."
    g grim "さあ、行け。"

# game/script/ch08.rpy:426
translate japanese ch08_keys_done_fc780a02:

    # "Roughly, to the girl, to the child, to whatever she was."
    "荒っぽく、少女に、子どもに、彼女が何者であれそれに向かって。"

# game/script/ch08.rpy:427
translate japanese ch08_keys_done_006c9ea0:

    # g "Go with the doctor. Be good."
    g "先生と一緒に行け。いい子にしてろ。"

# game/script/ch08.rpy:428
translate japanese ch08_keys_done_5dc3e8cb:

    # "The old words. The only benediction his kind had."
    "古い言葉。彼の同類が持つ唯一の祝福。"

# game/script/ch08.rpy:432
translate japanese ch08_keys_done_ba4dd33a:

    # g soft "Give them nothing."
    g soft "何も与えるな。"

# game/script/ch08.rpy:433
translate japanese ch08_keys_done_ca7db81f:

    # "Something moved, very deep, behind Alice's eyes — there and gone, unreadable, his last sight of whatever lived in her."
    "Aliceの目の奥、ずっと深いところで何かが動いた――現れて消えた、読めない何か。彼女のなかに棲むものを彼が見た、最後の姿だった。"

# game/script/ch08.rpy:434
translate japanese ch08_keys_done_5e67b1bd:

    # "Then Markou's hand was on her shoulder and the child was turning, and the small footsteps went back down the stair."
    "やがてMarkouの手が彼女の肩に置かれ、子どもは向きを変え、小さな足音が階段を下りていった。"

# game/script/ch08.rpy:438
translate japanese ch08_keys_done_886ed199:

    # "George Bennett sat down against the cold block wall and put his hands loose on his knees and gave his face to the middle distance, and waited, now, for the only thing left that was coming for him."
    "George Bennettは冷たいブロック壁にもたれて座り、両手を膝の上で緩め、顔を中空に向けた。そしていま、自分に向かってくる残されたただひとつのものを待った。"

# game/script/ch08.rpy:454
translate japanese ch08_keys_done_b3a5484b:

    # "The transport came up the mountain at first light, and the town was already awake to meet it."
    "夜明けに移送車が山を上ってきた。町はすでに目を覚まし、それを迎えた。"

# game/script/ch08.rpy:455
translate japanese ch08_keys_done_608e8e04:

    # "Samuel had not slept. He stood at the second-floor window with his fourth coffee and watched the square fill in the gray."
    "Samuelは眠っていなかった。四杯目のコーヒーを手に二階の窓辺に立ち、灰色のなかで広場が埋まっていくのを見ていた。"

# game/script/ch08.rpy:456
translate japanese ch08_keys_done_c90ddc31:

    # "It was worse in the daylight than it had been in the dark. In the dark a crowd is a mass. In the daylight it is faces."
    "闇のなかよりも、明るいなかのほうがひどかった。闇のなかでは群衆は塊だ。明るいなかでは顔になる。"

# game/script/ch08.rpy:457
translate japanese ch08_keys_done_bcacdaf7:

    # "Faces he knew now: the baker, the man from the hardware, the mother of two who'd fussed her children through the hotel breakfast his first morning here."
    "いまでは知っている顔。パン屋。金物屋の男。ここへ来た最初の朝、ホテルの朝食で子どもふたりの世話を焼いていた母親。"

# game/script/ch08.rpy:458
translate japanese ch08_keys_done_a8800697:

    # "All of them out in the cold with the fires burned down to ash at their feet and the same terrible patience on them, sharpened overnight to an edge."
    "全員が寒空の下にいた。足もとの火は燃え尽きて灰になり、あの同じ恐ろしい忍耐が、一晩で研がれて刃になっていた。"

# game/script/ch08.rpy:459
translate japanese ch08_keys_done_9863c546:

    # "Word had gone through them that George Bennett was being taken down the mountain."
    "George Bennettが山から下ろされるという話が、彼らのあいだに広まっていた。"

# game/script/ch08.rpy:460
translate japanese ch08_keys_done_a960f9d4:

    # th "They haven't come to stop it. They've come to see it. They've come in case."
    th "止めに来たんじゃない。見に来たんだ。もしものときのために来たんだ。"

# game/script/ch08.rpy:461
translate japanese ch08_keys_done_2254120f:

    # "He had spent the small hours on the phone trying to make it safer and gotten nowhere."
    "夜更けのあいだずっと、彼は少しでも安全にしようと電話をかけ続け、何ひとつ得られなかった。"

# game/script/ch08.rpy:462
translate japanese ch08_keys_done_bf70e1cd:

    # "He had asked Doyle for more men and been told there were no more men. He had asked to move George in the dead of night, unannounced, and been told the county van ran on the county's clock, and the county's clock said dawn."
    "Doyleに増員を頼み、これ以上の人手はないと言われた。真夜中に予告なしでGeorgeを移したいと頼み、郡の車は郡の時計で動いていて、郡の時計は夜明けを指していると言われた。"

# game/script/ch08.rpy:463
translate japanese ch08_keys_done_a7dc85ac:

    # "He had asked, last, whether they could take the old service track by the mine instead of Route Nine, and been told it was under four feet of snow and that he was, frankly, overthinking a twenty-minute drive down a public road."
    "最後に、Route Nineではなく鉱山脇の古い作業道を使えないかと尋ね、そこは四フィートの雪の下だ、それにはっきり言って、公道を二十分下るだけのことを考えすぎだと言われた。"

# game/script/ch08.rpy:464
translate japanese ch08_keys_done_e1dd383d:

    # "So he had watched the sky go gray and the square fill, and now the van was here."
    "だから彼は空が灰色になり、広場が埋まっていくのを見ていた。そしていま、車が来ていた。"

# game/script/ch08.rpy:465
translate japanese ch08_keys_done_ce33e826:

    # "A county remand vehicle, white, boxy, two county officers in it and a cage in the back. Nosing up the last of the road through the parting crowd, it looked exactly as fragile as Doyle had promised the cell would be."
    "郡の護送車。白い箱型で、郡の警官がふたり乗り、後部に檻がある。割れていく群衆のあいだを道の終わりまで鼻先を突き出して上ってくるそれは、Doyleが房についてそうだと請け合ったのとまったく同じくらい、もろく見えた。"

# game/script/ch08.rpy:466
translate japanese ch08_keys_done_580900f4:

    # "Samuel went down."
    "Samuelは下りていった。"

# game/script/ch08.rpy:467
translate japanese ch08_keys_done_53638e96:

    # s stern "I don't like the route."
    s stern "このルートは気に入らない。"

# game/script/ch08.rpy:468
translate japanese ch08_keys_done_53857a99:

    # "He said it in the cold of the yard to the senior county man, a heavyset sergeant named Poole, who had the unbothered look of a man who did this for a living and had never done it here."
    "中庭の寒さのなかで、彼は郡側の責任者にそう言った。Pooleという名のずんぐりした巡査部長で、これを生業にしていながらここでやったことは一度もない男の、動じない顔をしていた。"

# game/script/ch08.rpy:469
translate japanese ch08_keys_done_aac06c6e:

    # s "Route Nine's a single lane most of the way down, cliff on one side, gorge on the other. Bad bends. And half this town has a truck."
    s "Route Nineは下りのほとんどが一車線だ。片側は崖、反対側は峡谷。急なカーブもある。それにこの町の半分はトラックを持ってる。"

# game/script/ch08.rpy:470
translate japanese ch08_keys_done_d39bc224:

    # "Poole glanced at the crowd the way you glance at weather."
    "Pooleは、空模様に目をやるように群衆を一瞥した。"

# game/script/ch08.rpy:471
translate japanese ch08_keys_done_ec74cc52:

    # poole "It's the only road down, Detective. Unless you want to wait for a helicopter that isn't coming."
    poole "山を下りる道はあれしかありませんよ、刑事。来もしないヘリを待ちたいなら別ですがね。"

# game/script/ch08.rpy:472
translate japanese ch08_keys_done_b28dd8e9:

    # "He signed Samuel's transfer sheet without reading it."
    "彼はSamuelの移送書類を読みもせずに署名した。"

# game/script/ch08.rpy:473
translate japanese ch08_keys_done_e281c108:

    # poole "We've done harder towns than this. They shout, they film it, they go home to their dinner. Twenty minutes and he's ours."
    poole "もっと厄介な町もやってきました。連中は叫んで、撮影して、家に帰って晩飯を食う。二十分で奴はこっちのものです。"

# game/script/ch08.rpy:475
translate japanese ch08_keys_done_7a4195d5:

    # note_voice "Route Nine: single lane, cliff one side, gorge the other."
    note_voice "Route Nine――一車線、片側崖、反対側峡谷。"

# game/script/ch08.rpy:476
translate japanese ch08_keys_done_446519c5:

    # s "I'll follow you down."
    s "後ろからついていく。"

# game/script/ch08.rpy:477
translate japanese ch08_keys_done_1a2f2215:

    # poole "Suit yourself."
    poole "お好きに。"

# game/script/ch08.rpy:480
translate japanese ch08_keys_done_391557f7:

    # "They brought George out into the morning. He came the way he had gone in — upright, silent, his cuffed hands before him and his eyes on nothing."
    "彼らはGeorgeを朝のなかへ連れ出した。入っていったときと同じように彼は出てきた――背筋を伸ばし、無言で、手錠をかけられた両手を前に、目は何も見ずに。"

# game/script/ch08.rpy:481
translate japanese ch08_keys_done_f20c9a8a:

    # "The sound the crowd made when he appeared was not the roar Samuel had braced for but something lower and more frightening: a long exhaled {i}there he is{/i} that ran through the mass and drew it a step tighter."
    "彼が現れたとき群衆が立てた音は、Samuelが身構えていた怒号ではなく、もっと低く、もっと恐ろしいものだった。長く吐き出される{i}あいつだ{/i}という声が塊のなかを走り、群衆を一歩ぶん締めつけた。"

# game/script/ch08.rpy:482
translate japanese ch08_keys_done_2b8f45b4:

    # crowd "There he is."
    crowd "あいつだ。"

# game/script/ch08.rpy:483
translate japanese ch08_keys_done_f165e098:

    # "The officers walked him fast across the yard through a corridor of it. Phones up, faces contorting, a woman spitting."
    "警官たちは群衆がつくる通路を抜け、彼を足早に中庭を横切らせた。掲げられた携帯電話、歪む顔、唾を吐く女。"

# game/script/ch08.rpy:484
translate japanese ch08_keys_done_d5e4b715:

    # "A man's voice cracking as it screamed the Carter girl's name, and then Clara's, and then a name that was just a sound."
    "Carterの娘の名を叫んで裏返る男の声。次にClaraの名、そして、もはやただの音でしかない名。"

# game/script/ch08.rpy:485
translate japanese ch08_keys_done_d63d3b64:

    # "George did not look at any of them. He looked, once, up and to the left, at the high window where the psychiatrist's car had been an hour ago and was not now."
    "Georgeは誰も見なかった。一度だけ、左上の高い窓を見た。一時間前には精神科医の車があり、いまはもうない場所を。"

# game/script/ch08.rpy:486
translate japanese ch08_keys_done_56549c47:

    # th "Looking for the girl. Not finding her. A grandfather's last search for the child he raised."
    th "あの子を探している。見つからない。育てた子どもを探す、祖父の最後の目。"

# game/script/ch08.rpy:487
translate japanese ch08_keys_done_f7260765:

    # "That was all Samuel made of it."
    "Samuelがそこから読み取ったのは、それだけだった。"

# game/script/ch08.rpy:489
translate japanese ch08_keys_done_89a7f819:

    # "Then they put him in the cage and shut the door on him, and he was gone from view behind the mesh."
    "それから彼らは彼を檻に入れて扉を閉め、彼の姿は金網の向こうに見えなくなった。"

# game/script/ch08.rpy:490
translate japanese ch08_keys_done_ab828ffc:

    # "The van pulled out. The crowd did not stop it."
    "車が出た。群衆は止めなかった。"

# game/script/ch08.rpy:491
translate japanese ch08_keys_done_e781ec7f:

    # "The crowd, in ones and twos and then in a slow gathering current, began to follow it — on foot, and then in trucks that coughed to life along the square, headlights coming on in the gray."
    "群衆はひとり、ふたりと、やがてゆっくりと集まる流れになって、そのあとを追いはじめた――最初は徒歩で、次に広場沿いで咳き込むように息を吹き返したトラックで。灰色のなかにヘッドライトが灯っていった。"

# game/script/ch08.rpy:492
translate japanese ch08_keys_done_4737e226:

    # "A slow procession, forming in the transport's wake, down toward the mouth of Route Nine."
    "移送車の後ろにできていく緩やかな行列が、Route Nineの入り口へと下っていく。"

# game/script/ch08.rpy:493
translate japanese ch08_keys_done_6413959a:

    # "Samuel ran for his car. He was reaching for the door when Mercer caught his arm — Mercer white-faced, a phone in his hand, Doyle's voice small and urgent leaking out of it."
    "Samuelは車へ走った。ドアに手を伸ばしたとき、Mercerが彼の腕をつかんだ――顔面蒼白のMercerの手には電話があり、そこからDoyleの小さく切迫した声が漏れていた。"

# game/script/ch08.rpy:494
translate japanese ch08_keys_done_2d6a4926:

    # "The square was emptying downhill now, fast, the whole weight of the town pouring after the little white van toward the one narrow road off the mountain."
    "広場はいま、急速に坂の下へと空になっていった。町の全重量が、小さな白い車を追って、山を下りる一本の狭い道へと流れ込んでいく。"

# game/script/ch08.rpy:495
translate japanese ch08_keys_done_3af50ed1:

    # "Samuel stood for one second with his hand on the cold door, and the certainty went through him at last, complete and far too late."
    "Samuelは冷たいドアに手をかけたまま一秒立ち尽くした。そして確信がついに彼を貫いた。完全な、あまりにも遅すぎる確信が。"

# game/script/ch08.rpy:496
translate japanese ch08_keys_done_6638634e:

    # th "Ray was right about everything except the hour. They're not going to wait for the county. They're not going to wait for anything."
    th "Rayは時間以外、何もかも正しかった。奴らは郡を待つ気なんかない。何ひとつ待つ気はない。"

# game/script/ch08.rpy:504
translate japanese ch08_keys_done_b2a5af9b:

    # "Samuel got the car started and went down after them, into the bends, too fast, the gorge dropping away white on his right."
    "Samuelは車を出し、彼らを追ってカーブへと下っていった。速すぎた。右手には峡谷が白く落ち込んでいた。"

# game/script/ch08.rpy:505
translate japanese ch08_keys_done_e86200a3:

    # "Up ahead through the pines the brake lights were already blooming — a whole town's worth of them, red in the gray morning."
    "前方の松のあいだに、もうブレーキランプが咲きはじめていた――町ひとつぶんの、灰色の朝に赤く。"

# game/script/ch08.rpy:506
translate japanese ch08_keys_done_96ea4c3e:

    # "Slowing. Stopping. Piling up in the road where the van had stopped."
    "減速し。停まり。護送車が停まった道に、積み重なっていく。"

# game/script/ch08.rpy:507
translate japanese ch08_keys_done_933cfed7:

    # "Where something had stopped it."
    "何かが、それを停めた場所に。"

# game/script/ch08.rpy:508
translate japanese ch08_keys_done_62e60460:

    # "He put his hand on the horn and drove down into the thing he had built."
    "彼はクラクションに手を置き、自分が造り上げたものへと下っていった。"

translate japanese strings:

    # game/script/ch08.rpy:185
    old "Driftwood."
    new "Driftwood。"

    # game/script/ch08.rpy:188
    old "Alice."
    new "Alice。"

    # game/script/ch08.rpy:191
    old "The alibi."
    new "アリバイ。"

    # game/script/ch08.rpy:246
    old "Ask what he means."
    new "どういう意味か訊く。"

    # game/script/ch08.rpy:254
    old "Hear a grandfather's guilt."
    new "祖父の罪悪感と聞く。"

    # game/script/ch08.rpy:290
    old "His silence."
    new "彼の沈黙。"

    # game/script/ch08.rpy:404
    old "Say it. \"It's her. Watch her.\""
    new "言う。「この子だ。この子を見張れ」"

    # game/script/ch08.rpy:408
    old "Say nothing."
    new "何も言わない。"

