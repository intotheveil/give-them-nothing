# TODO: Translation updated at 2026-10-11 10:23

# game/script/ch03.rpy:9
translate japanese ch03_b90f233e:

    # "The hotel stood just off the main square, a modest three-story building with a sloped roof and a neon sign that buzzed faintly against the snow."
    "ホテルは中央広場から少し外れたところに建っていた。勾配のある屋根の、控えめな三階建て。ネオンサインが雪を背に、かすかに唸っていた。"

# game/script/ch03.rpy:10
translate japanese ch03_709dfed3:

    # "Inside, the lobby was warm. Pine cleaner, faint wood polish. A small Christmas tree leaned in one corner, its lights still glowing though the holiday had already passed."
    "中のロビーは暖かかった。松の香りの洗剤、かすかな木材用ワックス。片隅には小さなクリスマスツリーが傾いて立ち、祝日はもう過ぎたというのに電飾がまだ灯っていた。"

# game/script/ch03.rpy:11
translate japanese ch03_5be0486e:

    # "The clerk behind the counter straightened as Samuel approached. Early twenties, tidy hair, the expression of someone unused to late-night visitors."
    "Samuelが近づくと、カウンターの向こうのフロント係が背筋を伸ばした。二十代前半、整った髪。夜更けの客に慣れていない者の顔つきだった。"

# game/script/ch03.rpy:12
translate japanese ch03_f66d48b4:

    # s "I'll need a room."
    s "部屋を頼む。"

# game/script/ch03.rpy:13
translate japanese ch03_9f193097:

    # extend " Indefinitely."
    extend "期限なしで。"

# game/script/ch03.rpy:14
translate japanese ch03_5b6c70a3:

    # "The clerk blinked, but began to type, hands clumsy against the keys."
    "フロント係はまばたきしたが、キーボードを打ち始めた。手つきはぎこちなかった。"

# game/script/ch03.rpy:15
translate japanese ch03_a249f5bc:

    # clerk "Of course, sir. No problem."
    clerk "かしこまりました。問題ございません。"

# game/script/ch03.rpy:16
translate japanese ch03_5798b44e:

    # "He slid a form across. Samuel signed without hesitation. The young man hesitated before handing over the key, and his curiosity leaked into his voice."
    "彼は用紙を差し出した。Samuelはためらわずに署名した。若者は鍵を渡す前にためらい、好奇心が声に滲み出た。"

# game/script/ch03.rpy:17
translate japanese ch03_caea93e7:

    # clerk "If you don't mind me asking... was she crazy? That teacher in town... she jumped in a T-shirt at minus ten?"
    clerk "あの、差し支えなければ……その人、頭がおかしかったんですか？町のあの先生……零下十度に、Tシャツ一枚で飛び降りたって？"

# game/script/ch03.rpy:18
translate japanese ch03_f06895f1:

    # "Samuel looked at him once, his face unreadable, then slid the key from his hand without answering."
    "Samuelは一度だけ彼を見た。表情は読めなかった。それから答えずに、その手から鍵を抜き取った。"

# game/script/ch03.rpy:19
translate japanese ch03_d12b1800:

    # "The silence was sharper than a reply. The clerk fidgeted, suddenly aware of the weight of his own words."
    "沈黙は返事よりも鋭かった。フロント係はもじもじと身じろぎし、自分の言葉の重さに急に気づいた。"

# game/script/ch03.rpy:20
translate japanese ch03_867211ad:

    # "Samuel stepped into the elevator, then glanced back, voice blunt and dry."
    "Samuelはエレベーターに乗り込み、振り返った。ぶっきらぼうで、乾いた声だった。"

# game/script/ch03.rpy:21
translate japanese ch03_fc0d41b2:

    # s "I'm planning to smoke in there. I'm sure you don't mind."
    s "部屋で煙草を吸うつもりだ。構わないだろう。"

# game/script/ch03.rpy:22
translate japanese ch03_ca3c26a7:

    # clerk "Sir—"
    clerk "お客様――"

# game/script/ch03.rpy:23
translate japanese ch03_d0946149:

    # "The doors slid shut on the rest."
    "残りの言葉は、閉まる扉に断ち切られた。"

# game/script/ch03.rpy:27
translate japanese ch03_9d58a2f7:

    # "A hushed corridor, a room near the end. A double bed, a desk with a lamp, curtains drawn against the snow."
    "静まり返った廊下、突き当たり近くの部屋。ダブルベッド、ランプの載った机、雪に向けて引かれたカーテン。"

# game/script/ch03.rpy:29
translate japanese ch03_11e8f510:

    # "He closed the door with more force than he intended. The slam echoed briefly, then left the room in silence again."
    "思った以上の力でドアを閉めた。叩きつける音が短く響き、部屋はまた静けさに戻った。"

# game/script/ch03.rpy:30
translate japanese ch03_654809db:

    # "Almost at once, a sharp pang twisted his stomach. He hadn't eaten since morning, and the day had burned through whatever reserves he had left."
    "ほとんどすぐに、鋭い痛みが胃をよじった。朝から何も食べていなかった。この一日が、残っていた蓄えを燃やし尽くしていた。"

# game/script/ch03.rpy:31
translate japanese ch03_ff69ac91:

    # th "Fuel first. The case will keep an hour."
    th "まず燃料だ。事件は一時間くらい待ってくれる。"

# game/script/ch03.rpy:32
translate japanese ch03_069fe3b5:

    # "A wrapped croissant and a plain sandwich, packed for the trip. Practical, nothing more. He sat on the edge of the bed, food in one hand, notebook in the other."
    "包装したクロワッサンと、何の変哲もないサンドイッチ。旅のために詰めてきたものだ。実用的、それ以上ではない。彼はベッドの端に腰かけた。片手に食べ物、もう片手に手帳。"

# game/script/ch03.rpy:33
translate japanese ch03_8ed88643:

    # "He set his phone beside him and replayed the recording of Andreas Mallory's interview."
    "携帯を脇に置き、Andreas Malloryの事情聴取の録音を再生した。"

# game/script/ch03.rpy:34
translate japanese ch03_81e005e0:

    # an "...she stayed to wash the dishes... the door closed... I thought she went to throw the trash out..."
    an "……妻は皿を洗うと言って残って……ドアが閉まって……ゴミを出しに行ったんだと思って……"

# game/script/ch03.rpy:35
translate japanese ch03_1d47fd69:

    # "Samuel listened with eyes narrowed, cigarette burning in the ashtray. He let the pauses, the tone, the weight of guilt settle in his mind."
    "Samuelは目を細めて聞いた。灰皿では煙草が燃えていた。間を、口調を、罪悪感の重みを、頭の中に沈ませた。"

# game/script/ch03.rpy:36
translate japanese ch03_0d5115de:

    # "In the margins, small notes: {i}Dishes not washed. Phone left behind. Preplanned breakfast table.{/i}"
    "余白には小さなメモ。{i}皿は洗われていない。電話は置いたまま。前もって用意された朝食の席。{/i}"

# game/script/ch03.rpy:37
translate japanese ch03_b9f62427:

    # "He leaned back, exhaled smoke through his nose, and stared at the ceiling."
    "彼は背をもたせかけ、鼻から煙を吐き、天井を見つめた。"

# game/script/ch03.rpy:38
translate japanese ch03_9db8c777:

    # th "Suicide doesn't fit. Not cleanly."
    th "自殺では収まらない。すっきりとは。"

# game/script/ch03.rpy:39
translate japanese ch03_f0133cbf:

    # "Not by hands, maybe — but someone had put her on that roof all the same. By words. By pressure. By something that left no mark for a coroner to find."
    "手によってではないかもしれない――だが誰かが、それでも彼女をあの屋上に立たせたのだ。言葉によって。圧力によって。検視官に見つけられる痕を何ひとつ残さない、何かによって。"

# game/script/ch03.rpy:40
translate japanese ch03_f2ae7d06:

    # "He had seen grief before, and despair. He knew their shapes by now. This was a different shape."
    "悲しみも、絶望も、彼はこれまでに見てきた。その形はもう知っていた。これは違う形だった。"

# game/script/ch03.rpy:41
translate japanese ch03_2e892be1:

    # "He set the notebook aside and pulled Maria's phone from his coat. No password change, no special protections. He opened the call log first."
    "手帳を脇に置き、コートからMariaの携帯を取り出した。パスワードの変更なし、特別な保護もなし。まず通話履歴を開いた。"

# game/script/ch03.rpy:42
translate japanese ch03_135ea16f:

    # "Family calls over Christmas. New Year's greetings. Relatives, a few minutes to nearly an hour. Nothing unusual for the holidays."
    "クリスマスの家族との通話。新年の挨拶。親戚、数分から一時間近くまで。祝日としては何も変わったところはない。"

# game/script/ch03.rpy:43
translate japanese ch03_54fb2377:

    # "But one entry stood out."
    "だが、ひとつの記録が目を引いた。"

# game/script/ch03.rpy:44
translate japanese ch03_4f4536c8:

    # "December 31st, late evening. {i}Steve Collins.{/i} Duration: six seconds."
    "十二月三十一日、夜遅く。{i}Steve Collins。{/i}通話時間、六秒。"

# game/script/ch03.rpy:45
translate japanese ch03_98b3058a:

    # th "Six seconds isn't a conversation. Barely enough for a wrong number."
    th "六秒は会話じゃない。間違い電話がやっとだ。"

# game/script/ch03.rpy:46
translate japanese ch03_bc518294:

    # extend " Or for someone to lose their nerve."
    extend "あるいは、誰かが怖気づくのにちょうどいい。"

# game/script/ch03.rpy:48
translate japanese ch03_daa66878:

    # note_voice "Steve Collins — 6 sec call — NYE."
    note_voice "Steve Collins――通話6秒――大晦日。"

# game/script/ch03.rpy:49
translate japanese ch03_22c58f94:

    # "Into the messages. Her husband, the children's reminders, short notes with relatives. All the usual rhythm of family life."
    "次はメッセージ。夫、子どもたちへの念押し、親戚との短いやりとり。家族の暮らしの、ごく当たり前のリズム。"

# game/script/ch03.rpy:50
translate japanese ch03_4ef5e83e:

    # "But one chat drew his attention. A group named {i}Evening Study Group{/i}."
    "だが、ひとつのチャットが注意を引いた。{i}夕方の勉強会{/i}という名のグループ。"

# game/script/ch03.rpy:51
translate japanese ch03_2c8ad228:

    # "Eight participants. Three boys, five girls, their names lined up neatly, familiar from what Andreas had said."
    "参加者は八人。男子三人、女子五人。名前がきちんと並んでいる。Andreasの話で聞き覚えのある名前だった。"

# game/script/ch03.rpy:52
translate japanese ch03_1463ff3b:

    # "And there it was, buried among them: Steve Collins."
    "そして、その中に埋もれていた。Steve Collins。"

# game/script/ch03.rpy:53
translate japanese ch03_f7b52d17:

    # "Samuel paused, cigarette halfway to his lips."
    "Samuelは煙草を唇へ運ぶ途中で手を止めた。"

# game/script/ch03.rpy:54
translate japanese ch03_b48275ca:

    # th "So. The same boy who called her on New Year's Eve."
    th "なるほど。大晦日に彼女に電話した、あの少年だ。"

# game/script/ch03.rpy:55
translate japanese ch03_64d06b08:

    # "He copied the names carefully, circled Steve's and marked it twice."
    "彼は名前を丁寧に書き写し、Steveの名を丸で囲み、二重に印をつけた。"

# game/script/ch03.rpy:56
translate japanese ch03_d27a8f4f:

    # "Outwardly, the chat was harmless — reminders, small encouragements, schedules for extra lessons. But harmless things could hide teeth."
    "表向き、チャットは無害だった――念押し、ささやかな励まし、補習の予定。だが無害なものほど牙を隠せる。"

# game/script/ch03.rpy:57
translate japanese ch03_17ad48d3:

    # "He locked the phone and leaned back until the chair creaked. A nervous boy who'd dialed and lost his nerve in six seconds — or something else entirely."
    "携帯をロックし、椅子がきしむまで背をもたせた。電話をかけて六秒で怖気づいた気の弱い少年か――それとも、まったく別の何かか。"

# game/script/ch03.rpy:58
translate japanese ch03_44a73a44:

    # "He drew on the cigarette and let the smoke go slow, already deciding where he'd press first."
    "煙草を吸い込み、煙をゆっくりと吐いた。どこから先に押すか、もう決めかけていた。"

# game/script/ch03.rpy:61
translate japanese ch03_35539528:

    # "The phone screen dimmed. Going through the device had taken longer than expected, but it was worth it. Every call, every thread, every scrap mattered."
    "携帯の画面が暗くなった。端末を調べるのに思ったより時間がかかったが、その価値はあった。すべての通話、すべてのスレッド、すべての断片に意味があった。"

# game/script/ch03.rpy:63
translate japanese ch03_28ca6798:

    # "A knock. Three short, deliberate raps."
    "ノック。短く、慎重に、三度。"

# game/script/ch03.rpy:64
translate japanese ch03_76cf619a:

    # "Samuel slid the phone back into his coat and opened the door."
    "Samuelは携帯をコートに滑り込ませ、ドアを開けた。"

# game/script/ch03.rpy:66
translate japanese ch03_f453d8e1:

    # "Officer Daniel Mercer. The man who had greeted him at the schoolyard. Samuel hadn't looked at him properly then. He did now."
    "Daniel Mercer巡査。校庭で彼を出迎えた男だ。あのときSamuelはまともに彼を見ていなかった。今は見た。"

# game/script/ch03.rpy:67
translate japanese ch03_15e68a56:

    # "Late thirties, though his face carried more years than that. Eyes sore and rimmed red, the mark of bad sleep carried too long. Nails cut too close, raw at the edges, as if gnawed in idle moments."
    "三十代後半。だが顔はそれ以上の年月を背負っていた。目は痛々しく、縁が赤い。悪い眠りを長く抱えすぎた印だ。爪は短く切りすぎて、縁が剥けている。手持ち無沙汰なときに噛んでいるかのように。"

# game/script/ch03.rpy:68
translate japanese ch03_dee64420:

    # "Collar askew, belt cinched too tight, hair plastered down on one side by water and a flat hand rather than a comb. Presentable, but strangely unsettled."
    "襟は曲がり、ベルトはきつく締めすぎ、髪は櫛ではなく水と平手で片側に撫でつけられている。見苦しくはない。だが妙に落ち着きがない。"

# game/script/ch03.rpy:69
translate japanese ch03_1ae58a07:

    # m "Detective Harris."
    m "Harris刑事。"

# game/script/ch03.rpy:70
translate japanese ch03_469b0fea:

    # m "The names and addresses you asked for. The students Mrs. Mallory was tutoring."
    m "頼まれていた名前と住所です。Mallory先生が教えていた生徒たちの。"

# game/script/ch03.rpy:71
translate japanese ch03_9c8b63a0:

    # "Samuel took the folder and scanned it. The list matched the group chat. And there it was again, in print. {i}Steve Collins.{/i}"
    "Samuelはフォルダを受け取り、目を通した。リストはグループチャットと一致していた。そしてまたそこにあった。今度は印字で。{i}Steve Collins。{/i}"

# game/script/ch03.rpy:72
translate japanese ch03_420da3ff:

    # s "Good. Thank you, Mercer."
    s "よし。ありがとう、Mercer。"

# game/script/ch03.rpy:73
translate japanese ch03_5f3fc75e:

    # "The officer nodded once, waiting."
    "巡査は一度うなずき、待った。"

# game/script/ch03.rpy:74
translate japanese ch03_68eb3249:

    # s "I'll let you know as soon as I find something. For now, you'd better get some rest. We'll catch up tomorrow."
    s "何か見つけたらすぐ知らせる。今はもう休んだほうがいい。続きは明日だ。"

# game/script/ch03.rpy:75
translate japanese ch03_21c867ce:

    # m "Understood, Detective."
    m "わかりました、刑事。"

# game/script/ch03.rpy:76
translate japanese ch03_f9f900ad:

    # "He turned as if to leave, then paused. His voice dropped lower, careful, almost hesitant."
    "彼は帰りかけて、立ち止まった。声が低くなった。慎重で、ほとんどためらうように。"

# game/script/ch03.rpy:77
translate japanese ch03_01154b03:

    # m "Do you think... there's something behind it? Something more than just a suicide?"
    m "刑事は……何か裏があると思いますか？ただの自殺以上の何かが？"

# game/script/ch03.rpy:78
translate japanese ch03_263edc5e:

    # "Samuel's smile came easy, but thin."
    "Samuelの笑みはたやすく浮かんだが、薄かった。"

# game/script/ch03.rpy:79
translate japanese ch03_a38bd997:

    # s "We'll catch up tomorrow."
    s "続きは明日だ。"

# game/script/ch03.rpy:80
translate japanese ch03_2c3a3148:

    # "Polite. Dismissive. No room for argument. Mercer gave a respectful nod, and left."
    "礼儀正しく。そっけなく。反論の余地はなかった。Mercerは敬意をこめてうなずき、去った。"

# game/script/ch03.rpy:89
translate japanese ch03_c1dc931a:

    # "Collins' address. Nine minutes' walk. The clerk barely glanced up as he passed."
    "Collinsの住所。歩いて九分。前を通っても、フロント係はほとんど顔を上げなかった。"

# game/script/ch03.rpy:90
translate japanese ch03_3870053c:

    # "Outside, the air was sharp but cleaner, the snow down to a faint drizzle of flakes. Bakers setting trays behind glass. A grocer sweeping snow from his step."
    "外の空気は鋭かったが、前より澄んでいた。雪はかすかに舞う程度になっていた。ガラスの向こうでトレーを並べるパン屋。店先の雪を掃く食料品屋。"

# game/script/ch03.rpy:91
translate japanese ch03_406576a0:

    # "Most shops stayed shuttered. In small towns like this, nothing really started until after Epiphany, January sixth."
    "ほとんどの店はシャッターを下ろしたままだった。こういう小さな町では、一月六日の公現祭が過ぎるまで、何も本当には始まらない。"

# game/script/ch03.rpy:92
translate japanese ch03_5b755b19:

    # "His boots crunched over salt. Life moved slower here — measured, deliberate. For a fleeting moment he imagined it: a small business, quiet mornings, peace wrapped in routine."
    "ブーツの下で塩が鳴った。ここでは暮らしの歩みが遅い――ゆっくりと、着実に。ほんの一瞬、彼は想像した。小さな商売、静かな朝、日課に包まれた平穏。"

# game/script/ch03.rpy:93
translate japanese ch03_e98db741:

    # "His face hardened almost at once."
    "その顔は、ほとんどすぐに硬くなった。"

# game/script/ch03.rpy:94
translate japanese ch03_47992b3b:

    # th "I'd rot here. Boredom would finish me before anything else."
    th "ここにいたら腐る。何より先に退屈に殺される。"

# game/script/ch03.rpy:95
translate japanese ch03_090dc38f:

    # "At the end of the main district stood Collins' building: three stories of weathered stone, dignified in its way. The kind of construction that belonged to another time."
    "中心街の端に、Collinsの住む建物があった。風雨にさらされた石造りの三階建て。それなりの品格がある。別の時代に属する造りだった。"

# game/script/ch03.rpy:96
translate japanese ch03_67fba815:

    # "Samuel paused on the pavement, ember glowing in the mid-morning light."
    "Samuelは歩道で立ち止まった。午前半ばの光の中で、煙草の火が赤く灯っていた。"

# game/script/ch03.rpy:97
translate japanese ch03_b5433763:

    # th "Steve Collins lives here."
    th "Steve Collinsはここに住んでいる。"

# game/script/ch03.rpy:104
translate japanese ch03_fc7bf49a:

    # "Damp stone and cleaning detergent, the scent that never quite leaves old stairwells. Ground floor, Collins family."
    "湿った石と洗剤。古い階段室から決して抜けきらない匂い。一階、Collins家。"

# game/script/ch03.rpy:105
translate japanese ch03_38dd91f0:

    # "Not a bell. Just his knuckles against wood."
    "呼び鈴は使わない。拳で木の扉を叩くだけ。"

# game/script/ch03.rpy:106
translate japanese ch03_a3ccbfbb:

    # "The latch clicked."
    "掛け金が鳴った。"

# game/script/ch03.rpy:108
translate japanese ch03_8c97e472:

    # "Magda Stewart. Widowed four years. Early forties by the report, but her appearance leaned younger — too young."
    "Magda Stewart。夫を亡くして四年。報告書では四十代前半だが、見た目は若い方へ寄せていた――若すぎるほどに。"

# game/script/ch03.rpy:109
translate japanese ch03_8f3a63fc:

    # "Rose-colored makeup, lipstick in the same shade. A pinkish blouse, a short denim skirt, stockings. Her smile was pleasant. Her eyes evaluated him in a single glance."
    "ローズ色の化粧、同じ色の口紅。ピンクがかったブラウス、デニムのミニスカート、ストッキング。笑みは感じがよかった。目は一瞥で彼を値踏みしていた。"

# game/script/ch03.rpy:118
translate japanese ch03_a9401282:

    # "She had priced him in one look, and decided he might be useful. The smile came after the sum."
    "彼女はひと目で彼に値をつけ、使えるかもしれないと判断した。笑みは勘定のあとに来た。"

# game/script/ch03.rpy:119
translate japanese ch03_74ba8225:

    # mg "Detective Harris?"
    mg "Harris刑事？"

# game/script/ch03.rpy:120
translate japanese ch03_baa9e08f:

    # s "Yes, ma'am. I'm here about your son, Steve. I'd like to ask a few questions."
    s "ええ、奥さん。息子さんのSteveのことで伺いました。少しお聞きしたいことがあります。"

# game/script/ch03.rpy:121
translate japanese ch03_d468f360:

    # "She leaned against the doorframe, arms folded loosely."
    "彼女は腕をゆるく組み、ドア枠にもたれた。"

# game/script/ch03.rpy:122
translate japanese ch03_d8b702be:

    # mg "Yes, I heard about... Maria Mallory. About twenty minutes ago, a neighbor called me. Tragic."
    mg "ええ、聞いてます……Maria Malloryのこと。二十分くらい前に、近所の人から電話があって。悲劇ね。"

# game/script/ch03.rpy:123
translate japanese ch03_9a8bc040:

    # "She tilted her head, lips pursing in mock sadness."
    "彼女は首をかしげ、悲しんでみせるように唇をすぼめた。"

# game/script/ch03.rpy:124
translate japanese ch03_a2236c65:

    # mg "But I haven't told Steve yet. I can't stand to see him upset. Maybe you should tell him instead. You're the professional."
    mg "でも、Steveにはまだ話してないの。あの子が落ち込むのを見るのは耐えられなくて。あなたから話してくださらない？プロなんだから。"

# game/script/ch03.rpy:125
translate japanese ch03_e8f01d8d:

    # th "She can't stand to see him sad."
    th "息子が悲しむのを見るのは耐えられない、か。"

# game/script/ch03.rpy:126
translate japanese ch03_22a3a77a:

    # "Samuel's jaw tightened, though he kept his face neutral. Yet the opportunity was there. The boy's raw reaction would tell him more than any polished story later."
    "Samuelは顎をこわばらせたが、表情は平静に保った。それでも、好機はそこにあった。少年の生の反応は、あとで磨かれたどんな話よりも多くを語るだろう。"

# game/script/ch03.rpy:127
translate japanese ch03_91c273f7:

    # "Something in this house didn't sit right."
    "この家の何かが、しっくりこなかった。"

# game/script/ch03.rpy:128
translate japanese ch03_660c46d3:

    # s "Alright, Mrs. Stewart. I will speak with your son."
    s "わかりました、Stewartさん。息子さんと話します。"

# game/script/ch03.rpy:129
translate japanese ch03_25701c75:

    # mg "Steve's in his room. I'll be in the kitchen, finishing my... power juice."
    mg "Steveは自分の部屋よ。私はキッチンにいるわ。飲みかけの……パワージュースを片づけなきゃ。"

# game/script/ch03.rpy:130
translate japanese ch03_b97e13d7:

    # "A faint smile, too casual for the moment, and she turned away."
    "その場にそぐわない、気楽すぎるかすかな笑み。そして彼女は背を向けた。"

# game/script/ch03.rpy:135
translate japanese ch03_eb585e80:

    # "He knocked twice on the closed door."
    "彼は閉じたドアを二度ノックした。"

# game/script/ch03.rpy:136
translate japanese ch03_ecac9e27:

    # stv "Come in, Ma."
    stv "入っていいよ、母さん。"

# game/script/ch03.rpy:137
translate japanese ch03_2143deac:

    # "Irritated. Samuel pushed the door open."
    "苛立った声。Samuelはドアを押し開けた。"

# game/script/ch03.rpy:138
translate japanese ch03_8e94075c:

    # s "Not your mother, Steve."
    s "お母さんじゃない、Steve。"

# game/script/ch03.rpy:140
translate japanese ch03_45b1e6ea:

    # "He closed the door, pulled out a chair, and sat facing the boy."
    "ドアを閉め、椅子を引き出し、少年と向かい合って座った。"

# game/script/ch03.rpy:141
translate japanese ch03_fa03da2e:

    # s "Detective Harris."
    s "Harris刑事だ。"

# game/script/ch03.rpy:142
translate japanese ch03_6c4aafef:

    # stv "What do you want? I don't have the weed, alright? Jo's got it — it's at his place. Get the fuck out, man, leave me alone."
    stv "何の用だよ？草なら持ってないって、いいだろ？ジョーが持ってる――あいつの家にある。とっとと出てけよ、クソ、ほっといてくれ。"

# game/script/ch03.rpy:143
translate japanese ch03_9d98c97b:

    # "Too fast. Guilty reflex more than thought."
    "早すぎる。考えより先に出た、後ろめたさの反射だ。"

# game/script/ch03.rpy:148
translate japanese ch03_4bf0e9d0:

    # "Samuel didn't raise a hand. He didn't need to. He let the name fall like a dropped weight."
    "Samuelは手を上げなかった。その必要はなかった。彼はその名を、重りを落とすように落とした。"

# game/script/ch03.rpy:149
translate japanese ch03_c5d12486:

    # s "I'm not here for that. I'm here about Maria Mallory."
    s "その件で来たんじゃない。Maria Malloryのことで来た。"

# game/script/ch03.rpy:151
translate japanese ch03_b7ba0123:

    # "The name landed like a blow. Steve froze, the color draining from his face."
    "その名は殴打のように命中した。Steveは凍りつき、顔から血の気が引いた。"

# game/script/ch03.rpy:154
translate japanese ch03_517a30a7:

    # "Samuel raised a hand, calm and steady. Let the boy see he wasn't the enemy. Not yet."
    "Samuelは片手を上げた。落ち着いて、揺るがずに。自分が敵ではないと、少年にわからせる。今はまだ。"

# game/script/ch03.rpy:155
translate japanese ch03_5d3f8ae6:

    # s "Not here for that. Relax. I'm here about Maria Mallory."
    s "その件じゃない。楽にしていい。Maria Malloryのことで来たんだ。"

# game/script/ch03.rpy:156
translate japanese ch03_3c688f6a:

    # "Even gently, the name landed like a blow. Steve froze, the color draining from his face."
    "穏やかに告げても、その名は殴打のように命中した。Steveは凍りつき、顔から血の気が引いた。"

# game/script/ch03.rpy:158
translate japanese ch03_7f5a090d:

    # stv "Wh... what about her? She told you something?"
    stv "な……あの人がどうしたの？何か話したの？"

# game/script/ch03.rpy:159
translate japanese ch03_d1b18da2:

    # "Samuel let the silence drag. He lit a cigarette, the flame flaring briefly, then leaned back, eyes fixed on the boy."
    "Samuelは沈黙を引き延ばした。煙草に火をつけると、炎が一瞬燃え上がった。それから背をもたせ、少年から目を離さなかった。"

# game/script/ch03.rpy:160
translate japanese ch03_54f9a1bc:

    # s "She didn't need to tell me anything. You're telling me plenty right now."
    s "彼女が私に何か話す必要はなかった。今、君がたっぷり話してくれている。"

# game/script/ch03.rpy:161
translate japanese ch03_1bbf6436:

    # stv "No — she was just my teacher, that's all."
    stv "違う――ただの先生だよ、それだけ。"

# game/script/ch03.rpy:162
translate japanese ch03_8bdd76d9:

    # s "Teachers don't usually leave their students white as chalk at the mention of their name."
    s "ふつう教師は、名前を出されただけで生徒をチョークみたいに真っ白にはさせない。"

# game/script/ch03.rpy:163
translate japanese ch03_ae8016d3:

    # s "So I'll ask once. What was going on between you and Maria?"
    s "だから一度だけ聞く。君とMariaの間に何があった？"

# game/script/ch03.rpy:164
translate japanese ch03_9ba5a291:

    # "Steve's breathing quickened. His gaze darted to the door, then back, as if weighing escape."
    "Steveの呼吸が速くなった。視線がドアへ走り、また戻った。逃げ道を量るように。"

# game/script/ch03.rpy:165
translate japanese ch03_44d4dc3f:

    # stv "We... we started talking. After class. She said I was smart, different."
    stv "僕たち……話すようになって。授業のあとに。僕は頭がいい、ほかと違うって、先生が。"

# game/script/ch03.rpy:166
translate japanese ch03_2a385141:

    # s "When?"
    s "いつだ？"

# game/script/ch03.rpy:167
translate japanese ch03_66d67942:

    # "The boy's hands went to his hair, fingers pulling."
    "少年の両手が髪にいき、指が引っ張った。"

# game/script/ch03.rpy:168
translate japanese ch03_5647d59a:

    # stv "Few months ago. Three... maybe a little more."
    stv "何か月か前。三か月……もう少し前かも。"

# game/script/ch03.rpy:169
translate japanese ch03_08bde8cb:

    # stv "She said no one could ever know. Not my mom, not anyone. Just us."
    stv "誰にも絶対知られちゃいけないって。母さんにも、誰にも。僕たちだけだって。"

# game/script/ch03.rpy:170
translate japanese ch03_be9cdb18:

    # stv "She told me she needed me. That I wasn't like the others. She promised it was real."
    stv "僕が必要だって言ってた。僕はほかの奴らとは違うって。本物だって、約束してくれた。"

# game/script/ch03.rpy:171
translate japanese ch03_f9b0ba57:

    # "Samuel exhaled smoke slowly through his nose."
    "Samuelは鼻からゆっくりと煙を吐いた。"

# game/script/ch03.rpy:172
translate japanese ch03_3c527df6:

    # s "Evenings. At school?"
    s "夕方か。学校で？"

# game/script/ch03.rpy:173
translate japanese ch03_49ddcc3e:

    # stv "Yeah. Sometimes. Sometimes her place too."
    stv "うん。ときどき。ときどきは先生の家でも。"

# game/script/ch03.rpy:175
translate japanese ch03_50f55b03:

    # note_voice "Affair. Began three months ago. Evening meetings. School + her home."
    note_voice "関係あり。三か月前から。夕方に密会。学校＋彼女の自宅。"

# game/script/ch03.rpy:177
translate japanese ch03_fd26ac93:

    # stv "I didn't do anything to her! I swear — I didn't make her—"
    stv "僕は先生に何もしてない！誓うよ――僕がさせたんじゃ――"

# game/script/ch03.rpy:178
translate japanese ch03_3bbb828b:

    # "Samuel closed the notebook with a snap."
    "Samuelは手帳をぱちんと閉じた。"

# game/script/ch03.rpy:179
translate japanese ch03_89037015:

    # s "That's not what I asked."
    s "そんなことは聞いていない。"

# game/script/ch03.rpy:180
translate japanese ch03_b8b060d3:

    # "The boy flinched, burying his face in his hands. His voice rose, thin and frantic."
    "少年はびくりとして、両手に顔を埋めた。声が上ずった。細く、取り乱して。"

# game/script/ch03.rpy:181
translate japanese ch03_ee49036b:

    # stv cry "Please don't tell anyone. Don't tell my mom. Maria told you? Why would she — why would she say something? It's not my fault!"
    stv cry "お願い、誰にも言わないで。母さんに言わないで。Mariaが話したの？なんで――なんであの人がそんなこと言うんだよ？僕のせいじゃない！"

# game/script/ch03.rpy:182
translate japanese ch03_744fbbb7:

    # "Samuel's hand lifted, cutting through the spiral."
    "Samuelの手が上がり、渦を断ち切った。"

# game/script/ch03.rpy:183
translate japanese ch03_3c821ab8:

    # s "Nobody needs to know. Not yet."
    s "誰も知る必要はない。今はまだ。"

# game/script/ch03.rpy:184
translate japanese ch03_b29e493f:

    # s "And no, Steve — Maria didn't tell me. She couldn't. She's dead."
    s "それと、違う、Steve――Mariaは私に話していない。話せなかった。彼女は死んだ。"

# game/script/ch03.rpy:187
translate japanese ch03_6c0df984:

    # "The boy's face collapsed. His mouth opened, closed. His chest heaved. His hands clawed at his hair, as though he could wake himself from it."
    "少年の顔が崩れた。口が開き、閉じた。胸が大きく上下した。両手が髪をかきむしった。そうすれば悪い夢から覚められるとでもいうように。"

# game/script/ch03.rpy:188
translate japanese ch03_10053446:

    # "Samuel leaned forward, voice steady, anchoring him."
    "Samuelは身を乗り出した。揺るがない声で、少年を繋ぎとめた。"

# game/script/ch03.rpy:189
translate japanese ch03_e60be83e:

    # s "Listen to me. Stay here. Stay with what's real. You understand?"
    s "いいか、聞くんだ。ここにいろ。現実から離れるな。わかるな？"

# game/script/ch03.rpy:190
translate japanese ch03_4a3493ad:

    # s "She's gone. Now I need to know — did anyone else know about the two of you?"
    s "彼女はもういない。だから知る必要がある――君たち二人のことを、ほかに誰か知っていたか？"

# game/script/ch03.rpy:191
translate japanese ch03_254a4338:

    # "Steve's eyes went to the floor. He said nothing."
    "Steveの目が床に落ちた。何も言わなかった。"

# game/script/ch03.rpy:196
translate japanese ch03_88587abb:

    # "Not the look of a boy hunting for a way out. He was listening for the kitchen. Afraid of who might hear."
    "逃げ道を探す少年の目つきではない。彼はキッチンの気配に耳を澄ませていた。誰かに聞かれるのを恐れていた。"

# game/script/ch03.rpy:201
translate japanese ch03_8a631dc7:

    # s "Answer me, Steve. Did anyone else know?"
    s "答えるんだ、Steve。ほかに誰か知っていたか？"

# game/script/ch03.rpy:202
translate japanese ch03_5f3b4db1:

    # "The silence stretched. Samuel's pen tapped the notebook, once, twice."
    "沈黙が伸びた。Samuelのペンが手帳を叩いた。一度、二度。"

# game/script/ch03.rpy:203
translate japanese ch03_3969904a:

    # "Then the doorknob turned."
    "そのとき、ドアノブが回った。"

# game/script/ch03.rpy:206
translate japanese ch03_29d604ae:

    # "Magda stepped in on a perfume of fruit and powder. Her eyes didn't seem to register the weight of the air in the room."
    "Magdaが果物と白粉の香りをまとって入ってきた。部屋の空気の重さには、まるで気づいていないようだった。"

# game/script/ch03.rpy:207
translate japanese ch03_fb05f9a5:

    # mg "Oh, my boy. You're devastated. It's alright — we'll find another teacher to help you."
    mg "まあ、坊や。打ちのめされてるのね。大丈夫よ――勉強を見てくれる先生は、また別に見つけてあげるから。"

# game/script/ch03.rpy:208
translate japanese ch03_4d503a67:

    # "She knelt to hug him, smoothing his hair as if nothing in the world had changed."
    "彼女は膝をついて彼を抱きしめ、髪を撫でた。世界の何ひとつ変わっていないかのように。"

# game/script/ch03.rpy:209
translate japanese ch03_4275bcbb:

    # "Samuel rolled his eyes, sharp and visible."
    "Samuelは、はっきりとわかるように目を回してみせた。"

# game/script/ch03.rpy:210
translate japanese ch03_c2c15caf:

    # "Over his mother's shoulder, Steve's wide eyes stayed locked on him."
    "母親の肩越しに、Steveの見開いた目は彼に釘づけのままだった。"

# game/script/ch03.rpy:211
translate japanese ch03_e7b5fdc8:

    # th "No."
    th "違う。"

# game/script/ch03.rpy:212
translate japanese ch03_03749483:

    # "Samuel drew a card from his coat and placed it quietly on the boy's desk as he rose."
    "立ち上がりながら、Samuelはコートから名刺を取り出し、そっと少年の机に置いた。"

# game/script/ch03.rpy:213
translate japanese ch03_abd952aa:

    # s "You've got my number now. If you remember anything — anything at all — you call me. Doesn't matter when."
    s "これで私の番号はわかったね。何か思い出したら――何でもいい――電話しなさい。いつでも構わない。"

# game/script/ch03.rpy:214
translate japanese ch03_e413ac14:

    # "Steve gave the faintest nod, lips pressed tight. His mother was still murmuring empty comforts. She hadn't even noticed."
    "Steveはごくかすかにうなずいた。唇はきつく結ばれていた。母親はまだ空っぽの慰めをつぶやいていた。気づいてさえいなかった。"

# game/script/ch03.rpy:224
translate japanese ch03_3a6c162c:

    # "The door clicked shut behind him. Perfume and stale air gave way to the bite of cold. He lit a cigarette and let the smoke steady him."
    "背後でドアがかちりと閉まった。香水と淀んだ空気が、噛みつくような冷気に取って代わられた。煙草に火をつけ、煙で自分を落ち着かせた。"

# game/script/ch03.rpy:225
translate japanese ch03_9c4bf8d7:

    # "He walked without direction. Dots. Faint, scattered, refusing to join."
    "あてもなく歩いた。点。かすかで、散らばっていて、繋がろうとしない。"

# game/script/ch03.rpy:226
translate japanese ch03_35741b9f:

    # "Maria Mallory had died by her own hand. A T-shirt, leggings, no socks. Not an accident. A final breakfast, neat and deliberate. A silent farewell."
    "Maria Malloryは自らの手で死んだ。Tシャツ、レギンス、靴下なし。事故ではない。最後の朝食、整えられ、計算されていた。無言の別れ。"

# game/script/ch03.rpy:227
translate japanese ch03_3348c934:

    # "But then the cracks. She had been sleeping with a boy — sixteen, trembling in his bedroom like a child caught stealing."
    "だが、そこに亀裂がある。彼女は少年と寝ていた――十六歳、盗みを見つかった子どものように自室で震えていた少年と。"

# game/script/ch03.rpy:228
translate japanese ch03_9a6330df:

    # "Too raw to be false. Too fragile to have planned something darker. Steve was weak, cowardly even. But blackmail required a coldness, a control the boy did not possess."
    "偽りにしては生々しすぎる。もっと暗い何かを企てるには脆すぎる。Steveは弱く、臆病でさえあった。だが恐喝には冷たさが、自制が要る。あの少年にはないものだ。"

# game/script/ch03.rpy:229
translate japanese ch03_6253dc39:

    # th "And was he honest, that no one else knew? Secrets have weight. They press outward. Someone always catches the scent."
    th "それに、ほかに誰も知らなかったというのは本当か？秘密には重さがある。外へ外へと押し出す。誰かが必ず匂いを嗅ぎつける。"

# game/script/ch03.rpy:230
translate japanese ch03_ca617d76:

    # th "Blackmail. That fits."
    th "恐喝。それなら筋が通る。"

# game/script/ch03.rpy:231
translate japanese ch03_854f6134:

    # "A teacher exposed with a student. In a town like Greyvale, that wasn't a scandal — it was a permanent stain. Her children marked forever."
    "生徒との関係が暴かれた教師。Greyvaleのような町では、それはスキャンダルでは済まない――消えない染みだ。子どもたちは一生、烙印を押される。"

# game/script/ch03.rpy:232
translate japanese ch03_4aee75bd:

    # "Enough to make her climb a roof. Enough to make her jump."
    "屋上に登らせるには十分だ。飛び降りさせるには十分だ。"

# game/script/ch03.rpy:233
translate japanese ch03_c7a0d395:

    # th "Speculation. Words chasing smoke. I need something concrete."
    th "憶測だ。煙を追いかける言葉。何か確かなものが要る。"

# game/script/ch03.rpy:239
translate japanese ch03_a8be120b:

    # "The hours bled together. Address to address, name after name. First the boys, then the girls."
    "時間は滲んで溶け合った。住所から住所へ、名前から名前へ。まず男子、それから女子。"

# game/script/ch03.rpy:240
translate japanese ch03_4b355b85:

    # "Parents hovering close. Children speaking in low, uncertain voices. All said the same things."
    "すぐそばを離れない親たち。低く、自信なげな声で話す子どもたち。誰もが同じことを言った。"

# game/script/ch03.rpy:241
translate japanese ch03_10f3226f:

    # woman "She helped him with his lessons, yes. She was kind. Strict in her way, but never unfair."
    woman "ええ、あの子の勉強を見てくださって。優しい方でした。あの人なりに厳しかったけど、理不尽なことは一度もなかった。"

# game/script/ch03.rpy:242
translate japanese ch03_e66460b6:

    # "No resentment. No whispered secrets. Nothing useful."
    "恨みはない。ひそひそ話の秘密もない。役に立つものは何もない。"

# game/script/ch03.rpy:243
translate japanese ch03_e9b126e3:

    # "By late afternoon he had run the circuit. His notebook was fuller, but not sharper."
    "夕方近くには、一巡し終えていた。手帳は厚くなったが、鋭くはなっていなかった。"

# game/script/ch03.rpy:244
translate japanese ch03_3133a34a:

    # "At the corner mini market: a bag of chips, a packet of crackers, a soda bottle. Junk, but enough to fill the space where a meal should be."
    "角のミニマーケットで、ポテトチップスをひと袋、クラッカーをひと箱、ソーダを一本。ジャンクだが、食事があるべき空白を埋めるには足りる。"

# game/script/ch03.rpy:250
translate japanese ch03_c688a76f:

    # "Night had set in by the time he returned. The clerk was lost in a paperback. In the sitting room the big fireplace roared, armchairs empty around it, shadows stretching long."
    "戻った頃には夜になっていた。フロント係はペーパーバックに没頭していた。談話室では大きな暖炉が燃え盛り、周りの肘掛け椅子は空っぽで、影が長く伸びていた。"

# game/script/ch03.rpy:251
translate japanese ch03_20298a93:

    # "Samuel didn't linger."
    "Samuelは長居しなかった。"

# game/script/ch03.rpy:254
translate japanese ch03_cf858427:

    # "The silence was deeper upstairs, broken only by the hum of the radiator."
    "上の階の静けさはさらに深く、ラジエーターの唸りだけがそれを破っていた。"

# game/script/ch03.rpy:255
translate japanese ch03_e6213f72:

    # "Chips first — cheap, oily, loud in the teeth. Then crackers, dry but steady. Soda straight from the bottle, the fizz sharp against his throat."
    "まずチップス――安っぽく、油っぽく、歯の間でうるさい。それからクラッカー、乾いているが腹にたまる。ソーダは瓶から直接。炭酸が喉に鋭く刺さった。"

# game/script/ch03.rpy:256
translate japanese ch03_f8bad980:

    # "Between bites he turned the pages, cross-checking his observations against the meager results of the day."
    "食べる合間にページをめくり、自分の観察をその日の乏しい成果と照らし合わせた。"

# game/script/ch03.rpy:257
translate japanese ch03_dc99f559:

    # th "Nothing to move on."
    th "動ける材料がない。"

# game/script/ch03.rpy:258
translate japanese ch03_211f6ab5:

    # "Still he chewed and wrote, his mind running circles while the clock ticked past eight."
    "それでも噛み、書いた。頭は堂々巡りを続け、時計は八時を過ぎた。"

# game/script/ch03.rpy:259
translate japanese ch03_e60a6fda:

    # "At some point the notes blurred, the pen slipped from his hand, and Samuel drifted into sleep sitting upright on the bed."
    "いつしかメモがぼやけ、ペンが手から滑り落ち、Samuelはベッドの上で背を起こしたまま眠りに落ちた。"

# game/script/ch03.rpy:266
translate japanese ch03_3849200c:

    # "The faint wash of dawn crept past the curtains, pale and cold. He stirred, groaned, straightened his stiff back."
    "夜明けのかすかな光が、青白く冷たくカーテンの隙間から忍び込んだ。彼は身じろぎし、うめき、こわばった背中を伸ばした。"

# game/script/ch03.rpy:267
translate japanese ch03_bb01f032:

    # "The notebook still lay open on the blanket. A hot shower burned the chill from his bones, though the heaviness in his head lingered."
    "手帳はまだ毛布の上に開いたままだった。熱いシャワーが骨から冷えを焼き払ったが、頭の重さは残った。"

# game/script/ch03.rpy:271
translate japanese ch03_4463ef83:

    # "Downstairs, the dining room was already open. The fireplace still smoldered from the night before."
    "階下では、食堂がもう開いていた。暖炉は昨夜からまだくすぶっていた。"

# game/script/ch03.rpy:272
translate japanese ch03_c240edb0:

    # "He filled a plate, poured a coffee, and took a seat with his back to the wall, notebook and phone set neatly beside his tray."
    "皿に料理を取り、コーヒーを注ぎ、壁を背にして席に着いた。手帳と携帯はトレーの脇にきちんと置いた。"

# game/script/ch03.rpy:273
translate japanese ch03_13d04163:

    # "The coffee was thin and bitter. He pushed it aside after a sip. But the chicken pie surprised him — golden crust, rich with herbs and soft meat."
    "コーヒーは薄く苦かった。ひと口すすって脇へ押しやった。だがチキンパイには驚かされた――黄金色の生地、ハーブがたっぷり効いて、肉は柔らかい。"

# game/script/ch03.rpy:274
translate japanese ch03_b54d80af:

    # "His eyes wandered, as they always did."
    "彼の目はさまよった。いつものように。"

# game/script/ch03.rpy:275
translate japanese ch03_35ac976b:

    # "An elderly couple, neat, deliberate, sharing toast and jam in low voices as though the world outside didn't matter."
    "年配の夫婦。身なりが整い、所作が丁寧で、外の世界などどうでもいいかのように、低い声でトーストとジャムを分け合っている。"

# game/script/ch03.rpy:276
translate japanese ch03_7f833ca5:

    # "A young mother corralling two boys in sweaters. One tugged her sleeve for another croissant. The other stared dreamily at the fire."
    "セーターを着た二人の男の子をまとめようとしている若い母親。一人は母親の袖を引いてクロワッサンをもうひとつねだっている。もう一人はぼんやりと火を見つめていた。"

# game/script/ch03.rpy:277
translate japanese ch03_21c840e9:

    # "At the far end, a man in a dark coat sat alone over a newspaper. His eyes never left the page, though he hadn't turned it once."
    "いちばん奥では、暗い色のコートの男がひとり、新聞に向かって座っていた。目は紙面から一度も離れない。だが一度もページをめくっていなかった。"

# game/script/ch03.rpy:278
translate japanese ch03_5192ec61:

    # th "Small-town lives. Ordinary routines. And in the middle of all this quiet, a teacher climbed a roof and ended her life."
    th "小さな町の暮らし。ありふれた日常。そしてこの静けさの真ん中で、一人の教師が屋上に登り、自分の命を絶った。"

# game/script/ch03.rpy:279
translate japanese ch03_2eed5c9e:

    # "He finished the last bite of pie and wiped his hands. Something nagged at him."
    "彼はパイの最後のひと口を食べ終え、手を拭いた。何かが引っかかっていた。"

# game/script/ch03.rpy:280
translate japanese ch03_2eede265:

    # "The roof. He hadn't gone up himself. And as far as he remembered, neither had the local uniforms. Too focused on the crowd, the fall, the mess below."
    "屋上だ。彼は自分では上がっていなかった。覚えている限り、地元の制服組もだ。群衆と、落下と、下の惨状に気を取られすぎていた。"

# game/script/ch03.rpy:281
translate japanese ch03_1651114d:

    # th "If she left anything — a note, a sign — it won't be at her home. It'll be at the place she ended it."
    th "彼女が何か残したとしたら――遺書でも、しるしでも――家にはない。終わらせた場所にある。"

# game/script/ch03.rpy:286
translate japanese ch03_f5038930:

    # "Business first. Keep the city off his back while he still had a thread to pull."
    "まずは仕事だ。手繰る糸があるうちに、本部に背中をつつかれないようにしておく。"

# game/script/ch03.rpy:299
translate japanese ch03_mercer_first_55aefec0:

    # "Halfway to the gates, he remembered the captain and dialed with his thumb."
    "校門まで半分ほど来たところで、警部のことを思い出し、親指で番号を押した。"

# game/script/ch03.rpy:306
translate japanese ch03_doyle_dawn_ef44911a:

    # d "Sam. Didn't expect to hear from you before the sun."
    d "Sam。日が昇る前にお前から電話が来るとはな。"

# game/script/ch03.rpy:307
translate japanese ch03_doyle_dawn_ff66b545:

    # s "I wanted to update you. Interviewed the family, checked the tutoring students. Nothing concrete. I'll give it a few more hours, then wrap it up."
    s "報告しておこうと思ってな。家族に話を聞いて、補習の生徒たちも当たった。確かなものは何もない。あと数時間当たって、それで締める。"

# game/script/ch03.rpy:308
translate japanese ch03_doyle_dawn_904f95b1:

    # "A low chuckle on the line."
    "電話口で低い笑い声。"

# game/script/ch03.rpy:309
translate japanese ch03_doyle_dawn_9cdcbfb9:

    # d "Knew you'd have it under control. Greyvale's a quiet place — don't go digging too deep for trouble that isn't there."
    d "お前なら抜かりないと思ってたよ。Greyvaleは静かな町だ――ありもしない面倒を深く掘り返すなよ。"

# game/script/ch03.rpy:310
translate japanese ch03_doyle_dawn_c2997fcb:

    # "Samuel allowed himself the faintest smile."
    "Samuelは、ごくかすかな笑みを自分に許した。"

# game/script/ch03.rpy:311
translate japanese ch03_doyle_dawn_3489a17b:

    # s "Wouldn't dream of it."
    s "夢にも思わないさ。"

# game/script/ch03.rpy:319
translate japanese ch03_mercer_dawn_bd6169e5:

    # "Outside, the air cut colder, the streets just beginning to stir. He lit a cigarette and scrolled to Mercer's number."
    "外の空気はさらに冷たく切りつけ、通りはようやく動き出したところだった。煙草に火をつけ、Mercerの番号を探した。"

# game/script/ch03.rpy:322
translate japanese ch03_mercer_dawn_911f1e42:

    # m "Mercer..."
    m "Mercer……"

# game/script/ch03.rpy:323
translate japanese ch03_mercer_dawn_d47828cd:

    # "Groggy. Heavy with sleep."
    "寝ぼけた声。眠気で重い。"

# game/script/ch03.rpy:324
translate japanese ch03_mercer_dawn_e8cb22c5:

    # s "It's Harris. I need access to the school rooftop. Now."
    s "Harrisだ。学校の屋上に入りたい。今すぐ。"

# game/script/ch03.rpy:325
translate japanese ch03_mercer_dawn_a06f9d14:

    # m "The roof? We didn't... uh, no one went up there yesterday."
    m "屋上ですか？俺たちは……その、昨日は誰も上がってません。"

# game/script/ch03.rpy:326
translate japanese ch03_mercer_dawn_d594bf8d:

    # s "That's why I'm calling you."
    s "だから電話してる。"

# game/script/ch03.rpy:327
translate japanese ch03_mercer_dawn_388e0ec7:

    # "He drew smoke into his lungs and exhaled hard."
    "彼は煙を肺に吸い込み、強く吐いた。"

# game/script/ch03.rpy:328
translate japanese ch03_mercer_dawn_a0f1fa37:

    # s "Meet me at the school gates in twenty. Bring the keys."
    s "二十分後に校門で。鍵を持ってこい。"

# game/script/ch03.rpy:329
translate japanese ch03_mercer_dawn_c14cb80a:

    # m "Understood, Detective. I'll be there."
    m "わかりました、刑事。行きます。"

# game/script/ch03.rpy:331
translate japanese ch03_mercer_dawn_ca83358b:

    # "Snow crunched under his boots, his breath rising in slow plumes."
    "ブーツの下で雪が鳴り、吐く息がゆっくりと白く立ちのぼった。"

# game/script/ch03.rpy:340
translate japanese ch03_rooftop_0a4fc0f9:

    # "It took three full smokes before Mercer showed. Samuel stood at the gate, hands buried in his pockets, eyes narrowed in quiet irritation."
    "Mercerが現れるまでに、煙草をまるまる三本吸った。Samuelは門のところに立っていた。両手をポケットに深く突っ込み、静かな苛立ちに目を細めて。"

# game/script/ch03.rpy:342
translate japanese ch03_rooftop_0740e2b7:

    # "Mercer half-jogged the last stretch, fumbling with his duty belt, nearly tripping on a patch of ice."
    "Mercerは最後の道のりを小走りでやってきた。装備ベルトをいじりながら、凍った地面で危うく転びかけた。"

# game/script/ch03.rpy:343
translate japanese ch03_rooftop_c48a9db6:

    # m "Detective. Sorry — I came as quick as I could."
    m "刑事。すみません――できるだけ急いだんですが。"

# game/script/ch03.rpy:344
translate japanese ch03_rooftop_6f4bd559:

    # "Samuel exhaled the last drag and flicked the butt into the snow."
    "Samuelは最後の一服を吐き出し、吸い殻を雪に弾き飛ばした。"

# game/script/ch03.rpy:345
translate japanese ch03_rooftop_8e2839b2:

    # s "You're here now. Let's go."
    s "来たならいい。行くぞ。"

# game/script/ch03.rpy:350
translate japanese ch03_rooftop_bc90afd3:

    # "The building was still and echoing. Chalk and detergent. Their boots clapped against the linoleum, the holiday silence making every sound sharper."
    "校舎は静まり返り、音がよく響いた。チョークと洗剤。二人のブーツがリノリウムを打ち、休暇中の静けさがあらゆる音を鋭くした。"

# game/script/ch03.rpy:351
translate japanese ch03_rooftop_539b8597:

    # "Up the stairwell, each step creaking, the air colder as they climbed. At the heavy metal door, Mercer fumbled with the lock, hands unsteady from the chill or his nerves."
    "階段を上る。一段ごとにきしみ、上るにつれて空気が冷えていった。重い金属の扉の前で、Mercerは錠に手こずった。寒さのせいか、神経のせいか、手が震えていた。"

# game/script/ch03.rpy:352
translate japanese ch03_rooftop_4d007fde:

    # "Samuel waited, arms crossed, with the patience of a man used to worse delays."
    "Samuelは腕を組んで待った。もっとひどい遅れに慣れた男の忍耐で。"

# game/script/ch03.rpy:353
translate japanese ch03_rooftop_831e486c:

    # "The lock clicked. A wash of cold air swept in, carrying the scent of snow and iron."
    "錠がかちりと鳴った。冷たい空気がどっと流れ込み、雪と鉄の匂いを運んできた。"

# game/script/ch03.rpy:359
translate japanese ch03_rooftop_035b7b08:

    # "They crossed the roof in slow, deliberate arcs. Vent housings. The low parapet. The patches where the snow had thinned."
    "二人はゆっくりと、念入りに弧を描いて屋上を歩いた。換気口の囲い。低い胸壁。雪が薄くなった箇所。"

# game/script/ch03.rpy:360
translate japanese ch03_rooftop_a972bfc4:

    # "Nothing. No footprints but their own, no scrap of paper caught in the wind. No sign of Maria's final moments except the silent void she'd left behind."
    "何もない。自分たちのもの以外に足跡はなく、風に引っかかった紙切れもない。Mariaの最期の瞬間を示すものは、彼女が残していった無言の空白のほかに何もなかった。"

# game/script/ch03.rpy:361
translate japanese ch03_rooftop_222eb0ed:

    # "Samuel exhaled through his nose, half sigh, half growl."
    "Samuelは鼻から息を吐いた。半分はため息、半分はうなり声。"

# game/script/ch03.rpy:362
translate japanese ch03_rooftop_9d91f7a9:

    # s "Well... it was a positive thought to begin with."
    s "まあ……そもそも楽観的な考えだったな。"

# game/script/ch03.rpy:363
translate japanese ch03_rooftop_a7b6030b:

    # s "Perhaps we can check her office while we're here."
    s "せっかく来たんだ、彼女の職員室も見ておくか。"

# game/script/ch03.rpy:365
translate japanese ch03_rooftop_f14370f5:

    # "Mercer nodded quickly, eager to be useful."
    "Mercerは役に立ちたくて、急いでうなずいた。"

# game/script/ch03.rpy:372
translate japanese ch03_rooftop_00506af7:

    # "The teachers' common office smelled of paper and stale coffee. A row of desks, each with a small wooden nameplate. Maria Mallory's sat neatly in the center."
    "共用の職員室は紙と古いコーヒーの匂いがした。並んだ机には、それぞれ小さな木の名札。Maria Malloryの机は、真ん中にきちんと収まっていた。"

# game/script/ch03.rpy:374
translate japanese ch03_rooftop_6c14629a:

    # "Samuel slid into her chair. Assignments stacked, notes folded, homework neatly arranged. The bin under the desk was empty."
    "Samuelは彼女の椅子に滑り込んだ。積まれた課題、折りたたまれたメモ、きちんと揃えられた宿題。机の下のゴミ箱は空だった。"

# game/script/ch03.rpy:375
translate japanese ch03_rooftop_646fd91f:

    # th "Too orderly. Almost sterile."
    th "整いすぎている。無菌に近い。"

# game/script/ch03.rpy:376
translate japanese ch03_rooftop_361a6d92:

    # "He powered on the computer. File history, browsing logs, her school email. Nothing out of place. No flagged messages, no unusual searches."
    "パソコンの電源を入れた。ファイル履歴、閲覧記録、学校のメール。おかしなところは何もない。フラグの付いたメッセージも、妙な検索もない。"

# game/script/ch03.rpy:377
translate japanese ch03_rooftop_e4a84f06:

    # "Then he noticed it. A USB stick, lying on the desk. Plain, unmarked."
    "そのとき、それに気づいた。机の上に置かれたUSBメモリ。無地で、何の印もない。"

# game/script/ch03.rpy:378
translate japanese ch03_rooftop_ade7792b:

    # "He slotted it into the front port. Nothing. Another port. Still nothing. The drive didn't register."
    "前面のポートに挿した。反応なし。別のポート。やはり何もない。ドライブが認識されなかった。"

# game/script/ch03.rpy:380
translate japanese ch03_rooftop_8d216e19:

    # m "Maybe it's broken."
    m "壊れてるのかもしれませんね。"

# game/script/ch03.rpy:381
translate japanese ch03_rooftop_0c6203ae:

    # s "Maybe. Or maybe it isn't school property. Could be blocked by their security system — unregistered devices, possible virus risk."
    s "かもな。あるいは学校の備品じゃないか。セキュリティシステムに弾かれてるのかもしれない――未登録の機器、ウイルスの危険性。"

# game/script/ch03.rpy:382
translate japanese ch03_rooftop_0dcee63f:

    # m "You think so?"
    m "そう思いますか？"

# game/script/ch03.rpy:383
translate japanese ch03_rooftop_74125c89:

    # "Samuel leaned back and fixed him with a dry look. For a few seconds they stared at each other, the silence awkward, drawn out. Then Samuel smirked faintly."
    "Samuelは背をもたせ、乾いた目つきで彼を見据えた。数秒、二人は見つめ合った。気まずい沈黙が引き延ばされた。やがてSamuelはかすかににやりとした。"

# game/script/ch03.rpy:384
translate japanese ch03_rooftop_413b7c2e:

    # s "We've got the same bullshit in central department."
    s "本部にも同じクソみたいなのがあるんだ。"

# game/script/ch03.rpy:385
translate japanese ch03_rooftop_9a08ecca:

    # m relieved "Guess some things don't change."
    m relieved "どこも変わらないってことですね。"

# game/script/ch03.rpy:386
translate japanese ch03_rooftop_c97aaa9c:

    # "Mercer chuckled once, nervous but easing. Samuel turned the device over in his fingers, voice low, half to himself."
    "Mercerは一度笑った。神経質だが、ほぐれてきていた。Samuelは指先で機器を裏返しながら、低い声で、半ばひとりごとのように言った。"

# game/script/ch03.rpy:387
translate japanese ch03_rooftop_b1c3516a:

    # s "If it's not school property... doesn't explain why it was just lying here."
    s "学校の備品じゃないとしても……ここに置きっぱなしだった理由にはならない。"

# game/script/ch03.rpy:388
translate japanese ch03_rooftop_ef639691:

    # s "Everything else on this desk is neat, organized to the point of obsession. And this—"
    s "この机のほかのものは全部きちんとしてる。病的なくらい整理されてる。なのにこれは――"

# game/script/ch03.rpy:389
translate japanese ch03_rooftop_5969911b:

    # "He set the USB down in the exact spot it had been. Dead center."
    "彼はUSBを、元あったまさにその場所に置いた。ど真ん中に。"

# game/script/ch03.rpy:390
translate japanese ch03_rooftop_02b6d904:

    # s "—was left in the middle. Like it was waiting to be found."
    s "――真ん中に置かれていた。見つけられるのを待っていたみたいに。"

# game/script/ch03.rpy:391
translate japanese ch03_rooftop_95892b6f:

    # "Mercer shifted on his feet, hanging on every word."
    "Mercerは足を踏みかえ、一言一句に聞き入っていた。"

# game/script/ch03.rpy:392
translate japanese ch03_rooftop_e21ffef2:

    # s "And as it seems, it wasn't. Maria couldn't have used it. So why was it left here?"
    s "で、どうやら学校の備品じゃなかった。Mariaには使えなかったはずだ。なら、なぜここに置いてあった？"

# game/script/ch03.rpy:393
translate japanese ch03_rooftop_ed7bfd83:

    # m "Do you think it means something?"
    m "何か意味があると思いますか？"

# game/script/ch03.rpy:394
translate japanese ch03_rooftop_0e3f35ed:

    # "A grin tugged at the corner of Samuel's mouth."
    "Samuelの口の端に、笑みが引っかかった。"

# game/script/ch03.rpy:395
translate japanese ch03_rooftop_e09453a0:

    # s "Well, we can't know that. Not yet. What we can do is register it as evidence. Then we'll have your department run the checks."
    s "さあな、それはわからない。まだな。できるのは証拠品として登録することだ。それからそっちの署で調べてもらう。"

# game/script/ch03.rpy:396
translate japanese ch03_rooftop_29362efd:

    # m "Of course."
    m "もちろんです。"

# game/script/ch03.rpy:397
translate japanese ch03_rooftop_d62c6300:

    # "They logged the item and sealed it in a small bag. Nothing in the desk disturbed, everything returned as they'd found it."
    "二人は品目を記録し、小さな袋に封をした。机の中は何も乱さず、すべて見つけたときのままに戻した。"

# game/script/ch03.rpy:398
translate japanese ch03_rooftop_f1882e2e:

    # s "Alright. That's all we can do here."
    s "よし。ここでできるのはこれで全部だ。"

# game/script/ch03.rpy:404
translate japanese ch03_rooftop_eb6a31c3:

    # "The station sat on a side street, weathered stone and concrete. Civil offices on the first floor, the officers on the second, a narrow jail on the third for drunks and petty thieves."
    "署は脇道にあった。風雨にさらされた石とコンクリート。一階に一般の窓口、二階に警官たち、三階には酔っ払いやこそ泥用の狭い留置場。"

# game/script/ch03.rpy:405
translate japanese ch03_rooftop_bd591eac:

    # "Walls once white, now dulled to gray and bluish-dark. Corners peeled. The air smelled of dust and stale coffee."
    "かつて白かった壁は、灰色と青黒い色にくすんでいた。角は剥がれていた。空気は埃と古いコーヒーの匂いがした。"

# game/script/ch03.rpy:406
translate japanese ch03_rooftop_7c3b172e:

    # "A cramped office on the second floor. An old desktop humming on a metal desk, its tower scarred with years of fingerprints."
    "二階の狭苦しい部屋。金属の机の上で古いデスクトップが唸っている。本体には長年の指紋の跡が刻まれていた。"

# game/script/ch03.rpy:408
translate japanese ch03_rooftop_d4e475a9:

    # "Samuel placed the USB carefully on the surface."
    "SamuelはUSBを慎重に机に置いた。"

# game/script/ch03.rpy:409
translate japanese ch03_rooftop_4c5dc83a:

    # s "Let's see what we've got."
    s "さて、何が出てくるか。"

# game/script/ch03.rpy:410
translate japanese ch03_rooftop_b1d564ac:

    # "Mercer slid it into the port. For a moment, nothing. Then the system chimed, and the drive appeared."
    "Mercerがポートに差し込んだ。一瞬、何も起きない。それからシステムが鳴り、ドライブが表示された。"

# game/script/ch03.rpy:411
translate japanese ch03_rooftop_823edbab:

    # "One file. {i}doc1.pdf{/i}"
    "ファイルがひとつ。{i}doc1.pdf{/i}"

# game/script/ch03.rpy:412
translate japanese ch03_rooftop_ce44d0bf:

    # "Samuel's jaw tightened. Mercer opened it. A single page of text."
    "Samuelの顎がこわばった。Mercerがそれを開いた。一ページだけの文章。"

# game/script/ch03.rpy:418
translate japanese ch03_rooftop_09214698:

    # "{i}You are a lying whore of a woman.{/i}"
    "{i}お前は嘘つきの売女だ。{/i}"

# game/script/ch03.rpy:419
translate japanese ch03_rooftop_f49fbd4e:

    # "{i}Do as you've been told or everyone will know.{/i}"
    "{i}言われたとおりにしろ。さもないと皆に知られる。{/i}"

# game/script/ch03.rpy:420
translate japanese ch03_rooftop_3d5cdd6d:

    # "{i}Don't make me send the photograph to everyone.{/i}"
    "{i}写真を皆に送らせるな。{/i}"

# game/script/ch03.rpy:427
translate japanese ch03_rooftop_ddecc28a:

    # m shaken "Christ..."
    m shaken "なんてことだ……"

# game/script/ch03.rpy:428
translate japanese ch03_rooftop_22df7e4d:

    # "Samuel's eyes lingered on the words, cold and even. Proof."
    "Samuelの目は、冷たく平らに、その文字に留まった。証拠だ。"

# game/script/ch03.rpy:429
translate japanese ch03_rooftop_607a3f8c:

    # s "Looks like blackmail."
    s "恐喝らしいな。"

# game/script/ch03.rpy:430
translate japanese ch03_rooftop_d7313e13:

    # "No triumph in it. Only confirmation of what he'd already known."
    "勝ち誇る気持ちはなかった。すでにわかっていたことの確認にすぎなかった。"

# game/script/ch03.rpy:431
translate japanese ch03_rooftop_bc021392:

    # "They wasted no time. Mercer called in the department's IT technician: balding, wire-rim glasses, a coffee stain on his shirt. Within an hour, he turned to them."
    "二人はすぐに動いた。Mercerが署のIT技術者を呼んだ。禿げかけた頭、ワイヤーフレームの眼鏡、シャツにはコーヒーの染み。一時間もしないうちに、彼は二人の方を振り向いた。"

# game/script/ch03.rpy:432
translate japanese ch03_rooftop_e390e3ad:

    # tech "School computer. Timestamp matches thirteen days before she died."
    tech "学校のコンピューターです。タイムスタンプは彼女が死ぬ十三日前と一致します。"

# game/script/ch03.rpy:433
translate japanese ch03_rooftop_cedd6e19:

    # s "Which user?"
    s "どのユーザーだ？"

# game/script/ch03.rpy:434
translate japanese ch03_rooftop_1da34947:

    # tech "That's the problem. There's no user list. The library terminals at the school are open — no logins, no IDs. Anyone can sit down, type, print."
    tech "そこが問題なんです。ユーザー一覧がない。学校の図書室の端末は開放されてて――ログインもIDもなし。誰でも座って、打って、印刷できる。"

# game/script/ch03.rpy:435
translate japanese ch03_rooftop_9aecf359:

    # tech "Security doesn't restrict external devices either. Kids bring in USB sticks for posters, essays, whatever."
    tech "セキュリティも外部機器を制限してません。子どもたちはポスターだの作文だの、何でもUSBを持ち込むんで。"

# game/script/ch03.rpy:436
translate japanese ch03_rooftop_5ead44ac:

    # s "So it's untraceable."
    s "つまり、追跡できないと。"

# game/script/ch03.rpy:437
translate japanese ch03_rooftop_1c98924e:

    # tech "Short of someone leaving fingerprints on the keyboard — yes."
    tech "誰かがキーボードに指紋でも残してない限りは――ええ。"

# game/script/ch03.rpy:438
translate japanese ch03_rooftop_e90b3d89:

    # "Proof of blackmail, yes. A culprit? Still smoke in the air."
    "恐喝の証拠は、ある。犯人は？まだ宙に漂う煙だ。"

# game/script/ch03.rpy:440
translate japanese ch03_rooftop_3a9162b9:

    # note_voice "Maria was pushed."
    note_voice "Mariaは追い込まれた。"

# game/script/ch03.rpy:445
translate japanese ch03_rooftop_6f4c8449:

    # "Samuel stepped into the corridor, colder and stiller than before, and leaned against the wall by a cracked window."
    "Samuelは廊下に出た。さっきより冷たく、静かだった。ひびの入った窓のそばの壁にもたれた。"

# game/script/ch03.rpy:448
translate japanese ch03_rooftop_9c4a50ea:

    # d "Sam. Thought you'd be ready to head back by now. You find yourself a souvenir in Greyvale?"
    d "Sam。そろそろ戻る支度ができた頃かと思ったぞ。Greyvaleで土産でも見つけたか？"

# game/script/ch03.rpy:449
translate japanese ch03_rooftop_698e0e1a:

    # "A short laugh, rough and humorless."
    "短い笑い。ざらついて、可笑しさのかけらもない。"

# game/script/ch03.rpy:450
translate japanese ch03_rooftop_227970ec:

    # s "Something like that. Listen, Ray — we've got more here than a simple suicide."
    s "そんなところだ。聞いてくれ、Ray――ここにあるのはただの自殺じゃない。"

# game/script/ch03.rpy:451
translate japanese ch03_rooftop_ca210f38:

    # d "Go on."
    d "続けろ。"

# game/script/ch03.rpy:452
translate japanese ch03_rooftop_f9c3e2e4:

    # s "She didn't jump because of despair. She was pushed — blackmailed."
    s "彼女は絶望して飛び降りたんじゃない。追い込まれたんだ――恐喝で。"

# game/script/ch03.rpy:453
translate japanese ch03_rooftop_e0c46da8:

    # "He lit a cigarette, smoke curling past the windowpane."
    "煙草に火をつけた。煙が窓ガラスをかすめて渦を巻いた。"

# game/script/ch03.rpy:454
translate japanese ch03_rooftop_e78b7ab0:

    # s "We found a USB on her desk. File on it reads: 'You are a lying whore of a woman. Do as you've been told or everyone will know. Don't make me send the photograph to everyone.'"
    s "机の上でUSBを見つけた。中のファイルにはこうある。「お前は嘘つきの売女だ。言われたとおりにしろ。さもないと皆に知られる。写真を皆に送らせるな」"

# game/script/ch03.rpy:455
translate japanese ch03_rooftop_ffd19725:

    # d "Christ."
    d "なんてこった。"

# game/script/ch03.rpy:456
translate japanese ch03_rooftop_0a764efc:

    # s "Our IT confirmed it was created on one of the school's public terminals. No user IDs, no tracking. Could've been anyone — students, staff, a stranger."
    s "こっちのIT担当が、学校の公共端末のどれかで作られたと確認した。ユーザーIDなし、追跡なし。誰でもあり得る――生徒、職員、よそ者。"

# game/script/ch03.rpy:457
translate japanese ch03_rooftop_96b0acfe:

    # d "So it's real. Not gossip. Someone had her by the throat."
    d "じゃあ本物か。噂じゃない。誰かが彼女の喉首を押さえてたってわけだ。"

# game/script/ch03.rpy:458
translate japanese ch03_rooftop_0be06163:

    # s "Exactly. And if she believed the photograph existed, she'd know what it meant for her kids. The shame in a town like this... she never would've recovered."
    s "そういうことだ。写真が存在すると信じていたなら、子どもたちにとってそれが何を意味するか、彼女にはわかっていたはずだ。こういう町での恥……二度と立ち直れなかっただろう。"

# game/script/ch03.rpy:459
translate japanese ch03_rooftop_d70072ec:

    # d "Alright. You've got something solid. Stay on it, Sam. But don't spook the locals. Keep it tight. I'll make sure you've got the department's backing if you need it."
    d "よし。確かなものをつかんだな。そのまま追え、Sam。だが地元の連中を怯えさせるな。固く締めておけ。必要なら本部の後ろ盾はつけてやる。"

# game/script/ch03.rpy:460
translate japanese ch03_rooftop_062a81bf:

    # s "Don't worry. Greyvale's quiet. I'll be quieter."
    s "心配するな。Greyvaleは静かな町だ。俺はもっと静かにやる。"

# game/script/ch03.rpy:461
translate japanese ch03_rooftop_baef3f78:

    # d "Good man. Keep me updated."
    d "それでいい。逐一報告しろ。"

# game/script/ch03.rpy:463
translate japanese ch03_rooftop_d2e2269f:

    # "One last drag. Outside the window, snow lay over the rooftops of the town."
    "最後の一服。窓の外では、雪が町の屋根を覆っていた。"

# game/script/ch03.rpy:467
translate japanese ch03_rooftop_f7e90340:

    # s "Keep your eyes and ears open. Be discreet. Nobody needs to know about the blackmail yet."
    s "目と耳を開けておけ。目立たないように。恐喝のことは、まだ誰も知る必要はない。"

# game/script/ch03.rpy:468
translate japanese ch03_rooftop_3dfb88f5:

    # s "If word gets out, the culprit will hide — or vanish altogether. For now, we keep the initial statement. Anxiety. Suicide. Let it linger."
    s "話が漏れれば、犯人は隠れる――あるいは完全に消える。今は最初の見解のままでいく。不安。自殺。そのまま漂わせておけ。"

# game/script/ch03.rpy:469
translate japanese ch03_rooftop_21c867ce:

    # m "Understood, Detective."
    m "わかりました、刑事。"

# game/script/ch03.rpy:470
translate japanese ch03_rooftop_90bbf0dc:

    # "Samuel was pulling on his coat when the phone on the duty desk began to ring. Shrill, cutting through the stillness."
    "Samuelがコートを羽織っていると、当直デスクの電話が鳴り出した。甲高く、静けさを切り裂いて。"

# game/script/ch03.rpy:472
translate japanese ch03_rooftop_e14b2dc3:

    # m "Greyvale PD."
    m "Greyvale警察です。"

# game/script/ch03.rpy:473
translate japanese ch03_rooftop_43a1a130:

    # "Silence, and a muffled voice on the other end. Mercer's eyebrows drew tight. The color drained from his face."
    "沈黙。それから受話器の向こうのくぐもった声。Mercerの眉が寄った。顔から血の気が引いた。"

# game/script/ch03.rpy:475
translate japanese ch03_rooftop_916031d6:

    # m shaken "Detective..."
    m shaken "刑事……"

# game/script/ch03.rpy:476
translate japanese ch03_rooftop_f9bd836d:

    # extend " We have another body."
    extend "また死体です。"

# game/script/ch03.rpy:478
translate japanese ch03_rooftop_2dc351a2:

    # "The room seemed to grow colder, the hum of the old building pressing close. Samuel's cigarette flared."
    "部屋が冷えていくようだった。古い建物の唸りが身に迫った。Samuelの煙草の火が強まった。"

# game/script/ch03.rpy:479
translate japanese ch03_rooftop_048c73ac:

    # s shocked "Where?"
    s shocked "どこだ？"

# game/script/ch03.rpy:480
translate japanese ch03_rooftop_962a91b1:

    # "Mercer set the receiver back in its cradle."
    "Mercerは受話器を架台に戻した。"

# game/script/ch03.rpy:481
translate japanese ch03_rooftop_fbd621a6:

    # m shaken "Name's Patrick Hensley. Mid-forties. Owned the general store on Birch Street."
    m shaken "Patrick Hensley。四十代半ば。Birch Streetで雑貨店をやってた男です。"

# game/script/ch03.rpy:482
translate japanese ch03_rooftop_66b8527f:

    # "Samuel remembered the storefront from his walk. A faded sign, shuttered for the holiday."
    "Samuelは歩いたときに見たその店構えを思い出した。色褪せた看板、祝日でシャッターが下りていた。"

# game/script/ch03.rpy:483
translate japanese ch03_rooftop_7fa3a652:

    # s "What happened?"
    s "何があった？"

# game/script/ch03.rpy:484
translate japanese ch03_rooftop_f5e0a6dd:

    # m "Collapsed in his shop. Caller says he was alone when it happened. Neighbors found him locked inside."
    m "店で倒れたそうです。通報者によると、そのとき一人だったと。近所の人たちが、鍵のかかった店の中で見つけたそうです。"

# game/script/ch03.rpy:485
translate japanese ch03_rooftop_d74aaa8d:

    # "Samuel flicked his cigarette into the metal ashtray and pulled his coat tight."
    "Samuelは煙草を金属の灰皿に弾き入れ、コートの前をきつく合わせた。"

# game/script/ch03.rpy:486
translate japanese ch03_rooftop_a802d9f8:

    # s "Alright. Let's go."
    s "よし。行くぞ。"

# game/script/ch03.rpy:494
translate japanese ch03_rooftop_9c6e1ad6:

    # "The snow had thinned to a soft dusting, the holiday silence stretched taut over Greyvale."
    "雪は柔らかな粉雪にまで薄くなり、祝日の静けさがGreyvaleの上にぴんと張りつめていた。"

# game/script/ch03.rpy:495
translate japanese ch03_rooftop_bd25bf12:

    # "Mercer drove. The engine coughed, then growled to life. Old buildings rolled past in muted grays and whites."
    "Mercerが運転した。エンジンが咳きこみ、それから唸りを上げて息を吹き返した。古い建物が、くすんだ灰色と白の中を流れていった。"

# game/script/ch03.rpy:496
translate japanese ch03_rooftop_d9f001b4:

    # "Neither man spoke. Another body. Another piece in a pattern Samuel had barely begun to see."
    "どちらも口をきかなかった。また死体。Samuelがようやく見え始めたばかりの模様の、もうひとつのピース。"

# game/script/ch03.rpy:497
translate japanese ch03_rooftop_69e3ed67:

    # "Birch Street. Stone walls, narrow windows, a faded awning sagging under snow. A small knot of bystanders outside, their breath fogging in the cold."
    "Birch Street。石の壁、細い窓、雪の重みでたわんだ色褪せた日よけ。外には野次馬の小さな群れ。吐く息が寒さに白く曇っていた。"

# game/script/ch03.rpy:498
translate japanese ch03_rooftop_4f990044:

    # "Blue lights painted the shopfront in flickers. Samuel rubbed his temple with two fingers."
    "青い光が店の正面をちらちらと染めた。Samuelは二本の指でこめかみをさすった。"

# game/script/ch03.rpy:499
translate japanese ch03_rooftop_4c5dc83a_1:

    # s "Let's see what we've got."
    s "さて、何が出てくるか。"

# game/script/ch03.rpy:506
translate japanese ch03_rooftop_5262c34c:

    # "The bell above the door gave a weak jangle. The air inside was heavy: dust, damp cardboard, and something sour beneath."
    "ドアの上のベルが弱々しく鳴った。中の空気は重かった。埃、湿った段ボール、その下に何か酸っぱいもの。"

# game/script/ch03.rpy:507
translate japanese ch03_rooftop_c7fe074b:

    # "Two tired fluorescents, one buzzing in uneven rhythm. Shelves half-stocked, flour and sugar beside gaps, cans scattered without order. Freezers humming, panes fogged with frost."
    "疲れた蛍光灯が二本、一本は不規則なリズムで唸っている。半分しか埋まっていない棚。小麦粉と砂糖の隣に隙間があり、缶詰が無秩序に散らばっている。冷凍庫が唸り、ガラスは霜で曇っていた。"

# game/script/ch03.rpy:508
translate japanese ch03_rooftop_5f56cbcb:

    # "Paint peeled from the walls. The floor needed more than a mop. It needed years undone."
    "壁のペンキは剥がれていた。床にはモップ以上のものが必要だった。積もった年月を、元に戻すことが。"

# game/script/ch03.rpy:509
translate japanese ch03_rooftop_c069002e:

    # "At the front counter lay Patrick Hensley."
    "正面のカウンターに、Patrick Hensleyが横たわっていた。"

# game/script/ch03.rpy:511
translate japanese ch03_rooftop_198ed97b:

    # "Face down, one arm draped over the edge as though reaching for something in the fall. His head rested in a shallow pool of coffee, streaked darker where his split lip had bled."
    "うつ伏せで、片腕はカウンターの縁から垂れていた。倒れる途中で何かをつかもうとしたかのように。頭は浅いコーヒーの溜まりに沈み、裂けた唇から出た血でところどころ黒ずんでいた。"

# game/script/ch03.rpy:512
translate japanese ch03_rooftop_305aea33:

    # "A broken mug lay shattered on the floor just beyond his hand."
    "割れたマグカップが、彼の手のすぐ先の床で粉々になっていた。"

# game/script/ch03.rpy:513
translate japanese ch03_rooftop_e178fa8b:

    # "Samuel crouched, notebook already in hand."
    "Samuelはしゃがみこんだ。手にはもう手帳があった。"

# game/script/ch03.rpy:517
translate japanese ch03_rooftop_89708cce:

    # "He studied the man methodically. The skin had a strange pallor, drained faster than it should have."
    "彼は男を順序立てて観察した。肌は奇妙に青白く、本来よりも早く血の気が失せていた。"

# game/script/ch03.rpy:518
translate japanese ch03_rooftop_1fb3af68:

    # "Lips tinged bluish-purple, teeth visible through them as if clenched before death. The fingernails carried the same discoloration, like bruises pressing outward."
    "唇は青紫に染まり、その間から歯がのぞいていた。死ぬ前に食いしばったかのように。爪にも同じ変色があった。内側から押し出してくる痣のように。"

# game/script/ch03.rpy:519
translate japanese ch03_rooftop_0c66923b:

    # "One leg bent awkwardly beneath him, the calf stiff, the tendon in the neck corded even in death."
    "片脚は体の下で不自然に曲がり、ふくらはぎはこわばり、首の腱は死んでなお浮き出ていた。"

# game/script/ch03.rpy:520
translate japanese ch03_rooftop_8b65d4f3:

    # "Then the counter. A trace of vomit at its edge, acidic, sharp in scent."
    "それからカウンター。縁に嘔吐物の跡。酸っぱく、鋭い匂い。"

# game/script/ch03.rpy:522
translate japanese ch03_rooftop_8ed30d64:

    # "The counter first. Spilled coffee, dark and cold. Shards of ceramic. A trace of vomit at the edge, acidic, sharp in scent."
    "まずカウンター。こぼれたコーヒー、黒く冷たい。陶器のかけら。縁に嘔吐物の跡。酸っぱく、鋭い匂い。"

# game/script/ch03.rpy:523
translate japanese ch03_rooftop_6e691828:

    # "Only then the man. A strange pallor. Lips tinged bluish-purple, teeth visible as if clenched before death. Fingernails discolored like bruises pressing outward."
    "それからようやく男。奇妙な青白さ。青紫に染まった唇、死ぬ前に食いしばったかのようにのぞく歯。内側から押し出す痣のように変色した爪。"

# game/script/ch03.rpy:524
translate japanese ch03_rooftop_b9e27dbe:

    # "The posture rigid, locked where the body had seized. The tendon in the neck corded with unnatural tension even in death."
    "姿勢は硬直し、体が発作を起こしたその形で固まっていた。首の腱は、死んでなお不自然な緊張で浮き出ていた。"

# game/script/ch03.rpy:526
translate japanese ch03_rooftop_d0d2f0aa:

    # "It looked sudden. Violent. Not the slow collapse of a man with a weak heart."
    "突然に見えた。激しく。心臓の弱い男がゆっくり崩れ落ちたのとは違う。"

# game/script/ch03.rpy:528
translate japanese ch03_rooftop_c36a0efc:

    # note_voice "Face down, counter. Coffee spilled. Mug broken. Rigor tight. Cyanosis lips/fingertips. Vomit trace."
    note_voice "カウンターにうつ伏せ。コーヒーこぼれ。マグ破損。硬直強い。唇・指先にチアノーゼ。嘔吐痕。"

# game/script/ch03.rpy:529
translate japanese ch03_rooftop_061e79e3:

    # "He set the pen against his lip a moment."
    "彼は一瞬、ペンを唇に当てた。"

# game/script/ch03.rpy:530
translate japanese ch03_rooftop_bafc0b15:

    # th "Something ingested. Poison?"
    th "何かを口にした。毒か？"

# game/script/ch03.rpy:531
translate japanese ch03_rooftop_d1815213:

    # "But he didn't write the word. Not yet."
    "だが、その言葉は書かなかった。まだ。"

# game/script/ch03.rpy:533
translate japanese ch03_rooftop_f3fcd100:

    # "Outside, Mercer was calling orders to keep the crowd back, his tone more confident now than at the school."
    "外ではMercerが群衆を下がらせる指示を飛ばしていた。学校のときよりも、口調に自信が出ていた。"

# game/script/ch03.rpy:534
translate japanese ch03_rooftop_43f1bce0:

    # "Among the spilled coffee and shards, a flash of white. Samuel leaned closer, careful not to disturb the liquid."
    "こぼれたコーヒーと破片の中に、白いものがちらりと光った。Samuelは液体を乱さないよう、慎重に顔を寄せた。"

# game/script/ch03.rpy:535
translate japanese ch03_rooftop_3e895e38:

    # "A slip of paper, no bigger than a coin. Torn, not cut. Ragged edges. Not printer stock. Thicker, pulpier, like the page of a book."
    "紙切れ。硬貨ほどの大きさもない。切ったのではなく、破ったもの。ぎざぎざの縁。プリンター用紙ではない。もっと厚く、繊維が粗い。本のページのような。"

# game/script/ch03.rpy:537
translate japanese ch03_rooftop_eb861262:

    # "He lifted it with tweezers and held it to the light."
    "ピンセットでつまみ上げ、光にかざした。"

# game/script/ch03.rpy:541
translate japanese ch03_rooftop_00efa63d:

    # "{size=+12}{b}WEAKNESS{/b}{/size}"
    "{size=+12}{b}弱さ{/b}{/size}"

# game/script/ch03.rpy:542
translate japanese ch03_rooftop_2d8db119:

    # "The single word stood stark against the blank scrap. Deliberate. Placed here, like a signature."
    "その一語が、何もない紙片にくっきりと浮かんでいた。意図的だ。署名のように、ここに置かれたのだ。"

# game/script/ch03.rpy:545
translate japanese ch03_rooftop_b9c3b0a2:

    # note_voice "WEAKNESS — torn, thick pulpy stock."
    note_voice "弱さ――破り取り。厚手、繊維の粗い紙。"

# game/script/ch03.rpy:548
translate japanese ch03_rooftop_50ac46ab:

    # "He sealed it into a clean evidence bag and handed it to Mercer, who had stepped in with the cold trailing after him."
    "彼はそれを清潔な証拠袋に封じ、Mercerに手渡した。Mercerは冷気を引き連れて入ってきたところだった。"

# game/script/ch03.rpy:549
translate japanese ch03_rooftop_598eb09c:

    # s "Log this separately. Exact location — countertop, just right of the mug."
    s "これは別に記録しろ。正確な位置――カウンターの上、マグのすぐ右。"

# game/script/ch03.rpy:550
translate japanese ch03_rooftop_c177d425:

    # s "Bag the fragments too. Every piece. And the liquid — get a sample of what's left in the cup. We'll send it for tox."
    s "かけらも袋に入れろ。ひとつ残らず。それに液体も――カップに残ってるものをサンプルに取れ。毒物検査に回す。"

# game/script/ch03.rpy:551
translate japanese ch03_rooftop_6ed0b7be:

    # s "Don't mop anything, don't dump anything. Even the stains go to lab."
    s "何もモップで拭くな、何も捨てるな。染みひとつまで鑑識に回す。"

# game/script/ch03.rpy:552
translate japanese ch03_rooftop_d25909e4:

    # s "Swab the counter near his face. Both the liquid and that vomit trace. Gloves on, double bags. We'll need tox screens."
    s "顔の近くのカウンターを拭い取れ。液体も、あの嘔吐物の跡も。手袋をはめて、袋は二重に。毒物検査が要る。"

# game/script/ch03.rpy:553
translate japanese ch03_rooftop_2d463fa4:

    # "Mercer worked briskly, gloved hands moving. Samuel looked at the victim again. Bluish lips, stiff posture, hands curled tight."
    "Mercerは手袋をはめた手をきびきびと動かした。Samuelはもう一度被害者を見た。青い唇、硬直した姿勢、固く丸まった手。"

# game/script/ch03.rpy:554
translate japanese ch03_rooftop_53cd32a4:

    # th "Not a weak heart. Something sharper."
    th "心臓の弱さじゃない。もっと鋭い何かだ。"

# game/script/ch03.rpy:555
translate japanese ch03_rooftop_7bd7e938:

    # s "Also — get a list of everyone who came in here yesterday. Deliveries, customers. If there's CCTV, we'll want that too. Even if it's grainy."
    s "それと――昨日ここに来た全員のリストを取れ。配達、客。防犯カメラがあるなら、その映像も要る。画質が粗くても。"

# game/script/ch03.rpy:556
translate japanese ch03_rooftop_791cbab5:

    # "Mercer glanced up at the word in the bag."
    "Mercerは袋の中の言葉をちらりと見上げた。"

# game/script/ch03.rpy:557
translate japanese ch03_rooftop_865ae263:

    # m "You think this means something?"
    m "これ、何か意味があると思いますか？"

# game/script/ch03.rpy:558
translate japanese ch03_rooftop_770f7dbf:

    # s "A man doesn't die facedown in his own shop with a scrap like this by chance. We keep it tight. Register everything. No shortcuts."
    s "男が自分の店でうつ伏せに死んで、こんな紙切れがたまたまそばにある――そんな偶然はない。固く締めていく。全部記録しろ。手抜きはなしだ。"

# game/script/ch03.rpy:559
translate japanese ch03_rooftop_f6bf1b45:

    # "The silence of the shop seemed to weigh heavier now."
    "店の静けさが、いっそう重くのしかかるようだった。"

# game/script/ch03.rpy:562
translate japanese ch03_rooftop_552741ab:

    # s "What do you know about Hensley?"
    s "Hensleyについて何を知ってる？"

# game/script/ch03.rpy:563
translate japanese ch03_rooftop_a642f94a:

    # m "Not much. He wasn't wealthy. Always bitter, telling anyone who'd listen that the town was dying, that life was unfair. Spent more time complaining than working."
    m "大して知りません。金持ちじゃなかった。いつも苦々しくて、聞く耳のある相手なら誰にでも、町は死にかけてる、人生は不公平だって言ってました。働くより文句を言ってる時間のほうが長かった。"

# game/script/ch03.rpy:564
translate japanese ch03_rooftop_eba67584:

    # s "Go on."
    s "続けろ。"

# game/script/ch03.rpy:565
translate japanese ch03_rooftop_59c1d61f:

    # m "He also skimmed. Shelves marked one price, he'd ring it higher. If a customer caught it, he laughed it off as a mistake. If not, he pocketed the difference."
    m "それに、ちょろまかしてました。棚には一つの値段をつけて、レジでは高く打つ。客に気づかれたら、間違いだって笑ってごまかす。気づかれなければ、差額を懐に入れる。"

# game/script/ch03.rpy:566
translate japanese ch03_rooftop_3b1653f1:

    # "Samuel glanced at the evidence bag."
    "Samuelは証拠袋に目をやった。"

# game/script/ch03.rpy:567
translate japanese ch03_rooftop_aac6f9f3:

    # s "Complainer. And a cheat."
    s "不平屋。それにペテン師か。"

# game/script/ch03.rpy:569
translate japanese ch03_rooftop_8376c226:

    # m shaken "That's about right."
    m shaken "まあ、そんなところです。"

# game/script/ch03.rpy:570
translate japanese ch03_rooftop_a5353d90:

    # th "Two deaths. Two judgments."
    th "死が二つ。裁きが二つ。"

# game/script/ch03.rpy:571
translate japanese ch03_rooftop_f836889e:

    # extend " Someone is keeping score."
    extend "誰かが、採点している。"

# game/script/ch03.rpy:573
translate japanese ch03_rooftop_af9e7c5b:

    # note_voice "Two deaths, two judgments. Someone is keeping score."
    note_voice "死二件、裁き二件。誰かが採点している。"

# game/script/ch03.rpy:574
translate japanese ch03_rooftop_d0574723:

    # s "What about his family? Wife, kids?"
    s "家族は？妻や子どもは？"

# game/script/ch03.rpy:575
translate japanese ch03_rooftop_3e5ea9f6:

    # m "No. He was a loner. Lived above the shop, kept to himself."
    m "いません。一匹狼でした。店の上に住んで、人づきあいはしなかった。"

# game/script/ch03.rpy:576
translate japanese ch03_rooftop_298222d5:

    # "Samuel nodded slowly, jotting it down. Alone, bitter, dishonest. Another life judged and ended."
    "Samuelはゆっくりうなずき、書きとめた。孤独で、苦々しく、不正直。またひとつ、裁かれ、終わらされた命。"

# game/script/ch03.rpy:578
translate japanese ch03_rooftop_b3812f7b:

    # "He closed the notebook with a snap."
    "彼は手帳をぱちんと閉じた。"

translate japanese strings:

    # game/script/ch03.rpy:112
    old "Her smile."
    new "彼女の笑み。"

    # game/script/ch03.rpy:114
    old "Her clothes."
    new "彼女の服。"

    # game/script/ch03.rpy:116
    old "Her eyes."
    new "彼女の目。"

    # game/script/ch03.rpy:146
    old "Press him. Hard."
    new "押せ。強く。"

    # game/script/ch03.rpy:152
    old "Give him room."
    new "余地を与えろ。"

    # game/script/ch03.rpy:194
    old "The door."
    new "ドア。"

    # game/script/ch03.rpy:197
    old "The floor."
    new "床。"

    # game/script/ch03.rpy:284
    old "Call Doyle first. Keep the captain calm."
    new "先にDoyleに電話する。警部を落ち着かせておく。"

    # game/script/ch03.rpy:288
    old "Straight to the school. Doyle can wait."
    new "まっすぐ学校へ。Doyleは後回しだ。"

    # game/script/ch03.rpy:516
    old "Look at the body first."
    new "まず死体を見る。"

    # game/script/ch03.rpy:521
    old "Look at the counter first."
    new "まずカウンターを見る。"

