# TODO: Translation updated at 2026-10-11 10:23

# game/script/ch06.rpy:18
translate japanese ch06_551cafb1:

    # "Dr. Markou was the one who ended it, in the end."
    "結局、それを終わらせたのはMarkou医師だった。"

# game/script/ch06.rpy:19
translate japanese ch06_e687d464:

    # "She let the girl finish. Let the last of it settle into the warm room: the fire, the snow at the glass, the two adults leaning toward the small figure in the armchair."
    "彼女は少女に最後まで話させた。最後の言葉が暖かな部屋に沈んでいくのを待った。暖炉の火、窓ガラスに当たる雪、肘掛け椅子の小さな姿へ身を乗り出す二人の大人。"

# game/script/ch06.rpy:20
translate japanese ch06_6d972ed0:

    # "Then she closed the folder on her knee with the quiet finality of a woman drawing a blanket over someone asleep."
    "それから膝の上のフォルダーを閉じた。眠っている誰かに毛布を掛けてやる女の、静かな決着のつけ方だった。"

# game/script/ch06.rpy:21
translate japanese ch06_4cc37bd4:

    # h "That's enough for tonight."
    h "今夜はここまでにしましょう。"

# game/script/ch06.rpy:22
translate japanese ch06_7e2a5f19:

    # h "You've been very brave, Alice. Braver than you should have had to be."
    h "とても勇敢だったわ、Alice。本当なら、そこまで勇敢でいる必要なんてなかったのに。"

# game/script/ch06.rpy:23
translate japanese ch06_8594542b:

    # "Samuel didn't move for a moment. His pen had stopped somewhere in the last minute and he hadn't noticed."
    "Samuelはしばらく動かなかった。ペンはこの一分のどこかで止まっていて、彼はそれに気づいていなかった。"

# game/script/ch06.rpy:24
translate japanese ch06_926a9698:

    # "He looked at the child: the composed face, the folded hands, the tea gone cold and untouched at her elbow."
    "彼は子どもを見た。落ち着いた顔、組まれた手、肘のそばで手をつけられないまま冷めた紅茶。"

# game/script/ch06.rpy:25
translate japanese ch06_15b99fc9:

    # "Then at Helena. Something passed between the two adults that had no words in it, only the shared weight of what they had heard and could not yet use."
    "それからHelenaを見た。二人の大人のあいだを、言葉のない何かが通り過ぎた。聞いてしまったが、まだ使えない。その重さを分け合っただけだった。"

# game/script/ch06.rpy:26
translate japanese ch06_96e8081c:

    # "He closed his notebook."
    "彼は手帳を閉じた。"

# game/script/ch06.rpy:27
translate japanese ch06_a5c4fa9a:

    # s "You did the right thing. Telling us."
    s "正しいことをしたね。話してくれて。"

# game/script/ch06.rpy:28
translate japanese ch06_afa230c8:

    # "Alice nodded, small, her eyes on the fire."
    "Aliceは小さく頷いた。目は火に向けられていた。"

# game/script/ch06.rpy:29
translate japanese ch06_bda8b2ac:

    # "Outside, the storm had not eased. It threw itself against the tall windows in long gray sheets."
    "外の嵐はおさまっていなかった。長い灰色の幕となって、背の高い窓に体ごとぶつかってきた。"

# game/script/ch06.rpy:30
translate japanese ch06_ece67954:

    # "When Samuel stood and looked toward the door, his face changed: the calculation of a man measuring a road."
    "Samuelが立ち上がってドアのほうを見たとき、顔つきが変わった。道のりを測る男の計算だった。"

# game/script/ch06.rpy:31
translate japanese ch06_7e7a6740:

    # h firm "You're not walking her home in this."
    h firm "この中を歩いて帰らせるつもりじゃないでしょうね。"

# game/script/ch06.rpy:32
translate japanese ch06_5a5e2e0e:

    # "It wasn't a question."
    "問いではなかった。"

# game/script/ch06.rpy:33
translate japanese ch06_1bfae857:

    # s "No."
    s "ああ。"

# game/script/ch06.rpy:34
translate japanese ch06_fa177323:

    # "He was already reaching for his coat."
    "彼はもうコートに手を伸ばしていた。"

# game/script/ch06.rpy:35
translate japanese ch06_c5c3371c:

    # s "I'll take her. It's on my way back to the hotel. More or less."
    s "私が送っていく。ホテルへの帰り道だ。だいたいはね。"

# game/script/ch06.rpy:36
translate japanese ch06_b4d7e32d:

    # s "That alright with you, Alice? I'll have you at your door in fifteen minutes. Warmer than the last time you made that walk."
    s "それでいいかな、Alice？十五分で家の前まで送る。この前その道を歩いたときよりは暖かいはずだ。"

# game/script/ch06.rpy:37
translate japanese ch06_43e130ec:

    # "For a moment the girl didn't answer."
    "一瞬、少女は答えなかった。"

# game/script/ch06.rpy:39
translate japanese ch06_e1211503:

    # "Then she lifted her face to him and gave him a small, tired smile."
    "それから顔を上げて彼を見ると、小さな、疲れた笑みを浮かべた。"

# game/script/ch06.rpy:40
translate japanese ch06_c9e6a91e:

    # a "Thank you, Detective. I'd like that."
    a "ありがとうございます、刑事さん。お願いします。"

# game/script/ch06.rpy:41
translate japanese ch06_ffddaa7e:

    # "Helena walked them to the door. At the threshold she crouched and tucked a stray strand of damp hair behind the child's ear."
    "Helenaは二人をドアまで見送った。敷居のところでしゃがみ込み、湿ったほつれ毛を一筋、子どもの耳にかけてやった。"

# game/script/ch06.rpy:42
translate japanese ch06_89e4a3d0:

    # "She murmured something too low for Samuel to catch."
    "彼女は何かをつぶやいた。Samuelには聞き取れないほど低い声だった。"

# game/script/ch06.rpy:43
translate japanese ch06_2ca3d5d0:

    # h sad "{size=-6}You can come to me. Any hour. You understand?{/size}"
    h sad "{size=-6}私のところに来ていいのよ。いつでも。わかった？{/size}"

# game/script/ch06.rpy:44
translate japanese ch06_6856c4c0:

    # a neutral "I understand."
    a neutral "わかりました。"

# game/script/ch06.rpy:45
translate japanese ch06_a57b29a1:

    # "She said it as if she meant it. Or seemed to."
    "本心から言っているようだった。あるいは、そう見えた。"

# game/script/ch06.rpy:47
translate japanese ch06_4c4c737f:

    # "Then the cold took them, and the warm door closed behind."
    "それから寒さが二人をのみ込み、暖かなドアが背後で閉まった。"

# game/script/ch06.rpy:57
translate japanese ch06_20c53a9a:

    # "The road out of town belonged to the storm."
    "町から出ていく道は嵐のものだった。"

# game/script/ch06.rpy:58
translate japanese ch06_6568a53d:

    # "The wipers kept their steady two-count. The heater roared dry heat into the small lit box of the cabin."
    "ワイパーは一定の二拍子を刻みつづけた。ヒーターが唸りを上げ、明かりの灯った小さな箱のような車内に乾いた熱を吹き込んだ。"

# game/script/ch06.rpy:59
translate japanese ch06_4b3feedb:

    # "Beyond the glass the world had gone to two colors: the black of the pines, and the white coming at them out of it, endless, hypnotic, swallowed under the headlights."
    "ガラスの向こうで、世界は二色になっていた。松の黒と、その黒の中から向かってくる白。果てしなく、催眠的に、ヘッドライトの下へのみ込まれていく。"

# game/script/ch06.rpy:60
translate japanese ch06_030bc1ce:

    # "Samuel drove with his hands at ten and two and his mind three hours behind him, in a warm office, turning over the four words that mattered."
    "Samuelは十時と二時の位置でハンドルを握り、心は三時間後ろの暖かな診察室に置いたまま、意味のある四つの言葉を転がしていた。"

# game/script/ch06.rpy:61
translate japanese ch06_c9f18d50:

    # th "Finish his work here."
    th "ここでの仕事を終わらせる。"

# game/script/ch06.rpy:62
translate japanese ch06_bf11e83f:

    # "Beside him the girl sat with her hands folded in her lap and watched the snow."
    "隣で少女は膝の上で手を組み、雪を見ていた。"

# game/script/ch06.rpy:63
translate japanese ch06_cba7113e:

    # "She hadn't reached for the radio. Hadn't fidgeted, hadn't asked how long, hadn't done any of the small restless things a child does to fill a moving car."
    "ラジオに手を伸ばしもしなかった。そわそわもせず、あとどれくらいかとも訊かず、走る車の中を埋めるために子どもがする、落ち着きのない小さなことを何ひとつしなかった。"

# game/script/ch06.rpy:64
translate japanese ch06_8c2d442b:

    # "She filled it instead with a stillness he found himself aware of, the way you become aware of a held breath in a room."
    "代わりに彼女は、それを静けさで満たした。気がつくと彼はその静けさを意識していた。部屋の中で誰かが息を止めているのに気づくように。"

# game/script/ch06.rpy:65
translate japanese ch06_dd46474a:

    # th "Twelve years old. I know grown men who came apart in the back of a patrol car. This one sits like she's waiting for a bus."
    th "十二歳。パトカーの後部座席で崩れていった大の男を何人も知ってる。この子はバスでも待ってるみたいに座ってる。"

# game/script/ch06.rpy:66
translate japanese ch06_5bff7739:

    # th "Don't."
    th "よせ。"

# game/script/ch06.rpy:67
translate japanese ch06_97d5d606:

    # "That was the part of him that had listened to Helena Markou."
    "それは、Helena Markouの話に耳を傾けた彼の一部だった。"

# game/script/ch06.rpy:68
translate japanese ch06_a70fcdc1:

    # th "She's a child. You treat a child as a source, you break something you can't fix, and a lawyer buries whatever you get."
    th "相手は子どもだ。子どもを情報源として扱えば、取り返しのつかない何かを壊す。それに、何を得ようが弁護士に葬られる。"

# game/script/ch06.rpy:69
translate japanese ch06_d953f4d9:

    # "He knew it. He also had three bodies in a town of not three thousand souls."
    "わかっていた。だが同時に、人口三千に満たない町で死体が三つあった。"

# game/script/ch06.rpy:70
translate japanese ch06_6fb8e0c5:

    # "A grandfather with no past on paper, a village behind him that answered the phone in shrugs."
    "書類の上では過去のない祖父。その背後には、電話に肩をすくめるようにしか答えない村。"

# game/script/ch06.rpy:71
translate japanese ch06_e7c51879:

    # "And a girl in his passenger seat who had just used the phrase {i}finish his work{/i} about a man Samuel was quietly, carefully, beginning to build into a shape."
    "そして助手席には、ある男について、たった今{i}仕事を終わらせる{/i}という言い回しを使った少女がいた。Samuelが静かに、慎重に、ひとつの形に組み上げはじめている男について。"

# game/script/ch06.rpy:72
translate japanese ch06_a945e1f2:

    # th "Walk the line. You've walked worse."
    th "線の上を歩け。もっとひどい綱渡りもしてきた。"

# game/script/ch06.rpy:73
translate japanese ch06_fd6fd984:

    # s "You did well back there."
    s "さっきはよく頑張ったね。"

# game/script/ch06.rpy:74
translate japanese ch06_a62a9cfe:

    # "Easy. Eyes on the road."
    "さりげなく。目は道に。"

# game/script/ch06.rpy:75
translate japanese ch06_ea7bfcb1:

    # s "That's a hard thing, saying all that out loud. To me and Dr. Markou both."
    s "大変なことだ。あれを全部、声に出して言うのは。私とMarkou先生の両方に。"

# game/script/ch06.rpy:76
translate japanese ch06_aab2b907:

    # a "She's kind. I trust her."
    a "先生は優しいです。信頼しています。"

# game/script/ch06.rpy:77
translate japanese ch06_80e3065c:

    # s "Good. You should have someone."
    s "よかった。誰かがいるべきだ。"

# game/script/ch06.rpy:78
translate japanese ch06_1d70a0ed:

    # "He let a bend come and go."
    "彼はカーブをひとつやり過ごした。"

# game/script/ch06.rpy:79
translate japanese ch06_f7f92c94:

    # s "This work of your grandfather's. The traveling. He tell you where, this time?"
    s "おじいさんのその仕事のことだが。旅に出るという。今度はどこへ行くか、聞いているかい？"

# game/script/ch06.rpy:80
translate japanese ch06_9a58adc6:

    # a "No."
    a "いいえ。"

# game/script/ch06.rpy:81
translate japanese ch06_da2e2439:

    # a "He never says where. He says it's safer if I don't carry it."
    a "どこへ行くかは絶対に言いません。私が抱えていないほうが安全だって。"

# game/script/ch06.rpy:82
translate japanese ch06_b03c814e:

    # th "Safer if I don't carry it."
    th "抱えていないほうが安全。"

# game/script/ch06.rpy:83
translate japanese ch06_a700b1fb:

    # "Samuel let that one sit, kept his face flat, filed it."
    "Samuelはその言葉を寝かせておき、顔を平らに保ったまま、頭の中に綴じ込んだ。"

# game/script/ch06.rpy:84
translate japanese ch06_5c787446:

    # "It was the kind of sentence a frightened kid parroted from a controlling man."
    "怯えた子どもが、支配的な男の口ぶりをそのまま繰り返す。そういう種類の文だった。"

# game/script/ch06.rpy:85
translate japanese ch06_53b4c763:

    # "It was also the kind of sentence that meant a man moved when he needed to move, and left no one able to say which road he'd taken."
    "同時に、動く必要があるときに動き、どの道を行ったか誰にも言えないようにしていく男の文でもあった。"

# game/script/ch06.rpy:86
translate japanese ch06_0e2821b2:

    # s "When does he go? These trips."
    s "出かけるのはいつだい？その旅には。"

# game/script/ch06.rpy:87
translate japanese ch06_53209ef1:

    # a "At night, mostly. When it's quiet."
    a "たいていは夜です。静かなときに。"

# game/script/ch06.rpy:88
translate japanese ch06_f75d8ff1:

    # "She was still watching the snow."
    "彼女はまだ雪を見ていた。"

# game/script/ch06.rpy:89
translate japanese ch06_fe476acb:

    # a "He leaves after I'm asleep. Sometimes I hear the truck. In the morning he's back and we don't talk about it."
    a "私が寝てから出ていきます。ときどきトラックの音が聞こえます。朝には戻っていて、そのことは話しません。"

# game/script/ch06.rpy:91
translate japanese ch06_072211f7:

    # note_voice "'Safer if I don't carry it.' He leaves at night."
    note_voice "「抱えていないほうが安全」。夜に出かける。"

# game/script/ch06.rpy:92
translate japanese ch06_5314f81a:

    # s "And tonight? He out on one now?"
    s "それで今夜は？今もその旅に出ているのかい？"

# game/script/ch06.rpy:93
translate japanese ch06_fdbf8ede:

    # a "He said he'd be late."
    a "遅くなるって言っていました。"

# game/script/ch06.rpy:94
translate japanese ch06_2fe880de:

    # "Her voice didn't change."
    "声は変わらなかった。"

# game/script/ch06.rpy:95
translate japanese ch06_41f19987:

    # a "He said he had preparations."
    a "準備があるって。"

# game/script/ch06.rpy:96
translate japanese ch06_b49730e5:

    # "The word landed the same way it had in the office, heavy and shapeless at once."
    "その言葉は診察室のときと同じように落ちてきた。重く、同時に形がなかった。"

# game/script/ch06.rpy:97
translate japanese ch06_f77cd03d:

    # "Samuel felt the old pull of it, the detective's greed for a thing that almost means something."
    "Samuelはその古い引力を感じた。もう少しで意味を持ちそうなものに対する、刑事の貪欲さを。"

# game/script/ch06.rpy:98
translate japanese ch06_c1c7470b:

    # th "Preparations. A twelve-year-old wouldn't know what that word could carry."
    th "準備。十二歳の子に、その言葉が何を運びうるかなんてわかるはずがない。"

# game/script/ch06.rpy:99
translate japanese ch06_8fd97f15:

    # "He did. He'd sat across steel tables from men who used it."
    "彼にはわかった。その言葉を使う男たちと、鋼鉄のテーブル越しに向き合ってきたのだ。"

# game/script/ch06.rpy:103
translate japanese ch06_a6d7cc51:

    # s "You've got people here, though. Friends."
    s "でも、ここにも人がいるだろう。友達が。"

# game/script/ch06.rpy:104
translate japanese ch06_a065803d:

    # "He said it before he'd decided to, and kept his eyes on the road."
    "そうしようと決める前に口に出ていた。目は道から離さなかった。"

# game/script/ch06.rpy:105
translate japanese ch06_b355baa4:

    # "Beside him she stayed exactly as still as before. He didn't look."
    "隣で彼女はさっきとまったく同じように静かだった。彼は見なかった。"

# game/script/ch06.rpy:106
translate japanese ch06_a5682d44:

    # th "Leave her be a second. She's had enough eyes on her tonight."
    th "少しそっとしておけ。今夜はもう十分に視線を浴びた。"

# game/script/ch06.rpy:111
translate japanese ch06_5dd23b77:

    # "He glanced at her. Just a flick, road to profile and back."
    "彼は彼女をちらりと見た。ほんの一瞬、道から横顔へ、そしてまた道へ。"

# game/script/ch06.rpy:113
translate japanese ch06_5cf4b39a:

    # "The dashboard light caught the side of her face. Calm. Composed. The lashes lowered."
    "ダッシュボードの明かりが彼女の顔の片側を照らしていた。穏やか。落ち着いている。睫毛は伏せられていた。"

# game/script/ch06.rpy:114
translate japanese ch06_7e389d40:

    # "For a half-second something in him ticked over wrong, some old instinct turning in its sleep."
    "半秒のあいだ、彼の中で何かがずれた音を立てた。古い本能が眠りの中で寝返りを打った。"

# game/script/ch06.rpy:115
translate japanese ch06_2b82abbb:

    # "A sense he had no words for, except that a face that still had no fear in it, after the week this child had lived, was a face that—"
    "言葉にできない感覚だった。ただ、この子が過ごしたあんな一週間のあとで、まだ恐怖のかけらもない顔というのは、つまり――"

# game/script/ch06.rpy:116
translate japanese ch06_0b112390:

    # "Then the thing turned back over and slept."
    "それから、それはまた寝返りを打って眠った。"

# game/script/ch06.rpy:117
translate japanese ch06_717ea53c:

    # th "She's a kid. Kids go blank when the world gets too big."
    th "子どもなんだ。世界が大きくなりすぎると、子どもは空っぽになる。"

# game/script/ch06.rpy:118
translate japanese ch06_bd85c71b:

    # "He'd seen it in the Mallory children, in the girls in the counselor's office. The ones who couldn't cry because the crying place was already full."
    "Mallory家の子どもたちにも、スクールカウンセラーの部屋にいた少女たちにも、それを見た。泣けない子たち。泣く場所が、もういっぱいだったから。"

# game/script/ch06.rpy:119
translate japanese ch06_581cc762:

    # th "She isn't cold. She's emptied."
    th "冷たいんじゃない。空っぽになってるだけだ。"

# game/script/ch06.rpy:120
translate japanese ch06_99ca4236:

    # "God knew he understood emptied."
    "空っぽになるということなら、神も知るとおり、彼にはよくわかっていた。"

# game/script/ch06.rpy:122
translate japanese ch06_42f28ebd:

    # "The car warmed. The snow came on."
    "車内が暖まった。雪は降りつづいた。"

# game/script/ch06.rpy:123
translate japanese ch06_67e02c48:

    # s "You've got people here, though."
    s "でも、ここにも人がいるだろう。"

# game/script/ch06.rpy:124
translate japanese ch06_b7517722:

    # "Gentler now. He wasn't sure anymore if he was working her or just talking. The two had gone blurred, the way they did when he was tired."
    "今度はもっと穏やかに。彼女を探っているのか、ただ話しているだけなのか、もう自分でもよくわからなかった。疲れているときにはいつもそうなるように、二つの境目がぼやけていた。"

# game/script/ch06.rpy:125
translate japanese ch06_8a88c8ef:

    # s "Friends."
    s "友達が。"

# game/script/ch06.rpy:128
translate japanese ch06_car_emily_2844912c:

    # s "That girl at the funeral, holding onto you. Emily."
    s "葬式のとき、君にしがみついていた子。Emilyだ。"

# game/script/ch06.rpy:129
translate japanese ch06_car_emily_0f464123:

    # "For the first time the folded hands moved. A small thing: one thumb passing over the other knuckles, there and gone."
    "初めて、組まれた手が動いた。小さな動きだった。片方の親指がもう一方の指の関節をなぞり、すぐに止まった。"

# game/script/ch06.rpy:130
translate japanese ch06_car_emily_7dbc9179:

    # a sad "Emily."
    a sad "Emily。"

# game/script/ch06.rpy:131
translate japanese ch06_car_emily_fdc8e0b3:

    # "She said it like the name cost something."
    "その名前を口にするのに何かを支払ったような言い方だった。"

# game/script/ch06.rpy:132
translate japanese ch06_car_emily_c65b19c0:

    # a "She's my best friend."
    a "私の、一番の友達です。"

# game/script/ch06.rpy:133
translate japanese ch06_car_emily_4c7002fb:

    # s "She's a good one, from the look of her."
    s "いい子のようだね、見たところ。"

# game/script/ch06.rpy:134
translate japanese ch06_car_emily_36f6ec5c:

    # "He kept it light."
    "彼は軽い調子を保った。"

# game/script/ch06.rpy:135
translate japanese ch06_car_emily_8061a236:

    # s "George alright with that? Her coming round?"
    s "Georgeはそれでいいと言ってるのかい？あの子が家に来ることは。"

# game/script/ch06.rpy:136
translate japanese ch06_car_emily_dd363539:

    # "A silence, longer than the others. The wipers counted through it."
    "沈黙。それまでのどれよりも長かった。ワイパーがその中を数えていった。"

# game/script/ch06.rpy:137
translate japanese ch06_car_emily_6ba4b36d:

    # a "He says she makes me weak."
    a "あの子のせいで私が弱くなるって、言います。"

# game/script/ch06.rpy:138
translate japanese ch06_car_emily_50a06174:

    # "She said it finally, quietly, to the glass."
    "ようやく彼女は、静かに、ガラスに向かってそう言った。"

# game/script/ch06.rpy:139
translate japanese ch06_car_emily_7b0ed64c:

    # a "He doesn't like me having her. He says we won't be able to keep people, where we're going."
    a "私にあの子がいるのが気に入らないんです。これから行くところでは、人とつながっていられないからって。"

# game/script/ch06.rpy:140
translate japanese ch06_car_emily_82f544da:

    # a "I don't want to lose her."
    a "あの子を失いたくない。"

# game/script/ch06.rpy:141
translate japanese ch06_car_emily_2c722f71:

    # th "And there it is."
    th "やっぱりな。"

# game/script/ch06.rpy:142
translate japanese ch06_car_emily_0b283c70:

    # "The whole shape of the man in one child's sentence. A grandfather who broke a girl's ties before he dragged her off into the dark, one town after another."
    "子どものひと言に、男の全体の形があった。少女のつながりを断ち切ってから闇の中へ引きずっていく祖父。町から町へ。"

# game/script/ch06.rpy:143
translate japanese ch06_car_emily_e0307986:

    # "It made him want to put George Bennett in a small room and leave the light on."
    "George Bennettを狭い部屋に放り込んで、明かりをつけっぱなしにしてやりたくなった。"

# game/script/ch06.rpy:145
translate japanese ch06_car_emily_d0a8d583:

    # note_voice "George resents the friendship (per Alice)."
    note_voice "Georgeは友人関係を快く思っていない（Alice談）。"

# game/script/ch06.rpy:146
translate japanese ch06_car_emily_4d7dccda:

    # "He filed it with the rest, another brick in the wall he was quietly building around the old man."
    "彼はそれを他のものと一緒に綴じ込んだ。老人の周りに静かに築いている壁に、また煉瓦をひとつ。"

# game/script/ch06.rpy:147
translate japanese ch06_car_emily_626c6dd0:

    # "The girl beside him was small and sad and frightened of losing the one warm thing she had."
    "隣の少女は小さく、悲しげで、持っているたったひとつの温かいものを失うことに怯えていた。"

# game/script/ch06.rpy:148
translate japanese ch06_car_emily_dfdab444:

    # "That was what he saw, because that was what he was able to see, with a child in the seat beside him and the other thing in him kept behind its welded door."
    "彼に見えたのはそれだった。それしか見ることができなかったからだ。隣の座席には子どもがいて、彼の中のもうひとつのものは、溶接された扉の向こうに閉じ込められていた。"

# game/script/ch06.rpy:157
translate japanese ch06_car_emily_bde32866:

    # "The house rose behind its fence. He slowed, pulled into the drive, let the engine idle."
    "家は柵の向こうにそびえていた。彼は速度を落とし、私道に入ってエンジンをアイドリングさせた。"

# game/script/ch06.rpy:158
translate japanese ch06_car_emily_cf1bb9c9:

    # "The garden lay squared and trimmed under the snow, every hedge neat, the path already cleared once and going white again. Order announcing itself before you reached the gate."
    "雪の下で、庭は四角く刈り揃えられていた。生垣はどれもきちんと整い、小道は一度雪かきされて、また白くなりかけていた。門にたどり着く前から、秩序が自らを告げていた。"

# game/script/ch06.rpy:159
translate japanese ch06_car_emily_33984e26:

    # "No truck. The windows dark."
    "トラックはない。窓は暗い。"

# game/script/ch06.rpy:160
translate japanese ch06_car_emily_74772280:

    # s "He's not back."
    s "まだ戻ってないな。"

# game/script/ch06.rpy:161
translate japanese ch06_car_emily_0ecb529f:

    # s "You going to be alright? Alone, till he is?"
    s "大丈夫かい？戻るまで、ひとりで。"

# game/script/ch06.rpy:162
translate japanese ch06_car_emily_ec4f7b13:

    # a "I'm used to it."
    a "慣れていますから。"

# game/script/ch06.rpy:163
translate japanese ch06_car_emily_6059aa0c:

    # "Her hand was already on the door."
    "彼女の手はもうドアにかかっていた。"

# game/script/ch06.rpy:164
translate japanese ch06_car_emily_67c6cb12:

    # a "I'll go straight to bed."
    a "すぐに寝ます。"

# game/script/ch06.rpy:165
translate japanese ch06_car_emily_f455c924:

    # s "Alice."
    s "Alice。"

# game/script/ch06.rpy:166
translate japanese ch06_car_emily_9b78404f:

    # "She stopped."
    "彼女は止まった。"

# game/script/ch06.rpy:167
translate japanese ch06_car_emily_8d437794:

    # "He held out one of his cards. The second one he'd given someone in this town who was too young for it."
    "彼は名刺を一枚差し出した。この町で、それを持つには幼すぎる相手に渡すのは二枚目だった。"

# game/script/ch06.rpy:168
translate japanese ch06_car_emily_a57d24be:

    # s "Anything at all. Any hour. You hear the truck, you get scared, you remember something, you call me."
    s "何でもいい。いつでもいい。トラックの音が聞こえたら、怖くなったら、何か思い出したら、電話しなさい。"

# game/script/ch06.rpy:169
translate japanese ch06_car_emily_f56258e3:

    # s stern "Not Markou. Me. Understand?"
    s stern "Markou先生じゃない。私にだ。わかったね？"

# game/script/ch06.rpy:170
translate japanese ch06_car_emily_b5cbc34a:

    # "She took it, and looked at it a moment in the dashboard light, and something crossed her face he couldn't read."
    "彼女はそれを受け取り、ダッシュボードの明かりの中でしばらく眺めた。その顔を、彼には読めない何かがよぎった。"

# game/script/ch06.rpy:178
translate japanese ch06_car_emily_6603f81f:

    # "Not relief. Interest. The look of someone handed a key and already thinking which door."
    "安堵ではない。関心だ。鍵を渡されて、もうどの扉に使うかを考えている者の顔。"

# game/script/ch06.rpy:179
translate japanese ch06_car_emily_94d81c18:

    # th "Gratitude. She's forgotten what it looks like. That's all it is."
    th "感謝だ。感謝がどういうものか、忘れてるんだ。それだけのことだ。"

# game/script/ch06.rpy:183
translate japanese ch06_car_emily_bd889947:

    # a "Thank you, Detective."
    a "ありがとうございます、刑事さん。"

# game/script/ch06.rpy:185
translate japanese ch06_car_emily_3375514e:

    # "She got out. He watched her cross the cleared path, small and straight-backed against the pale garden, and let herself in."
    "彼女は車を降りた。彼は見ていた。彼女が雪かきされた小道を、白い庭を背に小さく背筋を伸ばして渡り、自分で鍵を開けて中に入るのを。"

# game/script/ch06.rpy:186
translate japanese ch06_car_emily_0e205d18:

    # "He waited, engine idling, until a light came on in a downstairs window. Proof of life. An old habit."
    "彼はエンジンをアイドリングさせたまま、一階の窓に明かりがつくまで待った。生きている証。古い習慣だ。"

# game/script/ch06.rpy:187
translate japanese ch06_car_emily_eb1a549e:

    # "Then a moment longer, for no reason he could name, watching the lit square of the house with the snow coming down between them."
    "それから、自分でも理由の言えないまま、もう少しだけ待った。明かりの灯った家の四角い窓を見ていた。そのあいだを雪が降っていた。"

# game/script/ch06.rpy:189
translate japanese ch06_car_emily_d992f6fd:

    # note_voice "No truck at the house. Gave her my card."
    note_voice "家にトラックなし。名刺を渡す。"

# game/script/ch06.rpy:190
translate japanese ch06_car_emily_e1f3c251:

    # "Then he put the car in gear and drove back toward town, and the wrongness rode with him the whole way, formless, insistent."
    "それから彼はギアを入れ、町へ引き返した。違和感は道中ずっと彼と一緒に乗っていた。形がなく、しつこかった。"

# game/script/ch06.rpy:191
translate japanese ch06_car_emily_1bc01544:

    # "He spent the drive pinning it on George Bennett, because George Bennett was where all the arrows pointed."
    "彼は帰り道のあいだ、それをGeorge Bennettに貼りつけていた。すべての矢印がGeorge Bennettを指していたからだ。"

# game/script/ch06.rpy:192
translate japanese ch06_car_emily_209256d1:

    # "And because the other place it might have pointed was a door in Samuel he had welded shut a long time ago, and did not know how to open."
    "そして、それが指していたかもしれないもうひとつの場所は、Samuelの中の、ずっと昔に溶接して閉じた扉で、彼はその開け方を知らなかったからだ。"

# game/script/ch06.rpy:204
translate japanese ch06_car_emily_6e8aa9d0:

    # "The light went off again twenty minutes later."
    "二十分後、明かりはまた消えた。"

# game/script/ch06.rpy:205
translate japanese ch06_car_emily_8690d241:

    # "The house held its heat for a while, and then began, room by room, to give it back to the night."
    "家はしばらく熱を保っていた。それから、ひと部屋ずつ、その熱を夜に返しはじめた。"

# game/script/ch06.rpy:206
translate japanese ch06_car_emily_95cb3a22:

    # "George's coat was not on its peg. The truck was not in the drive."
    "Georgeのコートは掛け釘になかった。トラックは私道になかった。"

# game/script/ch06.rpy:207
translate japanese ch06_car_emily_4c22f04b:

    # "The snow came down over the fence and the trimmed hedges and the cleared path, and began, patiently, to un-clear it."
    "雪は柵の上に、刈り込まれた生垣の上に、雪かきされた小道の上に降り、辛抱強く、それを元に戻しはじめた。"

# game/script/ch06.rpy:209
translate japanese ch06_car_emily_ae9eec54:

    # "A little before eleven the side door opened and Alice stepped out into the cold, buttoned to the throat, and pulled the door shut behind her with both hands."
    "十一時少し前、勝手口が開き、Aliceが寒さの中へ出てきた。喉元までボタンを留め、両手でドアを引いて閉めた。"

# game/script/ch06.rpy:210
translate japanese ch06_car_emily_28efa734:

    # "She carried a small bag over one shoulder."
    "片方の肩に小さな鞄を掛けていた。"

# game/script/ch06.rpy:211
translate japanese ch06_car_emily_7ea9f132:

    # "She stood a moment on the step, her breath clouding, listening to the particular silence of a town gone under snow."
    "彼女はしばらく戸口の段に立っていた。息が白く曇った。雪の下に沈んだ町の、独特の静けさに耳を澄ませていた。"

# game/script/ch06.rpy:212
translate japanese ch06_car_emily_febef07b:

    # "Then she went down the path and through the gate, and turned uphill. Away from the road that led to the houses. Toward the darker road that climbed."
    "それから小道を下り、門を抜け、坂の上へと曲がった。家々へ続く道から離れて。上へと登っていく、もっと暗い道へ。"

# game/script/ch06.rpy:218
translate japanese ch06_car_emily_933c6821:

    # "She walked without hurry. The cold did not seem to touch her."
    "彼女は急がずに歩いた。寒さは彼女に触れていないようだった。"

# game/script/ch06.rpy:219
translate japanese ch06_car_emily_c005abaf:

    # "Where the streetlamps gave out she took a small torch from her pocket and did not use it. Only held it, and let her eyes find the road on their own."
    "街灯が尽きたところで、ポケットから小さな懐中電灯を取り出したが、つけなかった。ただ握ったまま、目が自分で道を見つけるにまかせた。"

# game/script/ch06.rpy:220
translate japanese ch06_car_emily_e9678cdb:

    # "It was not far now. A few minutes, no more, to the place she was going."
    "もう遠くはなかった。行き先まで、あと数分。それ以上はかからない。"

# game/script/ch06.rpy:221
translate japanese ch06_car_emily_e2c3a00d:

    # "She kept climbing, and the town fell away below her, small and bright and asleep."
    "彼女は登りつづけ、町は眼下に遠ざかっていった。小さく、明るく、眠っていた。"

# game/script/ch06.rpy:222
translate japanese ch06_car_emily_37233f4f:

    # "And ahead the dark shape of the hill waited, with its low wall and its open gate."
    "そして前方では、丘の暗い影が待っていた。低い塀と、開いた門をそなえて。"

# game/script/ch06.rpy:237
translate japanese ch06_car_emily_ae7678cd:

    # "That same morning, Emily Carter had woken up happy."
    "その同じ朝、Emily Carterは幸せな気分で目を覚ましていた。"

# game/script/ch06.rpy:238
translate japanese ch06_car_emily_63e7a7e8:

    # "She didn't always. Since Clara, the nights had been bad."
    "いつもそうだったわけではない。Claraのことがあってから、夜はひどかった。"

# game/script/ch06.rpy:239
translate japanese ch06_car_emily_15310a27:

    # "Full of a locker room she'd never actually seen properly, and a face she kept trying to draw and couldn't. Most mornings she woke with her jaw aching from clenching."
    "ちゃんと見たこともない更衣室と、何度描こうとしても描けない顔でいっぱいの夜。たいていの朝、歯を食いしばっていたせいで顎が痛んだまま目が覚めた。"

# game/script/ch06.rpy:240
translate japanese ch06_car_emily_762e845e:

    # "But that morning the sun was out for the first time in a week. Real sun, laying yellow squares across her bedroom wall."
    "けれどその朝は、一週間ぶりに太陽が出ていた。本物の太陽が、寝室の壁に黄色い四角をいくつも並べていた。"

# game/script/ch06.rpy:241
translate japanese ch06_car_emily_825e3835:

    # "She lay in it for a while like a cat before she remembered to be sad. By then the day had already started being good, and it seemed rude to stop it."
    "悲しむことを思い出すまで、彼女は猫みたいにしばらくその中に寝そべっていた。その頃にはもう一日はいい日になりはじめていて、それを止めるのは失礼な気がした。"

# game/script/ch06.rpy:245
translate japanese ch06_car_emily_a962314b:

    # "Her mother made pancakes because the sun was out. Her father did his terrible impression of the weatherman."
    "太陽が出ているからと、母はパンケーキを焼いた。父は天気予報士のひどい物真似をした。"

# game/script/ch06.rpy:246
translate japanese ch06_car_emily_07f937a2:

    # "Emily drew a bird in the syrup with the tip of her fork, a fat crooked bird. Her little brother demanded one too, and she gave him a dog."
    "Emilyはフォークの先でシロップに鳥を描いた。太った、歪んだ鳥。弟が自分にも描いてと言い張ったので、犬を描いてやった。"

# game/script/ch06.rpy:247
translate japanese ch06_car_emily_b5720441:

    # "For ten minutes the kitchen was loud and warm and the way it used to be, before the whole town had gone quiet and watchful and afraid."
    "十分のあいだ、台所はにぎやかで暖かく、昔のままだった。町じゅうが静まり返り、目を光らせ、怯えるようになる前の。"

# game/script/ch06.rpy:249
translate japanese ch06_car_emily_eb513b6e:

    # "At the door her mother held her face for a second, the way she'd taken to doing lately."
    "戸口で母がEmilyの顔を一瞬両手で包んだ。最近そうするようになっていた。"

# game/script/ch06.rpy:250
translate japanese ch06_car_emily_2570b37e:

    # mrsc "You seem brighter. Sleep alright?"
    mrsc "明るい顔をしてるわね。よく眠れた？"

# game/script/ch06.rpy:251
translate japanese ch06_car_emily_53d0a89c:

    # e "Mostly."
    e "だいたいね。"

# game/script/ch06.rpy:252
translate japanese ch06_car_emily_1b5a7aeb:

    # "Emily leaned into the hand because it was nice."
    "気持ちがよかったので、Emilyはその手に顔をあずけた。"

# game/script/ch06.rpy:253
translate japanese ch06_car_emily_1ca270a3:

    # e "It's just the sun."
    e "お日さまのせいだよ。"

# game/script/ch06.rpy:254
translate japanese ch06_car_emily_db4df75d:

    # mrsc "Dr. Elena on Thursday. You'll go?"
    mrsc "木曜日はElena先生よ。行くわね？"

# game/script/ch06.rpy:255
translate japanese ch06_car_emily_03f9191c:

    # e "I'll go, Mum."
    e "行くよ、お母さん。"

# game/script/ch06.rpy:256
translate japanese ch06_car_emily_0dd786d8:

    # "She'd said it lightly. She did mean to go."
    "軽い調子で言った。本当に行くつもりではいた。"

# game/script/ch06.rpy:257
translate japanese ch06_car_emily_d05b26df:

    # "She just didn't think a lady with a soft voice and a box of tissues was going to fix the thing that was actually wrong."
    "ただ、柔らかい声とティッシュの箱を持った女の人に、本当にまずいところが直せるとは思えなかった。"

# game/script/ch06.rpy:258
translate japanese ch06_car_emily_ec9dbf87:

    # "It wasn't a thing she had a name for. Only a shape: a cold shape at the edge of everything, that had started the week Clara died and had not gone away."
    "名前のつけられるものではなかった。ただの形だった。すべてのものの縁にある冷たい形。Claraが死んだ週に始まって、消えなかった。"

# game/script/ch06.rpy:259
translate japanese ch06_car_emily_1c7c1572:

    # eth "Not now. Not on a sun day."
    eth "今はやめて。お日さまの日なんだから。"

# game/script/ch06.rpy:260
translate japanese ch06_car_emily_60aa200b:

    # "She put it out of her mind. She was good at that."
    "彼女はそれを頭から追い出した。そういうのは得意だった。"

# game/script/ch06.rpy:261
translate japanese ch06_car_emily_f8b27334:

    # "It was, her mother sometimes said, her best and her worst quality."
    "それはあなたの一番いいところで、一番悪いところ。母はときどきそう言った。"

# game/script/ch06.rpy:262
translate japanese ch06_car_emily_a1f6fbc1:

    # "That Emily could look straight at a hard thing and decide, out of sheer stubborn hope, to see the softer thing beside it instead."
    "Emilyはつらいものをまっすぐ見つめながら、ひたすら頑固な希望で、その隣にある柔らかいほうを見ると決めることができた。"

# game/script/ch06.rpy:267
translate japanese ch06_car_emily_1802b74e:

    # "She looked for Alice before first bell, the way she always did."
    "始業のベルの前に、彼女はAliceを探した。いつもそうしていた。"

# game/script/ch06.rpy:268
translate japanese ch06_car_emily_46093e3a:

    # "That was the shape of Emily's days and had been for two years: finding Alice."
    "それがEmilyの毎日の形で、二年前からそうだった。Aliceを見つけること。"

# game/script/ch06.rpy:269
translate japanese ch06_car_emily_9b5111a6:

    # "In the yard, in the library, at the end of the corridor by the tall windows where Alice liked to stand, because the light was good and nobody bothered her there."
    "校庭で、図書室で、背の高い窓のある廊下の突き当たりで。Aliceはそこに立つのが好きだった。光がよくて、誰にも邪魔されなかったから。"

# game/script/ch06.rpy:270
translate japanese ch06_car_emily_91732586:

    # "Emily had appointed herself to Alice on the second day of school, when Alice was a stranger, and being a stranger in Greyvale was a kind of crime."
    "学校が始まって二日目、Emilyは自分をAliceの係に任命した。Aliceがよそ者で、Greyvaleでよそ者であることが一種の罪だった頃だ。"

# game/script/ch06.rpy:271
translate japanese ch06_car_emily_c797d850:

    # "She had never once regretted it. Not really."
    "一度も後悔したことはなかった。本当の意味では。"

# game/script/ch06.rpy:272
translate japanese ch06_car_emily_4aadd9ee:

    # "People didn't understand Alice. That was the thing Emily carried like a small hot coal of loyalty."
    "みんなはAliceをわかっていない。Emilyはそれを、忠誠心の小さな熱い炭火のように胸に抱えていた。"

# game/script/ch06.rpy:273
translate japanese ch06_car_emily_eb0299cd:

    # "They said she was cold, that she was strange, that she made your skin crawl. Emily had heard all of it and defended her every time."
    "冷たい子だ、変な子だ、ぞっとする子だと、みんなは言った。Emilyはそれを全部聞いてきて、そのたびにAliceをかばった。"

# game/script/ch06.rpy:274
translate japanese ch06_car_emily_c3480fa5:

    # eth "They don't know her."
    eth "みんな、あの子のことを知らないんだ。"

# game/script/ch06.rpy:275
translate japanese ch06_car_emily_f13d1aca:

    # "They hadn't seen Alice save a cornered girl from bullies with three quiet sentences."
    "追い詰められた女の子を、Aliceが静かな三つの言葉でいじめっ子たちから救うところを、みんなは見ていなかった。"

# game/script/ch06.rpy:276
translate japanese ch06_car_emily_d566dc8d:

    # "They didn't know that Alice never wasted a kind word, so that when she gave you one it was worth ten of anyone else's."
    "Aliceが優しい言葉を決して無駄遣いしないことを、だから一度もらえば他の誰の十倍の値打ちがあることを、みんなは知らなかった。"

# game/script/ch06.rpy:277
translate japanese ch06_car_emily_75b84d82:

    # "They didn't know that Alice had held her at the funeral, and turned her face away from the terrible thing so she wouldn't have to see it."
    "葬式のときAliceが自分を抱きしめ、あの恐ろしいものを見なくてすむように顔をそむけさせてくれたことを、みんなは知らなかった。"

# game/script/ch06.rpy:278
translate japanese ch06_car_emily_38a6593d:

    # "They didn't know, and Emily did, and that was that."
    "みんなは知らなくて、Emilyは知っていた。それだけのことだった。"

# game/script/ch06.rpy:283
translate japanese ch06_car_emily_88b4e256:

    # "She thought sometimes of the day she'd given Alice the coin."
    "Aliceにコインをあげた日のことを、彼女はときどき思い出した。"

# game/script/ch06.rpy:284
translate japanese ch06_car_emily_1c08c0af:

    # "It had been autumn, the two of them on the low wall behind the school with the leaves coming down."
    "秋だった。二人で学校の裏の低い塀に座っていて、木の葉が降っていた。"

# game/script/ch06.rpy:285
translate japanese ch06_car_emily_d6ebbd25:

    # "Emily had been going through her tin. She carried it everywhere: the flat toffee tin with the buttons and the pressed leaves and the three foreign coins and the one good marble."
    "Emilyは缶の中身を見ていた。どこへでも持ち歩いている平たいタフィーの缶で、ボタンと押し葉と三枚の外国のコインと、一個だけのいいビー玉が入っていた。"

# game/script/ch06.rpy:286
translate japanese ch06_car_emily_6f0f09fa:

    # "And she had come to the old coin, the best one. Bronze, worn so smooth by so many hands over so many years that there was no face left on it at all."
    "そして古いコインに行き当たった。一番いいやつだ。青銅で、長い年月のあいだにあまりにも多くの手に触れられ、すり減って、顔がまったく残っていなかった。"

# game/script/ch06.rpy:287
translate japanese ch06_car_emily_0c558c26:

    # "Only a blind gold-brown blank."
    "ただ何も見えない金茶色ののっぺらぼう。"

# game/script/ch06.rpy:290
translate japanese ch06_car_emily_9d4a5d76:

    # "She had held it up to the light, and then, without really deciding to, held it out to Alice."
    "彼女はそれを光にかざし、それから、ちゃんと決めたわけでもなく、Aliceに差し出した。"

# game/script/ch06.rpy:291
translate japanese ch06_car_emily_e1c07173:

    # e "You should have this one."
    e "これはあなたが持ってて。"

# game/script/ch06.rpy:292
translate japanese ch06_car_emily_77c8f03d:

    # "Alice had looked at it a long moment, not taking it, the way she looked at anything offered to her. As though a gift were a small test she had to be sure of."
    "Aliceは長いあいだそれを見ていた。受け取らずに。差し出されたものを見るときはいつもそうだった。贈り物が、確かめなければならない小さな試験であるかのように。"

# game/script/ch06.rpy:293
translate japanese ch06_car_emily_854ff0e8:

    # a "It's your best one."
    a "一番いいやつでしょう。"

# game/script/ch06.rpy:294
translate japanese ch06_car_emily_6598ac22:

    # e "That's why."
    e "だからだよ。"

# game/script/ch06.rpy:295
translate japanese ch06_car_emily_16051ab6:

    # "Emily pressed it into her hand and folded her fingers over it."
    "EmilyはそれをAliceの手に押しつけ、指を折り曲げて握らせた。"

# game/script/ch06.rpy:296
translate japanese ch06_car_emily_c49ba0a7:

    # "She could not have said, then or after, why it had felt so important that Alice, of all the people in the world, be the one to carry the coin with no face. Only that it had."
    "あのときも、あとになっても、彼女には説明できなかっただろう。世界中の誰よりもAliceにこそ、顔のないコインを持っていてほしいと、なぜあれほど大切に感じたのか。ただ、そう感じたのだ。"

# game/script/ch06.rpy:297
translate japanese ch06_car_emily_86ebeecc:

    # "Alice had turned it over once in her fingers and put it in her pocket."
    "Aliceは指の中でそれを一度裏返し、ポケットにしまった。"

# game/script/ch06.rpy:298
translate japanese ch06_car_emily_cba6b3b7:

    # a "I'll keep it."
    a "大事にする。"

# game/script/ch06.rpy:299
translate japanese ch06_car_emily_c24680af:

    # "Flat and quiet. From her, it meant more than anyone else's tears. And she had, as far as Emily knew, kept it."
    "平板で、静かだった。Aliceが言うと、それは他の誰の涙よりも重かった。そしてEmilyの知るかぎり、Aliceはそれを大事に持っていた。"

# game/script/ch06.rpy:300
translate japanese ch06_car_emily_6f253d0f:

    # "That was who Alice was, to Emily. The one who kept things."
    "Emilyにとって、Aliceはそういう子だった。ものを大事に持っている子。"

# game/script/ch06.rpy:301
translate japanese ch06_car_emily_dcf6908e:

    # "The one who, when you gave her the best thing you had, understood exactly what it had cost you and did not waste it."
    "持っている一番いいものをあげたら、それがこちらにとってどれだけの値打ちがあったかを正確にわかってくれて、決して無駄にしない子。"

# game/script/ch06.rpy:306
translate japanese ch06_car_emily_745a890a:

    # "She found her by the windows."
    "窓のそばで彼女を見つけた。"

# game/script/ch06.rpy:308
translate japanese ch06_car_emily_b2aeccfe:

    # e "There you are."
    e "いた。"

# game/script/ch06.rpy:309
translate japanese ch06_car_emily_000fbce4:

    # "It came out on a breath of relief, the way it always did."
    "安堵の息と一緒にこぼれた。いつもそうだった。"

# game/script/ch06.rpy:311
translate japanese ch06_car_emily_ea4fbc8c:

    # "Alice turned, and the faint curve came to her mouth that Emily had learned to read as gladness."
    "Aliceが振り向いた。口もとに淡い弧が浮かんだ。Emilyが喜びと読むようになった弧だった。"

# game/script/ch06.rpy:312
translate japanese ch06_car_emily_ae61be6e:

    # "They walked to class together, and the day folded itself around her the way the days did now: Alice at her side, and the town's fear humming under everything."
    "二人は一緒に教室へ歩いた。一日が、近頃の毎日と同じように彼女を包み込んだ。隣にはAliceがいて、あらゆるものの下で町の恐怖が低く唸っていた。"

# game/script/ch06.rpy:317
translate japanese ch06_car_emily_1fe962f3:

    # "At lunch she told Alice the true things, because Alice was the one person she could tell them to."
    "昼休み、彼女はAliceに本当のことを話した。それを話せる相手はAliceだけだったから。"

# game/script/ch06.rpy:318
translate japanese ch06_car_emily_2ab0ad18:

    # "The nightmares. Dr. Elena on Thursday. How she still couldn't get Clara's face right on paper, no matter how many times she tried."
    "悪夢のこと。木曜日のElena先生のこと。何度描こうとしても、紙の上でClaraの顔がまだうまく描けないこと。"

# game/script/ch06.rpy:319
translate japanese ch06_car_emily_1730fb6b:

    # "Alice took her hand across the table, her gray-brown eyes steady."
    "Aliceはテーブル越しに彼女の手を取った。灰褐色の目は揺らがなかった。"

# game/script/ch06.rpy:320
translate japanese ch06_car_emily_c441dc93:

    # "The good memories would hold, she said, if Emily kept them close. And if there were not enough of them, she should go and make more."
    "いい思い出は残る、とAliceは言った。そばに置いておけば。そしてもし足りないなら、もっと作りに行けばいい。"

# game/script/ch06.rpy:326
translate japanese ch06_car_emily_64ced4d5:

    # "Later, in the corridor, Emily said the smaller, uglier thing. The thing she'd overheard at home."
    "あとで廊下で、Emilyはもっと小さくて、もっと醜いことを口にした。家で漏れ聞いたこと。"

# game/script/ch06.rpy:327
translate japanese ch06_car_emily_81cdc4d2:

    # "That her parents believed George was mixed up in all of it. That it frightened her."
    "両親が、Georgeがすべてに関わっていると思っていること。それが怖いこと。"

# game/script/ch06.rpy:328
translate japanese ch06_car_emily_6ea0c1fa:

    # "Alice had gone quiet at that."
    "Aliceはそれを聞いて黙り込んだ。"

# game/script/ch06.rpy:329
translate japanese ch06_car_emily_21a0ea02:

    # "She said only that she hardly saw George anymore. That she kept to her room, and he kept to the cold."
    "ただ、もうほとんどGeorgeに会っていない、とだけ言った。自分は部屋にこもっていて、Georgeは寒い外にこもっている、と。"

# game/script/ch06.rpy:330
translate japanese ch06_car_emily_356ebe65:

    # "Emily let it drop. Pressing made her friend go somewhere Emily couldn't follow, and helped no one."
    "Emilyはそれ以上訊かなかった。問い詰めると、友達はEmilyがついていけない場所へ行ってしまう。それは誰の助けにもならなかった。"

# game/script/ch06.rpy:336
translate japanese ch06_car_emily_a97bd0c0:

    # "The cold shape had only truly moved once, and it had not been that day."
    "冷たい形が本当に動いたのは一度だけで、それはその日ではなかった。"

# game/script/ch06.rpy:337
translate japanese ch06_car_emily_13890ce3:

    # "Days before, they had been talking about the killings, the way everyone did that winter. Emily had said how frightening it was. That it could be anyone."
    "何日か前、二人は殺人事件のことを話していた。その冬は誰もがそうしていた。Emilyは、すごく怖い、と言った。誰がやっていてもおかしくない、と。"

# game/script/ch06.rpy:339
translate japanese ch06_car_emily_a3127a6f:

    # "Alice had answered mild, not looking up from the apple she was turning in her hands."
    "Aliceは穏やかに答えた。両手の中で転がしているリンゴから目を上げずに。"

# game/script/ch06.rpy:340
translate japanese ch06_car_emily_6fa6af0b:

    # a "Not anyone. Only the ones who deserved a closer look."
    a "誰でもじゃないよ。もっとよく見られて当然の人たちだけ。"

# game/script/ch06.rpy:341
translate japanese ch06_car_emily_f9dc0be5:

    # "Emily had laughed, because it was the kind of dry, strange thing Alice said."
    "Emilyは笑った。Aliceがよく口にする、乾いた、変わったことだったから。"

# game/script/ch06.rpy:342
translate japanese ch06_car_emily_93739587:

    # "And then the laugh had not quite finished."
    "そして、その笑いは最後まで終わらなかった。"

# game/script/ch06.rpy:344
translate japanese ch06_car_emily_8b201675:

    # "For half a second she had heard the sentence another way, and felt her stomach drop for no reason she could have defended."
    "半秒のあいだ、彼女はその文を別の意味で聞いてしまい、自分でも弁護できない理由で胃がすとんと落ちるのを感じた。"

# game/script/ch06.rpy:346
translate japanese ch06_car_emily_eb74ed75:

    # "She had pushed it down hard, the way you push a jack-in-the-box back into its case."
    "彼女はそれを力いっぱい押し戻した。びっくり箱の人形を箱に押し込むように。"

# game/script/ch06.rpy:347
translate japanese ch06_car_emily_17d0dafa:

    # eth "What kind of person thinks a thing like that about their best friend?"
    eth "一番の友達のことをそんなふうに考えるなんて、どんな人間？"

# game/script/ch06.rpy:348
translate japanese ch06_car_emily_d0116d11:

    # eth "A disloyal one. A person as ugly as the ones who called Clara names."
    eth "裏切り者だよ。Claraの悪口を言ってた子たちと同じくらい醜い人間。"

# game/script/ch06.rpy:349
translate japanese ch06_car_emily_b88a7df7:

    # "She had bought Alice a chocolate milk the next morning, to make up for a thought Alice never knew she'd had."
    "次の朝、彼女はAliceにチョコレートミルクを買った。Aliceが知りもしない考えの埋め合わせに。"

# game/script/ch06.rpy:350
translate japanese ch06_car_emily_ee3f414f:

    # "She told no one, ever. And refused, flatly and completely, to be the kind of girl that thought would make her."
    "誰にも話さなかった。一度も。そして、そんな考えを持つ子になることを、きっぱりと、完全に拒んだ。"

# game/script/ch06.rpy:358
translate japanese ch06_car_emily_0acaec73:

    # "The message came that evening, after dark, on the cheap phone Emily wasn't supposed to have either."
    "メッセージが来たのはその晩、暗くなってからだった。Emilyが持っていてはいけないことになっている、安物の携帯に。"

# game/script/ch06.rpy:360
translate japanese ch06_car_emily_71810fca:

    # a "{size=-4}i'm scared, em. george says we're leaving. soon. maybe any day. i can't sleep.{/size}"
    a "{size=-4}こわいよ、Em。Georgeがもうすぐ出ていくって。いつになるかわからない。ねむれない。{/size}"

# game/script/ch06.rpy:362
translate japanese ch06_car_emily_24abd950:

    # "Emily was sitting up in bed before she'd finished reading it. Then more."
    "読み終える前に、Emilyはベッドの上で身を起こしていた。それから、続きが来た。"

# game/script/ch06.rpy:364
translate japanese ch06_car_emily_79be1e9e:

    # a "{size=-4}i keep thinking about clara. nobody got to say goodbye properly. the funeral got ruined, everyone ran, it wasn't finished. it's not right is it.{/size}"
    a "{size=-4}Claraのことばかり考えてる。だれもちゃんとお別れできなかった。お葬式はめちゃくちゃになって、みんな逃げて、終わってない。こんなのおかしいよね。{/size}"

# game/script/ch06.rpy:366
translate japanese ch06_car_emily_6b909a23:

    # a "{size=-4}i want to go to her. tonight, while george is out. before i'm gone and can't. just us. i don't want to do it alone. will you come.{/size}"
    a "{size=-4}Claraのところに行きたい。今夜、Georgeがいないあいだに。いなくなって行けなくなる前に。ふたりだけで。ひとりじゃいや。来てくれる？{/size}"

# game/script/ch06.rpy:367
translate japanese ch06_car_emily_d0ec5c16:

    # "Emily read it three times."
    "Emilyはそれを三回読んだ。"

# game/script/ch06.rpy:368
translate japanese ch06_car_emily_7ee2f5d2:

    # "Outside her window the sun's good morning had gone. The sky had closed over again, and the snow had come back."
    "窓の外では、太陽のいい朝はもう去っていた。空はまた閉ざされ、雪が戻ってきていた。"

# game/script/ch06.rpy:369
translate japanese ch06_car_emily_01959169:

    # "Somewhere across the dark town Alice was frightened and about to be taken away, and wanted, of all the things in the world, to go and finish a goodbye for a girl nobody else had bothered to mourn."
    "暗い町のどこかで、Aliceが怯えていた。もうすぐ連れ去られようとしていて、世界中のあらゆることの中から、他の誰もわざわざ悼もうとしなかった女の子へのお別れを、終わらせに行きたいと願っていた。"

# game/script/ch06.rpy:370
translate japanese ch06_car_emily_70996f86:

    # "And it was a cemetery. At night. And Emily was the kind of person who checked under the bed at fourteen."
    "しかも、墓地だった。夜の。そしてEmilyは、十四にもなってベッドの下を確かめるような子だった。"

# game/script/ch06.rpy:373
translate japanese ch06_car_emily_4d02e712:

    # "For one moment — one — the cold shape was there in the room with her."
    "一瞬――ほんの一瞬――冷たい形が部屋の中に、彼女と一緒にいた。"

# game/script/ch06.rpy:374
translate japanese ch06_car_emily_32948d03:

    # "It had almost a voice. And the voice almost said:"
    "それはほとんど声を持っていた。そしてその声は、ほとんどこう言っていた。"

# game/script/ch06.rpy:375
translate japanese ch06_car_emily_116f8373:

    # eth "{i}Don't.{/i}"
    eth "{i}やめて。{/i}"

# game/script/ch06.rpy:379
translate japanese ch06_car_emily_4b5314b4:

    # "She didn't listen to it. She was ashamed it had spoken at all."
    "彼女は耳を貸さなかった。そんなものが口をきいたこと自体を恥じた。"

# game/script/ch06.rpy:381
translate japanese ch06_car_emily_2b37ba6b:

    # "Her thumb hovered over the screen. She could say no. She could say {i}tomorrow{/i}. She could say her parents would hear the stairs."
    "親指が画面の上で止まった。断ることはできた。{i}明日{/i}にしようと言うこともできた。階段の音で親に気づかれる、と言うこともできた。"

# game/script/ch06.rpy:382
translate japanese ch06_car_emily_5d39d0df:

    # "She sat there in the dark with the phone lighting her face, and the cold shape waited with her, patient, almost kind."
    "彼女は暗闇の中で携帯の光に顔を照らされて座っていた。冷たい形が一緒に待っていた。辛抱強く、ほとんど優しく。"

# game/script/ch06.rpy:383
translate japanese ch06_car_emily_baff7296:

    # "And then the shame came, hot and total, flooding up over it."
    "それから恥ずかしさが来た。熱く、すべてを覆いつくして、それの上に押し寄せた。"

# game/script/ch06.rpy:384
translate japanese ch06_car_emily_3c115860:

    # eth "She's scared. She asked me. Me. And I'm sitting here thinking — what? About Alice?"
    eth "あの子は怖がってる。私に頼んだんだよ。私に。なのに私はここで考えてる――何を？Aliceのことを？"

# game/script/ch06.rpy:385
translate japanese ch06_car_emily_04099135:

    # eth "That's not a feeling. That's me being a coward in a costume."
    eth "こんなの感覚なんかじゃない。仮装した臆病者の私だ。"

# game/script/ch06.rpy:386
translate japanese ch06_car_emily_06c81fb8:

    # "She pushed it down, harder than she had ever pushed it, and was ashamed it had spoken at all."
    "彼女はそれを押し戻した。これまでのどのときよりも強く。そしてそんなものが口をきいたこと自体を恥じた。"

# game/script/ch06.rpy:388
translate japanese ch06_car_emily_dcb1be02:

    # "You did not leave a person alone with fear like that. Not a person you loved. Not for anything."
    "あんなふうに怯えている人をひとりにしてはいけない。好きな人なら、なおさら。何があっても。"

# game/script/ch06.rpy:389
translate japanese ch06_car_emily_1ae13b72:

    # "Not even for a feeling you couldn't explain, and were half sure was just your own cowardice wearing a costume."
    "説明のつかない感覚のためでも。仮装した自分の臆病さにすぎないと半分は確信している感覚のためでも。"

# game/script/ch06.rpy:390
translate japanese ch06_car_emily_31aabb91:

    # "Alice had come for her at the funeral. Alice had turned her face away from the horror."
    "葬式のとき、Aliceは来てくれた。Aliceはあの恐ろしいものから顔をそむけさせてくれた。"

# game/script/ch06.rpy:391
translate japanese ch06_car_emily_4f2c2c99:

    # "You didn't get to be loved like that and then not show up."
    "あんなふうに大事にしてもらっておいて、行かないなんて許されない。"

# game/script/ch06.rpy:392
translate japanese ch06_car_emily_a1154e45:

    # e worried "{size=-4}of course. dont be scared. ill be there. i wont let you do it alone.{/size}"
    e worried "{size=-4}もちろん。こわがらないで。行くよ。ひとりになんかさせない。{/size}"

# game/script/ch06.rpy:393
translate japanese ch06_car_emily_3ed1daa5:

    # "Her thumbs were quick and certain, even though her heart was going."
    "心臓は早鐘を打っていたのに、親指は素早く、迷いがなかった。"

# game/script/ch06.rpy:394
translate japanese ch06_car_emily_cbae9e74:

    # "She dressed in the dark. She waited for her parents' window to go black."
    "暗闇の中で服を着た。両親の部屋の窓が暗くなるのを待った。"

# game/script/ch06.rpy:395
translate japanese ch06_car_emily_5b55ce73:

    # "She counted the stairs on the way down and landed on twelve, which was even, so everything would be fine."
    "下りながら階段を数えると、十二で終わった。偶数だ。だから全部うまくいく。"

# game/script/ch06.rpy:396
translate japanese ch06_car_emily_82360fb6:

    # "She brought things, because you didn't come empty-handed to a goodbye."
    "彼女は物を持っていった。お別れに手ぶらで行くものではないから。"

# game/script/ch06.rpy:397
translate japanese ch06_car_emily_a6ab7907:

    # "The little drawing she'd done of Clara from memory. Not a good one. She'd never looked at Clara long enough to draw her properly, and that was one of the sad things she kept turning over."
    "記憶を頼りに描いた、Claraの小さな絵。上手ではない。ちゃんと描けるほど長くClaraを見たことがなかった。それは、彼女が何度も考えてしまう悲しいことのひとつだった。"

# game/script/ch06.rpy:398
translate japanese ch06_car_emily_809188c4:

    # "And a button from her collection, her second-best: deep green, with a tiny anchor stamped in it, to leave on the grave."
    "それから、コレクションのボタンをひとつ。二番目にいいやつだ。深い緑で、小さな錨が刻印されている。お墓に置いていくために。"

# game/script/ch06.rpy:399
translate japanese ch06_car_emily_07b77537:

    # "A stone was what you left, Alice had told her once. But Emily didn't have a nice enough stone, and a button was more like a present."
    "置いていくのは石なんだよ、といつかAliceが教えてくれた。でもEmilyは十分にきれいな石を持っていなかったし、ボタンのほうがプレゼントらしかった。"

# game/script/ch06.rpy:400
translate japanese ch06_car_emily_906ff527:

    # "And Clara had probably not had many of those."
    "それにClaraは、たぶんプレゼントをあまりもらったことがなかった。"

# game/script/ch06.rpy:408
translate japanese ch06_car_emily_47960d78:

    # "The town was blue and silent and enormous. Her boots were the only sound in it."
    "町は青く、静まり返り、途方もなく大きかった。その中で音を立てているのは彼女のブーツだけだった。"

# game/script/ch06.rpy:409
translate japanese ch06_car_emily_fa039aff:

    # "She climbed the hill talking herself up it under her breath."
    "彼女は小声で自分を励ましながら、丘を登っていった。"

# game/script/ch06.rpy:410
translate japanese ch06_car_emily_188789fa:

    # eth "It's fine. It's just Alice. Ghosts aren't real, and Clara was nice anyway."
    eth "大丈夫。Aliceに会うだけ。幽霊なんていないし、それにClaraはいい子だったし。"

# game/script/ch06.rpy:411
translate japanese ch06_car_emily_b80c83a5:

    # "The houses fell away, and the black gate stood open against the pale slope."
    "家並みが途切れ、白い斜面を背に黒い門が開いていた。"

# game/script/ch06.rpy:412
translate japanese ch06_car_emily_8b917776:

    # "Her stomach rolled over slow, and she went through it anyway. Because on the other side of the fear was Alice."
    "胃がゆっくりとひっくり返った。それでも彼女は門をくぐった。恐怖の向こう側に、Aliceがいたから。"

# game/script/ch06.rpy:418
translate japanese ch06_car_emily_0bb61c4a:

    # "And there she was. A small dark shape among the stones, so still that for one lurching second every ghost story Emily had ever heard came true at once."
    "そして、いた。墓石のあいだの小さな黒い影。あまりにも静かで、ぐらりとする一瞬、Emilyが聞いたことのあるすべての怪談がいっぺんに本当になった。"

# game/script/ch06.rpy:420
translate japanese ch06_car_emily_669bc4b3:

    # "Then the shape turned, and it was only Alice, of course it was, her breath a little cloud."
    "それから影が振り向いた。Aliceだった。もちろんAliceだ。息が小さな雲になっていた。"

# game/script/ch06.rpy:421
translate japanese ch06_car_emily_e22fc558:

    # "Emily's chest went loose all at once. She half-ran the last stretch, weaving between the headstones, and threw her arms around her."
    "Emilyの胸が一気にほどけた。最後の距離を半分走るようにして、墓石のあいだを縫って進み、Aliceに抱きついた。"

# game/script/ch06.rpy:423
translate japanese ch06_car_emily_886ee6e1:

    # a "You came."
    a "来てくれたんだ。"

# game/script/ch06.rpy:424
translate japanese ch06_car_emily_211a3afa:

    # "Alice said it into her hair."
    "AliceはEmilyの髪に向かってそう言った。"

# game/script/ch06.rpy:425
translate japanese ch06_car_emily_0be13da1:

    # e "Of course I came."
    e "来るに決まってるでしょ。"

# game/script/ch06.rpy:426
translate japanese ch06_car_emily_5abe0ff1:

    # "Emily pulled back to hold her by both arms, checking her over the way her mother checked her."
    "Emilyは身を離して両腕をつかみ、母が自分にするようにAliceの様子を確かめた。"

# game/script/ch06.rpy:427
translate japanese ch06_car_emily_e55287f4:

    # e "You're freezing, how long have you been out here, you icicle."
    e "冷えきってるじゃない、いつからここにいたの、このつららちゃん。"

# game/script/ch06.rpy:428
translate japanese ch06_car_emily_e1eb5523:

    # "She was talking too much. She could hear it, the words tumbling the way they did when she was scared and trying not to be."
    "しゃべりすぎていた。自分でもわかった。怖くて、怖がらないようにしているときにいつもそうなるように、言葉が転がり出ていた。"

# game/script/ch06.rpy:429
translate japanese ch06_car_emily_b652b37c:

    # e "Okay. I'm here now. Look — I brought a drawing, it's bad, I couldn't get her nose."
    e "よし。もう私がいるからね。ほら――絵を持ってきたの、下手だけど、鼻がうまく描けなくて。"

# game/script/ch06.rpy:430
translate japanese ch06_car_emily_4f3a1ed1:

    # e "And this button, isn't it a good one, the little anchor? I thought we could leave it for her. Is that stupid?"
    e "それとこのボタン、いいでしょ、この小さな錨。Claraに置いていこうと思って。ばかみたいかな？"

# game/script/ch06.rpy:431
translate japanese ch06_car_emily_087948ce:

    # a "I think it's exactly right."
    a "ぴったりだと思う。"

# game/script/ch06.rpy:432
translate japanese ch06_car_emily_f62e5b18:

    # "Emily beamed. She couldn't help it. Alice never said things like that unless she meant them."
    "Emilyは顔を輝かせた。どうしようもなかった。Aliceは本心でなければ、そんなことは言わない。"

# game/script/ch06.rpy:434
translate japanese ch06_car_emily_64b43645:

    # "They stood a while over the raw new grave three plots along, where the earth was unmarked and no one had yet paid for a stone."
    "二人はしばらく、三つ先の区画にある真新しい墓の前に立っていた。土にはまだ何の印もなく、誰も墓石の代金を払っていなかった。"

# game/script/ch06.rpy:435
translate japanese ch06_car_emily_fe28a0da:

    # "Emily pressed the green button down into the snow at the head of it, and said a small goodbye in her head."
    "Emilyは緑のボタンを墓の頭のほうの雪に押し込み、心の中で小さなさよならを言った。"

# game/script/ch06.rpy:436
translate japanese ch06_car_emily_a47a2bab:

    # "She found, to her surprise, that the cemetery wasn't frightening anymore. It was sad, and quiet, and almost beautiful."
    "驚いたことに、墓地はもう怖くなかった。悲しくて、静かで、ほとんど美しかった。"

# game/script/ch06.rpy:437
translate japanese ch06_car_emily_5f318dc8:

    # "The valley dropped away below the low wall, all the town's little lights far down and small. The clouds had torn open, and there were actual stars."
    "低い塀の向こうで谷が落ち込み、町の小さな明かりがはるか下に、小さく並んでいた。雲が裂けて、本物の星が出ていた。"

# game/script/ch06.rpy:438
translate japanese ch06_car_emily_cb4668c8:

    # e "It's not scary. I thought it'd be scary."
    e "怖くないね。怖いと思ってた。"

# game/script/ch06.rpy:439
translate japanese ch06_car_emily_d7acc3c5:

    # a warm "Not with you here."
    a warm "あなたがいるから。"

# game/script/ch06.rpy:440
translate japanese ch06_car_emily_472a4c66:

    # "Emily bumped her shoulder against Alice's, and Alice let her, which was its own small victory."
    "Emilyは肩をAliceの肩にぶつけた。Aliceはそれを許した。それ自体が小さな勝利だった。"

# game/script/ch06.rpy:442
translate japanese ch06_car_emily_e3e56910:

    # e "Whatever happens..."
    e "何があっても……"

# game/script/ch06.rpy:443
translate japanese ch06_car_emily_066ecd18:

    # "Her voice wobbled without permission."
    "声が勝手に震えた。"

# game/script/ch06.rpy:444
translate japanese ch06_car_emily_2f0c6f17:

    # e "If he takes you — I'll write. Every week. I'll be so annoying you'll beg to come back."
    e "もしあの人があなたを連れていっても――手紙を書くから。毎週。うっとうしすぎて、戻らせてって頼みたくなるくらい。"

# game/script/ch06.rpy:445
translate japanese ch06_car_emily_7f22cab0:

    # "Her eyes were stinging, stupidly."
    "目がしみた。ばかみたいに。"

# game/script/ch06.rpy:446
translate japanese ch06_car_emily_dfa74303:

    # e "I don't want you to go."
    e "行ってほしくない。"

# game/script/ch06.rpy:447
translate japanese ch06_car_emily_8fed7782:

    # "Alice looked at her for a long moment."
    "Aliceは長いあいだ、彼女を見つめていた。"

# game/script/ch06.rpy:448
translate japanese ch06_car_emily_4104bc4f:

    # "Something moved behind her face, quick and deep, there and gone, like a fish turning under ice."
    "その顔の奥で何かが動いた。素早く、深く。現れて、消えた。氷の下で身を翻す魚のように。"

# game/script/ch06.rpy:449
translate japanese ch06_car_emily_2587d6c4:

    # a warm "Drink something warm first."
    a warm "先に何か温かいものを飲んで。"

# game/script/ch06.rpy:456
translate japanese ch06_car_emily_982c8ea3:

    # "She crouched to a flat stone and poured from a thermos, the steam rising up between them into the cold."
    "彼女は平たい石のところにしゃがみ、魔法瓶から注いだ。湯気が二人のあいだを冷気の中へ立ちのぼった。"

# game/script/ch06.rpy:457
translate japanese ch06_car_emily_60677533:

    # "She pressed the mug into Emily's hands, folding Emily's stiff red fingers around it with both of her own."
    "マグをEmilyの手に押しつけ、こわばった赤い指を、自分の両手で包んでマグに巻きつけさせた。"

# game/script/ch06.rpy:458
translate japanese ch06_car_emily_658e2468:

    # a "You walked all this way. You're frozen."
    a "こんなに遠くまで歩いてきたんだもの。凍えてるよ。"

# game/script/ch06.rpy:459
translate japanese ch06_car_emily_eeb74b26:

    # "The mug was hot, gloriously hot, and thick and sweet with chocolate the way Emily liked it, and no one else ever bothered to make it."
    "マグは熱かった。素晴らしく熱く、濃くて甘いチョコレートの味がした。Emilyの好きな作り方で、他の誰もわざわざそう作ってはくれなかった。"

# game/script/ch06.rpy:460
translate japanese ch06_car_emily_bb20a2b9:

    # "Emily curled around it and breathed it in, and felt the warmth go straight up her arms into the cold frightened place in her chest."
    "Emilyはマグを抱え込むように体を丸めて香りを吸い込み、温もりが腕をまっすぐ上って、胸の中の冷たく怯えた場所に届くのを感じた。"

# game/script/ch06.rpy:461
translate japanese ch06_car_emily_1c44194b:

    # "She looked at Alice crouched in the snow, having remembered, of everything, the cocoa."
    "雪の中にしゃがむAliceを見た。何よりもまず、ココアのことを覚えていてくれた。"

# game/script/ch06.rpy:462
translate japanese ch06_car_emily_fc9fbe7c:

    # eth "I have the best friend in the whole world. And I'm never, ever going to let her be alone."
    eth "私には世界で一番の友達がいる。そして私は絶対に、絶対に、あの子をひとりにしない。"

# game/script/ch06.rpy:463
translate japanese ch06_car_emily_0af36474:

    # e "Thank you."
    e "ありがとう。"

# game/script/ch06.rpy:464
translate japanese ch06_car_emily_9bdddf4d:

    # "And she drank."
    "そして彼女は飲んだ。"

# game/script/ch06.rpy:465
translate japanese ch06_car_emily_b6c3ea49:

    # "They talked a while. Emily did most of it. The stars, the letters she'd write, a plan for a code so George couldn't read them."
    "二人はしばらく話した。話していたのはほとんどEmilyだった。星のこと、書くつもりの手紙のこと、Georgeに読まれないための暗号の計画。"

# game/script/ch06.rpy:466
translate japanese ch06_car_emily_b74d316c:

    # "Alice mostly listened, and watched her, and let her talk."
    "Aliceはたいてい聞き役で、彼女を見つめ、話すにまかせていた。"

# game/script/ch06.rpy:467
translate japanese ch06_car_emily_8625f96e:

    # "The warmth spread through her, lovely at first, an ease sinking into her cold hands and her chest."
    "温もりが体じゅうに広がった。はじめは心地よかった。冷えた手に、胸に、安らぎが沈んでいった。"

# game/script/ch06.rpy:468
translate japanese ch06_car_emily_ad5b4cce:

    # "It was a while before it changed."
    "それが変わるまでには、しばらくかかった。"

# game/script/ch06.rpy:474
translate japanese ch06_car_emily_05759cd4:

    # "Somewhere in the middle of a sentence about the code, it stopped being the warmth of the cocoa and became too much of itself."
    "暗号の話の途中のどこかで、それはココアの温もりであることをやめ、温もりそのものが過剰になった。"

# game/script/ch06.rpy:475
translate japanese ch06_car_emily_2f08402f:

    # "A heat that climbed her throat, and turned."
    "熱が喉を這い上がり、そして、反転した。"

# game/script/ch06.rpy:478
translate japanese ch06_car_emily_361d95bf:

    # "The stars smeared. Her mouth had gone strange, thick and far away."
    "星がにじんだ。口の中が奇妙になっていた。厚ぼったく、遠く。"

# game/script/ch06.rpy:479
translate japanese ch06_car_emily_f21df534:

    # "She put a hand to the flat stone to steady the tilting world."
    "傾いていく世界を支えようと、平たい石に手をついた。"

# game/script/ch06.rpy:481
translate japanese ch06_car_emily_7ee8c02e:

    # "The mug went from her other hand and rang once on the rock, and she barely heard it."
    "もう片方の手からマグが離れ、岩に当たって一度だけ鳴った。それもほとんど聞こえなかった。"

# game/script/ch06.rpy:482
translate japanese ch06_car_emily_cb753082:

    # e scared "{size=-6}Alice... I feel — something's —{/size}"
    e scared "{size=-6}Alice……なんか――何かが――{/size}"

# game/script/ch06.rpy:484
translate japanese ch06_car_emily_7e2e50dd:

    # "Alice was very close, and very calm."
    "Aliceはすぐそばにいて、とても落ち着いていた。"

# game/script/ch06.rpy:485
translate japanese ch06_car_emily_4e70e08b:

    # "Her hands came up to hold Emily's face, and her eyes did not have any fear in them at all."
    "その両手が上がってEmilyの顔を包んだ。その目には、恐怖がまったくなかった。"

# game/script/ch06.rpy:486
translate japanese ch06_car_emily_258a0cfd:

    # "None."
    "かけらも。"

# game/script/ch06.rpy:488
translate japanese ch06_car_emily_bd58c868:

    # "And the cold shape that Emily had pushed down all day, all week, for two whole years — the shape she had refused and refused, because loving Alice meant refusing it —"
    "そして、Emilyが一日じゅう、一週間じゅう、まる二年間押し込めてきた冷たい形が――Aliceを愛するということはそれを拒むことだったから、拒んで、拒みつづけてきた形が――"

# game/script/ch06.rpy:489
translate japanese ch06_car_emily_6ff8d23f:

    # "rose up all at once, now that there was no strength left to hold it under."
    "いっぺんに浮かび上がった。もうそれを沈めておく力は残っていなかった。"

# game/script/ch06.rpy:490
translate japanese ch06_car_emily_b72c412a:

    # "And it finished forming. Finally. Completely. In the last clear second she had."
    "そしてそれは形をなし終えた。ついに。完全に。彼女に残された、最後の澄んだ一秒の中で。"

# game/script/ch06.rpy:491
translate japanese ch06_car_emily_e6d7752b:

    # "She looked at her friend. Her friend looked back, steady, waiting."
    "彼女は友達を見た。友達は見返した。揺るがずに、待ちながら。"

# game/script/ch06.rpy:493
translate japanese ch06_car_emily_6dc8ad4c:

    # e "{size=-6}So it's you.{/size}"
    e "{size=-6}あなただったのね。{/size}"

# game/script/ch06.rpy:494
translate japanese ch06_car_emily_9b501ee9:

    # "The world was going."
    "世界が遠のいていった。"

# game/script/ch06.rpy:495
translate japanese ch06_car_emily_3992ded7:

    # a cold "...Of course."
    a cold "……もちろん。"

translate japanese strings:

    # game/script/ch06.rpy:102
    old "Ask her about Emily."
    new "Emilyのことを訊く。"

    # game/script/ch06.rpy:109
    old "Watch her face in the dash light."
    new "ダッシュボードの明かりで彼女の顔を見る。"

    # game/script/ch06.rpy:173
    old "Her hand on the door."
    new "ドアにかけた彼女の手。"

    # game/script/ch06.rpy:180
    old "The card."
    new "名刺。"

    # game/script/ch06.rpy:378
    old "Go to her."
    new "あの子のところへ行く。"

    # game/script/ch06.rpy:380
    old "Stay home."
    new "家にいる。"

