# TODO: Translation updated at 2026-10-11 10:23

# game/script/ch02.rpy:13
translate japanese ch02_34ffc7e5:

    # "The Greyford Division spent the morning of New Year's Eve being scrubbed for luck. Cleaners worked the bullpen with mops and a lemon-and-lavender solution."
    "大晦日の朝、Greyford分署は縁起かつぎに磨きあげられていた。清掃員たちがモップとレモンとラベンダーの洗浄液で大部屋を拭いてまわった。"

# game/script/ch02.rpy:14
translate japanese ch02_404a7a98:

    # "Officers traded plans for the night over the smell of it — family dinners, quiet drinks, bar crawls that ended in regret."
    "警官たちはそのにおいの中で今夜の予定を交わしていた。家族との夕食、静かな一杯、後悔で終わるはしご酒。"

# game/script/ch02.rpy:15
translate japanese ch02_ee9890e8:

    # "A small Christmas tree stood forgotten in the corner, its lights washed thin in the daylight, an ornament or two hanging crooked."
    "隅には小さなクリスマスツリーが忘れられたように立っていた。電飾は昼の光に薄く洗われ、オーナメントがひとつふたつ、傾いて下がっていた。"

# game/script/ch02.rpy:16
translate japanese ch02_870aa18c:

    # "None of it reached the records office at the end of the corridor. That room had belonged to Detective Samuel Harris for thirteen years, and it smelled of it."
    "そのどれも、廊下の突き当たりの記録課までは届かなかった。その部屋は十三年のあいだSamuel Harris刑事のものであり、そのにおいがした。"

# game/script/ch02.rpy:17
translate japanese ch02_3a68506b:

    # "Old smoke, standing in a haze the cracked window did nothing to move."
    "古い煙。ひびの入った窓ではどうにも動かない靄になって、澱んでいた。"

# game/script/ch02.rpy:18
translate japanese ch02_3b736442:

    # "He sat with the year's final report in one hand and a cigarette going in the other. He was not, whatever the room suggested, a man his work had beaten down."
    "彼は片手にその年の最後の報告書を、もう片手に火のついた煙草を持って座っていた。部屋が何を匂わせようと、彼は仕事に打ちのめされた男ではなかった。"

# game/script/ch02.rpy:19
translate japanese ch02_c490e1fd:

    # "He was the best reader of people the division had — the one they brought in when a suspect wouldn't break or a story wouldn't hold."
    "彼は分署でいちばんの、人を読む者だった。容疑者が口を割らないとき、供述の辻褄が合わないとき、呼ばれるのは彼だった。"

# game/script/ch02.rpy:20
translate japanese ch02_437dc67d:

    # "And everyone who mattered knew, too, that he had asked for this desk. Records. The one corner of the job where the only things a man had to read were numbers."
    "そして、肝心な人間は皆、この机を望んだのが彼自身だということも知っていた。記録課。この仕事の中で唯一、読まねばならないのが数字だけで済む片隅。"

# game/script/ch02.rpy:21
translate japanese ch02_33a7cf26:

    # "He had walked into strangers' worst days for a living until, at some point he never named to anyone, he decided he had done enough of it."
    "彼は見知らぬ人間の最悪の一日に踏みこむことを生業にしてきた。そしてあるとき、誰にも明かさなかったある時点で、もう十分だと決めた。"

# game/script/ch02.rpy:22
translate japanese ch02_ef06b09c:

    # "Since then he had been, by every measure the department kept, exceptional and quiet and no trouble to anyone."
    "それ以来、署がつけるあらゆる尺度において、彼は優秀で、物静かで、誰の面倒にもならない男だった。"

# game/script/ch02.rpy:24
translate japanese ch02_c004150d:

    # "A knock. He didn't look up. It came again, and then a throat cleared, and he let the silence run one more beat — an old habit, making the room wait."
    "ノック。彼は顔を上げなかった。もう一度ノックがあり、それから咳払いがして、彼は沈黙をもう一拍だけ引き延ばした。部屋を待たせる、昔からの癖だった。"

# game/script/ch02.rpy:25
translate japanese ch02_f3d00146:

    # "Officer James Crown stood in the doorway, neat-haired and pressed, with the careful straightness of a young man determined to be taken seriously."
    "戸口にJames Crown巡査が立っていた。髪をきちんと整え、制服に折り目をつけ、真剣に扱われたいと心に決めた若者の、慎重なまっすぐさで。"

# game/script/ch02.rpy:26
translate japanese ch02_997ae54c:

    # "Samuel had him read before he'd finished stepping in: the boy wanted his paperwork done today, and was too polite to say so and too anxious to hide it."
    "彼が部屋に入りきるより先に、Samuelは彼を読み終えていた。この若者は今日のうちに書類を片づけてほしいのだ。口に出すには礼儀正しすぎ、隠すには気が急きすぎていた。"

# game/script/ch02.rpy:27
translate japanese ch02_06623e48:

    # s "It's here, James."
    s "ここにあるよ、James。"

# game/script/ch02.rpy:28
translate japanese ch02_e381c766:

    # "He lifted the folder from the corner of the desk where it had sat waiting."
    "彼は机の隅で待っていたフォルダーを持ち上げた。"

# game/script/ch02.rpy:29
translate japanese ch02_b883e42f:

    # s "I'll have it filed before I leave. You didn't need to come all this way."
    s "帰る前に提出しておく。わざわざここまで来なくてもよかったのに。"

# game/script/ch02.rpy:30
translate japanese ch02_4423ead4:

    # "Relief crossed the young man's face, and he worked to keep it off."
    "若者の顔に安堵がよぎり、彼はそれを顔に出すまいと努めた。"

# game/script/ch02.rpy:31
translate japanese ch02_a1ce875e:

    # jc "Thank you, sir."
    jc "ありがとうございます。"

# game/script/ch02.rpy:32
translate japanese ch02_c553dd71:

    # s "Plans tonight?"
    s "今夜の予定は？"

# game/script/ch02.rpy:33
translate japanese ch02_d0882e49:

    # jc "My parents. And my fiancée."
    jc "両親と。それに婚約者と。"

# game/script/ch02.rpy:34
translate japanese ch02_1da32686:

    # s "Good. That's where you should be. Go on."
    s "いいな。いるべき場所だ。行け。"

# game/script/ch02.rpy:35
translate japanese ch02_bec37f30:

    # "He meant it, and let the boy see that he did."
    "本心だった。そして、本心だということを若者に見せてやった。"

# game/script/ch02.rpy:36
translate japanese ch02_af702660:

    # "James went. Samuel crushed out the cigarette, sat a moment with his hand flat on the last page of the year, then got up for more coffee, because the alternative was to keep sitting there."
    "Jamesは出ていった。Samuelは煙草をもみ消し、その年の最後のページに手のひらを置いてしばらく座っていた。それからコーヒーのお代わりを取りに立った。そうしなければ、座りつづけるしかなかったからだ。"

# game/script/ch02.rpy:38
translate japanese ch02_01e06bfc:

    # "Two women from another floor broke off their talk in the kitchen to wish him a happy new year. He gave it back with a nod."
    "別の階の女性が二人、給湯室で話を中断して、良いお年をと言った。彼はうなずいて返した。"

# game/script/ch02.rpy:39
translate japanese ch02_d01c43e7:

    # "He read them both without meaning to — one of them newly unhappy about something at home, the whole of it plain in the way she held her cup."
    "そのつもりもなく、彼は二人とも読んでいた。一人は家庭の何かについて新たに不幸を抱えていた。そのすべてが、カップの持ち方にありありと出ていた。"

# game/script/ch02.rpy:40
translate japanese ch02_64de8e74:

    # "He disliked, the way he always did now, how little the reading cost him and how seldom it did anyone any good."
    "いつものように、彼はそれが嫌だった。読むことがほとんど何の代償も求めず、それが誰かの役に立つことはめったにない、ということが。"

# game/script/ch02.rpy:41
translate japanese ch02_73964fdc:

    # "Back in the office he lit another. He had never cared for the new year: too much manufactured warmth, too much empty time."
    "部屋に戻ると、彼はまた一本に火をつけた。新年が好きだったことは一度もない。作りものの温もりが多すぎ、空っぽの時間が多すぎた。"

# game/script/ch02.rpy:42
translate japanese ch02_c3e66876:

    # "Administration had spent a month pushing him to take the leave he'd let stack up, as though rest were a thing a man could be ordered into."
    "事務方はひと月がかりで、溜まった休暇を取れと彼をせっついていた。まるで休息とは、命令されて入るものであるかのように。"

# game/script/ch02.rpy:43
translate japanese ch02_9f49d252:

    # "So he worked instead. It was what the room was for. It was, if he was honest, most of what he was for now."
    "だから彼はかわりに働いた。この部屋はそのためにあった。正直に言えば、いまの彼もほとんどそのためにあった。"

# game/script/ch02.rpy:44
translate japanese ch02_2d66ae75:

    # "A man holding a great deal of chaos in order with nothing but ink and routine, and asking for no more than that."
    "インクと決まりごとだけで大量の混沌を秩序に保ち、それ以上は何も求めない男。"

# game/script/ch02.rpy:49
translate japanese ch02_092a9a05:

    # "By evening the building had thinned to silence. The clock ticked past eight when another knock rattled his door."
    "夕方には、建物は静まりかえるほど人が減っていた。時計が八時を回ったころ、またノックが彼の扉を揺らした。"

# game/script/ch02.rpy:50
translate japanese ch02_b1e9df35:

    # s tired "Come in."
    s tired "どうぞ。"

# game/script/ch02.rpy:52
translate japanese ch02_a995f80e:

    # "Captain Raymond Doyle stepped in, broad-shouldered, his fifties showing in the heavy lines of his face. He fanned the air in front of him."
    "Raymond Doyle警部が入ってきた。肩幅が広く、五十代であることが顔に刻まれた重い皺に表れていた。彼は顔の前の空気を手で払った。"

# game/script/ch02.rpy:53
translate japanese ch02_c8a48116:

    # d "God, Sam. It's like breathing a chimney in here. One of these years it's going to be you I'm writing the report on."
    d "ひどいな、Sam。煙突の中で息をしてるみたいだ。いつか俺が報告書を書く相手は、お前になるぞ。"

# game/script/ch02.rpy:54
translate japanese ch02_672139fc:

    # "Samuel gave a low laugh."
    "Samuelは低く笑った。"

# game/script/ch02.rpy:55
translate japanese ch02_afef7485:

    # s "Ray. What brings you down here?"
    s "Ray。こんなところまで何の用だ？"

# game/script/ch02.rpy:56
translate japanese ch02_2734d40f:

    # d "Just to wish you a happy new year. And to tell you it's late. You should go."
    d "良いお年を、と言いに来ただけだ。それと、もう遅いと言いにな。帰れ。"

# game/script/ch02.rpy:57
translate japanese ch02_60c466a0:

    # s "Happy new year, Ray. I'll be on my way soon enough."
    s "良いお年を、Ray。じきに帰るよ。"

# game/script/ch02.rpy:58
translate japanese ch02_9d331241:

    # d "Good man."
    d "それでいい。"

# game/script/ch02.rpy:60
translate japanese ch02_b0b048c2:

    # "Doyle clapped the doorframe lightly and left. Samuel rubbed a hand through his graying hair, the gesture more nervous than weary."
    "Doyleは戸枠を軽く叩いて出ていった。Samuelは白髪まじりの髪を手でかき回した。疲れよりも、落ち着かなさの出た仕草だった。"

# game/script/ch02.rpy:61
translate japanese ch02_64caff1c:

    # "He shuffled the files and cups into some semblance of order, slipped on his coat, and pocketed the nearly empty pack of Marlboros."
    "彼はファイルとカップをどうにか片づけた体裁に寄せ、コートをはおり、ほとんど空になったマルボロの箱をポケットに入れた。"

# game/script/ch02.rpy:62
translate japanese ch02_2656b005:

    # "Without a glance back, he left the department behind."
    "振り返りもせず、彼は分署をあとにした。"

# game/script/ch02.rpy:68
translate japanese ch02_0ee3d5fa:

    # "His building met him with the strange silence of overcleaned spaces. Marble polished to a mirror, the mirror wall a little too bright, a little too honest."
    "彼の住む建物は、磨かれすぎた場所特有の奇妙な静けさで彼を迎えた。鏡のように磨かれた大理石。鏡張りの壁は少しばかり明るすぎ、少しばかり正直すぎた。"

# game/script/ch02.rpy:69
translate japanese ch02_f2bfcc36:

    # "Lemon and lavender, the same as the precinct. The annual ritual — less tradition, he thought, than a way of pretending order could be renewed with a mop and bucket."
    "レモンとラベンダー。分署と同じだった。毎年の儀式。伝統というより、モップとバケツで秩序を新しくできるふりをする方法なのだ、と彼は思った。"

# game/script/ch02.rpy:70
translate japanese ch02_0b95c4b6:

    # "From the higher floors, music and laughter bled through the ceilings. The sounds of company, family. A distant joy that seemed meant for other people."
    "上の階から、音楽と笑い声が天井越しに滲んできた。人の集まる音、家族の音。他人のためにあるような、遠い喜び。"

# game/script/ch02.rpy:71
translate japanese ch02_396e555d:

    # "At the door of 44 the smell hit him — roasted meat, garlic, onions, something home-cooked. His shoulders eased before he realized it."
    "四十四号室の前で、においが彼を打った。焼いた肉、にんにく、玉ねぎ、家庭の料理の何か。気づく前に、肩の力が抜けていた。"

# game/script/ch02.rpy:72
translate japanese ch02_8bf610c2:

    # s "Martha?"
    s "Martha？"

# game/script/ch02.rpy:73
translate japanese ch02_0a5276f3:

    # ma "Who else would it be, you dumb fool? A burglar with a New Year's Eve mood who decided to make you dinner?"
    ma "ほかに誰がいるっていうの、このおばかさん。大晦日で浮かれた泥棒が、あなたに夕食を作ってやろうと思い立ったとでも？"

# game/script/ch02.rpy:75
translate japanese ch02_a3da5708:

    # "Samuel smiled — one of the rare, real ones."
    "Samuelは微笑んだ。めったにない、本物の笑みだった。"

# game/script/ch02.rpy:76
translate japanese ch02_ddf1310a:

    # "Martha Johnson came out of the kitchen wiping her hands on a dish towel. Heavyset but sturdy, warmth and authority both, dark fuzzy hair framing her round face like a halo she'd never bothered to tame."
    "Martha Johnsonが布巾で手を拭きながら台所から出てきた。太り肉だが頑丈で、温かさと威厳を併せ持っていた。黒いふわふわした髪が、一度も手なずけようとしなかった後光のように丸い顔を縁取っていた。"

# game/script/ch02.rpy:77
translate japanese ch02_13d1db27:

    # ma "You're late. Food's almost gone cold."
    ma "遅いわよ。料理がもう冷めかけてる。"

# game/script/ch02.rpy:78
translate japanese ch02_0b32d234:

    # s "I was working. Raymond passed by, wished me a happy new year. Told me to get the hell out of there."
    s "仕事だったんだ。Raymondが寄って、良いお年をと言っていった。さっさと出ていけ、ってさ。"

# game/script/ch02.rpy:79
translate japanese ch02_4fe1dff0:

    # ma "Good man. He probably saved you from drowning in your own smoke."
    ma "いい人ね。きっと、あなたが自分の煙で溺れるのを救ってくれたのよ。"

# game/script/ch02.rpy:80
translate japanese ch02_58f805ae:

    # ma "You're the smartest fool I know, Sam. Too smart for this smoke, too foolish to stop it."
    ma "あなたは私の知ってるなかでいちばん頭のいいおばかさんよ、Sam。この煙には頭が良すぎて、それをやめられないほどおばかさん。"

# game/script/ch02.rpy:81
translate japanese ch02_3f3fe98b:

    # "She gave the stew a final stir. The table was already set, a plate waiting, cutlery laid straight. She set the pot within reach, steam rising thick and fragrant."
    "彼女はシチューを最後にひと混ぜした。食卓はもう整っていた。皿が一枚待ち、カトラリーがまっすぐ並べてあった。彼女は手の届くところに鍋を置いた。湯気が濃く、香り高く立ちのぼった。"

# game/script/ch02.rpy:82
translate japanese ch02_0d144e31:

    # ma "That's dinner. Enough to last you through the night."
    ma "これが夕食。今夜いっぱいもつくらいあるわ。"

# game/script/ch02.rpy:83
translate japanese ch02_cd6a4517:

    # s soft "Thank you, Martha."
    s soft "ありがとう、Martha。"

# game/script/ch02.rpy:84
translate japanese ch02_6254fba5:

    # "She untied her apron and headed for the door. Just before she reached it, she stopped, one hand resting on the frame."
    "彼女はエプロンをほどき、扉へ向かった。たどり着く直前、片手を戸枠に置いて立ち止まった。"

# game/script/ch02.rpy:86
translate japanese ch02_6b05e856:

    # "Her voice changed — no longer playful, but steady, serious, almost maternal."
    "その声が変わった。もうふざけてはいない。落ち着いて、真剣で、ほとんど母親のような声だった。"

# game/script/ch02.rpy:87
translate japanese ch02_2f5ae18e:

    # ma "Dear, try to do something different tomorrow. Go on a trip. See something new for once."
    ma "ねえ、明日は何か違うことをしてごらんなさい。旅に出るの。たまには新しいものを見なさい。"

# game/script/ch02.rpy:88
translate japanese ch02_3b34b6d4:

    # ma "I'm sick and tired of watching you live on coffee, smoke, and whatever garbage you drag in from across the street. You need a change."
    ma "あなたがコーヒーと煙草と、通りの向こうから引きずってくるろくでもないもので生きてるのを見るのは、もううんざり。変化が要るのよ。"

# game/script/ch02.rpy:89
translate japanese ch02_d0c4b8ad:

    # "Samuel didn't answer. He sat still, eyes on the floor. The words stung, not because they were wrong, but because they were true."
    "Samuelは答えなかった。じっと座り、目を床に落としていた。その言葉は胸を刺した。間違っていたからではない。真実だったからだ。"

# game/script/ch02.rpy:90
translate japanese ch02_c49b8937:

    # "A man his age, hardened, disciplined, sitting like a boy being scolded. The silence stretched until he lifted his head and broke into a small smile."
    "この歳の、鍛えられ、規律の身についた男が、叱られる少年のように座っていた。沈黙が引き延ばされ、やがて彼は顔を上げ、小さく笑みを崩した。"

# game/script/ch02.rpy:91
translate japanese ch02_c111eb4c:

    # s "Happy New Year, Martha. To you and your family."
    s "良いお年を、Martha。君と、君の家族に。"

# game/script/ch02.rpy:92
translate japanese ch02_d55b6d6a:

    # "Her expression softened, though sadness lingered in her eyes."
    "彼女の表情がやわらいだ。それでも、目には悲しみが残っていた。"

# game/script/ch02.rpy:93
translate japanese ch02_2cec8492:

    # ma "Happy New Year, Sam."
    ma "良いお年を、Sam。"

# game/script/ch02.rpy:95
translate japanese ch02_a2ed6ea4:

    # "The door closed behind her, and the apartment fell quiet once more."
    "扉が彼女の背後で閉まり、部屋はふたたび静かになった。"

# game/script/ch02.rpy:96
translate japanese ch02_5c376403:

    # "The kitchen was still warm, rich with the stew. But he didn't sit. He never did. Martha knew it, though she pretended not to. Her meals were left like offerings, mostly untouched."
    "台所はまだ温かく、シチューの香りに満ちていた。だが彼は座らなかった。座ったことはなかった。Marthaはそれを知っていて、知らないふりをしていた。彼女の料理は供え物のように置かれ、たいていは手つかずのままだった。"

# game/script/ch02.rpy:97
translate japanese ch02_636bd57a:

    # "He poured another coffee from the pot she'd set ready, sat heavily on the sofa, and switched on the television — background more than anything."
    "彼は彼女が用意しておいたポットからコーヒーをもう一杯注ぎ、ソファに重く腰を下ろし、テレビをつけた。何よりも背景の音として。"

# game/script/ch02.rpy:98
translate japanese ch02_d9e23fa4:

    # "He lit another cigarette and let the smoke seep slowly from his lungs."
    "彼はまた一本に火をつけ、煙が肺からゆっくりと滲み出ていくにまかせた。"

# game/script/ch02.rpy:102
translate japanese ch02_251f0019:

    # "That was when the phone rang. He exhaled, close to a sigh, and leaned across the table for it."
    "電話が鳴ったのはそのときだった。彼はため息に近い息を吐き、テーブル越しに手を伸ばした。"

# game/script/ch02.rpy:103
translate japanese ch02_3bc1803f:

    # "One glance at the screen told him all he needed to know. Claire. Of course it would be her."
    "画面をひと目見れば、知るべきことはすべてわかった。Claire。もちろん彼女だ。"

# game/script/ch02.rpy:105
translate japanese ch02_fb63ba4c:

    # "He answered but didn't speak."
    "彼は電話に出たが、何も言わなかった。"

# game/script/ch02.rpy:106
translate japanese ch02_a7ee1838:

    # cl "Hello, Sam."
    cl "もしもし、Sam。"

# game/script/ch02.rpy:107
translate japanese ch02_ffca4470:

    # "No warmth, no edge either — just flat calm. Behind her, the faint spill of life: cheerful voices, a room full of people, children laughing. He swallowed hard."
    "温もりもなく、とげもない。ただ平らな落ち着きだけ。彼女の背後から、かすかに生活がこぼれてきた。陽気な声、人で満ちた部屋、子どもたちの笑い声。彼は強く唾を飲んだ。"

# game/script/ch02.rpy:108
translate japanese ch02_89303a79:

    # s "Hey, Claire. Checking on me again? You need to stop that."
    s "やあ、Claire。また俺の様子見か？　もうやめたほうがいい。"

# game/script/ch02.rpy:109
translate japanese ch02_21c47d0d:

    # cl "Yeah. Something like that. How are you, Sam?"
    cl "ええ。そんなところ。元気、Sam？"

# game/script/ch02.rpy:114
translate japanese ch02_8374954f:

    # s "I'm..."
    s "俺は……"

# game/script/ch02.rpy:115
translate japanese ch02_fee38c83:

    # "{i}Alone. Sitting in the smoke. The stew going cold on the table.{/i} The words were right there."
    "{i}独りだ。煙の中に座ってる。シチューが食卓で冷めていく{/i}。言葉はすぐそこにあった。"

# game/script/ch02.rpy:116
translate japanese ch02_f5cc8471:

    # "He heard the children laughing behind her, and the truth went back where he kept it."
    "彼女の後ろで子どもたちが笑うのが聞こえ、真実は彼がいつもしまっておく場所へ戻っていった。"

# game/script/ch02.rpy:117
translate japanese ch02_c66fce4a:

    # s "I'm fine. Just finished my stew. Planning to rest, maybe sleep early."
    s "元気だよ。シチューを食べ終えたところだ。休むつもりだ、早めに寝るかもしれない。"

# game/script/ch02.rpy:118
translate japanese ch02_2236d197:

    # "The lie came out anyway, smooth and practiced, as though it had been waiting its turn."
    "嘘はそれでも出てきた。なめらかに、手慣れて、まるで自分の番を待っていたかのように。"

# game/script/ch02.rpy:121
translate japanese ch02_c66fce4a_1:

    # s "I'm fine. Just finished my stew. Planning to rest, maybe sleep early."
    s "元気だよ。シチューを食べ終えたところだ。休むつもりだ、早めに寝るかもしれない。"

# game/script/ch02.rpy:122
translate japanese ch02_35fd8933:

    # "A lie, smooth, practiced. He never touched the stew."
    "嘘だった。なめらかで、手慣れた嘘。彼はシチューに手もつけていなかった。"

# game/script/ch02.rpy:124
translate japanese ch02_87de0518:

    # s "How about you? How are the kids? Mark?"
    s "君は？　子どもたちは元気か？　マークは？"

# game/script/ch02.rpy:125
translate japanese ch02_6e29e2f4:

    # cl "Everyone's doing fine. I was—"
    cl "みんな元気よ。私は――"

# game/script/ch02.rpy:126
translate japanese ch02_6dc14df2:

    # s "I'm glad. Really. But I've got to go. I'm tired."
    s "よかった。本当に。でも、もう切らないと。疲れてるんだ。"

# game/script/ch02.rpy:127
translate japanese ch02_3ddd991b:

    # "A pause."
    "間。"

# game/script/ch02.rpy:128
translate japanese ch02_bd1aad20:

    # cl "Of course. Sam..."
    cl "そうよね。Sam……"

# game/script/ch02.rpy:129
translate japanese ch02_16b8cb94:

    # "Silence."
    "沈黙。"

# game/script/ch02.rpy:130
translate japanese ch02_c8b9c0e0:

    # cl "It's okay, Sam. You need to let go."
    cl "もういいのよ、Sam。手放さなきゃ。"

# game/script/ch02.rpy:131
translate japanese ch02_04ac43dc:

    # "More silence. His grip tightened on the phone. Then a burst of laughter — forced, loud, wrong."
    "さらに沈黙。電話を握る手に力がこもった。それから、笑い声がはじけた。無理やりで、大きく、ちぐはぐな笑い。"

# game/script/ch02.rpy:132
translate japanese ch02_0b0aeaab:

    # s "You know we're not married anymore, right? You don't have to say things like that. Go now. Happy New Year."
    s "俺たち、もう夫婦じゃないんだぞ。わかってるだろ？　そんなことを言う必要はない。もう行けよ。良いお年を。"

# game/script/ch02.rpy:133
translate japanese ch02_f02b4f17:

    # cl "Yes. Happy New Year. Take care, Sam."
    cl "ええ。良いお年を。気をつけてね、Sam。"

# game/script/ch02.rpy:134
translate japanese ch02_7249fee6:

    # s "You too, Claire."
    s "君もな、Claire。"

# game/script/ch02.rpy:136
translate japanese ch02_9097858f:

    # "He lowered the phone, stared at it a moment, then slipped it into his pocket. The television light flickered across his face."
    "彼は電話を下ろし、しばらくそれを見つめ、それからポケットに滑りこませた。テレビの光が顔の上でちらついた。"

# game/script/ch02.rpy:140
translate japanese ch02_5f0d8884:

    # "The apartment seemed larger when it was quiet. Too large."
    "静かになると、部屋は広く見えた。広すぎた。"

# game/script/ch02.rpy:141
translate japanese ch02_de55e36b:

    # "The children's laughter from Claire's call lingered, sharper now, echoing against the walls of his memory."
    "Claireの電話の向こうの子どもたちの笑い声が残っていた。いまはさらに鋭く、記憶の壁に反響していた。"

# game/script/ch02.rpy:144
translate japanese ch02_0f74ed7e:

    # "It pulled him back to a smaller space, warmer, cluttered with toys and blankets. A nursery. The faint, powdery smell of baby lotion."
    "それは彼を、もっと狭い場所へ引き戻した。もっと温かく、おもちゃと毛布で散らかった場所。子ども部屋。ベビーローションの、かすかな粉っぽいにおい。"

# game/script/ch02.rpy:145
translate japanese ch02_29dc7e0e:

    # "The soft weight of a child in his arms, no heavier than a loaf of bread, but alive, real, everything."
    "腕の中の子どもの柔らかな重み。一斤のパンほどの重さしかないのに、生きていて、本物で、すべてだった。"

# game/script/ch02.rpy:146
translate japanese ch02_11fc01e5:

    # "The curve of an infant's cheek. Fingers curling instinctively around his thumb."
    "赤ん坊の頬の丸み。本能で彼の親指を握りしめる指。"

# game/script/ch02.rpy:147
translate japanese ch02_8991e226:

    # "A sound — half yawn, half sigh — escaping lips still learning the world."
    "ひとつの声。半分あくびで、半分ため息の。まだ世界を覚えている途中の唇から漏れた声。"

# game/script/ch02.rpy:151
translate japanese ch02_e67c306d:

    # "And then nothing. Just silence, like the one in his apartment now."
    "そして、何もなくなった。ただ沈黙だけ。いま、この部屋にある沈黙のような。"

# game/script/ch02.rpy:152
translate japanese ch02_34afa61e:

    # "Thirteen years had passed, yet the grief sat where it always had, untouched by distance."
    "十三年が過ぎた。それでも悲しみはいつもの場所に座っていた。距離に触れられることもなく。"

# game/script/ch02.rpy:153
translate japanese ch02_fb65c63f:

    # "His marriage had cracked beneath it. His every habit was built around keeping the wound covered. But the wound never closed."
    "結婚はその下でひび割れた。彼の習慣はどれも、傷を覆っておくためにできていた。だが傷は一度も塞がらなかった。"

# game/script/ch02.rpy:157
translate japanese ch02_0e3462bb:

    # "Samuel rubbed his face, forcing the thought back down, and drew on the cigarette deeper, letting the smoke burn away the edges of memory."
    "Samuelは顔をこすり、その考えを無理やり押し戻した。煙草をさらに深く吸い、煙に記憶の縁を焼かせた。"

# game/script/ch02.rpy:158
translate japanese ch02_ede3cc6a:

    # th "Work was easier. Work was safer. Work was all that was left."
    th "仕事のほうが楽だった。仕事のほうが安全だった。残っているのは仕事だけだった。"

# game/script/ch02.rpy:159
translate japanese ch02_4be5a9e2:

    # "The cigarette burned low until the heat bit into his skin. He hissed and dropped it into the ashtray." with hpunch
    "煙草は短く燃え尽き、熱が肌に噛みついた。彼は息を鋭く吸い、それを灰皿に落とした。" with hpunch

# game/script/ch02.rpy:160
translate japanese ch02_8e1919d0:

    # "He reached for his pack. Empty. He sighed, slipped on his coat, and stepped out."
    "彼は箱に手を伸ばした。空だった。ため息をつき、コートをはおり、外へ出た。"

# game/script/ch02.rpy:169
translate japanese ch02_d991ce82:

    # "The street was still, the snow falling in a thin veil, coating the sidewalks in a fragile carpet of white."
    "通りは静かだった。雪が薄いヴェールのように降り、歩道を壊れやすい白い絨毯で覆っていた。"

# game/script/ch02.rpy:170
translate japanese ch02_3eb90628:

    # "Around him the neighborhood glowed. Strings of colored bulbs blinked; silhouettes shifted behind thin glass; children darted past curtains."
    "あたりの街並みは光っていた。色とりどりの電球の連なりが瞬き、薄いガラスの向こうで人影が動き、子どもたちがカーテンの前を駆け抜けた。"

# game/script/ch02.rpy:171
translate japanese ch02_02f09016:

    # "The collective pulse of a city breathing into a new year. Samuel moved through it apart, his presence quieter than the snow itself."
    "新しい年へ息を吐く街の、ひとつにまとまった鼓動。Samuelはその中を離れて歩いた。その気配は、雪そのものよりも静かだった。"

# game/script/ch02.rpy:172
translate japanese ch02_019b96a1:

    # "The mini market stood at the corner, its neon sign buzzing faintly. A bell chimed above the door."
    "角にミニマーケットがあり、ネオンの看板がかすかに唸っていた。扉の上でベルが鳴った。"

# game/script/ch02.rpy:173
translate japanese ch02_db2a05c0:

    # "The young man at the counter nodded. Early thirties. The type who worked holidays for the extra pay."
    "カウンターの若い男がうなずいた。三十代前半。割増賃金のために祝日に働く手合いだ。"

# game/script/ch02.rpy:174
translate japanese ch02_49fe1043:

    # "Patchy beard, hair cropped close to hide the thinning. Long nails on one hand — guitarist's nails, or something close. The kind of man with no plans later but to sleep."
    "まだらな顎ひげ、薄くなったのを隠すために短く刈った髪。片手だけ爪が長い。ギタリストの爪か、それに近い何か。今夜の予定は寝ることだけ、という種類の男。"

# game/script/ch02.rpy:175
translate japanese ch02_3d47dd24:

    # "Samuel studied him for a moment, then looked away. Four packs of Marlboros on the counter. Money changed hands. No more words than necessary."
    "Samuelはしばらく男を観察し、それから目をそらした。カウンターにマルボロが四箱。金がやり取りされた。必要以上の言葉はなかった。"

# game/script/ch02.rpy:176
translate japanese ch02_ca2959b3:

    # "Outside, he tore open the first pack. The warning met him in bold type: SMOKING KILLS. A picture of a hospital bed, a body reduced to fragility."
    "外で、彼は最初の箱を破いた。太字の警告が彼を迎えた。「喫煙は死を招く」。病院のベッドの写真。脆さだけになった体。"

# game/script/ch02.rpy:177
translate japanese ch02_df43aa31:

    # s "Of course."
    s "だろうな。"

# game/script/ch02.rpy:178
translate japanese ch02_03b2ffdd:

    # "He grinned faintly, shook his head, and slid a cigarette between his lips. The lighter's flame flickered once in the winter air, then held."
    "彼はかすかに笑い、首を振り、煙草を一本唇に挟んだ。ライターの炎が冬の空気の中で一度揺らぎ、それから落ち着いた。"

# game/script/ch02.rpy:184
translate japanese ch02_a403aa3b:

    # "Samuel tilted his head back, exhaling toward the night. Snow drifted down, gathering on his coat, his hair."
    "Samuelは頭を後ろへ傾け、夜に向かって煙を吐いた。雪が舞い降り、彼のコートに、髪に積もった。"

# game/script/ch02.rpy:185
translate japanese ch02_dd151116:

    # "Above, the sky was a mass of heavy cloud, but a small break remained — just enough for the crescent moon to show itself, sharp and pale."
    "頭上の空は重い雲の塊だったが、小さな切れ間がひとつ残っていた。三日月が姿を見せるのにちょうど足りるだけの切れ間。鋭く、青白い月。"

# game/script/ch02.rpy:186
translate japanese ch02_d4bfa64c:

    # "He drew hard on the cigarette, the tip flaring bright against the dark."
    "彼は煙草を強く吸った。先端が闇に明るく燃え上がった。"

# game/script/ch02.rpy:187
translate japanese ch02_93fafd65:

    # th "Maybe Martha's right. Maybe a trip. A change of scenery, just once."
    th "Marthaの言うとおりかもしれない。旅か。一度くらい、景色を変えてみるか。"

# game/script/ch02.rpy:200
translate japanese ch02_2766a4c0:

    # "The road stretched long and white beneath his wheels. One hand on the wheel, the other tapping his knee in rhythm with the music."
    "道は車輪の下に長く白く伸びていた。片手をハンドルに、もう片方の手で音楽に合わせて膝を叩いていた。"

# game/script/ch02.rpy:201
translate japanese ch02_224068d0:

    # "From the radio came the heavy riffs of System of a Down's {i}Mr. Jack{/i} — a relic of his younger days, sharp enough to pull half-forgotten pieces of himself forward."
    "ラジオからシステム・オブ・ア・ダウンの{i}『Mr. Jack』{/i}の重いリフが流れていた。若いころの遺物で、半ば忘れていた自分の欠片を引っぱり出すほどに鋭かった。"

# game/script/ch02.rpy:202
translate japanese ch02_599bfa7b:

    # "A small duffel on the back seat. His phone and police radio side by side on the passenger seat — habits he couldn't leave behind even on so-called time off."
    "後部座席には小さなダッフルバッグ。助手席には携帯電話と警察無線が並んでいた。いわゆる休暇中でさえ置いていけない習慣だった。"

# game/script/ch02.rpy:203
translate japanese ch02_124561f1:

    # "Nearly dawn when he had started; now past seven. The city lay far behind, swallowed by distance and snow."
    "出発したのは夜明け近くだった。いまは七時を過ぎていた。街ははるか後方にあり、距離と雪に呑みこまれていた。"

# game/script/ch02.rpy:204
translate japanese ch02_4c4c633e:

    # th "Fresh air, Martha had said. Go take some fresh air."
    th "新鮮な空気、とMarthaは言った。新鮮な空気を吸ってきなさい。"

# game/script/ch02.rpy:205
translate japanese ch02_3586ac9e:

    # "Well, here he was — out where the air was as fresh as it got. He almost laughed."
    "さて、こうして来てみたわけだ。空気がこれ以上ないほど新鮮な場所に。彼はもう少しで笑いそうになった。"

# game/script/ch02.rpy:206
translate japanese ch02_94f62b9f:

    # "Pines bowed heavy under snow. Ridges caught the morning light, silver mist clinging to their bases. Every few miles the road bent around cliffs that fell into valleys deep enough to vanish in shadow."
    "松が雪の重みに頭を垂れていた。尾根が朝の光を受け、その裾に銀色の靄がまとわりついていた。数マイルごとに、道は崖を回りこんだ。崖は影の中に消えてしまうほど深い谷へと落ちていた。"

# game/script/ch02.rpy:207
translate japanese ch02_8a91f919:

    # "It was beautiful, yes — but the beauty carried weight. A reminder of how far from everything he was driving."
    "美しかった。たしかに。だがその美しさには重みがあった。自分がどれほどすべてから遠くへ車を走らせているのか、思い知らされた。"

# game/script/ch02.rpy:208
translate japanese ch02_09d68842:

    # "His best companion rested between his fingers: a Marlboro, burning slow, rolled across his knuckles as absently as shifting gears."
    "いちばんの相棒は指のあいだにあった。ゆっくり燃えるマルボロ。ギアを切り替えるのと同じくらい無意識に、指の関節の上で転がされていた。"

# game/script/ch02.rpy:212
translate japanese ch02_490073f1:

    # "The song cut suddenly, replaced by a burst of static." with hpunch
    "曲が突然途切れ、雑音の破裂に取って代わられた。" with hpunch

# game/script/ch02.rpy:213
translate japanese ch02_d964dad6:

    # disp "All available units, be advised — possible suicide in progress, Greyvale High School. Female on rooftop."
    disp "全移動、警戒せよ。Greyvale Highにて自殺企図の可能性。屋上に女性一名。"

# game/script/ch02.rpy:214
translate japanese ch02_f40d29c8:

    # disp "Requesting immediate assistance. Local patrol en route, limited coverage. Time stamp, oh-seven-twelve."
    disp "至急の応援を要請する。地元パトロールが急行中、対応範囲は限定的。時刻、〇七一二。"

# game/script/ch02.rpy:215
translate japanese ch02_2b0750c7:

    # "Samuel's hand moved without thinking. He grabbed the mic from its cradle, its weight as familiar as the cigarette in his other hand."
    "Samuelの手は考えるより先に動いた。架台からマイクをつかむ。その重さは、もう片方の手の煙草と同じくらい馴染んでいた。"

# game/script/ch02.rpy:216
translate japanese ch02_89f9d307:

    # s stern "This is Detective Harris, badge four-one-seven. Copy on Greyvale call. I'm in proximity, off duty but available. I'll respond."
    s stern "こちらHarris刑事、バッジ番号四一七。Greyvaleの件、了解。近くにいる。非番だが対応可能。向かう。"

# game/script/ch02.rpy:218
translate japanese ch02_b2c15411:

    # disp "Copy, four-one-seven. Greyvale confirms. Proceed with caution. Advise once on scene."
    disp "了解、四一七。Greyvaleが確認した。慎重に向かえ。現着したら報告せよ。"

# game/script/ch02.rpy:219
translate japanese ch02_d20cf001:

    # s "Ten-four."
    s "了解。"

# game/script/ch02.rpy:220
translate japanese ch02_b83c0d5c:

    # "He took a drag and exhaled hard through his nose. The car seemed quieter now, the mountains less serene."
    "彼は一服し、鼻から強く息を吐いた。車内はさっきより静かに思え、山々はさっきほど穏やかには見えなかった。"

# game/script/ch02.rpy:221
translate japanese ch02_f944e31b:

    # "Maps recalculated toward the next exit. Greyvale lay twenty minutes north, tucked in the white folds of the hills."
    "地図が次の出口へ向けて経路を再計算した。Greyvaleは北へ二十分、丘陵の白い襞の中に抱えこまれていた。"

# game/script/ch02.rpy:230
translate japanese ch02_48688b86:

    # "Greyvale greeted him with the silence small towns carry during the holidays. Holiday lights clung to lampposts, tired in the gray morning."
    "Greyvaleは、小さな町が祝日に抱える静けさで彼を迎えた。祝祭の電飾が街灯にしがみつき、灰色の朝の中でくたびれていた。"

# game/script/ch02.rpy:231
translate japanese ch02_97277d60:

    # "At the dark brick of the high school the emptiness gave way: thirty or forty people pressed close despite the cold."
    "高校の黒ずんだ煉瓦の前で、その空っぽさが途切れた。寒さをものともせず、三十人か四十人が押し合っていた。"

# game/script/ch02.rpy:232
translate japanese ch02_5542fa2b:

    # "Two patrol cars at odd angles, lights spinning blue and red across the falling snow. Three officers trying to push the crowd back."
    "パトカーが二台、ちぐはぐな角度で停まり、降る雪に青と赤の光を回していた。三人の警官が群衆を押し戻そうとしていた。"

# game/script/ch02.rpy:233
translate japanese ch02_1157daba:

    # "He pulled the Yaris in just beyond the barricade. The air was sharp enough to sting his lungs."
    "彼はバリケードのすぐ先にヤリスを入れた。空気は肺を刺すほど鋭かった。"

# game/script/ch02.rpy:234
translate japanese ch02_06235c91:

    # "One of the officers broke away and came toward him — midthirties, flushed red from the wind, his uniform dusted with snow. He extended a hand."
    "警官の一人が離れて、こちらへやってきた。三十代半ば、風で顔を赤くし、制服に雪をまぶしていた。彼は手を差し出した。"

# game/script/ch02.rpy:235
translate japanese ch02_006b5294:

    # officer "Detective Harris?"
    officer "Harris刑事ですか？"

# game/script/ch02.rpy:236
translate japanese ch02_e6631ca5:

    # s "That's me."
    s "そうだ。"

# game/script/ch02.rpy:237
translate japanese ch02_4764396f:

    # "The officer nodded in relief, as though a detective's presence might restore order. Samuel turned toward the crowd — curiosity, dread, morbid hunger."
    "警官は安堵したようにうなずいた。刑事がいれば秩序が戻るとでもいうように。Samuelは群衆のほうへ向き直った。好奇心、恐れ、病的な飢え。"

# game/script/ch02.rpy:238
translate japanese ch02_fc8f6c8c:

    # s stern "Go home, folks. This isn't a show. You've seen enough."
    s stern "帰ってください、皆さん。見世物じゃない。もう十分見たでしょう。"

# game/script/ch02.rpy:239
translate japanese ch02_edb543ca:

    # "Something in his tone worked where the pushing hadn't. Coats pulled tight; people shuffled away into the street, leaving a cleaner silence behind."
    "押しても効かなかったものが、彼の口調の何かで効いた。人々はコートの前をかき合わせ、足を引きずるように通りへ散っていき、あとにはもっと澄んだ沈黙が残った。"

# game/script/ch02.rpy:240
translate japanese ch02_9a513e20:

    # "As the last cluster drifted off, a girl lingered by the bike racks, too still for the freezing cold. Hair in her eyes."
    "最後のひと塊が流れ去るなか、自転車置き場のそばに一人の少女が残っていた。凍える寒さにしては、静かすぎた。髪が目にかかっていた。"

# game/script/ch02.rpy:245
translate japanese ch02_ac44656a:

    # "When Samuel glanced her way, she looked past him like he wasn't there."
    "Samuelがそちらを見ると、少女は彼などいないかのように、彼の向こうを見た。"

# game/script/ch02.rpy:246
translate japanese ch02_0055d32a:

    # "No hugging herself against the cold, no craning to see. A strange, still child, looking at nothing — or at all of it."
    "寒さに自分を抱きしめるでもなく、首を伸ばしてのぞきこむでもない。何も見ていない、あるいはそのすべてを見ている、奇妙に静かな子ども。"

# game/script/ch02.rpy:247
translate japanese ch02_efd9167a:

    # th "Shock. Kids go strange in shock."
    th "ショックだ。ショックを受けると、子どもはおかしくなる。"

# game/script/ch02.rpy:248
translate japanese ch02_a7c41a14:

    # "He filed it there. When he looked again, she was gone."
    "彼はそれをそこに整理してしまいこんだ。もう一度見たとき、少女はいなかった。"

# game/script/ch02.rpy:250
translate japanese ch02_6ad50e80:

    # "He kept his attention on the officer, on the tape, on the work. From the corner of his eye, a small shape by the bike racks."
    "彼は警官に、テープに、仕事に注意を向けつづけた。目の端に、自転車置き場のそばの小さな人影。"

# game/script/ch02.rpy:251
translate japanese ch02_8568647a:

    # "When he glanced her way, she looked past him like he wasn't there, and then she was gone."
    "そちらを見ると、少女は彼などいないかのように彼の向こうを見ていた。そして、いなくなった。"

# game/script/ch02.rpy:254
translate japanese ch02_077d46a4:

    # "Samuel let the cigarette between his fingers drop to the snow and nodded toward the schoolyard."
    "Samuelは指に挟んでいた煙草を雪に落とし、校庭のほうへ顎をしゃくった。"

# game/script/ch02.rpy:255
translate japanese ch02_b3839988:

    # s "Alright. Let's see it."
    s "よし。見せてもらおう。"

# game/script/ch02.rpy:258
translate japanese ch02_247565cc:

    # "The officer led him past the tape, boots crunching on frozen snow. Only the hum of idling patrol cars remained."
    "警官は彼をテープの内側へ案内した。凍った雪をブーツが踏みしだいた。残っているのは、アイドリングするパトカーの低い唸りだけだった。"

# game/script/ch02.rpy:259
translate japanese ch02_ed875555:

    # officer "She was one of the teachers here — Maria Mallory. Thirty-eight. Married. Two kids, both students at this school. Husband's at home with them now."
    officer "ここの教師の一人でした。Maria Mallory。三十八歳。既婚。子どもが二人、どちらもこの学校の生徒です。夫がいま、家で子どもたちと一緒にいます。"

# game/script/ch02.rpy:260
translate japanese ch02_fecb4f00:

    # "Samuel's face stayed flat. His hand slid into his coat and came out with a small notebook and pen."
    "Samuelの表情は平らなままだった。手がコートの中へ滑りこみ、小さな手帳とペンを持って出てきた。"

# game/script/ch02.rpy:262
translate japanese ch02_e56cf99d:

    # "The body lay a few yards ahead. Snow gathered around it, turning crimson where it met the blood."
    "遺体は数ヤード先に横たわっていた。そのまわりに雪が積もり、血に触れたところで深紅に変わっていた。"

# game/script/ch02.rpy:264
translate japanese ch02_30522bf1:

    # "Black leggings, a plain T-shirt. No coat, no sweater, nothing against the cold. Thin sneakers, the laces still tied neatly — but no socks."
    "黒いレギンスに、無地のTシャツ。コートもセーターもなく、寒さを防ぐものは何もない。薄いスニーカー。紐はまだきちんと結ばれている。だが、靴下はなかった。"

# game/script/ch02.rpy:265
translate japanese ch02_a2a7da1e:

    # "She had landed chest-down, arms bent beneath her. The face, pressed into the paving stones, was unrecognizable."
    "彼女は胸から落ち、両腕を体の下に折り曲げていた。敷石に押しつけられた顔は、見分けがつかなかった。"

# game/script/ch02.rpy:266
translate japanese ch02_d8ac5bda:

    # "No pockets. No purse. Nothing on the ground to suggest she had carried anything with her. Just the body, alone."
    "ポケットはない。バッグもない。何かを持っていたことをうかがわせるものは、地面に何もなかった。ただ遺体だけが、ひとつきりで。"

# game/script/ch02.rpy:268
translate japanese ch02_0b1cab42:

    # "Samuel crouched, the pad balanced on his knee, the pen scratching."
    "Samuelはしゃがみこみ、膝に手帳をのせた。ペンが紙を引っかいた。"

# game/script/ch02.rpy:269
translate japanese ch02_2eae2c16:

    # note_voice "Improper dress. No belongings. Sneakers, no socks."
    note_voice "不適切な服装。所持品なし。スニーカー、靴下なし。"

# game/script/ch02.rpy:271
translate japanese ch02_08ee7d96:

    # note_voice "Chest down, severe cranial deformation. Blood spread consistent with fall impact."
    note_voice "うつ伏せ、頭部の高度な変形。血の広がりは落下の衝撃と一致。"

# game/script/ch02.rpy:273
translate japanese ch02_c0f2378d:

    # "His breath fogged, mingling briefly with the faint steam still rising from the body's warmth. He closed the notebook and stood."
    "彼の息が白く曇り、遺体のぬくもりからまだかすかに立ちのぼる湯気と束の間まじりあった。彼は手帳を閉じて立ち上がった。"

# game/script/ch02.rpy:274
translate japanese ch02_6a001f71:

    # s "Family informed?"
    s "家族には知らせたか？"

# game/script/ch02.rpy:275
translate japanese ch02_6102de94:

    # officer "Yes. Husband's home with the kids. We've got a man there now. School psychologist too — helping the children handle it."
    officer "はい。夫が子どもたちと家にいます。いまうちの者が一人ついています。学校の心理士も。子どもたちのケアをしています。"

# game/script/ch02.rpy:276
translate japanese ch02_edf36554:

    # s "Did you know her? The family?"
    s "君は彼女を知っていたか？　あの家族を？"

# game/script/ch02.rpy:277
translate japanese ch02_686e0387:

    # officer "Yes. Greyvale's a small town — everybody knows everybody. Never had a single complaint from them. No disturbances, no calls."
    officer "ええ。Greyvaleは小さな町ですから、誰もが誰もを知っています。あの家から苦情が出たことは一度もありません。騒ぎも、通報も。"

# game/script/ch02.rpy:278
translate japanese ch02_24786a2c:

    # officer "Her husband works for the municipality. Maintains the public park, does seasonal work with the plantations."
    officer "夫は町役場に勤めています。公園の管理と、植林地の季節仕事をしています。"

# game/script/ch02.rpy:279
translate japanese ch02_142c6233:

    # s "And the kids?"
    s "子どもたちは？"

# game/script/ch02.rpy:280
translate japanese ch02_d4254858:

    # officer "Son's fourteen. Daughter's eleven."
    officer "息子が十四歳。娘が十一歳です。"

# game/script/ch02.rpy:281
translate japanese ch02_a34151b8:

    # "The words hung in the cold, heavier than the air itself."
    "その言葉は冷気の中に垂れこめた。空気そのものより重く。"

# game/script/ch02.rpy:282
translate japanese ch02_bd69f443:

    # "Samuel drew the last drag, then pressed the ember into the hollow of his palm where the snow had melted to slush. A sharp hiss, a curl of steam. He pocketed the butt."
    "Samuelは最後の一服を吸い、雪が溶けてぬかるみになった手のひらのくぼみに火種を押しつけた。鋭い音、ひと筋の湯気。彼は吸い殻をポケットにしまった。"

# game/script/ch02.rpy:283
translate japanese ch02_4d42a648:

    # s "Can you take me to the family?"
    s "家族のところへ連れていってもらえるか？"

# game/script/ch02.rpy:284
translate japanese ch02_0923d746:

    # officer "Of course, sir."
    officer "もちろんです。"

# game/script/ch02.rpy:285
translate japanese ch02_b9fb70ad:

    # s "Alright. Give me a minute, and we'll leave."
    s "よし。一分くれ。それから行こう。"

# game/script/ch02.rpy:290
translate japanese ch02_bd9d0445:

    # "Raymond picked up on the third ring."
    "Raymondは三度目の呼び出し音で出た。"

# game/script/ch02.rpy:291
translate japanese ch02_1ea13c02:

    # d "Sam? Don't tell me — you ran out of smokes again and need me to send an intern with a carton."
    d "Sam？　言うなよ。また煙草が切れて、インターンに一カートン届けさせろってんだろう。"

# game/script/ch02.rpy:292
translate japanese ch02_846e3c02:

    # "Samuel barked a laugh, loud enough to startle the officer beside him."
    "Samuelは声をあげて笑った。そばの警官がびくりとするほどの大声で。"

# game/script/ch02.rpy:293
translate japanese ch02_bc515825:

    # s "Ha! Not this time, Ray."
    s "はっ！　今回は違うよ、Ray。"

# game/script/ch02.rpy:294
translate japanese ch02_8190ffda:

    # s "I'm in Greyvale. Just walked a scene — female, mid-thirties, jumped from the high school roof. Married, two kids. Local force asked for support."
    s "いまGreyvaleにいる。現場を見てきたところだ。女性、三十代半ば、高校の屋上から飛び降りた。既婚、子ども二人。地元の署から応援要請があった。"

# game/script/ch02.rpy:295
translate japanese ch02_d3abec20:

    # d "Alright. I'll check who's available, get someone assigned to it."
    d "わかった。手の空いてるやつを確認して、誰か担当をつける。"

# game/script/ch02.rpy:296
translate japanese ch02_43598d9f:

    # s "No need. I'll take it."
    s "その必要はない。俺がやる。"

# game/script/ch02.rpy:297
translate japanese ch02_5480a32a:

    # "A pause, heavier this time."
    "間。今度はもっと重い。"

# game/script/ch02.rpy:298
translate japanese ch02_11cb59f6:

    # d "You sure about that, Sam? You're supposed to be on leave. You don't owe them your holiday."
    d "本気か、Sam？　お前は休暇中のはずだろう。あいつらに休みを差し出す義理はない。"

# game/script/ch02.rpy:299
translate japanese ch02_08585d3d:

    # s "I'm sure. It's straightforward. I can handle it."
    s "本気だ。単純な件だ。俺で片づく。"

# game/script/ch02.rpy:300
translate japanese ch02_03200b37:

    # d "After thirteen years of paperwork, you're begging me for a suicide case, huh?"
    d "十三年書類仕事をやってきて、自殺の案件をくれと俺に頼みこむのか、え？"

# game/script/ch02.rpy:301
translate japanese ch02_e9c62d94:

    # s "Something like that."
    s "そんなところだ。"

# game/script/ch02.rpy:302
translate japanese ch02_e5611742:

    # "He smiled faintly, though no one was there to see it."
    "彼はかすかに笑った。見ている者は誰もいなかったが。"

# game/script/ch02.rpy:303
translate japanese ch02_070d8359:

    # d "Alright, Harris. It's yours. Shouldn't be more than an open-and-shut. Get your notes in order, file the report, and don't make it into more than it is."
    d "わかった、Harris。お前の担当だ。開けてすぐ閉じる程度の件のはずだ。メモを整理して、報告書を出して、実際以上の話にするなよ。"

# game/script/ch02.rpy:304
translate japanese ch02_f9956746:

    # s "Understood."
    s "了解。"

# game/script/ch02.rpy:305
translate japanese ch02_d099c2d5:

    # d "Good man. Let me know if you need anything."
    d "それでいい。何か要るなら知らせろ。"

# game/script/ch02.rpy:306
translate japanese ch02_13758d79:

    # s "Copy that."
    s "了解だ。"

# game/script/ch02.rpy:308
translate japanese ch02_dfc72cc2:

    # s "Alright. Let's go meet the family."
    s "よし。家族に会いに行こう。"

# game/script/ch02.rpy:315
translate japanese ch02_ed74545f:

    # "Five minutes through narrow streets to a three-story block, the kind where every sound carried and every neighbor knew each other's business."
    "狭い通りを五分走ると、三階建ての集合住宅に着いた。どんな物音も筒抜けで、隣人どうしが互いの事情を知り尽くしている種類の建物だった。"

# game/script/ch02.rpy:316
translate japanese ch02_405ed574:

    # "The stairwell smelled of burnt wood, faint but sharp, clinging to the walls as they climbed. No one spoke."
    "階段室には焦げた木のにおいがした。かすかだが鋭く、のぼっていくあいだ壁にまとわりついていた。誰も口をきかなかった。"

# game/script/ch02.rpy:317
translate japanese ch02_2f1a5d79:

    # "On the second floor the door stood half-open. String lights around the archway; small ornaments arranged carefully across shelves and mantel."
    "二階で、扉が半分開いていた。アーチのまわりに電飾。小さなオーナメントが棚や暖炉の上に丁寧に並べられていた。"

# game/script/ch02.rpy:319
translate japanese ch02_dda4d5e7:

    # l "Detective Harris? I'm Officer Lara Whitfield."
    l "Harris刑事ですか？　Lara Whitfield巡査です。"

# game/script/ch02.rpy:320
translate japanese ch02_1c6582e4:

    # "Brisk but respectful. Samuel gave a short nod and stepped past her. His eyes went first to the man on the sofa."
    "きびきびしているが、礼を失していない。Samuelは短くうなずき、彼女の横を通り過ぎた。彼の目はまずソファの男へ向かった。"

# game/script/ch02.rpy:323
translate japanese ch02_179e1349:

    # "The husband sat forward, arms crossed tightly over his chest, staring into the space before him as though holding the silence together with his gaze."
    "夫は前かがみに座り、胸の前で固く腕を組み、目の前の空間を見つめていた。まるで視線で沈黙をつなぎとめているかのように。"

# game/script/ch02.rpy:324
translate japanese ch02_253b2660:

    # "Early forties, but grief aged him. His jaw was freshly shaved — the skin there lighter than the rest of his face. He usually wore a thick beard."
    "四十代前半だが、悲しみが彼を老けさせていた。顎はひげを剃ったばかりで、その部分の肌が顔のほかの部分より白かった。いつもは濃いひげを生やしているのだ。"

# game/script/ch02.rpy:325
translate japanese ch02_2f1529eb:

    # "Large, roughened hands, marked with cuts old and new. The hands of a man used to labor."
    "大きく、荒れた手。古い切り傷と新しい切り傷が刻まれていた。力仕事に慣れた男の手。"

# game/script/ch02.rpy:326
translate japanese ch02_c14aebb4:

    # "The place was tidy, every surface touched by holiday preparation. Stockings above the fireplace, each embroidered with a name."
    "部屋は片づいていて、どの面にも祝日の支度の手が入っていた。暖炉の上には靴下が下がり、それぞれに名前が刺繍してあった。"

# game/script/ch02.rpy:327
translate japanese ch02_ac9c73b6:

    # th "Family lived here. Not just people passing time under the same roof."
    th "ここには家族が暮らしていた。同じ屋根の下で時間をやり過ごすだけの人間たちではなく。"

# game/script/ch02.rpy:328
translate japanese ch02_b44c7513:

    # s "Detective Samuel Harris."
    s "Samuel Harris刑事です。"

# game/script/ch02.rpy:329
translate japanese ch02_7c8b98e8:

    # an "Andreas Mallory."
    an "Andreas Malloryです。"

# game/script/ch02.rpy:330
translate japanese ch02_e33ff42f:

    # "His grip was firm despite the tremor running through him. His voice thick, wavering but not broken."
    "体を震えが走っていたが、握手は力強かった。声はくぐもり、揺れていたが、崩れてはいなかった。"

# game/script/ch02.rpy:331
translate japanese ch02_09b54272:

    # s "Mr. Mallory, I can't pretend to know your grief. But for the sake of you and your children, I need you to focus now. Help me with what you can, while it's fresh."
    s "Malloryさん、あなたの悲しみがわかるふりはできません。ですが、あなたとお子さんたちのために、いまは集中していただきたい。記憶が新しいうちに、できることで力を貸してください。"

# game/script/ch02.rpy:332
translate japanese ch02_c8a89491:

    # "Andreas nodded quickly, almost gratefully, as though the structure of a request gave him something solid to hold."
    "Andreasはすばやく、ほとんど感謝するようにうなずいた。頼みごとという枠組みが、つかまるための確かなものを与えてくれたかのように。"

# game/script/ch02.rpy:333
translate japanese ch02_67c4483b:

    # an "Of course. Anything you need."
    an "もちろんです。何でもおっしゃってください。"

# game/script/ch02.rpy:334
translate japanese ch02_740a9b0b:

    # s "Do you mind if I record this? Just for accuracy."
    s "録音してもかまいませんか？　正確を期すためだけです。"

# game/script/ch02.rpy:335
translate japanese ch02_cfc160ee:

    # an "No... no, go ahead."
    an "いえ……いえ、どうぞ。"

# game/script/ch02.rpy:336
translate japanese ch02_a648785b:

    # "Samuel set the phone recording on the coffee table between them, clicked his pen once, notebook open in his lap."
    "Samuelは録音中の電話を二人のあいだのコーヒーテーブルに置き、ペンを一度カチリと鳴らした。手帳は膝の上に開いていた。"

# game/script/ch02.rpy:337
translate japanese ch02_68bfabb5:

    # s "Did you see Maria today? Before she left the house?"
    s "今日、Mariaさんに会いましたか？　彼女が家を出る前に？"

# game/script/ch02.rpy:338
translate japanese ch02_4897ce93:

    # an "Yes. We... we had breakfast together. Me, her, and the kids."
    an "はい。一緒に……一緒に朝食をとりました。私と、妻と、子どもたちで。"

# game/script/ch02.rpy:343
translate japanese ch02_5690027c:

    # "Shaved. This morning, close, the skin still pale along the jaw. He had made himself presentable for a family breakfast."
    "剃っている。今朝、深剃りで、顎に沿った肌がまだ白い。家族の朝食のために、身なりを整えたのだ。"

# game/script/ch02.rpy:349
translate japanese ch02_b6afbfe9:

    # s "And then what happened?"
    s "それから、何がありました？"

# game/script/ch02.rpy:350
translate japanese ch02_557bab0a:

    # an "We went to light the fireplace — me and the kids. Maria stayed behind to wash the dishes. Just quick, she said."
    an "暖炉に火を入れに行ったんです。私と子どもたちで。Mariaは残って皿を洗うと。すぐ済むから、と言って。"

# game/script/ch02.rpy:351
translate japanese ch02_dcf99037:

    # an "After a while I heard the main door close. I thought she'd gone to throw the trash out... so I waited. But she didn't come back."
    an "しばらくして、玄関の扉が閉まる音がしました。ゴミを出しに行ったんだと思って……それで待っていたんです。でも、戻ってこなかった。"

# game/script/ch02.rpy:352
translate japanese ch02_c33db353:

    # an "Her phone was still here. She never went anywhere without it."
    an "電話はここに置いたままでした。あれを持たずにどこかへ行くことなんて、なかったのに。"

# game/script/ch02.rpy:353
translate japanese ch02_c6a4e08b:

    # an "Maria... why — why would she..."
    an "Maria……どうして……どうして、あいつが……"

# game/script/ch02.rpy:354
translate japanese ch02_1706b52a:

    # "His words dissolved. Samuel watched the trembling hands, the collapse of posture, the raw confusion in every feature."
    "言葉は溶けて消えた。Samuelは震える両手を、崩れていく姿勢を、顔のあらゆる部分に出ている生々しい混乱を見ていた。"

# game/script/ch02.rpy:355
translate japanese ch02_69aee30c:

    # th "No performance. The grief is sincere."
    th "芝居じゃない。悲しみは本物だ。"

# game/script/ch02.rpy:359
translate japanese ch02_5ba42682:

    # s "Did you argue with her recently?"
    s "最近、彼女と口論をしましたか？"

# game/script/ch02.rpy:360
translate japanese ch02_d205fcb8:

    # an "Yes. We did. She was tense, I wanted her to relax, enjoy the holidays with the kids..."
    an "はい。しました。あいつは張りつめていて、私は気を楽にしてほしかったんです。子どもたちと休みを楽しんでほしくて……"

# game/script/ch02.rpy:361
translate japanese ch02_e4f7a87c:

    # "His voice cracked. He pressed his hands to his face, then forced them down again."
    "声がひび割れた。彼は両手で顔を押さえ、それから無理やり下ろした。"

# game/script/ch02.rpy:362
translate japanese ch02_ba893ed8:

    # s "And her behavior? Did you notice anything different, recently?"
    s "彼女の様子はどうでした？　最近、何か変わったことに気づきましたか？"

# game/script/ch02.rpy:363
translate japanese ch02_fa8fb7e9:

    # an "I... I don't know. She was stressed, but Maria was always like that. Even when things were good, she worried. She carried too much inside. But nothing like—"
    an "わ……わかりません。ストレスを抱えてはいましたが、Mariaはいつもそうでした。うまくいっているときでも心配していた。内に抱えこみすぎるんです。でも、こんな――"

# game/script/ch02.rpy:364
translate japanese ch02_f0ce3779:

    # "He stopped himself. Panic crossed his face, closer to guilt than certainty."
    "彼は自分で言葉を止めた。顔に狼狽がよぎった。確信というより、罪悪感に近い狼狽が。"

# game/script/ch02.rpy:365
translate japanese ch02_8ec6eda5:

    # th "A man who hadn't paid close attention, now punishing himself for it."
    th "ちゃんと見ていなかった男が、いまそのことで自分を罰している。"

# game/script/ch02.rpy:366
translate japanese ch02_3950678e:

    # s "Was she taking any medication? Seeing a therapist?"
    s "何か薬を飲んでいましたか？　セラピストにかかっていたとか？"

# game/script/ch02.rpy:367
translate japanese ch02_9315de88:

    # an "No. Nothing like that."
    an "いいえ。そういうことは何も。"

# game/script/ch02.rpy:368
translate japanese ch02_4ce6d4b9:

    # "Samuel wrote it down. Andreas's shoulders folded forward."
    "Samuelはそれを書きとめた。Andreasの肩が前へ折れた。"

# game/script/ch02.rpy:369
translate japanese ch02_2c647313:

    # an "We both said things, I—"
    an "お互いに、いろいろ言ってしまって、私は――"

# game/script/ch02.rpy:370
translate japanese ch02_d03af9a1:

    # "The tears came, sudden and rough."
    "涙が来た。突然に、荒々しく。"

# game/script/ch02.rpy:372
translate japanese ch02_e0725b66:

    # s "Did you notice anything different in her behavior recently?"
    s "最近、彼女の様子で何か変わったことに気づきましたか？"

# game/script/ch02.rpy:373
translate japanese ch02_fa8fb7e9_1:

    # an "I... I don't know. She was stressed, but Maria was always like that. Even when things were good, she worried. She carried too much inside. But nothing like—"
    an "わ……わかりません。ストレスを抱えてはいましたが、Mariaはいつもそうでした。うまくいっているときでも心配していた。内に抱えこみすぎるんです。でも、こんな――"

# game/script/ch02.rpy:374
translate japanese ch02_f0ce3779_1:

    # "He stopped himself. Panic crossed his face, closer to guilt than certainty."
    "彼は自分で言葉を止めた。顔に狼狽がよぎった。確信というより、罪悪感に近い狼狽が。"

# game/script/ch02.rpy:375
translate japanese ch02_8ec6eda5_1:

    # th "A man who hadn't paid close attention, now punishing himself for it."
    th "ちゃんと見ていなかった男が、いまそのことで自分を罰している。"

# game/script/ch02.rpy:376
translate japanese ch02_3950678e_1:

    # s "Was she taking any medication? Seeing a therapist?"
    s "何か薬を飲んでいましたか？　セラピストにかかっていたとか？"

# game/script/ch02.rpy:377
translate japanese ch02_9315de88_1:

    # an "No. Nothing like that."
    an "いいえ。そういうことは何も。"

# game/script/ch02.rpy:378
translate japanese ch02_7fa56d15:

    # s "I see. Did you argue with her recently?"
    s "なるほど。最近、彼女と口論をしましたか？"

# game/script/ch02.rpy:379
translate japanese ch02_e588e656:

    # "Andreas's eyes clouded, his jaw tightening."
    "Andreasの目が曇り、顎がこわばった。"

# game/script/ch02.rpy:380
translate japanese ch02_d205fcb8_1:

    # an "Yes. We did. She was tense, I wanted her to relax, enjoy the holidays with the kids..."
    an "はい。しました。あいつは張りつめていて、私は気を楽にしてほしかったんです。子どもたちと休みを楽しんでほしくて……"

# game/script/ch02.rpy:381
translate japanese ch02_2c647313_1:

    # an "We both said things, I—"
    an "お互いに、いろいろ言ってしまって、私は――"

# game/script/ch02.rpy:382
translate japanese ch02_4249b7b4:

    # "His body folded forward and the tears came, sudden and rough."
    "体が前へ折れ、涙が来た。突然に、荒々しく。"

# game/script/ch02.rpy:384
translate japanese ch02_67ad16dc:

    # s soft "It's alright. I heard what I needed to."
    s soft "大丈夫です。必要なことは聞けました。"

# game/script/ch02.rpy:385
translate japanese ch02_95d274ee:

    # "He ended the recording and slipped the phone back into his coat."
    "彼は録音を止め、電話をコートに戻した。"

# game/script/ch02.rpy:386
translate japanese ch02_48b6173a:

    # s "I'll take a look around, if that's alright with you."
    s "よろしければ、少し見て回らせてもらいます。"

# game/script/ch02.rpy:387
translate japanese ch02_39d6554b:

    # an "Of course."
    an "もちろんです。"

# game/script/ch02.rpy:395
translate japanese ch02_9db62ae0:

    # "The kitchen still carried the scent of pancakes, butter, and sugar — a sweetness clinging to the air like a ghost."
    "台所にはまだパンケーキとバターと砂糖の香りが残っていた。幽霊のように空気にまとわりつく甘さ。"

# game/script/ch02.rpy:396
translate japanese ch02_2996495d:

    # "Juice in glasses, a half-finished cake, toast stacked neatly, croissants in a dish. A spread meant for a holiday morning, for family."
    "グラスに注がれたジュース、食べかけのケーキ、きちんと積まれたトースト、皿に盛られたクロワッサン。祝日の朝のための、家族のための食卓。"

# game/script/ch02.rpy:397
translate japanese ch02_4f061ef1:

    # "Samuel checked the sink. The dishes were not washed, contrary to Andreas's words. Plates piled neatly, untouched."
    "Samuelは流しを確かめた。Andreasの言葉に反して、皿は洗われていなかった。きちんと重ねられ、手つかずのまま。"

# game/script/ch02.rpy:398
translate japanese ch02_f373d61d:

    # note_voice "Meal prepared. Not cleaned. Suggests planning. Possible farewell."
    note_voice "食事の用意あり。片づけなし。計画性を示唆。別れの食事の可能性。"

# game/script/ch02.rpy:402
translate japanese ch02_7b661935:

    # "Down the hallway: three doors. The bathroom — clean, organized, nothing out of place."
    "廊下の先に扉が三つ。浴室。清潔で整頓され、何ひとつ乱れていない。"

# game/script/ch02.rpy:403
translate japanese ch02_32657482:

    # "The second on the right — children's voices. Muffled talk, quiet sobbing. He paused, then shook his head slightly."
    "右手の二つめ。子どもたちの声。くぐもった話し声、静かなすすり泣き。彼は足を止め、それから小さく首を振った。"

# game/script/ch02.rpy:404
translate japanese ch02_640ced4c:

    # th "Not yet."
    th "まだだ。"

# game/script/ch02.rpy:405
translate japanese ch02_0a968a03:

    # "The couple's bedroom: the air still, the bedspread tucked, side tables bare but for a lamp and a framed photograph."
    "夫婦の寝室。空気は動かず、ベッドカバーはきちんと折りこまれ、サイドテーブルにはランプと額入りの写真のほかには何もなかった。"

# game/script/ch02.rpy:406
translate japanese ch02_f0eccff7:

    # "Everything polished, arranged. No notes, no discarded items, no trace of disarray."
    "すべてが磨かれ、整えられていた。書き置きも、捨てられた物も、乱れの痕跡もない。"

# game/script/ch02.rpy:409
translate japanese ch02_e9eb25c7:

    # "At the children's room the psychologist rose and came to him, whispering."
    "子ども部屋の前で、心理士が立ち上がって彼のところへ来て、ささやいた。"

# game/script/ch02.rpy:410
translate japanese ch02_4b223dcd:

    # woman "Detective Harris? I'd recommend not questioning them right now. They're devastated."
    woman "Harris刑事？　いまは質問しないことをお勧めします。あの子たち、打ちのめされているんです。"

# game/script/ch02.rpy:411
translate japanese ch02_9062bf44:

    # s soft "I won't press hard. Just a few questions. It may help."
    s soft "強くは訊きません。少し質問するだけです。助けになるかもしれない。"

# game/script/ch02.rpy:412
translate japanese ch02_64d56fff:

    # "She hesitated, then gave a reluctant nod and stepped aside."
    "彼女はためらい、それから渋々うなずいて脇へ退いた。"

# game/script/ch02.rpy:413
translate japanese ch02_3369bc2f:

    # "The two children sat together on one bed. The boy kept his fists clenched on his knees, jaw rigid, eyes on the floor."
    "二人の子どもは一つのベッドに並んで座っていた。少年は膝の上で拳を握りしめ、顎をこわばらせ、目を床に落としていた。"

# game/script/ch02.rpy:414
translate japanese ch02_88de9387:

    # "Beside him his younger sister murmured softly to herself, voice broken by sobs, her hair hanging into her face."
    "その隣で妹が小さく独り言をつぶやいていた。声はすすり泣きで途切れ、髪が顔に垂れかかっていた。"

# game/script/ch02.rpy:415
translate japanese ch02_c05b0bb5:

    # "Samuel lowered himself to one knee so his eyes were level with theirs. His tone shifted — quiet, curious, soft."
    "Samuelは片膝をつき、目の高さを二人に合わせた。口調が変わった。静かで、関心をこめた、柔らかな口調に。"

# game/script/ch02.rpy:416
translate japanese ch02_366c2576:

    # s soft "What's your name?"
    s soft "名前は？"

# game/script/ch02.rpy:417
translate japanese ch02_b50a46ff:

    # tonia "Tonia."
    tonia "Tonia。"

# game/script/ch02.rpy:418
translate japanese ch02_71a8857b:

    # s "And you, young man? What's your name?"
    s "君は？　名前は何ていうんだい？"

# game/script/ch02.rpy:419
translate japanese ch02_e730e520:

    # tim "Tim."
    tim "Tim。"

# game/script/ch02.rpy:420
translate japanese ch02_14f4793e:

    # "Their eyes did not meet his, nor each other's. Grief had sealed them inward."
    "二人の目は彼とも、互いとも合わなかった。悲しみが二人を内側へ封じこめていた。"

# game/script/ch02.rpy:427
translate japanese ch02_a36b8e4d:

    # "Not only grief in the boy. Anger, with nowhere to go, and he was holding it the way you hold a thing for someone smaller."
    "少年の中にあるのは悲しみだけではなかった。行き場のない怒り。そして彼はそれを、自分より小さな誰かのために物を抱えるようにして抱えていた。"

# game/script/ch02.rpy:430
translate japanese ch02_3408a1f3:

    # s "I won't take much of your time. I just want to know if your mother was doing anything new these last weeks. Anything she spent extra time on?"
    s "長くはかからないよ。この何週間か、お母さんが何か新しいことをしていなかったか知りたいだけなんだ。特に時間をかけていたことはあったかい？"

# game/script/ch02.rpy:431
translate japanese ch02_65bc5ba9:

    # "Tim's knuckles whitened. He spoke without lifting his gaze."
    "Timの拳の関節が白くなった。彼は視線を上げないまま話した。"

# game/script/ch02.rpy:432
translate japanese ch02_5c5c2568:

    # tim "She stayed after school sometimes. Said she was helping some of the older kids. Tutoring."
    tim "ときどき放課後に残ってた。上の学年の子を手伝ってるって。家庭教師みたいなこと。"

# game/script/ch02.rpy:433
translate japanese ch02_68f6c4a1:

    # tonia "Math and... history, I think. She was helping. She always wanted to help."
    tonia "数学と……歴史、だったと思う。手伝ってたの。ママはいつも、人を助けたがってた。"

# game/script/ch02.rpy:434
translate japanese ch02_51747220:

    # "Her small voice cracked. Samuel wrote the words carefully, his eyes never leaving the children."
    "小さな声がひび割れた。Samuelはその言葉を丁寧に書きとめた。目は一度も子どもたちから離れなかった。"

# game/script/ch02.rpy:436
translate japanese ch02_478c4d28:

    # s soft "She was proud of you both. That much I can see."
    s soft "お母さんは、君たち二人を誇りに思っていたよ。それだけは、私にもわかる。"

# game/script/ch02.rpy:437
translate japanese ch02_65722fa0:

    # "Neither answered, but Tonia leaned into her brother's shoulder, and Tim's fists slowly unclenched, just a little."
    "どちらも答えなかった。だがToniaは兄の肩にもたれかかり、Timの拳はゆっくりと、ほんの少しだけほどけた。"

# game/script/ch02.rpy:442
translate japanese ch02_dc805c18:

    # s "I'll need her phone."
    s "奥さんの電話をお預かりする必要があります。"

# game/script/ch02.rpy:443
translate japanese ch02_c315652c:

    # "Andreas reached for the coffee table drawer, hands trembling as he passed it over."
    "Andreasはコーヒーテーブルの引き出しに手を伸ばし、震える手でそれを渡した。"

# game/script/ch02.rpy:444
translate japanese ch02_1f3cba37:

    # an "Here. Pin 9877."
    an "どうぞ。暗証番号は9877です。"

# game/script/ch02.rpy:445
translate japanese ch02_cbde7394:

    # "Lara Whitfield produced an evidence bag. Samuel slid the device in."
    "Lara Whitfieldが証拠品袋を差し出した。Samuelは端末を滑りこませた。"

# game/script/ch02.rpy:446
translate japanese ch02_523f5976:

    # s "Log it to me on a property receipt. I'll start with exigent review and get a warrant in motion."
    s "私の名前で押収品受領書に記録してくれ。まず緊急措置として内容を確認し、令状の手続きを進める。"

# game/script/ch02.rpy:447
translate japanese ch02_27aa8324:

    # l "Yes sir."
    l "はい。"

# game/script/ch02.rpy:449
translate japanese ch02_2d89e840:

    # note_voice "Phone left behind."
    note_voice "電話、置いたまま。"

# game/script/ch02.rpy:458
translate japanese ch02_0d8841f8:

    # "He texted Doyle to authorize exigent review of the victim's cell phone. A blunt {i}Ok{/i} came back a few seconds later."
    "彼はDoyleにメッセージを送り、被害者の携帯電話を緊急措置として確認する許可を求めた。数秒後、素っ気ない{i}OK{/i}が返ってきた。"

# game/script/ch02.rpy:459
translate japanese ch02_70c17ef7:

    # "Down the narrow stairwell, the burnt-wood smell still clinging to the walls, and out into the cold. Snow had thickened, heavy flakes muffling the world."
    "狭い階段を下りた。焦げた木のにおいはまだ壁にまとわりついていた。そして寒さの中へ出た。雪は厚みを増し、重い雪片が世界の音を消していた。"

# game/script/ch02.rpy:460
translate japanese ch02_cda63e72:

    # "Samuel cupped his lighter against the wind and brought flame to another Marlboro."
    "Samuelは風からライターを手で囲い、新しいマルボロに火をつけた。"

# game/script/ch02.rpy:461
translate japanese ch02_90609302:

    # officer "What now?"
    officer "これからどうします？"

# game/script/ch02.rpy:462
translate japanese ch02_2d7264c5:

    # s "I'll need somewhere to stay. And I'll need the names of the students she was tutoring. Addresses too."
    s "泊まる場所が要る。それと、彼女が教えていた生徒の名前も。住所もだ。"

# game/script/ch02.rpy:463
translate japanese ch02_8c01c5d4:

    # officer "I'll see to it. As for a place — there's a small hotel up the hill, near the main square. It's the only one in town."
    officer "手配します。宿なら、丘の上の中央広場の近くに小さなホテルがあります。町で唯一のホテルです。"

# game/script/ch02.rpy:464
translate japanese ch02_6a6f2071:

    # s "Good. Appreciate it."
    s "よし。助かる。"

# game/script/ch02.rpy:466
translate japanese ch02_0c0f81c5:

    # "He gave the officer a short nod of thanks, then turned and walked away, the cigarette burning steady between his fingers as the snow closed in around his tall figure."
    "彼は警官に短くうなずいて礼を示し、それから背を向けて歩き去った。指のあいだで煙草が静かに燃えつづけ、雪が彼の長身を包みこんでいった。"

translate japanese strings:

    # game/script/ch02.rpy:112
    old "Tell her the truth."
    new "本当のことを言う。"

    # game/script/ch02.rpy:119
    old "Give her the practiced lie."
    new "言い慣れた嘘をつく。"

    # game/script/ch02.rpy:243
    old "Look at the girl by the bike racks."
    new "自転車置き場の少女を見る。"

    # game/script/ch02.rpy:249
    old "Keep your eyes on the officer."
    new "警官から目を離さない。"

    # game/script/ch02.rpy:341
    old "His jaw."
    new "顎。"

    # game/script/ch02.rpy:344
    old "His hands."
    new "手。"

    # game/script/ch02.rpy:346
    old "His eyes."
    new "目。"

    # game/script/ch02.rpy:358
    old "Ask about the argument first."
    new "先に口論のことを訊く。"

    # game/script/ch02.rpy:371
    old "Ask about her behavior first."
    new "先に彼女の様子を訊く。"

    # game/script/ch02.rpy:423
    old "The girl's voice."
    new "少女の声。"

    # game/script/ch02.rpy:425
    old "The boy's fists."
    new "少年の拳。"

    # game/script/ch02.rpy:428
    old "The space between them."
    new "二人のあいだの距離。"

