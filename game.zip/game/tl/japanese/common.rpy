# TODO: Translation updated at 2026-10-11 10:23

translate japanese strings:

    # renpy/common/000statements.rpy:28
    old "Click to play the video."
    new "クリックで動画を再生します。"

    # renpy/common/00accessibility.rpy:28
    old "Self-voicing disabled."
    new "セルフボイシング無効化。"

    # renpy/common/00accessibility.rpy:29
    old "Clipboard voicing enabled. "
    new "クリップボードボイシング有効化。"

    # renpy/common/00accessibility.rpy:30
    old "Self-voicing enabled. "
    new "セルフボイシング有効化。"

    # renpy/common/00accessibility.rpy:32
    old "bar"
    new "バー"

    # renpy/common/00accessibility.rpy:33
    old "selected"
    new "選択中"

    # renpy/common/00accessibility.rpy:34
    old "viewport"
    new "ビューポート"

    # renpy/common/00accessibility.rpy:35
    old "horizontal scroll"
    new "水平スクロール"

    # renpy/common/00accessibility.rpy:36
    old "vertical scroll"
    new "垂直スクロール"

    # renpy/common/00accessibility.rpy:37
    old "activate"
    new "有効"

    # renpy/common/00accessibility.rpy:38
    old "deactivate"
    new "無効"

    # renpy/common/00accessibility.rpy:39
    old "increase"
    new "増加"

    # renpy/common/00accessibility.rpy:40
    old "decrease"
    new "減少"

    # renpy/common/00accessibility.rpy:134
    old "Self-Voicing"
    new "セルフボイシング"

    # renpy/common/00accessibility.rpy:137
    old "Self-voicing support is limited when using a touch screen."
    new "セルフボイシングのサポートはタッチスクリーン使用時に限定されます"

    # renpy/common/00accessibility.rpy:139
    old "Off"
    new "オフ"

    # renpy/common/00accessibility.rpy:143
    old "Text-to-speech"
    new "テキストを読む"

    # renpy/common/00accessibility.rpy:147
    old "Clipboard"
    new "クリップボード"

    # renpy/common/00accessibility.rpy:151
    old "Debug"
    new "デバッグ"

    # renpy/common/00accessibility.rpy:163
    old "Reset"
    new "リセット"

    # renpy/common/00accessibility.rpy:167
    old "Self-Voicing Volume Drop"
    new "セルフボイシングボリューム低減"

    # renpy/common/00accessibility.rpy:180
    old "Mono Audio"
    new "モノラル音声"

    # renpy/common/00accessibility.rpy:182
    old "Enable"
    new "有効"

    # renpy/common/00accessibility.rpy:186
    old "Disable"
    new "無効"

    # renpy/common/00accessibility.rpy:198
    old "Font Override"
    new "フォントオーバーライド"

    # renpy/common/00accessibility.rpy:200
    old "Default"
    new "デフォルト"

    # renpy/common/00accessibility.rpy:204
    old "DejaVu Sans"
    new "DejaVu Sans"

    # renpy/common/00accessibility.rpy:208
    old "Opendyslexic"
    new "Opendyslexic"

    # renpy/common/00accessibility.rpy:212
    old "High Contrast Text"
    new "ハイコントラストテキスト"

    # renpy/common/00accessibility.rpy:224
    old "Text Size Scaling"
    new "テキストサイズのスケーリング"

    # renpy/common/00accessibility.rpy:235
    old "Line Spacing Scaling"
    new "行間のスケーリング"

    # renpy/common/00accessibility.rpy:246
    old "Kerning"
    new "カーニング"

    # renpy/common/00accessibility.rpy:267
    old "Accessibility Menu. Use up and down arrows to navigate, and enter to activate buttons and bars."
    new "アクセシビリティーメニュー。上下矢印キーをナビゲーションに使用し、ボタンとバーのアクティブ化にはエンターを使用します"

    # renpy/common/00accessibility.rpy:288
    old "Self-Voicing and Audio"
    new "セルフボイシングと音声"

    # renpy/common/00accessibility.rpy:292
    old "Text"
    new "テキスト"

    # renpy/common/00accessibility.rpy:306
    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "このメニューのオプションはアクセシビリティーを改善するためのものです。すべてのゲームで動作するわけではなく、特定の組合せではゲームを正常にレンダリングしないでしょう。これはゲームやエンジンの問題ではありません。フォント変更時に最良の結果を得るには、テキストサイズをオリジナルのままにしてください。"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Monday"
    new "{#weekday}月曜日"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Tuesday"
    new "{#weekday}火曜日"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Wednesday"
    new "{#weekday}水曜日"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Thursday"
    new "{#weekday}木曜日"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Friday"
    new "{#weekday}金曜日"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Saturday"
    new "{#weekday}土曜日"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Sunday"
    new "{#weekday}日曜日"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Mon"
    new "{#weekday_short}月"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Tue"
    new "{#weekday_short}火"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Wed"
    new "{#weekday_short}水"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Thu"
    new "{#weekday_short}木"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Fri"
    new "{#weekday_short}金"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sat"
    new "{#weekday_short}土"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sun"
    new "{#weekday_short}日"

    # renpy/common/00action_file.rpy:47
    old "{#month}January"
    new "{#month}１月"

    # renpy/common/00action_file.rpy:47
    old "{#month}February"
    new "{#month}２月"

    # renpy/common/00action_file.rpy:47
    old "{#month}March"
    new "{#month}３月"

    # renpy/common/00action_file.rpy:47
    old "{#month}April"
    new "{#month}４月"

    # renpy/common/00action_file.rpy:47
    old "{#month}May"
    new "{#month}５月"

    # renpy/common/00action_file.rpy:47
    old "{#month}June"
    new "{#month}６月"

    # renpy/common/00action_file.rpy:47
    old "{#month}July"
    new "{#month}７月"

    # renpy/common/00action_file.rpy:47
    old "{#month}August"
    new "{#month}８月"

    # renpy/common/00action_file.rpy:47
    old "{#month}September"
    new "{#month}９月"

    # renpy/common/00action_file.rpy:47
    old "{#month}October"
    new "{#month}１０月"

    # renpy/common/00action_file.rpy:47
    old "{#month}November"
    new "{#month}１１月"

    # renpy/common/00action_file.rpy:47
    old "{#month}December"
    new "{#month}１２月"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jan"
    new "{#month_short}１月"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Feb"
    new "{#month_short}２月"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Mar"
    new "{#month_short}３月"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Apr"
    new "{#month_short}４月"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}May"
    new "{#month_short}５月"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jun"
    new "{#month_short}６月"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jul"
    new "{#month_short}７月"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Aug"
    new "{#month_short}８月"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Sep"
    new "{#month_short}９月"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Oct"
    new "{#month_short}１０月"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Nov"
    new "{#month_short}１１月"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Dec"
    new "{#month_short}１２月"

    # renpy/common/00action_file.rpy:258
    old "%b %d, %H:%M"
    new "%m月%d日, %H:%M"

    # renpy/common/00action_file.rpy:395
    old "Save slot %s: [text]"
    new "スロット%s: [text]にセーブ"

    # renpy/common/00action_file.rpy:481
    old "Load slot %s: [text]"
    new "スロット%s: [text]をロード"

    # renpy/common/00action_file.rpy:534
    old "Delete slot [text]"
    new "スロット[text]を削除"

    # renpy/common/00action_file.rpy:613
    old "File page auto"
    new "オートファイルページ"

    # renpy/common/00action_file.rpy:615
    old "File page quick"
    new "クイックファイルページ"

    # renpy/common/00action_file.rpy:617
    old "File page [text]"
    new "ファイルページ[text]"

    # renpy/common/00action_file.rpy:816
    old "Next file page."
    new "次のファイルページ"

    # renpy/common/00action_file.rpy:888
    old "Previous file page."
    new "前のファイルページ"

    # renpy/common/00action_file.rpy:949
    old "Quick save complete."
    new "クイックセーブ完了。"

    # renpy/common/00action_file.rpy:964
    old "Quick save."
    new "クイックセーブ"

    # renpy/common/00action_file.rpy:983
    old "Quick load."
    new "クイックロード"

    # renpy/common/00action_other.rpy:416
    old "Language [text]"
    new "言語 [text]"

    # renpy/common/00action_other.rpy:786
    old "Open [text] directory."
    new "[text]ディレクトリを開く。"

    # renpy/common/00director.rpy:712
    old "The interactive director is not enabled here."
    new "ここではインタラクティブディレクターは使えません"

    # renpy/common/00director.rpy:1512
    old "⬆"
    new "⬆"

    # renpy/common/00director.rpy:1518
    old "⬇"
    new "⬇"

    # renpy/common/00director.rpy:1582
    old "Done"
    new "終了"

    # renpy/common/00director.rpy:1592
    old "(statement)"
    new "(ステートメント)"

    # renpy/common/00director.rpy:1593
    old "(tag)"
    new "(タグ)"

    # renpy/common/00director.rpy:1594
    old "(attributes)"
    new "(属性)"

    # renpy/common/00director.rpy:1595
    old "(transform)"
    new "（トランスフォーム）"

    # renpy/common/00director.rpy:1620
    old "(transition)"
    new "（トランジション）"

    # renpy/common/00director.rpy:1632
    old "(channel)"
    new "(チャンネル)"

    # renpy/common/00director.rpy:1633
    old "(filename)"
    new "(ファイル名)"

    # renpy/common/00director.rpy:1662
    old "Change"
    new "変更"

    # renpy/common/00director.rpy:1664
    old "Add"
    new "追加"

    # renpy/common/00director.rpy:1667
    old "Cancel"
    new "キャンセル"

    # renpy/common/00director.rpy:1670
    old "Remove"
    new "削除"

    # renpy/common/00director.rpy:1705
    old "Statement:"
    new "ステートメント:"

    # renpy/common/00director.rpy:1726
    old "Tag:"
    new "画像タグ:"

    # renpy/common/00director.rpy:1742
    old "Attributes:"
    new "画像属性:"

    # renpy/common/00director.rpy:1753
    old "Click to toggle attribute, right click to toggle negative attribute."
    new "クリックすると属性が切り替わり、右クリックすると負の属性が切り替わります。"

    # renpy/common/00director.rpy:1765
    old "Transforms:"
    new "変換:"

    # renpy/common/00director.rpy:1776
    old "Click to set transform, right click to add to transform list."
    new "クリックでトランスフォームを設定し、右クリックでトランスフォームリストに追加します。"

    # renpy/common/00director.rpy:1777
    old "Customize director.transforms to add more transforms."
    new "director.transform を設定して transform を追加できます。"

    # renpy/common/00director.rpy:1789
    old "Behind:"
    new "背後に表示:"

    # renpy/common/00director.rpy:1800
    old "Click to set, right click to add to behind list."
    new "クリックで設定、右クリックで背後のリストに追加します。"

    # renpy/common/00director.rpy:1812
    old "Transition:"
    new "トランジション:"

    # renpy/common/00director.rpy:1822
    old "Click to set."
    new "クリックで設定します"

    # renpy/common/00director.rpy:1823
    old "Customize director.transitions to add more transitions."
    new "director.transitions を設定してトランジションを追加できます。"

    # renpy/common/00director.rpy:1835
    old "Channel:"
    new "チャンネル:"

    # renpy/common/00director.rpy:1846
    old "Customize director.audio_channels to add more channels."
    new "director.audio_channels を設定してチャンネルを追加できます"

    # renpy/common/00director.rpy:1858
    old "Audio Filename:"
    new "オーディオファイルネーム:"

    # renpy/common/00gui.rpy:448
    old "Are you sure?"
    new "続けますか？"

    # renpy/common/00gui.rpy:449
    old "Are you sure you want to delete this save?"
    new "このセーブデータを消去しますか？"

    # renpy/common/00gui.rpy:450
    old "Are you sure you want to overwrite your save?"
    new "このセーブデータに上書きしますか？"

    # renpy/common/00gui.rpy:451
    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "ロードすると、セーブされていない進行状況は失われます。\nロードしますか？"

    # renpy/common/00gui.rpy:452
    old "Are you sure you want to quit?"
    new "終了しますか？"

    # renpy/common/00gui.rpy:453
    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "メインメニューに戻りますか？\nセーブされていない進行状況は失われます。"

    # renpy/common/00gui.rpy:454
    old "Are you sure you want to continue where you left off?"
    new "続きから開始しますか"

    # renpy/common/00gui.rpy:455
    old "Are you sure you want to end the replay?"
    new "リプレイを終了しますか？"

    # renpy/common/00gui.rpy:456
    old "Are you sure you want to begin skipping?"
    new "スキップを開始しますか？"

    # renpy/common/00gui.rpy:457
    old "Are you sure you want to skip to the next choice?"
    new "次の選択肢までスキップしますか？"

    # renpy/common/00gui.rpy:458
    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "次の選択肢まで、未読テキストをスキップしますか？"

    # renpy/common/00gui.rpy:459
    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "このセーブデータは、別のデバイスで作成されたものです。悪意を持って作成されたセーブデータは、あなたのコンピューターに害を及ぼす可能性があります。このセーブデータの作成者と、セーブデータを変更した可能性のあるすべての人を信用しますか？"

    # renpy/common/00gui.rpy:460
    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "セーブデータが作成されたデバイスを信頼しますか？あなたがそのデバイスの唯一のユーザーである場合のみ、「はい」を選択するべきです。"

    # renpy/common/00keymap.rpy:325
    old "Failed to save screenshot as %s."
    new "ファイル名 %s のスクリーンショットの保存に失敗しました。"

    # renpy/common/00keymap.rpy:346
    old "Saved screenshot as %s."
    new "スクリーンショットを %s に保存しました。"

    # renpy/common/00library.rpy:257
    old "Skip Mode"
    new "スキップモード"

    # renpy/common/00library.rpy:344
    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "本プログラムは、MIT License や GNU Lesser General Public License など、様々なライセンスのフリーウェアを含んでいます。 フルソースコードへのリンクを含む、完全なソフトウェアのリストは、{a=https://www.renpy.org/l/license}ここ{/a}にあります。"

    # renpy/common/00preferences.rpy:295
    old "display"
    new "表示"

    # renpy/common/00preferences.rpy:315
    old "transitions"
    new "トランジション"

    # renpy/common/00preferences.rpy:324
    old "skip transitions"
    new "トランジションをスキップ"

    # renpy/common/00preferences.rpy:326
    old "video sprites"
    new "ビデオ スプライト"

    # renpy/common/00preferences.rpy:335
    old "show empty window"
    new "空のウィンドウを表示"

    # renpy/common/00preferences.rpy:344
    old "text speed"
    new "テキストスピード"

    # renpy/common/00preferences.rpy:352
    old "joystick"
    new "ジョイスティック"

    # renpy/common/00preferences.rpy:352
    old "joystick..."
    new "ジョイスティック..."

    # renpy/common/00preferences.rpy:359
    old "skip"
    new "スキップ"

    # renpy/common/00preferences.rpy:362
    old "skip unseen [text]"
    new "未読の[text]をスキップ"

    # renpy/common/00preferences.rpy:367
    old "skip unseen text"
    new "未読のテキストをスキップ"

    # renpy/common/00preferences.rpy:369
    old "begin skipping"
    new "スキップ開始"

    # renpy/common/00preferences.rpy:373
    old "after choices"
    new "選択肢後"

    # renpy/common/00preferences.rpy:380
    old "skip after choices"
    new "選択肢後もスキップ"

    # renpy/common/00preferences.rpy:382
    old "auto-forward time"
    new "オート待ち時間"

    # renpy/common/00preferences.rpy:396
    old "auto-forward"
    new "オート送り"

    # renpy/common/00preferences.rpy:403
    old "Auto forward"
    new "オート送り"

    # renpy/common/00preferences.rpy:406
    old "auto-forward after click"
    new "クリック後もオート"

    # renpy/common/00preferences.rpy:415
    old "automatic move"
    new "自動ムービー"

    # renpy/common/00preferences.rpy:424
    old "wait for voice"
    new "ボイスを待つ"

    # renpy/common/00preferences.rpy:433
    old "voice sustain"
    new "ボイスの持続"

    # renpy/common/00preferences.rpy:442
    old "self voicing"
    new "セルフボイシング"

    # renpy/common/00preferences.rpy:445
    old "self voicing enable"
    new "セルフボイシング有効化"

    # renpy/common/00preferences.rpy:447
    old "self voicing disable"
    new "セルフボイシング無効化"

    # renpy/common/00preferences.rpy:451
    old "self voicing volume drop"
    new "セルフボイシングボリュームを下げる"

    # renpy/common/00preferences.rpy:459
    old "clipboard voicing"
    new "クリップボードボイシング"

    # renpy/common/00preferences.rpy:462
    old "clipboard voicing enable"
    new "クリップボードボイシング有効化"

    # renpy/common/00preferences.rpy:464
    old "clipboard voicing disable"
    new "クリップボードボイシング無効化"

    # renpy/common/00preferences.rpy:468
    old "debug voicing"
    new "ボイシングのデバッグ"

    # renpy/common/00preferences.rpy:471
    old "debug voicing enable"
    new "デバックボイシング有効化"

    # renpy/common/00preferences.rpy:473
    old "debug voicing disable"
    new "デバックボイシング無効化"

    # renpy/common/00preferences.rpy:477
    old "emphasize audio"
    new "オーディオの強調"

    # renpy/common/00preferences.rpy:486
    old "rollback side"
    new "ロールバックサイド"

    # renpy/common/00preferences.rpy:496
    old "gl powersave"
    new "ＧＬパワーセーブ"

    # renpy/common/00preferences.rpy:502
    old "gl framerate"
    new "ＧＬフレームレート"

    # renpy/common/00preferences.rpy:505
    old "gl tearing"
    new "ＧＬティアリング"

    # renpy/common/00preferences.rpy:508
    old "font transform"
    new "フォント変換"

    # renpy/common/00preferences.rpy:511
    old "font size"
    new "フォントサイズ"

    # renpy/common/00preferences.rpy:519
    old "font line spacing"
    new "フォントの行間"

    # renpy/common/00preferences.rpy:527
    old "system cursor"
    new "システムカーソル"

    # renpy/common/00preferences.rpy:536
    old "renderer menu"
    new "レンダーメニュー"

    # renpy/common/00preferences.rpy:539
    old "accessibility menu"
    new "アクセシビリティーメニュー"

    # renpy/common/00preferences.rpy:542
    old "high contrast text"
    new "ハイコントラストテキスト"

    # renpy/common/00preferences.rpy:551
    old "audio when minimized"
    new "最小化時音声"

    # renpy/common/00preferences.rpy:560
    old "audio when unfocused"
    new "バックグラウンドでの音声"

    # renpy/common/00preferences.rpy:569
    old "web cache preload"
    new "ウェブキャッシュプリロード"

    # renpy/common/00preferences.rpy:584
    old "voice after game menu"
    new "ゲームメニュー後のボイス"

    # renpy/common/00preferences.rpy:593
    old "restore window position"
    new "ウィンドウ位置を復元する"

    # renpy/common/00preferences.rpy:602
    old "mono audio"
    new "モノラル音声"

    # renpy/common/00preferences.rpy:611
    old "font kerning"
    new "フォントのカーニング"

    # renpy/common/00preferences.rpy:619
    old "reset"
    new "リセット"

    # renpy/common/00preferences.rpy:632
    old "main volume"
    new "メインの音量"

    # renpy/common/00preferences.rpy:633
    old "music volume"
    new "音楽の音量"

    # renpy/common/00preferences.rpy:634
    old "sound volume"
    new "効果音の音量"

    # renpy/common/00preferences.rpy:635
    old "voice volume"
    new "ボイスの音量"

    # renpy/common/00preferences.rpy:636
    old "mute main"
    new "メインをミュート"

    # renpy/common/00preferences.rpy:637
    old "mute music"
    new "音楽をミュート"

    # renpy/common/00preferences.rpy:638
    old "mute sound"
    new "効果音をミュート"

    # renpy/common/00preferences.rpy:639
    old "mute voice"
    new "ボイスをミュート"

    # renpy/common/00preferences.rpy:640
    old "mute all"
    new "音声を全てミュート"

    # renpy/common/00preferences.rpy:723
    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "クリップボードボイシングを有効化しました。 'shift+C'で無効化します。"

    # renpy/common/00preferences.rpy:725
    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "セルフボイシングは次のように話します。 \"[renpy.display.tts.last]\". 'alt+shift+V' で無効化します。"

    # renpy/common/00preferences.rpy:727
    old "Self-voicing enabled. Press 'v' to disable."
    new "セルフボイシングを有効化しました。 'v' で無効化します。"

    # renpy/common/00speechbubble.rpy:420
    old "Speech Bubble Editor"
    new "スピーチバブルエディター"

    # renpy/common/00speechbubble.rpy:425
    old "(hide)"
    new "(非表示)"

    # renpy/common/00speechbubble.rpy:436
    old "(clear retained bubbles)"
    new "(保持されている吹き出しをクリアします)"

    # renpy/common/00sync.rpy:70
    old "Sync downloaded."
    new "同期をダウンロードしました。"

    # renpy/common/00sync.rpy:184
    old "Could not connect to the Ren'Py Sync server."
    new "Ren'Py Syncサーバーに接続できませんでした。"

    # renpy/common/00sync.rpy:186
    old "The Ren'Py Sync server timed out."
    new "Ren'Py Syncサーバーがタイムアウトしました。"

    # renpy/common/00sync.rpy:188
    old "An unknown error occurred while connecting to the Ren'Py Sync server."
    new "Ren'Py Syncサーバーへの接続中に不明なエラーが発生しました。"

    # renpy/common/00sync.rpy:204
    old "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."
    new "Ren'Py Syncサーバーに、この同期のコピーがありません。同期IDが無効であるか、タイムアウトした可能性があります。"

    # renpy/common/00sync.rpy:305
    old "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."
    new "生成した同期IDを入力してください。\n自分で作成したものでない同期IDは絶対に入力しないでください。"

    # renpy/common/00sync.rpy:324
    old "The sync ID is not in the correct format."
    new "同期IDが正しい形式ではありません。"

    # renpy/common/00sync.rpy:344
    old "The sync could not be decrypted."
    new "同期を復号化することができませんでした。"

    # renpy/common/00sync.rpy:367
    old "The sync belongs to a different game."
    new "同期は別のゲームに属しています。"

    # renpy/common/00sync.rpy:372
    old "The sync contains a file with an invalid name."
    new "同期に不正な名前のファイルが含まれています。"

    # renpy/common/00sync.rpy:425
    old "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"
    new "これは、{a=https://sync.renpy.org}Ren'Py Sync Server{/a} にセーブをアップロードします。\n続けますか？"

    # renpy/common/00sync.rpy:457
    old "Enter Sync ID"
    new "同期IDを入力する"

    # renpy/common/00sync.rpy:468
    old "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."
    new "これは、{a=https://sync.renpy.org}Ren'Py Sync Server{/a} に連絡します。"

    # renpy/common/00sync.rpy:498
    old "Sync Success"
    new "同期成功"

    # renpy/common/00sync.rpy:501
    old "The Sync ID is:"
    new "同期IDは"

    # renpy/common/00sync.rpy:507
    old "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."
    new "このIDを使って、セーブデータを別の端末でダウンロードすることができます。\nこの同期は1時間後に期限切れとなります。\nRen'Py Sync は{a=https://www.renpy.org/sponsors.html}Ren'Py のスポンサー{/a} によってサポートされています。"

    # renpy/common/00sync.rpy:511
    old "Continue"
    new "続ける"

    # renpy/common/00sync.rpy:536
    old "Sync Error"
    new "同期エラー"

    # renpy/common/00translation.rpy:63
    old "Translation identifier: [identifier]"
    new "翻訳ID：[identifier]"

    # renpy/common/00translation.rpy:84
    old " translates [tl.filename]:[tl.linenumber]"
    new "翻訳元 [tl.filename]:[tl.linenumber]"

    # renpy/common/00translation.rpy:101
    old "\n{color=#fff}Copied to clipboard.{/color}"
    new "\n{color=#fff}クリップボードにコピーしました。{/color}"

    # renpy/common/00iap.rpy:231
    old "Contacting App Store\nPlease Wait..."
    new "App Store にコンタクトしています。\nしばらくお待ちください…"

    # renpy/common/00updater.rpy:415
    old "No update methods found."
    new "update メソッドが見付かりません"

    # renpy/common/00updater.rpy:462
    old "Could not download file list: "
    new "ファイルリストがダウンロードできません : "

    # renpy/common/00updater.rpy:465
    old "File list digest does not match."
    new "File listの要約がマッチしません"

    # renpy/common/00updater.rpy:675
    old "An error is being simulated."
    new "エラーがシミュレートされました。"

    # renpy/common/00updater.rpy:863
    old "Either this project does not support updating, or the update status file was deleted."
    new "このプロジェクトはアップデートをサポートしていないか、アップデート用のファイルが削除されています。"

    # renpy/common/00updater.rpy:877
    old "This account does not have permission to perform an update."
    new "このアカウントにはアップデート処理の権限がありません。"

    # renpy/common/00updater.rpy:880
    old "This account does not have permission to write the update log."
    new "このアカウントにはアップデートログを記録する権限がありません。"

    # renpy/common/00updater.rpy:966
    old "Could not verify update signature."
    new "アップデートシグネチャーを認証出来ません。"

    # renpy/common/00updater.rpy:1289
    old "The update file was not downloaded."
    new "アップデートファイルをダウンロードできませんでした。"

    # renpy/common/00updater.rpy:1307
    old "The update file does not have the correct digest - it may have been corrupted."
    new "アップデートファイルは正しい digest を持っていません - 破損の可能性がありまます。"

    # renpy/common/00updater.rpy:1457
    old "While unpacking {}, unknown type {}."
    new "{} を解凍中に、未知のタイプ {} を検出しました。"

    # renpy/common/00updater.rpy:1928
    old "Updater"
    new "アップデーター"

    # renpy/common/00updater.rpy:1935
    old "An error has occurred:"
    new "エラーが発生しました："

    # renpy/common/00updater.rpy:1937
    old "Checking for updates."
    new "アップデートを確認しています。"

    # renpy/common/00updater.rpy:1939
    old "This program is up to date."
    new "このプログラムは最新の状態です。"

    # renpy/common/00updater.rpy:1941
    old "[u.version] is available. Do you want to install it?"
    new "[u.version] が利用可能です。インストールしますか？"

    # renpy/common/00updater.rpy:1943
    old "Preparing to download the updates."
    new "ダウンロードする準備をしています。"

    # renpy/common/00updater.rpy:1945
    old "Downloading the updates."
    new "アップデートをダウンロードしています。"

    # renpy/common/00updater.rpy:1947
    old "Unpacking the updates."
    new "アップデートを展開しています。"

    # renpy/common/00updater.rpy:1949
    old "Finishing up."
    new "完了処理中です。"

    # renpy/common/00updater.rpy:1951
    old "The updates have been installed. The program will restart."
    new "アップデートをインストールしました。プログラムを再起動します。"

    # renpy/common/00updater.rpy:1953
    old "The updates have been installed."
    new "アップデートが完了しました。"

    # renpy/common/00updater.rpy:1955
    old "The updates were cancelled."
    new "アップデートをキャンセルしました。"

    # renpy/common/00updater.rpy:1970
    old "Proceed"
    new "続行"

    # renpy/common/00updater.rpy:1986
    old "Preparing to download the game data."
    new "ゲームデータのダウンロードを準備します。"

    # renpy/common/00updater.rpy:1988
    old "Downloading the game data."
    new "ゲームデータをダウンロードしています"

    # renpy/common/00updater.rpy:1990
    old "The game data has been downloaded."
    new "ゲームデータがダウンロードされました"

    # renpy/common/00updater.rpy:1992
    old "An error occurred when trying to download game data:"
    new "ゲームデータダウンロード中にエラーが発生しました:"

    # renpy/common/00updater.rpy:1997
    old "This game cannot be run until the game data has been downloaded."
    new "このゲームはゲームデータのダウンロードまでは実行できません"

    # renpy/common/00updater.rpy:2004
    old "Retry"
    new "リトライ"

    # renpy/common/00gallery.rpy:676
    old "Image [index] of [count] locked."
    new "画像 [index] / [count] はロックされています。"

    # renpy/common/00gallery.rpy:696
    old "prev"
    new "前へ"

    # renpy/common/00gallery.rpy:697
    old "next"
    new "次へ"

    # renpy/common/00gallery.rpy:698
    old "slideshow"
    new "スライドショー"

    # renpy/common/00gallery.rpy:699
    old "return"
    new "戻る"

    # renpy/common/00gltest.rpy:89
    old "Renderer"
    new "レンダラー"

    # renpy/common/00gltest.rpy:91
    old "Automatically Choose"
    new "自動選択"

    # renpy/common/00gltest.rpy:96
    old "Force GL2 Renderer"
    new "GL2レンダラーを強制"

    # renpy/common/00gltest.rpy:101
    old "Force ANGLE2 Renderer"
    new "ANGLE2レンダラーを強制"

    # renpy/common/00gltest.rpy:106
    old "Force GLES2 Renderer"
    new "GLES2レンダラーを強制"

    # renpy/common/00gltest.rpy:112
    old "Enable (No Blocklist)"
    new "有効（ブロックリストなし）"

    # renpy/common/00gltest.rpy:135
    old "Powersave"
    new "省電力"

    # renpy/common/00gltest.rpy:145
    old "Framerate"
    new "フレームレート"

    # renpy/common/00gltest.rpy:147
    old "Screen"
    new "画面"

    # renpy/common/00gltest.rpy:151
    old "60"
    new "60"

    # renpy/common/00gltest.rpy:155
    old "30"
    new "30"

    # renpy/common/00gltest.rpy:159
    old "Tearing"
    new "ティアリング"

    # renpy/common/00gltest.rpy:171
    old "Changes will take effect the next time this program is run."
    new "変更は、次にこのプログラムを起動したときに反映されます。"

    # renpy/common/00gltest.rpy:207
    old "Performance Warning"
    new "パフォーマンスの警告"

    # renpy/common/00gltest.rpy:212
    old "This computer is using software rendering."
    new "このコンピューターはソフトウェアレンダリングを使用しています。"

    # renpy/common/00gltest.rpy:214
    old "This game requires use of GL2 that can't be initialised."
    new "このゲームにはGL2が必要ですが、初期化できませんでした。"

    # renpy/common/00gltest.rpy:216
    old "This computer has a problem displaying graphics: [problem]."
    new "このコンピューターはグラフィックの表示に問題があります：[problem]。"

    # renpy/common/00gltest.rpy:220
    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "グラフィックドライバーが古いか、正しく動作していない可能性があります。グラフィックの表示が遅くなったり、正しく表示されなかったりすることがあります。"

    # renpy/common/00gltest.rpy:224
    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new "{a=edit:1:log.txt}log.txt{/a}ファイルに、コンピューターの問題を特定するのに役立つ情報が含まれている場合があります。"

    # renpy/common/00gltest.rpy:229
    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new "修正方法の詳細は{a=[url]}ドキュメント{/a}をご覧ください。"

    # renpy/common/00gltest.rpy:234
    old "Continue, Show this warning again"
    new "続行（次回もこの警告を表示する）"

    # renpy/common/00gltest.rpy:238
    old "Continue, Don't show warning again"
    new "続行（今後この警告を表示しない）"

    # renpy/common/00gltest.rpy:246
    old "Change render options"
    new "描画設定を変更"

    # renpy/common/00gamepad.rpy:33
    old "Select Gamepad to Calibrate"
    new "キャリブレーションするゲームパッドを選択"

    # renpy/common/00gamepad.rpy:36
    old "No Gamepads Available"
    new "利用できるゲームパッドがありません"

    # renpy/common/00gamepad.rpy:56
    old "Calibrating [name] ([i]/[total])"
    new "[name]をキャリブレーション中（[i]/[total]）"

    # renpy/common/00gamepad.rpy:60
    old "Press or move the '[control!s]' [kind]."
    new "「[control!s]」[kind]を押すか、動かしてください。"

    # renpy/common/00gamepad.rpy:70
    old "Skip (A)"
    new "スキップ（A）"

    # renpy/common/00gamepad.rpy:73
    old "Back (B)"
    new "戻る（B）"

    # renpy/common/_errorhandling.rpym:757
    old "Open"
    new "開く"

    # renpy/common/_errorhandling.rpym:759
    old "Opens the traceback.txt file in a text editor."
    new "traceback.txtファイルをテキストエディターで開きます。"

    # renpy/common/_errorhandling.rpym:761
    old "Copy BBCode"
    new "BBCodeをコピー"

    # renpy/common/_errorhandling.rpym:763
    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "traceback.txtファイルを、https://lemmasoft.renai.us/ などのフォーラム向けにBBCode形式でクリップボードにコピーします。"

    # renpy/common/_errorhandling.rpym:765
    old "Copy Markdown"
    new "Markdownをコピー"

    # renpy/common/_errorhandling.rpym:767
    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "traceback.txtファイルを、Discord向けにMarkdown形式でクリップボードにコピーします。"

    # renpy/common/_errorhandling.rpym:799
    old "An exception has occurred."
    new "例外が発生しました。"

    # renpy/common/_errorhandling.rpym:828
    old "Rollback"
    new "ロールバック"

    # renpy/common/_errorhandling.rpym:830
    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "以前の時点へのロールバックを試み、セーブしたり別の選択肢を選んだりできるようにします。"

    # renpy/common/_errorhandling.rpym:833
    old "Ignore"
    new "無視"

    # renpy/common/_errorhandling.rpym:837
    old "Ignores the exception, allowing you to continue."
    new "例外を無視して続行します。"

    # renpy/common/_errorhandling.rpym:839
    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "例外を無視して続行します。多くの場合、さらにエラーが発生します。"

    # renpy/common/_errorhandling.rpym:843
    old "Reload"
    new "リロード"

    # renpy/common/_errorhandling.rpym:845
    old "Reloads the game from disk, saving and restoring game state if possible."
    new "ディスクからゲームを再読み込みします。可能であればゲームの状態を保存し、復元します。"

    # renpy/common/_errorhandling.rpym:848
    old "Console"
    new "コンソール"

    # renpy/common/_errorhandling.rpym:850
    old "Opens a console to allow debugging the problem."
    new "問題をデバッグするためのコンソールを開きます。"

    # renpy/common/_errorhandling.rpym:863
    old "Quits the game."
    new "ゲームを終了します。"

    # renpy/common/_errorhandling.rpym:885
    old "Parsing the script failed."
    new "スクリプトの解析に失敗しました。"

