# TODO: Translation updated at 2026-10-11 10:23

translate japanese strings:

    # game/screens.rpy:249
    old "Back"
    new "戻る"

    # game/screens.rpy:250
    old "Notebook"
    new "手帳"

    # game/screens.rpy:251
    old "Board •"
    new "ボード •"

    # game/screens.rpy:251
    old "Board"
    new "ボード"

    # game/screens.rpy:252
    old "History"
    new "履歴"

    # game/screens.rpy:253
    old "Skip"
    new "スキップ"

    # game/screens.rpy:254
    old "Auto"
    new "オート"

    # game/screens.rpy:255
    old "Save"
    new "セーブ"

    # game/screens.rpy:256
    old "Q.Save"
    new "Qセーブ"

    # game/screens.rpy:257
    old "Q.Load"
    new "Qロード"

    # game/screens.rpy:258
    old "Prefs"
    new "設定"

    # game/screens.rpy:304
    old "Begin"
    new "はじめる"

    # game/screens.rpy:306
    old "Chapters"
    new "チャプター"

    # game/screens.rpy:308
    old "Gallery"
    new "ギャラリー"

    # game/screens.rpy:318
    old "Load"
    new "ロード"

    # game/screens.rpy:320
    old "Preferences"
    new "設定"

    # game/screens.rpy:324
    old "End Replay"
    new "リプレイ終了"

    # game/screens.rpy:328
    old "Main Menu"
    new "メインメニュー"

    # game/screens.rpy:330
    old "About"
    new "作品情報"

    # game/screens.rpy:335
    old "Help"
    new "ヘルプ"

    # game/screens.rpy:340
    old "Quit"
    new "終了"

    # game/screens.rpy:494
    old "Return"
    new "戻る"

    # game/screens.rpy:579
    old "Version [config.version!t]\n"
    new "バージョン [config.version!t]\n"

    # game/screens.rpy:585
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "{a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only] で制作されています。\n\n[renpy.license!t]"

    # game/screens.rpy:621
    old "Page {}"
    new "{}ページ"

    # game/screens.rpy:621
    old "Automatic saves"
    new "オートセーブ"

    # game/screens.rpy:621
    old "Quick saves"
    new "クイックセーブ"

    # game/screens.rpy:663
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%Y年%m月%d日 %H:%M"

    # game/screens.rpy:663
    old "empty slot"
    new "空きスロット"

    # game/screens.rpy:683
    old "<"
    new "<"

    # game/screens.rpy:687
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:690
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/screens.rpy:696
    old ">"
    new ">"

    # game/screens.rpy:701
    old "Upload Sync"
    new "同期をアップロード"

    # game/screens.rpy:705
    old "Download Sync"
    new "同期をダウンロード"

    # game/screens.rpy:765
    old "Display"
    new "画面モード"

    # game/screens.rpy:766
    old "Window"
    new "ウィンドウ"

    # game/screens.rpy:767
    old "Fullscreen"
    new "全画面"

    # game/screens.rpy:772
    old "Unseen Text"
    new "未読も"

    # game/screens.rpy:773
    old "After Choices"
    new "選択後も"

    # game/screens.rpy:774
    old "Transitions"
    new "画面効果"

    # game/screens.rpy:778
    old "Content"
    new "表現"

    # game/screens.rpy:779
    old "Standard"
    new "標準"

    # game/screens.rpy:780
    old "Mature 18+"
    new "成人向け 18+"

    # game/screens.rpy:780
    old "Mature mode shows graphic imagery of the adult characters' deaths.\nConfirm you are 18 or older."
    new "成人向けモードでは、大人の登場人物の死が生々しい画像で表示されます。\n18歳以上であることを確認してください。"

    # game/screens.rpy:793
    old "Text Speed"
    new "文字速度"

    # game/screens.rpy:797
    old "Auto-Forward Time"
    new "オート待ち時間"

    # game/screens.rpy:804
    old "Music Volume"
    new "音楽の音量"

    # game/screens.rpy:811
    old "Sound Volume"
    new "効果音の音量"

    # game/screens.rpy:817
    old "Test"
    new "テスト"

    # game/screens.rpy:821
    old "Voice Volume"
    new "ボイスの音量"

    # game/screens.rpy:832
    old "Mute All"
    new "すべてミュート"

    # game/screens.rpy:950
    old "The dialogue history is empty."
    new "会話履歴はありません。"

    # game/screens.rpy:1019
    old "Keyboard"
    new "キーボード"

    # game/screens.rpy:1020
    old "Mouse"
    new "マウス"

    # game/screens.rpy:1023
    old "Gamepad"
    new "ゲームパッド"

    # game/screens.rpy:1036
    old "Enter"
    new "Enter"

    # game/screens.rpy:1037
    old "Advances dialogue and activates the interface."
    new "会話を進め、インターフェースを操作します。"

    # game/screens.rpy:1040
    old "Space"
    new "Space"

    # game/screens.rpy:1041
    old "Advances dialogue without selecting choices."
    new "選択肢を選ばずに会話を進めます。"

    # game/screens.rpy:1044
    old "Arrow Keys"
    new "矢印キー"

    # game/screens.rpy:1045
    old "Navigate the interface."
    new "インターフェースを移動します。"

    # game/screens.rpy:1048
    old "Escape"
    new "Escape"

    # game/screens.rpy:1049
    old "Accesses the game menu."
    new "ゲームメニューを開きます。"

    # game/screens.rpy:1052
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1053
    old "Skips dialogue while held down."
    new "押している間、会話をスキップします。"

    # game/screens.rpy:1056
    old "Tab"
    new "Tab"

    # game/screens.rpy:1057
    old "Toggles dialogue skipping."
    new "会話スキップのオン／オフを切り替えます。"

    # game/screens.rpy:1060
    old "Page Up"
    new "Page Up"

    # game/screens.rpy:1061
    old "Rolls back to earlier dialogue."
    new "前の会話に戻ります。"

    # game/screens.rpy:1064
    old "Page Down"
    new "Page Down"

    # game/screens.rpy:1065
    old "Rolls forward to later dialogue."
    new "後の会話に進みます。"

    # game/screens.rpy:1069
    old "Hides the user interface."
    new "ユーザーインターフェースを隠します。"

    # game/screens.rpy:1073
    old "Takes a screenshot."
    new "スクリーンショットを撮ります。"

    # game/screens.rpy:1077
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "支援機能の{a=https://www.renpy.org/l/voicing}セルフボイシング{/a}を切り替えます。"

    # game/screens.rpy:1081
    old "Opens the accessibility menu."
    new "アクセシビリティメニューを開きます。"

    # game/screens.rpy:1087
    old "Left Click"
    new "左クリック"

    # game/screens.rpy:1091
    old "Middle Click"
    new "中クリック"

    # game/screens.rpy:1095
    old "Right Click"
    new "右クリック"

    # game/screens.rpy:1099
    old "Mouse Wheel Up"
    new "マウスホイール上"

    # game/screens.rpy:1103
    old "Mouse Wheel Down"
    new "マウスホイール下"

    # game/screens.rpy:1110
    old "Right Trigger\nA/Bottom Button"
    new "右トリガー\nA／下ボタン"

    # game/screens.rpy:1114
    old "Left Trigger\nLeft Shoulder"
    new "左トリガー\n左ショルダー"

    # game/screens.rpy:1118
    old "Right Shoulder"
    new "右ショルダー"

    # game/screens.rpy:1122
    old "D-Pad, Sticks"
    new "十字キー、スティック"

    # game/screens.rpy:1126
    old "Start, Guide, B/Right Button"
    new "スタート、ガイド、B／右ボタン"

    # game/screens.rpy:1130
    old "Y/Top Button"
    new "Y／上ボタン"

    # game/screens.rpy:1133
    old "Calibrate"
    new "キャリブレーション"

    # game/screens.rpy:1198
    old "Yes"
    new "はい"

    # game/screens.rpy:1199
    old "No"
    new "いいえ"

    # game/screens.rpy:1245
    old "Skipping"
    new "スキップ中"

    # game/screens.rpy:1559
    old "Menu"
    new "メニュー"

# TODO: Translation updated at 2026-10-11 10:28

translate japanese strings:

    # game/screens.rpy:784
    old "Language"
    new "言語"

# TODO: Translation updated at 2026-10-11 11:00

translate japanese strings:

    # game/screens.rpy:415
    old "a visual novel after the book by A. Damon"
    new "A. Damonの小説を原作とするビジュアルノベル"

