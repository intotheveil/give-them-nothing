# TODO: Translation updated at 2026-10-11 10:23

translate japanese strings:

    # game/options.rpy:17
    old "Give Them Nothing"
    new "Give Them Nothing"

    # game/options.rpy:34
    old "Adapted from the novel {i}Give Them Nothing{/i} by A. Damon.\n\nOriginal score composed for this adaptation. Fonts: Crimson Text, Cormorant Garamond, Cinzel (SIL Open Font License)."
    new "A. Damonの小説『{i}Give Them Nothing{/i}』を原作とする。\n\n音楽は本作のために作曲されたオリジナル・スコア。フォント：Crimson Text、Cormorant Garamond、Cinzel（SIL Open Font License）。"

# TODO: Translation updated at 2026-10-11 10:44

translate japanese strings:

    # game/options.rpy:34
    old "Adapted from the novel {i}Give Them Nothing{/i} by A. Damon.\n\nOriginal score composed for this adaptation. Fonts: Crimson Text, Cormorant Garamond, Cinzel, Noto Serif JP (SIL Open Font License)."
    new "A. Damonの小説『{i}Give Them Nothing{/i}』を原作とする。\n\n音楽は本作のために作曲されたオリジナル・スコア。フォント：Crimson Text、Cormorant Garamond、Cinzel、Noto Serif JP（SIL Open Font License）。"

