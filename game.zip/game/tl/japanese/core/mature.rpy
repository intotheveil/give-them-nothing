# TODO: Translation updated at 2026-10-11 10:23

translate japanese strings:

    # game/core/mature.rpy:76
    old "Mature — I am 18 or older"
    new "成人向け ― 18歳以上です"

